PSR (Performance Scalability & Reliability) 

PSR - Performance, Scalability & Reliability Team at Vlocity is focused on strategising performance engineering efforts that are designed and focused on improving and optimising performance for products built at Vlocity and ensure customer success by certifying their scalability for customer environments. 
This is the central repository for all the tools and frameworks used by PSR team.


