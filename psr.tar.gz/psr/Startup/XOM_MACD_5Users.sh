mvn gatling:execute -X  -Dgatling.simulationClass=XOM_MACD.XOM_MACD_Scn  -DNormalflowRampup=120 -DNormalflowUsers=5 -DDeleteflowRampup=30 -DDeleteflowUsers=5 -DUpdateflowRampup=120 -DUpdateflowUsers=120 -DmaxDurationSecs=2000 -DMinWaitMs=15000 -DMaxWaitMs=20000 >testmacd_5Users.log
#-Druncurrtest="Deleteflow"
