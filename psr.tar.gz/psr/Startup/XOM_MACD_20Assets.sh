mvn gatling:execute -X  -Dgatling.simulationClass=XOM_MACD_20Assets.XOM_MACD_Scn_20Assets  -DNormalflowRampup=1220 -DNormalflowUsers=375 -DDeleteflowRampup=1220 -DDeleteflowUsers=375 -DUpdateflowRampup=1220 -DUpdateflowUsers=375 -DmaxDurationSecs=3020 -DMinWaitMs=15000 -DMaxWaitMs=20000 >testmacd_20assets.log
#-Druncurrtest="Deleteflow"
