mvn gatling:execute -X -Dgatling.simulationClass=CreateData.CreateData_Scn -DrampUpTimeSecs=40 -DnoOfUsers=40 -DmaxDurationSecs=300  > test.log
