mvn gatling:execute -X -Dgatling.simulationClass=HealthCheck.P3HealthCheck_Scn -DrampUpTimeSecs=1 -DnoOfUsers=1 -DmaxDurationSecs=1000 > perf3.log
mvn gatling:execute -X -Dgatling.simulationClass=HealthCheck.P2HealthCheck_Scn -DrampUpTimeSecs=1 -DnoOfUsers=1 -DmaxDurationSecs=1000 > perf2.log
