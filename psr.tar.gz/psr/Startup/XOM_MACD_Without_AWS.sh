mvn gatling:execute -X  -Dgatling.simulationClass=XOM_MACD_Without_AWS.XOM_MACD_Without_AWS_Scn  -DNormalflowRampup=160 -DNormalflowUsers=126 -DDeleteflowRampup=160 -DDeleteflowUsers=126 -DUpdateflowRampup=160 -DUpdateflowUsers=126 -DmaxDurationSecs=2000 -DMinWaitMs=15000 -DMaxWaitMs=20000 >testmacd_withoutaws.log
#-Druncurrtest="Deleteflow"
