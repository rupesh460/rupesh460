mvn gatling:execute -X  -Dgatling.simulationClass=XOM_SF.XOM_SF_Scn -DrampUpTimeSecs=900 -DNoofXOMusers=900 -DmaxDurationSecs=4500 -DMinWaitMs=15000 -DMaxWaitMs=20000 > test.log
