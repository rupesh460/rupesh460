

Startup Scripts (Maven Commands) :

For Only Anonymous Funnel Ratio - SF :

nohup mvn gatling:test -X -Dgatling.simulationClass=eComm_V106_Anonymous.eComm_SF_Scn -DminWaitMs=3000 -DmaxWaitMs=5000 -DSF_DC_Anon_Login=427 -DSF_DC_Anon_Login_RampUp=1800 -DSF_DC_Anon_ProductViews=118 -DSF_DC_Anon_ProductViews_RampUp=1800 -DSF_DC_Anon_AddToCart=40 -DSF_DC_Anon_AddToCart_RampUp=1800 -DSF_DC_Anon_CheckOut=15 -DSF_DC_Anon_CheckOut_RampUp=1800 -DmaxDurationSecs=5400 >/dev/null  2>&1 &

mvn gatling:test -X -Dgatling.simulationClass=eComm_V106_Anonymous.eComm_SF_Scn -DminWaitMs=3000 -DmaxWaitMs=5000 -DSF_DC_Anon_Login=427 -DSF_DC_Anon_Login_RampUp=1800 -DSF_DC_Anon_ProductViews=118 -DSF_DC_Anon_ProductViews_RampUp=1800 -DSF_DC_Anon_AddToCart=40 -DSF_DC_Anon_AddToCart_RampUp=1800 -DSF_DC_Anon_CheckOut=15 -DSF_DC_Anon_CheckOut_RampUp=1800 -DmaxDurationSecs=5400


For Only Anonymous Funnel Ratio - AWS :

 nohup mvn gatling:test -X -Dgatling.simulationClass=eComm_V106_Anonymous.eComm_AWS_Scn -DminWaitMs=2000 -DmaxWaitMs=4000 -DAWS_Anon_ProductViews=264  -DAWS_Anon_ProductViews_RampUp=1800 -DAWS_Anon_AddToCart=186 -DAWS_Anon_AddToCart_RampUp=1800 -DAWS_Anon_CheckOut=150 -DAWS_Anon_CheckOut_RampUp=1800 -DmaxDurationSecs=5400 >/dev/null  2>&1 &

 nohup mvn gatling:test -X -Dgatling.simulationClass=eComm_V106_Anonymous.eComm_AWS_Scn -DminWaitMs=2000 -DmaxWaitMs=4000 -DAWS_Anon_ProductViews=264  -DAWS_Anon_ProductViews_RampUp=1800 -DAWS_Anon_AddToCart=186 -DAWS_Anon_AddToCart_RampUp=1800 -DAWS_Anon_CheckOut=150 -DAWS_Anon_CheckOut_RampUp=1800 -DmaxDurationSecs=5400


For Anonymous and Loggedin Funnel Ratio - SF :

nohup mvn gatling:test -X -Dgatling.simulationClass=eComm_V106_Anon_loggedin.eComm_SF_Scn -DminWaitMs=3000 -DmaxWaitMs=5000 -DSF_DC_Anon_Login=427 -DSF_DC_Anon_Login_RampUp=1800 -DSF_DC_Anon_ProductViews=118 -DSF_DC_Anon_ProductViews_RampUp=1800 -DSF_DC_Anon_AddToCart=40 -DSF_DC_Anon_AddToCart_RampUp=1800 -DSF_DC_Anon_CheckOut=15 -DSF_DC_Anon_CheckOut_RampUp=1800 -DSF_DC_Loggedin_Login=427 -SF_DC_Loggedin_Login_RampUp=1800 -DSF_DC_Loggedin_ProductViews=118 -DSF_DC_Loggedin_ProductViews_RampUp=1800 -DSF_DC_Loggedin_AddToCart=40 -DSF_DC_Loggedin_AddToCart_RampUp=1800 -DSF_DC_Loggedin_CheckOut=15 -DSF_DC_Loggedin_CheckOut_RampUp=1800 -DmaxDurationSecs=5400 >/dev/null  2>&1 &

mvn gatling:test -X -Dgatling.simulationClass=eComm_V106_Anon_loggedin.eComm_SF_Scn -DminWaitMs=3000 -DmaxWaitMs=5000 -DSF_DC_Anon_Login=427 -DSF_DC_Anon_Login_RampUp=1800 -DSF_DC_Anon_ProductViews=118 -DSF_DC_Anon_ProductViews_RampUp=1800 -DSF_DC_Anon_AddToCart=40 -DSF_DC_Anon_AddToCart_RampUp=1800 -DSF_DC_Anon_CheckOut=15 -DSF_DC_Anon_CheckOut_RampUp=1800 -DSF_DC_Loggedin_Login=427 -SF_DC_Loggedin_Login_RampUp=1800 -DSF_DC_Loggedin_ProductViews=118 -DSF_DC_Loggedin_ProductViews_RampUp=1800 -DSF_DC_Loggedin_AddToCart=40 -DSF_DC_Loggedin_AddToCart_RampUp=1800 -DSF_DC_Loggedin_CheckOut=15 -DSF_DC_Loggedin_CheckOut_RampUp=1800 -DmaxDurationSecs=5400


For Anonymous and Loggedin Funnel Ratio - AWS :

nohup mvn gatling:test -X -Dgatling.simulationClass=eComm_V106_Anon_loggedin.eComm_AWS_Scn -DminWaitMs=2000 -DmaxWaitMs=4000 -DAWS_Anon_ProductViews=264  -DAWS_Anon_ProductViews_RampUp=1800 -DAWS_Anon_AddToCart=186 -DAWS_Anon_AddToCart_RampUp=1800 -DAWS_Anon_CheckOut=150 -DAWS_Anon_CheckOut_RampUp=1800 -DAWS_Loggedin_ProductViews=264  -DAWS_Loggedin_ProductViews_RampUp=1800 -DAWS_Loggedin_AddToCart=186 -DAWS_Loggedin_AddToCart_RampUp=1800 -DAWS_Loggedin_CheckOut=150 -DAWS_Loggedin_CheckOut_RampUp=1800 -DmaxDurationSecs=5400 >/dev/null  2>&1 &

mvn gatling:test -X -Dgatling.simulationClass=eComm_V106_Anon_loggedin.eComm_AWS_Scn -DminWaitMs=2000 -DmaxWaitMs=4000 -DAWS_Anon_ProductViews=264  -DAWS_Anon_ProductViews_RampUp=1800 -DAWS_Anon_AddToCart=186 -DAWS_Anon_AddToCart_RampUp=1800 -DAWS_Anon_CheckOut=150 -DAWS_Anon_CheckOut_RampUp=1800 -DAWS_Loggedin_ProductViews=264  -DAWS_Loggedin_ProductViews_RampUp=1800 -DAWS_Loggedin_AddToCart=186 -DAWS_Loggedin_AddToCart_RampUp=1800 -DAWS_Loggedin_CheckOut=150 -DAWS_Loggedin_CheckOut_RampUp=1800 -DmaxDurationSecs=5400

For Loggedin Funnel Ratio - SF :

nohup mvn gatling:test -X -Dgatling.simulationClass=eComm_v106_loggedin.eComm_SF_Scn -DminWaitMs=3000 -DmaxWaitMs=5000 -DSF_DC_Loggedin_Login=427 -DSF_DC_Loggedin_Login_RampUp=1800 -DSF_DC_Loggedin_ProductViews=118 -DSF_DC_Loggedin_ProductViews_RampUp=1800 -DSF_DC_Loggedin_AddToCart=40 -DSF_DC_Loggedin_AddToCart_RampUp=1800 -DSF_DC_Loggedin_CheckOut=15 -DSF_DC_Loggedin_CheckOut_RampUp=1800 -DmaxDurationSecs=5400 >/dev/null  2>&1 &

For Loggedin Funnel Ratio - AWS :

nohup mvn gatling:test -X -Dgatling.simulationClass=eComm_v106_loggedin.eComm_AWS_Scn -DminWaitMs=2000 -DmaxWaitMs=4000 -DAWS_Loggedin_ProductViews=264  -DAWS_Loggedin_ProductViews_RampUp=1800 -DAWS_Loggedin_AddToCart=186 -DAWS_Loggedin_AddToCart_RampUp=1800 -DAWS_Loggedin_CheckOut=150 -DAWS_Loggedin_CheckOut_RampUp=1800 -DmaxDurationSecs=5400 >/dev/null  2>&1 &

For Cart Operations :

mvn gatling:test -X -Dgatling.simulationClass=eComm_Cart_Operations.eComm_SF_Scn -DminWaitMs=3000 -DmaxWaitMs=10000 -DeCommCartOperations_Users=1 -DeCommCartOperations_UsersRampUp_Time=10 -DtestDuration=600 -DmaxDurationSecs=500


For CK Generator :

mvn gatling:test -X -Dgatling.simulationClass=eComm_CK_generator.eComm_SF_Scn -DminWaitMs=3000 -DmaxWaitMs=10000 -DGenerate_CK_Test_Users=1 -DGenerate_CK_Test_Users_RampUp_Time=10 -DtestDuration=600 -DmaxDurationSecs=500


Project Related Wiki :

https://vlocity.atlassian.net/wiki/spaces/EP/pages/585696148/DC+APIs+-+V105+V106+Performance+Benchmark



