mvn gatling:execute -X  -Dgatling.simulationClass=XOM_MACD_OneAsset.XOM_MACD_Scn_OneAsset  -DNormalflowRampup=1320 -DNormalflowUsers=130 -DDeleteflowRampup=1320 -DDeleteflowUsers=165 -DUpdateflowRampup=1320 -DUpdateflowUsers=165 -DmaxDurationSecs=30120 -DMinWaitMs=15000 -DMaxWaitMs=20000 >testmacd.log
#-Druncurrtest="Deleteflow"
