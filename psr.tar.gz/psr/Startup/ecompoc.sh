mvn gatling:execute -X  -Dgatling.simulationClass=Ecom_POC.ecom_POC_Scn -DrampUpTimeSecs=100 -DNoofSFEcomusers=200 -DmaxDurationSecs=1000  > test.log
