mvn gatling:execute -X  -Dgatling.simulationClass=HCPQ.HCPQ_Scn -DrampUpTimeSecs=20 -DNoofORDCRTusers=5 -DmaxDurationSecs=1000  > test.log
