mvn gatling:execute -X  -Dgatling.simulationClass=OM_Standard.OM_Standard_Scn -DrampUpTimeSecs=150 -DNoofORDCRTusers=15 -DmaxDurationSecs=21750  > omstandard1200Longrun.log
