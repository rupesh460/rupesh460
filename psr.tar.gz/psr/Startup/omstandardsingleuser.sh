mvn gatling:execute -X  -Dgatling.simulationClass=OM_Standard.OM_Standard_Scn -DrampUpTimeSecs=1 -DNoofORDCRTusers=1 -DmaxDurationSecs=150  > omstandardsingleuser.log
