mvn gatling:execute -X  -Dgatling.simulationClass=XOM_Thor.XOM_Thor_Scn -DrampUpTimeSecs=30 -DNoofXOMusers=5 -DMinWaitMs=5000 -DMaxWaitMs=10000 -DmaxDurationSecs=930  > testneworder_5users.log


