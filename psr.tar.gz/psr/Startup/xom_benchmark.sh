mvn gatling:execute -X  -Dgatling.simulationClass=XOM_Benchmark.XOM_Benchmark_Scn -DrampUpTimeSecs=1 -DNoofXOMusers=1 -DmaxDurationSecs=700 >testxombenchmark.log
