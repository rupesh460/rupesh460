mvn gatling:execute -X  -Dgatling.simulationClass=XOM_MACD.XOM_MACD_Scn  -DNormalflowRampup=1 -DNormalflowUsers=1 -DDeleteflowRampup=2 -DDeleteflowUsers=1 -DUpdateflowRampup=3 -DUpdateflowUsers=1  -DmaxDurationSecs=930 -DMinWaitMs=15000 -DMaxWaitMs=20000 >testmacd_1User.log
#-Druncurrtest="Deleteflow"
