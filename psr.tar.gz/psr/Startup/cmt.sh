mvn gatling:test -X  -Dgatling.simulationClass=CMT.SKYPhase2ScaleTestScn -DrampUpTimeSecs=5  -DNoofORDCRTusers=1 -DNoofOrdPromoCRTusers=5 -DNoofPromoAdjUpdTypUsers=5 -DNoofPnltyRuFlUsers=5  -DmaxDurationSecs=1000 > test.log

#odin
mvn gatling:test -X -Dgatling.simulationClass=BMK_ODIN.BenchmarkOdin_Scn -DrampUpTimeSecs=10 -Dcpq_base_apis_users=0 -Dcpq_diff_cart_shapes_users=5 -DCop_Mobile_users=0 -DCop_Internet_users=0 -DmaxDurationSecs=100
