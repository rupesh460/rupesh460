mvn gatling:execute -X  -Dgatling.simulationClass=FGM.FGM_Scn -DrampUpTimeSecs=5  -DNoofORDCRTusers=1  -DmaxDurationSecs=400 > test.log
