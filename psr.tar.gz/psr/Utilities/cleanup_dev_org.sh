#!/bin/bash
# Scripts to clean  accounts, Orders, OrderItems, Asset after test
# Author:  sranjan@vlocity.com
# prerequisites : force client
############# How to Run the script ########
#sh cleanup_cmt_org.sh cmt_benchmark 2020-05-13T06:04:00.000Z 2020-05-13T11:04:00.000Z
####################################### environment details #######################################
#userName=perf-cmt-release-bmk@vlocity.com
#passWord=
#envtype=login
environment_Name=$1
startdate=$2
enddate=$3
environmentDetailsFile=resources/environmental_details.csv
###################################################################################################
envtype=`grep -w ${environment_Name} ${environmentDetailsFile}|awk -F "|" '{print $7}'`
userName=`grep -w ${environment_Name} ${environmentDetailsFile}|awk -F "|" '{print $2}'`
passWord_encoded=`grep -w ${environment_Name} ${environmentDetailsFile}|awk -F "|" '{print $3}'`
passWord=`echo $passWord_encoded| base64 --decode`

code1="for(Order o : oList)
{
    o.Status = 'Draft';
}
update oList;
delete oList;"

code2="delete aList;"
#check if force client binary  output folder if not present
if [ -e force ]
then
	./force login -i=${envtype} -u=${userName} -p=${passWord}
	./force query "SELECT Id FROM Account where CreatedDate > ${startdate} and CreatedDate < ${enddate}  order by CreatedDate desc" |sed -e 's/"//g'|sed 's/.000+0000//g' |sed 1d > account_ids.csv
	while read -r line;do
		echo "List<Order> oList = [SELECT Id, Status From Order where AccountId = '${line}'];" > test.apex
		echo "$code1" >> test.apex
		echo "List<Account> aList = [SELECT Id FROM Account where Id ='${line}'];" >> test.apex
		echo "$code2" >> test.apex
		./force apex test.apex
	done < "account_ids.csv"
else
	echo "Warning : force client is not present in current folder "
	echo "please download it from https://force-cli.heroku.com/  and save it in current folder, change permission to excecutable chmod 755 force"
	exit
fi
rm test.apex account_ids.csv
