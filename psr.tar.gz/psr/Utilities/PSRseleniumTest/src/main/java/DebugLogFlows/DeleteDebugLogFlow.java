package DebugLogFlows;

import org.testng.annotations.Test;
import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import org.openqa.selenium.JavascriptExecutor;
import org.apache.commons.lang3.time.StopWatch;
import org.influxdb.InfluxDB;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import Automation.seleniumtest.InfluxDBDAO;
import Automation.seleniumtest.Utilities;
import net.lightbody.bmp.BrowserMobProxyServer;
import java.text.SimpleDateFormat;  
import java.util.Date;  
import org.openqa.selenium.JavascriptExecutor;
import net.lightbody.bmp.mitm.manager.ImpersonatingMitmManager;
import net.lightbody.bmp.proxy.CaptureType;
import java.util.Random;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.NoSuchElementException;
import java.util.List;


public class DeleteDebugLogFlow {

	WebDriver driver = null;
	Utilities util = new Utilities();
	DeleteDebugLogFlow deleteDebugLogFlow;
	InfluxDBDAO conn = null;
	int iteration = 0;
	Properties prop = null;

	@BeforeTest
	public void beforeTest() throws IOException, InterruptedException {
		deleteDebugLogFlow = new DeleteDebugLogFlow();
		/*browserMobProxy = new BrowserMobProxyServer();
		browserMobProxy.setTrustAllServers(true);
		browserMobProxy.setMitmManager(ImpersonatingMitmManager.builder().trustAllServers(true).build());
		browserMobProxy.enableHarCaptureTypes(CaptureType.REQUEST_CONTENT, CaptureType.RESPONSE_CONTENT,
				CaptureType.RESPONSE_HEADERS);
		browserMobProxy.start(0); */
	//	System.out.println("Port Started On: " + browserMobProxy.getPort());

		conn = new InfluxDBDAO();
		//driver = Utilities.getDriver_CapProxyChrome();
		WebDriverManager.chromedriver().setup();
		ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.addArguments("--headless");
		chromeOptions.addArguments("--disable-gpu");
        driver = new ChromeDriver(chromeOptions);
		//driver = new ChromeDriver();
		


	}

	@Test
	public void test() throws IOException, InterruptedException {
		iteration++;
		WebDriver drivertest = null;
		drivertest = deleteDebugLogFlow.runTest(driver, iteration, conn);
	}


	public WebDriver runTest(WebDriver driver, int iteration, InfluxDBDAO conn)
			throws IOException, InterruptedException {

		
		Date now = new Date();
		StopWatch pageLoad = new StopWatch();
		WebDriverWait wait = new WebDriverWait(driver, 60);
		
		//String Password = util.decryptPassword();
		
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			driver.get("https://login.salesforce.com/");
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id='username']")).clear();
			driver.findElement(By.xpath("//*[@id='username']")).sendKeys("perf-cmt-automation@vlocity.com");
			driver.findElement(By.xpath("//*[@id='password']")).clear();
			driver.findElement(By.xpath("//*[@id='password']")).sendKeys("Market007");
			Thread.sleep(2000);

			// Login to Dashboard Page DashBoard Page
			pageLoad.start();
			driver.findElement(By.xpath("//*[@id='Login']")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("[title=\"Accounts Tab\"]")));
			pageLoad.stop();
			System.out.println("ORG_LogintoDashboard" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			//conn.writeData(influxDB, "ORG_LogintoDashboard", pageLoad.getTime(), "PSRDemo", iteration);
			
			
			Thread.sleep(10000);

			driver.findElement(By.xpath("//*[@id='setupSearch']")).click();
			driver.findElement(By.xpath("//*[@id='setupSearch']")).sendKeys(Keys.HOME, Keys.chord(Keys.SHIFT, Keys.END), "Debug");
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='ApexDebugLogs_font']")));
			Thread.sleep(10000);

			driver.findElement(By.xpath("//*[@id='ApexDebugLogs_font']")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(), 'Debug Logs')and contains(@class, 'pageType noSecondHeader')]")));
			
			Thread.sleep(10000);
			driver.findElement(By.xpath("//input[@name='Apex_Trace_List:traceForm:traceTable:j_id35:bottom:deleteAll']")).click();
			Thread.sleep(5000);
        	driver.findElement(By.xpath("//div[@id='userNavButton']")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("  //div[contains(@class,'navLinks')]//a[5]")).click();
			Thread.sleep(5000);
			System.out.println("Delete Debug Log Completed");
	


			
			return driver;
		
			}

				@AfterTest
				public void endTest() throws IOException {
					driver.quit();
				}

			}
			
