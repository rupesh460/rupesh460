package DebugLogFlows;

import org.testng.annotations.Test;
import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import org.openqa.selenium.JavascriptExecutor;
import org.apache.commons.lang3.time.StopWatch;
import org.influxdb.InfluxDB;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import Automation.seleniumtest.InfluxDBDAO;
import Automation.seleniumtest.Utilities;
import Automation.seleniumtest.SimpleGraphiteClient;
import net.lightbody.bmp.BrowserMobProxyServer;
import java.text.SimpleDateFormat;  
import java.util.Date;  
import org.openqa.selenium.JavascriptExecutor;
import net.lightbody.bmp.mitm.manager.ImpersonatingMitmManager;
import net.lightbody.bmp.proxy.CaptureType;
import java.util.Random;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.NoSuchElementException;
import java.util.List;
import java.io.DataOutputStream;
import java.net.Socket;


public class EnableDebugLogFlow {

	WebDriver driver = null;
	Utilities util = new Utilities();
	EnableDebugLogFlow enableDebugLogFlow;
	BrowserMobProxyServer browserMobProxy = null;
	InfluxDBDAO conn = null;
	int iteration = 0;
	Properties prop = null;
	SimpleGraphiteClient simpleGraphiteClient  = new SimpleGraphiteClient("10.1.240.150",2003);
	

	@BeforeTest
	public void beforeTest() throws IOException, InterruptedException {
		enableDebugLogFlow = new EnableDebugLogFlow();
		/*browserMobProxy = new BrowserMobProxyServer();
		browserMobProxy.setTrustAllServers(true);
		browserMobProxy.setMitmManager(ImpersonatingMitmManager.builder().trustAllServers(true).build());
		browserMobProxy.enableHarCaptureTypes(CaptureType.REQUEST_CONTENT, CaptureType.RESPONSE_CONTENT,
				CaptureType.RESPONSE_HEADERS);
		browserMobProxy.start(0); */
	//	System.out.println("Port Started On: " + browserMobProxy.getPort());

		conn = new InfluxDBDAO();
		//driver = Utilities.getDriver_CapProxyChrome();
		WebDriverManager.chromedriver().setup();
		ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.addArguments("--headless", "--disable-gpu", "--window-size=1920,1200","--ignore-certificate-errors");
        driver = new ChromeDriver(chromeOptions);
		//driver = new ChromeDriver();
		


	}

	@Test
	public void test() throws IOException, InterruptedException {
		iteration++;
		WebDriver drivertest = null;
		drivertest = enableDebugLogFlow.runTest(driver, iteration, conn);
	}


	public WebDriver runTest(WebDriver driver, int iteration, InfluxDBDAO conn)
			throws IOException, InterruptedException {

		
		Date now = new Date();
		StopWatch pageLoad = new StopWatch();
		WebDriverWait wait = new WebDriverWait(driver, 60);
		//GraphiteClient client = GraphiteClientFactory.defaultGraphiteClient("10.1.240.150", 2003);
		
		//String Password = util.decryptPassword();
		
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			driver.get("https://login.salesforce.com/");
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id='username']")).clear();
			driver.findElement(By.xpath("//*[@id='username']")).sendKeys("perf-cmt-automation@vlocity.com");
			driver.findElement(By.xpath("//*[@id='password']")).clear();
			driver.findElement(By.xpath("//*[@id='password']")).sendKeys("Market007");
			Thread.sleep(2000);

			// Login to Dashboard Page DashBoard Page
			pageLoad.start();
			driver.findElement(By.xpath("//*[@id='Login']")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("[title=\"Accounts Tab\"]")));
			pageLoad.stop();
			System.out.println("ORG_LogintoDashboard" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			
			
			Thread.sleep(10000);

			driver.findElement(By.xpath("//*[@id='setupSearch']")).click();
			driver.findElement(By.xpath("//*[@id='setupSearch']")).sendKeys(Keys.HOME, Keys.chord(Keys.SHIFT, Keys.END), "Debug");
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='ApexDebugLogs_font']")));
			Thread.sleep(10000);

			driver.findElement(By.xpath("//*[@id='ApexDebugLogs_font']")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(), 'Debug Logs')and contains(@class, 'pageType noSecondHeader')]")));
			
			Thread.sleep(10000);
			WebElement elemetEdit = driver.findElements(By.xpath("//*[contains(@title, 'Edit - Record 1 - team, Perf')]")).get(0);
			elemetEdit.click();

			Thread.sleep(10000);
			driver.findElement(By.xpath("//body[1]/div[1]/div[2]/table[1]/tbody[1]/tr[1]/td[2]/form[1]/div[1]/div[1]/div[2]/div[1]/div[1]/table[1]/tbody[1]/tr[3]/td[1]/span[1]/span[1]/a[1]")).click();
        
        
			JavascriptExecutor js = (JavascriptExecutor) driver;  
			js.executeScript("function formatDate(){var d=new Date(document.getElementById('traceFlag:TraceFlagForm:thePageBlock:mainPageBlock:StartDate:StartDate').value);d.setTime(d.getTime()+(10*60*1000));var day=d.getDate();var month=d.getMonth();var year=d.getFullYear();var hh=d.getHours();var m=d.getMinutes();var s=d.getSeconds();var dd='AM';var h=hh;if(h>=12){h=hh-12;dd='PM';} if(h==0){h=12;} m=m<10?'0'+m:m;s=s<10?'0'+s:s;h=h<10?'0'+h:h;return(month+1)+'/'+day+'/'+year+', '+h+':'+m+' '+dd} var endDate=formatDate();document.getElementById('traceFlag:TraceFlagForm:thePageBlock:mainPageBlock:ExpirationDate:ExpirationDate').value=endDate;");
			
			Thread.sleep(5000);

			driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/table[1]/tbody[1]/tr[1]/td[2]/form[1]/div[1]/div[1]/div[3]/table[1]/tbody[1]/tr[1]/td[2]/input[2]")).click();
			driver.findElement(By.xpath("//div[@id='userNavButton']")).click();
			driver.findElement(By.xpath("  //div[contains(@class,'navLinks')]//a[5]")).click();
		   
			Thread.sleep(10000);
			Thread.sleep((10*60*1000));
			System.out.println("Enable Debug Log Completed");


			
			return driver;
		
			}

				@AfterTest
				public void endTest() throws IOException {
					driver.quit();
				}

			}
			
