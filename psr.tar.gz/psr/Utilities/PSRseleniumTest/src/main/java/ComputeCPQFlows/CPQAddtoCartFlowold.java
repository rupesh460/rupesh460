package ComputeCPQFlows;

import org.testng.annotations.Test;
import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import org.openqa.selenium.JavascriptExecutor;
import org.apache.commons.lang3.time.StopWatch;
import org.influxdb.InfluxDB;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import Automation.seleniumtest.InfluxDBDAO;
import Automation.seleniumtest.Utilities;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.mitm.manager.ImpersonatingMitmManager;
import net.lightbody.bmp.proxy.CaptureType;
import java.util.Random;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.NoSuchElementException;
import java.util.List;


public class CPQAddtoCartFlowold {

	WebDriver driver = null;
	Utilities util = new Utilities();
	CPQAddtoCartFlowold computeaddtocart;
	BrowserMobProxyServer browserMobProxy = null;
	InfluxDBDAO conn = null;
	int iteration = 0;
	Properties prop = null;

	@BeforeTest
	public void beforeTest() throws IOException, InterruptedException {
		computeaddtocart = new CPQAddtoCartFlowold();
		/*browserMobProxy = new BrowserMobProxyServer();
		browserMobProxy.setTrustAllServers(true);
		browserMobProxy.setMitmManager(ImpersonatingMitmManager.builder().trustAllServers(true).build());
		browserMobProxy.enableHarCaptureTypes(CaptureType.REQUEST_CONTENT, CaptureType.RESPONSE_CONTENT,
				CaptureType.RESPONSE_HEADERS);
		browserMobProxy.start(0); */
	//	System.out.println("Port Started On: " + browserMobProxy.getPort());

		conn = new InfluxDBDAO();
		//driver = Utilities.getDriver_CapProxyChrome();
		WebDriverManager.chromedriver().setup();
		//ChromeOptions chromeOptions = new ChromeOptions();
		//chromeOptions.addArguments("--headless");
		//chromeOptions.addArguments("--disable-gpu");
       // driver = new ChromeDriver(chromeOptions);
		driver = new ChromeDriver();
		


	}

	@Test
	public void test() throws IOException, InterruptedException {
		iteration++;
		WebDriver drivertest = null;
		drivertest = computeaddtocart.runTest(driver, iteration, conn);
	}


	public WebDriver runTest(WebDriver driver, int iteration, InfluxDBDAO conn)
			throws IOException, InterruptedException {

		InfluxDB influxDB = conn.establishConnection();
		Date now = new Date();
		StopWatch pageLoad = new StopWatch();
		WebDriverWait wait = new WebDriverWait(driver, 60);
		
		//String Password = util.decryptPassword();
		
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			driver.get("https://login.salesforce.com/");
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id='username']")).clear();
			driver.findElement(By.xpath("//*[@id='username']")).sendKeys("perf-cmt-release-bmk@vlocity.com");
			driver.findElement(By.xpath("//*[@id='password']")).clear();
			driver.findElement(By.xpath("//*[@id='password']")).sendKeys("Market425425");
			Thread.sleep(2000);

			// Login to Dashboard Page DashBoard Page
			pageLoad.start();
			driver.findElement(By.xpath("//*[@id='Login']")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("[title=\"Quarterly Performance\"]")));
			pageLoad.stop();
			System.out.println("ORG_LogintoDashboard" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			conn.writeData(influxDB, "ORG_LogintoDashboard", pageLoad.getTime(), "PSRDemo", iteration);
			
			
			Thread.sleep(10000);
			

			//Navigate to Account Page

			driver.get("https://na123.lightning.force.com/lightning/o/Account/list?filterName=Recent?eptVisible=1");
			Thread.sleep(15000);

			//Create New Account 

			driver.findElement(By.cssSelector("[title=\"New\"]")).click();
			Thread.sleep(3000); 
			driver.findElement(By.xpath("//*[contains(@class, 'slds-button slds-button--neutral slds-button slds-button_brand uiButton')]")).click();
			Thread.sleep(5000);
			Random rand = new Random();
			int randomID= rand.nextInt(10000); 
			Thread.sleep(3000);
			driver.findElement(By.xpath("(//*[contains(@class, ' input')])[4]")).sendKeys("PSR"+randomID);
			Thread.sleep(5000);

			pageLoad.reset();
			pageLoad.start();
			driver.findElement(By.cssSelector("[title=\"Save\"]")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//*[contains(text(), 'Orders')and contains(@class, 'rlql-label')])[last()]")));
			pageLoad.stop();
			System.out.println("CPQ_CreateAccount" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			conn.writeData(influxDB, "CPQ_CreateAccount", pageLoad.getTime(), "PSRDemo", iteration);
			
			Thread.sleep(10000);

			//Click on Orders 
			driver.findElement(By.xpath("(//*[contains(text(), 'Orders')and contains(@class, 'rlql-label')])[last()]")).click();
			Thread.sleep(10000);

			// Click on New Order
			driver.findElement(By.xpath("(//*[@title='New'][@class='forceActionLink'])[last()]")).click();
			Thread.sleep(10000);
			
			
			//Fill Up New Order Details
			//driver.findElement(By.xpath("//*[@title='Search Price Lists']")).sendKeys("");
			//Thread.sleep(2000);
		//	driver.findElement(By.xpath("(//*[contains(@class, 'lookup__item  default uiAutocompleteOption forceSearchInputLookupDesktopOption')])[1]")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("(//*[contains(@class, ' input')])[6]")).sendKeys("PSR"+randomID);
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@class='datePicker-openIcon display']")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("(//*[@class='today slds-button slds-align_absolute-center slds-text-link'])[1]")).click();
			Thread.sleep(5000);

			// Create New Order Transaction 

			pageLoad.reset();
			pageLoad.start();
			driver.findElement(By.cssSelector("[title=\"Save\"]")).click();
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[contains(@class, 'slds-truncate outputLookupLink slds-truncate outputLookupLink')])[last()]")));
			pageLoad.stop(); 
			System.out.println("CPQ_CreateOrder" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			conn.writeData(influxDB, "CPQ_CreateOrder", pageLoad.getTime(), "PSRDemo", iteration);
			

			Thread.sleep(10000);

			// Click Order
			System.out.println("Click Order");
			driver.findElement(By.xpath("(//a[contains(@class, 'forceOutputLookup')])[last()]")).click();
			
			Thread.sleep(10000);
			//Click Dropdown
			driver.findElement(By.xpath("(//*[contains(@class, 'slds-button slds-button--icon-border-filled oneActionsDropDown')])[last()]")).click();
			Thread.sleep(5000);
			// Click on Configure 
			pageLoad.reset();
			pageLoad.start();
			driver.findElement(By.xpath("(//*[@class='uiMenuItem'])[last()-2]")).click();
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.xpath("(//iframe[@title='accessibility title'])[6]")));
			//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@title= 'Service']")));
			pageLoad.stop(); 
			System.out.println("CPQ_Configure" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			conn.writeData(influxDB, "CPQ_Configure", pageLoad.getTime(), "PSRDemo", iteration);
			
			Thread.sleep(20000);

			// Switch to iframe - Hidden - Without Switch page will not be interactable 
			System.out.println("Switching Frame");
			List<WebElement> elems = driver.findElements(By.xpath("//iframe[@title='accessibility title']"));
			System.out.println("Size" + elems.size());
			System.out.println("Size" + (elems.size()-1));
		    //driver.switchTo().frame(elems.get(elems.size()-1));
			
			//WebElement switchelElement = driver.findElement(By.xpath("(//iframe[@title='accessibility title'])[5]"));
			//driver.switchTo().frame(switchelElement);

		//	System.out.println("Switched Frame");
			Thread.sleep(5000); 

			// Add to Cart Transaction 

			pageLoad.reset();
			pageLoad.start();
			WebElement element = driver.findElements(By.xpath("//button[contains(.,'Add to Cart')][contains(@class,'cpq-add-button')]")).get(0);
			element.click();
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[contains(text(), 'Submit Order')])[1]")));
			pageLoad.stop(); 
			System.out.println("CPQ_AddtoCart" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			conn.writeData(influxDB, "CPQ_AddtoCart", pageLoad.getTime(), "PSRDemo", iteration);
			
			Thread.sleep(10000);

			//Update Cart 
			pageLoad.reset();
			pageLoad.start();
			WebElement elementupdate = driver.findElements(By.xpath("//input[contains(@class, 'slds-input cpq-item')]")).get(1);
			elementupdate.sendKeys(Keys.HOME, Keys.chord(Keys.SHIFT, Keys.END), "3");
			//driver.findElement(By.xpath("(//*[contains(@class, 'slds-input cpq-item-input ng-pristine ng-valid ng-not-empty ng-valid-min ng-valid-step ng-valid-required ng-touched')])[last()]")).sendKeys("3");
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("(//div[contains(text(), '$860')])[1]")));
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[contains(text(), 'Submit Order')])[1]")));
			pageLoad.stop(); 
			System.out.println("CPQ_UpdateCart" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			conn.writeData(influxDB, "CPQ_UpdateCart", pageLoad.getTime(), "PSRDemo", iteration);
			Thread.sleep(10000);
		  
			// Expand Root Product 

			pageLoad.reset();
			pageLoad.start();
			driver.findElement(By.xpath("//*[contains(text(), 'ACOMMS-UI-Prod-With-Child')and contains(@class, 'cpq-product-name cpq-large-name-text-wrap')]")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(), 'ACOMMS-UI-P0-Child-7')and contains(@class, 'cpq-product-name')]")));
			pageLoad.stop(); 
			System.out.println("CPQ_ExpandRootProduct" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			conn.writeData(influxDB, "CPQ_ExpandRootProduct", pageLoad.getTime(), "PSRDemo", iteration);
			Thread.sleep(10000);


			// Expand Child Product 

			pageLoad.reset();
			pageLoad.start();
			WebElement element1 = driver.findElement(By.xpath("//*[contains(text(), 'ACOMMS-UI-P0-Child-7')and contains(@class, 'cpq-product-name')]"));
			element1.click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(), 'ACOMMS-UI-P0-Child-8')and contains(@class, 'cpq-product-name')]")));
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[contains(text(), 'Submit Order')])[1]")));
			pageLoad.stop(); 
			System.out.println("CPQ_ExpandChildProduct" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			conn.writeData(influxDB, "CPQ_ExpandChildProduct", pageLoad.getTime(), "PSRDemo", iteration);
			
			Thread.sleep(10000);

			//Click Dropdown
			driver.findElement(By.xpath("(//*[contains(@class, 'slds-button slds-button_icon-border-filled cpq-item-actions-dropdown-button')])[last()]")).click();
			Thread.sleep(5000);
			
			
			// Click on Clone 
			pageLoad.reset();
			pageLoad.start();
			driver.findElement(By.xpath("(//*[@class='slds-truncate cpq-action-item-label'])[last()-1]")).click();
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[contains(@class, 'slds-button slds-button_icon-border-filled cpq-item-actions-dropdown-button')])[last()]")));
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[contains(text(), 'Submit Order')])[1]")));
			//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@title= 'Service']")));
			pageLoad.stop(); 
			System.out.println("CPQ_Clone" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			conn.writeData(influxDB, "CPQ_Clone", pageLoad.getTime(), "PSRDemo", iteration);
			
			Thread.sleep(10000);

			
			//Click Dropdown
			driver.findElement(By.xpath("(//*[contains(@class, 'slds-button slds-button_icon-border-filled cpq-item-actions-dropdown-button')])[last()]")).click();
			Thread.sleep(5000);
			
			// Click on Delete 

			pageLoad.reset();
			pageLoad.start();
			driver.findElement(By.xpath("(//*[contains(@class, 'slds-truncate cpq-action-item-label')])[last()]")).click();
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[contains(text(), 'Are you sure you want to delete this item?')])[1]")));
			//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@title= 'Service']")));
			pageLoad.stop(); 
			System.out.println("Click_Delete" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			//conn.writeData(influxDB, "CPQ_Configure", pageLoad.getTime(), "PSRDemo", iteration);
			Thread.sleep(10000);

			// Click on Delete 
			pageLoad.reset();
			pageLoad.start();
			driver.findElement(By.xpath("(//*[contains(@class, 'slds-button slds-button--destructive')])")).click();
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[contains(@class, 'slds-button slds-button_icon-border-filled cpq-item-actions-dropdown-button')])[last()]")));
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[contains(text(), 'Submit Order')])[1]")));
			pageLoad.stop(); 
			System.out.println("CPQ_Delete" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			conn.writeData(influxDB, "CPQ_Delete", pageLoad.getTime(), "PSRDemo", iteration);
			
			
			Thread.sleep(10000);


		
			// Discount Scenario


			// Checking Frame Size (varying frame size might cause issue)
			
			System.out.println("Switching Frame");
			List<WebElement> elems1 = driver.findElements(By.xpath("//iframe[@title='accessibility title']"));
			System.out.println("Size" + elems1.size());
		    //driver.switchTo().frame(elems.get(elems.size()-1));
			

          
			// Click on Discount option of Left plane
			
			driver.findElement(By.xpath("(//button[contains(text(), 'DISCOUNTS')])[1]")).click();
			Thread.sleep(10000);

			// Add discount to Cart

			pageLoad.reset();
			pageLoad.start();
			driver.findElement(By.xpath("(//button[contains(.,'Add to Cart')][contains(@class,'cpq-add-button')])[last()]")).click();
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[contains(@class,'slds-button slds-p-horizontal_xx-small')])[1]")));
			pageLoad.stop(); 
			System.out.println("CPQ_AddDiscounttoCart" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			conn.writeData(influxDB, "CPQ_AddDiscounttoCart", pageLoad.getTime(), "PSRDemo", iteration);
			
			Thread.sleep(10000);
			
			//Edit Discount 

			WebElement elementedit = driver.findElements(By.xpath("//button[contains(@class,'slds-button slds-p-horizontal_xx-small')]")).get(0);
			elementedit.click();
			Thread.sleep(5000);
			
			// Modify Discount
			pageLoad.reset();
			pageLoad.start();
			WebElement elementesave =driver.findElements(By.xpath("//*[contains(text(), 'Save')and contains(@class, 'slds-button slds-button--brand')]")).get(0);
			elementesave.click();
			wait.until(ExpectedConditions.invisibilityOfElementLocated(
                 By.xpath("(//*[contains(text(), 'Save')and contains(@class, 'slds-button slds-button--brand')])[1]")));
		//	wait.until(ExpectedConditions.InvisibilityOfElementLocated(By.xpath("(//*[contains(text(), 'Save')and contains(@class, 'slds-button slds-button--brand')])[1]")));
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[contains(text(), 'Submit Order')])[1]")));
			pageLoad.stop(); 
			System.out.println("CPQ_ModifyDiscount" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			conn.writeData(influxDB, "CPQ_ModifyDiscount", pageLoad.getTime(), "PSRDemo", iteration);
			
			Thread.sleep(10000);

			// Delete Discount

			// Click on Delete

			WebElement elementedelete = driver.findElements(By.xpath("//*[@class='slds-button']")).get(0);
			elementedelete.click();
			Thread.sleep(5000);

			// Delete Discount
			pageLoad.reset();
			pageLoad.start();
			WebElement elementd =driver.findElements(By.xpath("//button[contains(text(), 'Delete')]")).get(0);
			elementd.click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(), 'No Results Found')])[1]")));
			pageLoad.stop(); 
			System.out.println("CPQ_DeleteDiscount" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			conn.writeData(influxDB, "CPQ_DeleteDiscount", pageLoad.getTime(), "PSRDemo", iteration);
			
			
			Thread.sleep(10000);

			// Click on Promotion

			driver.findElement(By.xpath("(//*[contains(text(), 'Promotions')and contains(@class, 'slds-tabs_default__link')])[1]")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("(//button[contains(text(), 'PROMOTIONS')])[1]")).click();
			Thread.sleep(10000);

			// Add Promotion to Cart

			driver.findElement(By.xpath("(//button[contains(.,'Add to Cart')][contains(@class,'cpq-add-button')])[last()-1]")).click();
			Thread.sleep(10000);

			// Apply Promotion
			pageLoad.reset();
			pageLoad.start();
			WebElement elementapply =driver.findElements(By.xpath("//button[contains(text(), 'Apply')]")).get(0);
			elementapply.click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[contains(text(), 'Delete')])[1]")));
			pageLoad.stop(); 
			System.out.println("CPQ_ApplyPromotion" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			conn.writeData(influxDB, "CPQ_ApplyPromotion", pageLoad.getTime(), "PSRDemo", iteration);
			
			
			Thread.sleep(10000);
			
			// Click on Delete Promotion 
			WebElement elementdprm =driver.findElements(By.xpath("//span[contains(text(), 'Delete')]")).get(0);
			elementdprm.click();
			Thread.sleep(10000);

			// Delete Promotion
			pageLoad.reset();
			pageLoad.start();
			WebElement elementdeleteprom =driver.findElements(By.xpath("//button[contains(text(), 'Delete')]")).get(0);
			elementdeleteprom.click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(), 'No Results Found')])[1]")));
			pageLoad.stop(); 
			System.out.println("CPQ_DeletePromotion" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			conn.writeData(influxDB, "CPQ_DeletePromotion", pageLoad.getTime(), "PSRDemo", iteration);
			
			
			Thread.sleep(10000);

			
			// Create Discount Transaction

			
			driver.findElement(By.xpath("(//*[contains(text(), 'Discounts (0)')and contains(@class, 'slds-tabs_default__link')])[1]")).click();
			
			Thread.sleep(10000);

			driver.findElement(By.xpath("(//*[contains(text(), 'New Custom Discount')])[1]")).click();
			Thread.sleep(10000);
			
			driver.findElement(By.xpath("(//input[contains(@class, 'slds-input')])[2]")).click();
			
			driver.findElement(By.xpath("(//input[contains(@class, 'slds-input')])[2]")).sendKeys("PSRDiscount");
			
			Thread.sleep(10000);
			
			WebElement elementqnt = driver.findElements(By.xpath("//input[contains(@class, 'slds-input ng-pristine ng-untouched ng-valid ng-empty')]")).get(2);
			elementqnt.sendKeys(Keys.HOME, Keys.chord(Keys.SHIFT, Keys.END), "10");
			
			WebElement elementbutton = driver.findElements(By.xpath("//button[@id='cpq-custom-adjustment-view-button']")).get(0);
			elementbutton.click();
			
			Thread.sleep(5000);
			
			WebElement elementOrder = driver.findElements(By.xpath("//span[contains(text(), 'Order')]")).get(1);
			elementOrder.click();
			
			
			Thread.sleep(10000);
		//	driver.findElement(By.xpath("(//*[contains(@class, 'slds-input ng-valid ng-not-empty ng-dirty ng-valid-number ng-touched')])[1]")).sendKeys("10");
		

			Thread.sleep(5000);
			driver.findElement(By.xpath("(//span[@class='slds-radio_faux'])[last()]")).click();
			Thread.sleep(10000);

			pageLoad.reset();
			pageLoad.start();
			driver.findElement(By.xpath("(//*[contains(text(), 'Save')and contains(@class, 'slds-button slds-button--brand')])[1]")).click();
			wait.until(ExpectedConditions.invisibilityOfElementLocated(
                 By.xpath("(//*[contains(text(), 'Save')and contains(@class, 'slds-button slds-button--brand')])[1]")));
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[contains(text(), 'Submit Order')])[1]")));
			pageLoad.stop();
			System.out.println("CPQ_CreateDiscount" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			conn.writeData(influxDB, "CPQ_CreateDiscount", pageLoad.getTime(), "PSRDemo", iteration);
		
          
			// Submit Order 

			pageLoad.reset();
			pageLoad.start();
			driver.findElement(By.xpath("(//*[contains(text(), 'Submit Order')])[1]")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//*[contains(@class, 'form-control btn btn-primary ng-binding')])[1]")));
			pageLoad.stop();
			System.out.println("CPQ_SubmitOrder" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			conn.writeData(influxDB, "CPQ_SubmitOrder", pageLoad.getTime(), "PSRDemo", iteration);
			
			

			Thread.sleep(20000);
			return driver;
		
			}

				@AfterTest
				public void endTest() throws IOException {
					driver.quit();
				}

			}
			
