package Automation.seleniumtest;

import java.util.Properties;
import java.util.concurrent.TimeUnit;


import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.Point;
import org.influxdb.dto.Pong;

public class InfluxDBDAO {

	public static void main(String[] args) {
		InfluxDBDAO conn = new InfluxDBDAO();
		InfluxDB influxDB = conn.establishConnection();		
		//InfluxDB influxinstance = conn.createDB(influxDB,"CloudInfra");
		conn.writeData(influxDB,"Login",2900,"CloudInfra");
		//conn.deleteDB(influxDB,"CloudInfra");
	}

	
	
	InfluxDB influxDB = null;

	public InfluxDB establishConnection(String userName, String password) {
		String databaseURL = "http://localhost:8086";
		// String userName = "cloudinfra";
		// String password = "welcome1";
		influxDB = InfluxDBFactory.connect(databaseURL, userName, password);
		int check = checkConnection(influxDB);
		if (check == 1) {
			System.out.println("Error pinging server.");
			return null;
		} else {
			System.out.println(influxDB.ping().getVersion());
			return influxDB;
		}

	}	
	
	public InfluxDB establishConnection() {
		Properties prop = Utilities.readProperties();				
		String databaseURL = prop.getProperty("DATABASEURL");
		String userName = prop.getProperty("DATABASEUSER");
		String password = prop.getProperty("DATABASEPWD");
		//String databaseURL = "http://localhost:8086/";
		//String userName = "root";
		//String password = "root";
		influxDB = InfluxDBFactory.connect(databaseURL, userName, password);
		int check = checkConnection(influxDB);
		if (check == 1) {
			System.out.println("Error pinging server.");
			return null;
		} else {
			System.out.println(influxDB.ping().getVersion());
			return influxDB;
		}

	}

	public int checkConnection(InfluxDB influxDB2) {
		Pong response = influxDB2.ping();
		if (response.getVersion().equalsIgnoreCase("unknown")) {			
			return 1;
		}
		return 0;
	}

	public InfluxDB createDB(InfluxDB influx, String Name) {
		influx.createDatabase(Name);
		return influx;
	}
	
	public void deleteDB(InfluxDB influx, String Name) {
		influx.deleteDatabase(Name);
	}
	
	public void writeData(InfluxDB influx,String usecasename,long value,String dbName) {
		influx.createRetentionPolicy("defaultPolicy", dbName, "30d", 1, true);
		influx.setRetentionPolicy("defaultPolicy");
		//Point point  = Point.measurement("ResponseTime").time(System.currentTimeMillis(), TimeUnit.MILLISECONDS).addField("UseCase",usecasename.toString()).addField("TimeTaken",value).build();		
		Point point  = Point.measurement("ResponseTime").time(System.currentTimeMillis(), TimeUnit.MILLISECONDS).tag("UseCase", usecasename).addField("TimeTaken",value).build();
		influx.write(dbName, "defaultPolicy", point);
	}
	public void writeData(InfluxDB influx, String usecasename, long value, String dbName, int iteration) {
		influx.createRetentionPolicy("defaultPolicy", dbName, "30d", 1, true);
		influx.setRetentionPolicy("defaultPolicy");
		// Point point =
		// Point.measurement("ResponseTime").time(System.currentTimeMillis(),
		// TimeUnit.MILLISECONDS).addField("UseCase",usecasename.toString()).addField("TimeTaken",value).build();
		Point point = Point.measurement("ResponseTime").time(System.currentTimeMillis(), TimeUnit.MILLISECONDS)
				.tag("UseCase", usecasename).tag("Iteration", Integer.toString(iteration)).addField("TimeTaken", value)
				.build();
		influx.write(dbName, "defaultPolicy", point);
	}

	public void writeData(InfluxDB influx, String usecasename, long timetaken, String dbName, int iteration, String ecid,
			String url) {
		influx.createRetentionPolicy("defaultPolicy", dbName, "30d", 1, true);
		influx.setRetentionPolicy("defaultPolicy");
		Point point = Point.measurement("RT").time(System.currentTimeMillis(), TimeUnit.MILLISECONDS)
				.tag("UseCase", usecasename).tag("Iteration", Integer.toString(iteration)).tag("Url", url)
				.addField("Ecid", ecid).addField("TimeTaken", timetaken).build();
		influx.write(dbName, "defaultPolicy", point);
	}


}
