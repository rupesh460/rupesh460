package Automation.seleniumtest;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.*;
import java.util.*;
import java.net.UnknownHostException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;


import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;


import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.client.ClientUtil;
import net.lightbody.bmp.core.har.Har;


public class Utilities {
	
	//Properties prop_new = readProperties();

    byte[] arrayBytes;
  

	
	public static Properties readProperties() {
		Properties prop = new Properties();
		System.out.println("Inside Read Property");
		try  {
        	InputStream input = new FileInputStream("./src/main/java/config.properties");
            prop.load(input);
            //prop.keySet().stream().map(key -> key + ": " + prop.getProperty(key.toString())).forEach(System.out::println);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
		return prop;
	}

	public String decryptPassword(String password) {
        String decodedString=null;
        try {
            byte[] decodedBytes = Base64.getDecoder().decode(password);
			decodedString = new String(decodedBytes);
			System.out.println("DecodedString" + decodedString);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return decodedString;
    }
	
	
	public String readFile(String fileName) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(fileName));
		try {
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				sb.append("\n");
				line = br.readLine();
			}
			return sb.toString();
		} finally {
			br.close();
		}
	}	

	public void waitForHar(BrowserMobProxyServer browserMobProxy, String sFileName, int iteration,
			String transactionName) throws IOException, InterruptedException {
		long millis = System.currentTimeMillis();
		java.sql.Date date = new java.sql.Date(millis);
		String PATH = "/Users/rupesh.kumar/b2b_express/CME";

		String directoryName = PATH.concat(date.toString());
		//System.out.println(directoryName);
		File theDir = new File(directoryName);
		if (!theDir.exists()) {
			theDir.mkdir();
		}
		Har har = browserMobProxy.getHar();
		File harFile = new File(directoryName + "\\" + sFileName);
		har.writeTo(harFile);
		Thread.sleep(5000);
		if (iteration != 1) {
			String harFilePath = directoryName + "\\" + sFileName;
		}
	}	
	public void waitForHar(BrowserMobProxyServer browserMobProxy, String sFileName) throws IOException {
		Properties props =  readProperties();
		long millis = System.currentTimeMillis();
		java.sql.Date date = new java.sql.Date(millis);
		/*String harDirectory = props.getProperty("psrtest.har_output_dir");
				Har har = browserMobProxy.getHar();
		File harFile = new File(harDirectory+ sFileName);
		har.writeTo(harFile);*/
		String PATH = "/Users/rupesh.kumar/b2b_express/CME";

		String directoryName = PATH.concat(date.toString());
		System.out.println(directoryName);
		File theDir = new File(directoryName);
		if (!theDir.exists()) {
			theDir.mkdir();
		}
		Har har = browserMobProxy.getHar();
		File harFile = new File(directoryName + "//" + sFileName);
		har.writeTo(harFile);

	}
	
	public void executeCommand(String command) {		
		String host = "10.240.24.81";
		String user = "infrauser";
		String password = "Welcome1";
		SSHManager manager = new SSHManager();
		manager.sendCommand(command, host, user, password);
		//manager.connect();
		//String st = manager.sendCommand(command);
		//System.out.println(st);
		//manager.close();
		
	}
	
	public void startTail(String useCase,int iteration) {
	   String name = useCase + Integer.toString(iteration); 
	   String command = "tail -0f /scratch/infrauser/"+name+".out &";
	   executeCommand(command);
	   
	}
	
	public void stopTail() {
		executeCommand("killall tail");
	}
	
}
