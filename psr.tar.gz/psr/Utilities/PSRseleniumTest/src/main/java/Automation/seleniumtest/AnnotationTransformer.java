package Automation.seleniumtest;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Properties;

import org.testng.IAnnotationTransformer;
import org.testng.annotations.ITestAnnotation;


public class AnnotationTransformer implements IAnnotationTransformer {
   // Utilities util = new Utilities();
	public void transform(ITestAnnotation annotation, Class testClass, Constructor testConstructor, Method testMethod) {
		Properties prop = Utilities.readProperties();
		System.out.println(prop.getProperty("invocation"));
		annotation.setInvocationCount(Integer.parseInt(prop.getProperty("invocation")));
		//annotation.setInvocationCount(1);
		annotation.setRetryAnalyzer(RetryAnalyzer.class);
	}
}
