package Automation.seleniumtest;

import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.io.*;
import java.util.Map;



public class SimpleGraphiteClient {

	private final String graphiteHost;
	private final int graphitePort;
	
	/**
	 * Create a new Graphite client.
	 * 
	 * @param graphiteHost Host name to write to.
	 * @param graphitePort Graphite socket. Default is 2003
	 */
	public SimpleGraphiteClient(String graphiteHost, int graphitePort) {
		this.graphiteHost = graphiteHost;
		this.graphitePort = graphitePort;
	}

	/**
	 * Send a set of metrics with the current time as timestamp to graphite.
	 *  
	 * @param metrics the metrics as key-value-pairs
	 */
	public void sendMetrics(String key , Number metrics) {
		sendMetrics(key,metrics, getCurrentTimestamp());
	}

	/**
	 * Send a set of metrics with a given timestamp to graphite.
	 *  
	 * @param metrics the metrics as key-value-pairs
	 * @param timeStamp the timestamp
	 */
	public void sendMetrics(String key , Number metrics, long timeStamp) {
		try {
			System.out.println("Process Started");
			Socket socket = createSocket();
			System.out.println("Writer Process Started");
			Writer writer = new OutputStreamWriter(socket.getOutputStream());
			Long timestamp = System.currentTimeMillis() / 1000;
			System.out.println(timestamp);
		
			String sentMessage = key+" "+metrics+" "+ timestamp+"\n";
			System.out.println(sentMessage);
			writer.write(sentMessage);
			writer.flush();	
			socket.close();				
			} catch (UnknownHostException e) {
			throw new GraphiteException("Unknown host: " + graphiteHost);
		} catch (IOException e) {
			throw new GraphiteException("Error while writing data to graphite: " + e.getMessage(), e);
		}
	}
	
	/**
	 * Send a single metric with the current time as timestamp to graphite. 
	 * 
	 * @param key The metric key
	 * @param value the metric value
	 * 
	 * @throws GraphiteException if writing to graphite fails
	 */
	public void sendMetric(String key, Number value) {
		sendMetric(key, value, getCurrentTimestamp());
	}
	
	/**
	 * Send a single metric with a given timestamp to graphite.
	 * 
	 * @param key The metric key
	 * @param value The metric value
	 * @param timeStamp the timestamp to use
	 * 
	 * @throws GraphiteException if writing to graphite fails 
	 */
	@SuppressWarnings("serial")
	public void sendMetric(final String key, final Number value, long timeStamp) {		
		sendMetrics(key, value, timeStamp);
	}
	
	protected Socket createSocket() throws UnknownHostException, IOException {
		System.out.println("Data" + graphiteHost + graphitePort);
		return new Socket(graphiteHost, graphitePort);
	}
	 
	/***
	 * Compute the current graphite timestamp.
	 * 
	 * @return Seconds passed since 1.1.1970
	 */
	protected long getCurrentTimestamp() {
		return System.currentTimeMillis() / 1000;
	}

}
