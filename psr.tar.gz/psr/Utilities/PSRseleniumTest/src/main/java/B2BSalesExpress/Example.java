package B2BSalesExpress;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;

public class Example{
public static void main(String[] args){
    System.out.println("hellppppp");
try
{
BufferedReader b = new BufferedReader(new FileReader("/Users/rupesh.kumar/repo/b2b_selenium/psr/Utilities/PSRseleniumTest/locations.csv"));
String s;
while((s = b.readLine()) != null){
System.out.println(s);
}
}
catch(IOException e)
{
e.printStackTrace();
}
}
}