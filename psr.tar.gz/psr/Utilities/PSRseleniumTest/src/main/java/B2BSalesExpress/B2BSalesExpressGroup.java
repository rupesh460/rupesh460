package B2BSalesExpress;

import org.testng.annotations.Test;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.JavascriptExecutor;
import org.apache.commons.lang3.time.StopWatch;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.chrome.ChromeDriver;
import net.lightbody.bmp.BrowserMobProxy;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.client.ClientUtil;
import net.lightbody.bmp.core.har.Har;
import net.lightbody.bmp.proxy.CaptureType;
import org.openqa.selenium.Proxy;

import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import Automation.seleniumtest.SimpleGraphiteClient;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import Automation.seleniumtest.Utilities;
import org.openqa.selenium.remote.DesiredCapabilities;


public class B2BSalesExpressGroup {

	WebDriver driver = null;
	B2BSalesExpressGroup compueloginorg;
	Utilities util = new Utilities();
	BrowserMobProxy proxy = new BrowserMobProxyServer();
	int iteration = 0;
	Properties prop = null;
	//SimpleGraphiteClient simpleGraphiteClient  = new SimpleGraphiteClient("10.1.240.150",2003);

	@BeforeTest
	public void beforeTest() throws IOException, InterruptedException {
		

		compueloginorg = new B2BSalesExpressGroup();
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		// ChromeOptions chromeOptions = new ChromeOptions();
		// chromeOptions.addArguments("--headless", "--disable-gpu", "--window-size=1920,1200","--ignore-certificate-errors");
		// driver = new ChromeDriver(chromeOptions);
		Proxy seleniumProxy = ClientUtil.createSeleniumProxy(proxy);
				DesiredCapabilities capabilities = new DesiredCapabilities();
				capabilities.setCapability(CapabilityType.PROXY, seleniumProxy);
				proxy.enableHarCaptureTypes(CaptureType.REQUEST_CONTENT, CaptureType.RESPONSE_CONTENT);


	}

	@Test
	public void test() throws IOException, InterruptedException {
		iteration++;
		WebDriver drivertest = null;
		drivertest = compueloginorg.runTest(driver, iteration);
	}


	public WebDriver runTest(WebDriver driver, int iteration)
			throws IOException, InterruptedException {
				
				

				proxy.start(0);
		StopWatch pageLoad = new StopWatch();
		WebDriverWait wait = new WebDriverWait(driver, 600);
		Properties prop= util.readProperties();
		BufferedWriter writer = new BufferedWriter(new FileWriter(System.getProperty("user.dir")+"/"+prop.getProperty("filename")));
		writer.write("Street Address,Street Supplement 1,City,State,Country,Postal Code"+"\n");
		int noOfLocations=Integer.parseInt(prop.getProperty("noOfLocations"));

		for(int i=1;i<=Integer.parseInt(prop.getProperty("noOfLocations"));i++){
		 int postalCode=100000+i;
		 writer.append("Street Address "+i+",Supp "+i+",City "+i+",State "+i+",Country "+i+","+postalCode+"\n");
		}
		writer.close();
		System.out.println("Number of locations in iteration" + iteration + " : " +noOfLocations);
		long epochnoOfLocations = System.currentTimeMillis()/1000;
		//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.noOfLocations", noOfLocations, epochnoOfLocations);
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			proxy.newHar("login");
			driver.get("https://login.salesforce.com/");
			Har har = proxy.getHar();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id='username']")).clear();
			driver.findElement(By.xpath("//*[@id='username']")).sendKeys(prop.getProperty("userName"));
			driver.findElement(By.xpath("//*[@id='password']")).clear();
			driver.findElement(By.xpath("//*[@id='password']")).sendKeys(prop.getProperty("password"));
			Thread.sleep(10000);

			// Login to Dashboard Page DashBoard Page 
			pageLoad.start();
			driver.findElement(By.xpath("//*[@id='Login']")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()=\"Accounts\"]")));
			pageLoad.stop();
			// System.out.println("ORG_LogintoDashboard" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epoch = System.currentTimeMillis()/1000;
			int timetaken =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.Loginstats", timetaken, epoch);
			Thread.sleep(10000);
			

			// //Select Account tab
			// driver.findElement(By.xpath("//span[@class='triggerLinkText selectedListView uiOutputText']")).click();
			// Thread.sleep(5000);

			// driver.findElement(By.xpath("(//span[@class=' virtualAutocompleteOptionText'])[1]")).click();
			// Thread.sleep(5000);
            
            //Select Account
			pageLoad.reset(); 				
			pageLoad.start();
			// driver.findElement(By.xpath("//*[@title='Acme']")).click();
			//System.out.println(driver.getCurrentUrl().split("lightning/")[0]);
			driver.get(driver.getCurrentUrl().split("lightning/")[0]+prop.getProperty("ACME_accountID"));
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[text()='Create Enterprise Quote']")));
			pageLoad.stop();
			System.out.println("SelectAccount" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			
			long epochSelectAccount = System.currentTimeMillis()/1000;
			int timetakenSelectAccount =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.SelectAccount", timetakenSelectAccount, epochSelectAccount);
			Thread.sleep(10000);

            //Click Create Enterprise Quote
			pageLoad.reset(); 				
			pageLoad.start();			
			driver.findElement(By.xpath("//button[text()='Create Enterprise Quote']")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class='vlocity-btn nds-button nds-button_brand nds-button_stretch nds-p-around_xx-small nds-size_1-of-1']")));
			pageLoad.stop();
			System.out.println("ClickCreateEnterpriseQuote" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochCreateEnterpriseQuote = System.currentTimeMillis()/1000;
			int timetakenCreateEnterpriseQuote =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.CreateEnterpriseQuote", timetakenCreateEnterpriseQuote, epochCreateEnterpriseQuote);
			Thread.sleep(10000);

            //Input details
			driver.findElement(By.xpath("(//input[@class='vlocity-input nds-input'])[1]")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//span[text()='Acme - 600 Widgets']")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("(//input[@class='vlocity-input nds-input'])[1]")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//span[text()='B2B Pricelist']")).click();
			Thread.sleep(5000);			
			driver.findElement(By.xpath("//input[@class='vlocity-input nds-input nds-input_mask']")).clear();
			
			driver.findElement(By.xpath("//input[@class='vlocity-input nds-input nds-input_mask']")).sendKeys("Quote"+String.valueOf(System.currentTimeMillis()/1000));
			Thread.sleep(5000);

            //Click next after putting details
			pageLoad.reset(); 				
			pageLoad.start();
			driver.findElement(By.xpath("//button[@class='vlocity-btn nds-button nds-button_brand nds-button_stretch nds-p-around_xx-small nds-size_1-of-1']")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@class='nds-file-selector__input nds-assistive-text nds-b2b-file-selector']")));
			pageLoad.stop();
			System.out.println("EnterQuoteDetailAndClickNext" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochQuoteDetail = System.currentTimeMillis()/1000;
			int timetakenQuoteDetail =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.EnterQuoteDetailAndClickNext", timetakenQuoteDetail, epochQuoteDetail);
			Thread.sleep(10000);


            //Upload location file
			pageLoad.reset(); 				
			pageLoad.start();
			WebElement uploadElement = driver.findElement(By.xpath("//input[@class='nds-file-selector__input nds-assistive-text nds-b2b-file-selector']"));
			uploadElement.sendKeys(System.getProperty("user.dir")+"/"+prop.getProperty("filename"));
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class='vlocity-btn nds-button nds-button_brand']")));
			pageLoad.stop();
			System.out.println("UploadLocationFile" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochUploadLocation = System.currentTimeMillis()/1000;
			int timetakenUploadLocation =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.UploadLocation", timetakenUploadLocation, epochUploadLocation);
			Thread.sleep(10000);


            //Submit location detail after mapping
			pageLoad.reset(); 				
			pageLoad.start();
			driver.findElement(By.xpath("//button[@class='vlocity-btn nds-button nds-button_brand']")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[@class='nds-checkbox_faux'])[2]")));
			pageLoad.stop();
			System.out.println("SubmitFeildMapping" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochSubmitFeildMapping = System.currentTimeMillis()/1000;
			int timetakenSubmitFeildMapping =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.SubmitFeildMapping", timetakenSubmitFeildMapping, epochSubmitFeildMapping);
			Thread.sleep(10000);

            //Select locations
			pageLoad.reset(); 				
			pageLoad.start();
			driver.findElement(By.xpath("(//span[@class='nds-checkbox_faux'])[2]")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class='vlocity-btn nds-button nds-button_brand nds-b2b-button']")));
			pageLoad.stop();
			System.out.println("SelectLocations" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochSelectLocations1 = System.currentTimeMillis()/1000;
			int timetakenSelectLocations1 =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.SelectLocations", timetakenSelectLocations1, epochSelectLocations1);
			Thread.sleep(10000);
			
			//View Map
			pageLoad.reset(); 				
			pageLoad.start();
			driver.findElement(By.xpath("(//span[@class='nds-checkbox_faux'])[1]")).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='slds-spinner_container']")));
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='slds-spinner_container']")));			pageLoad.stop();
			System.out.println("ViewMap" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochViewMap = System.currentTimeMillis()/1000;
			int timetakenViewMap =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.ViewMap", timetakenViewMap, epochViewMap);
			Thread.sleep(10000);
            
            //Click add to group
			pageLoad.reset(); 				
			pageLoad.start();
			driver.findElement(By.xpath("//button[@class='vlocity-btn nds-button nds-button_brand nds-m-right_small nds-b2b-button']")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Add to Group']")));
			pageLoad.stop();
			System.out.println("ClickAddToGroup" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochAddToGroup = System.currentTimeMillis()/1000;
			int timetakenAddToGroup =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.AddToGroup", timetakenAddToGroup, epochAddToGroup);
			Thread.sleep(10000);


            //div[text()='Create a new group']
            driver.findElement(By.xpath("//div[text()='Create a new group']")).click();
            driver.findElement(By.xpath("//input[@class='vlocity-input nds-input nds-input_mask']")).clear();
			driver.findElement(By.xpath("//input[@class='vlocity-input nds-input nds-input_mask']")).sendKeys("testGrp");
			
			pageLoad.reset(); 				
            pageLoad.start();
            driver.findElement(By.xpath("//button[@class='vlocity-btn nds-button nds-button_brand']")).click();
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Group updated']")));
            pageLoad.stop();
			System.out.println("createGroup" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochcreateGroup = System.currentTimeMillis()/1000;
			int timetakencreateGroup =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.CreateGroup", timetakencreateGroup, epochcreateGroup);
			Thread.sleep(10000);
		  

			driver.findElement(By.xpath("(//c-combobox[@class='nds-b2b-input'])[1]")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//span[text()='Custom Group']")).click();
			Thread.sleep(5000);

			//Select group
			pageLoad.reset(); 				
			pageLoad.start();
			driver.findElement(By.xpath("(//span[@class='nds-checkbox_faux'])[2]")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class='vlocity-btn nds-button nds-button_brand nds-b2b-button']")));
			pageLoad.stop();
			System.out.println("SelectGroup" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochSelectSelectGroup = System.currentTimeMillis()/1000;
			int timetakenSelectSelectGroup =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.SelectGroup", timetakenSelectSelectGroup, epochSelectSelectGroup);
			Thread.sleep(10000);

            //Click add product
			pageLoad.reset(); 				
			pageLoad.start();
			driver.findElement(By.xpath("//button[@class='vlocity-btn nds-button nds-button_brand nds-b2b-button']")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[@class='nds-b2b-product-item'])[1]")));
			pageLoad.stop();
			System.out.println("ClickAddProduct" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochAddProduct = System.currentTimeMillis()/1000;
			int timetakenAddProduct =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.AddProduct", timetakenAddProduct, epochAddProduct);
            Thread.sleep(10000);
            
			//select product
			driver.findElement(By.xpath("//div[@class='via-nds']/li/label[@data-catalog-code='Internet Offers']")).click();
			Thread.sleep(10000);
			pageLoad.reset(); 				
			pageLoad.start();
			driver.findElement(By.xpath("(//div[@class='nds-b2b-product-item'])[1]")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='nds-b2b-configure-offer-container']")));
			pageLoad.stop();
			System.out.println("SelectProduct" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochSelectProduct = System.currentTimeMillis()/1000;
			int timetakenSelectProduct =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.SelectProduct", timetakenSelectProduct, epochSelectProduct);
			Thread.sleep(10000);
			
			// //edit Attribute
			// JavascriptExecutor js = (JavascriptExecutor) driver;
			// js.executeScript("window.scrollBy(0,500)");
			// Thread.sleep(10000);
			// driver.findElement(By.xpath("(//div[@class='nds-b2b-card nds-b2b-child-card'])[3]")).click();
			// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='Contact First Name']")));
			// driver.findElement(By.xpath("(//input[@class='vlocity-input slds-input'])[2]")).clear();
			// driver.findElement(By.xpath("(//input[@class='vlocity-input slds-input'])[2]")).sendKeys("last");
			// Actions action =new Actions(driver);
			// pageLoad.reset(); 				
			// pageLoad.start();
			// action.sendKeys("Keys.TAB");
			// driver.findElement(By.xpath("(//div[@class='nds-b2b-card nds-b2b-child-card'])[3]")).click();
			// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='Updated Installation']")));
			// pageLoad.stop();
			// System.out.println("editAttribute" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			// long epochEditAttribute = System.currentTimeMillis()/1000;
			// int timetakenEditAttribute =(int)pageLoad.getTime();
			// //simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.EditAttribute", timetakenEditAttribute, epochEditAttribute);
			// Thread.sleep(10000);
			// wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='nds-button nds-b2b-location-button']")));


            
			// js.executeScript("window.scrollBy(0,-500)");
			// Thread.sleep(10000);
			driver.findElement(By.xpath("(//button[@class='vlocity-btn nds-button'])[1]")).click();
			Thread.sleep(10000);
			
			//Get Discount list
			pageLoad.reset(); 				
			pageLoad.start();
			driver.findElement(By.xpath("//c-menu-item[@data-method='addDiscount']")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[@class='nds-b2b-add-discount'])[2]")));
			pageLoad.stop();
			System.out.println("GetDiscounts" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochGetDiscounts = System.currentTimeMillis()/1000;
			int timetakenGetDiscounts =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.GetDiscounts", timetakenGetDiscounts, epochGetDiscounts);
			Thread.sleep(10000);
			
			//select Discount
			pageLoad.reset(); 				
			pageLoad.start();
			driver.findElement(By.xpath("(//span[@class='nds-b2b-add-discount'])[2]")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='Added Discount(s) BETADISCOUNT50']")));
			pageLoad.stop();
			System.out.println("selectDiscount" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochSelectDiscount = System.currentTimeMillis()/1000;
			int timetakenSelectDiscount =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.SelectDiscount", timetakenSelectDiscount, epochSelectDiscount);
			Thread.sleep(10000);

			//Apply discount
			pageLoad.reset(); 				
			pageLoad.start();
			driver.findElement(By.xpath("(//button/span[text()='Done'])[1]")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//p[@class='nds-b2b-attribute_value nds-b2b-adjustment-price nds-text-align_right'])[1]")));
			pageLoad.stop();
			System.out.println("ApplyDiscount" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochApplyDiscount = System.currentTimeMillis()/1000;
			int timetakenApplyDiscount =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.ApplyDiscount", timetakenApplyDiscount, epochApplyDiscount);
			Thread.sleep(10000);


            //Click Add To Location
			pageLoad.reset(); 				
			pageLoad.start();
			driver.findElement(By.xpath("//button[@class='nds-button nds-b2b-location-button']")).click();
			// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Total records selected = ']")));
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Success' or text()='Products Loaded']")));
			pageLoad.stop();
			System.out.println("AddToLocation" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochAddToLocation = System.currentTimeMillis()/1000;
			int timetakenAddToLocation =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.AddToLocation", timetakenAddToLocation, epochAddToLocation);
			Thread.sleep(10000);

			//Click Summary
			pageLoad.reset(); 				
			pageLoad.start();
			driver.findElement(By.xpath("//span[contains(text(),'Summary')]")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@title='Name']")));
			pageLoad.stop();
			System.out.println("ClickSummary" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochClickSummary = System.currentTimeMillis()/1000;
			int timetakenClickSummary =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.ClickSummary", timetakenClickSummary, epochClickSummary);
			Thread.sleep(10000);

			//Create Order
			pageLoad.reset(); 				
			pageLoad.start();
			driver.findElement(By.xpath("(//button[@class='vlocity-btn nds-button nds-button_neutral nds-b2b-button'])[2]")).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='slds-spinner_container']")));
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='slds-spinner_container']")));
			pageLoad.stop();
			System.out.println("CreateOrder" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochCreateOrder = System.currentTimeMillis()/1000;
			int timetakenCreateOrder =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.CreateOrder", timetakenCreateOrder, epochCreateOrder);
			Thread.sleep(10000);
			return driver;
		
			}

				@AfterTest
				public void endTest() throws IOException {
					driver.quit();
				}

			}
			
