package B2BSalesExpress;

import org.testng.annotations.Test;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.JavascriptExecutor;
import org.apache.commons.lang3.time.StopWatch;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.chrome.ChromeDriver;
import net.lightbody.bmp.BrowserMobProxyServer;
import Automation.seleniumtest.SimpleGraphiteClient;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import java.io.BufferedWriter;
import java.io.FileWriter;
import Automation.seleniumtest.Utilities;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;

public class B2BSalesExpressAttributes {

	WebDriver driver = null;
	B2BSalesExpressAttributes b2bSalesExpressAttributes;
	Utilities util = new Utilities();
	int iteration = 0;
	Properties prop = null;
	SimpleGraphiteClient simpleGraphiteClient  = new SimpleGraphiteClient("10.1.240.150",2003);

	@BeforeTest
	public void beforeTest() throws IOException, InterruptedException {
		b2bSalesExpressAttributes = new B2BSalesExpressAttributes();
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		// ChromeOptions chromeOptions = new ChromeOptions();
		// chromeOptions.addArguments("--headless", "--disable-gpu", "--window-size=1920,1200","--ignore-certificate-errors");
        // driver = new ChromeDriver(chromeOptions);


	}

	@Test
	public void test() throws IOException, InterruptedException {
		iteration++;
		WebDriver drivertest = null;
		drivertest = b2bSalesExpressAttributes.runTest(driver, iteration);
	}


	public WebDriver runTest(WebDriver driver, int iteration)
			throws IOException, InterruptedException {
				String[] s ={"PSR_20L_Root","PSR_20L_Level1_P1","PSR_20L_Level1_P2","PSR_20L_Level1_P3","PSR_20L_Level1_P4","PSR_20L_Level1_P5","PSR_20L_Level1_P6","PSR_20L_Level1_P7","PSR_20L_Level1_P8","PSR_20L_Level1_P9","PSR_20L_Level1_P10","PSR_20L_Level2_P1.1","PSR_20L_Level2_P2.1","PSR_20L_Level2_P3.1","PSR_20L_Level2_P4.1","PSR_20L_Level2_P5.1","PSR_20L_Level2_P6.1","PSR_20L_Level2_P7.1","PSR_20L_Level2_P8.1","PSR_20L_Level2_P9.1"};
				for(String s1:s){
					System.out.println(s1);
				
		StopWatch pageLoad = new StopWatch();
		WebDriverWait wait = new WebDriverWait(driver, 600);
		Properties prop= util.readProperties();
		BufferedWriter writer = new BufferedWriter(new FileWriter(System.getProperty("user.dir")+"/"+prop.getProperty("filename")));
		writer.write("Street Address,Street Supplement 1,City,State,Country,Postal Code"+"\n");
		int noOfLocations=Integer.parseInt(prop.getProperty("noOfLocations"));
		
		ArrayList<String> array = new ArrayList<String>();
		Scanner input = new Scanner(new File("/Users/rupesh.kumar/Downloads/locations.csv"));
		int counter = 0;
		while(input.hasNextLine() && counter < noOfLocations)
		{
			//array.add(input.nextLine());
			writer.append(input.nextLine()+"\n");
			counter++;
		}
		//System.out.println(array);



		// for(int i=1;i<=noOfLocations;i++){
		//  int postalCode=100000+i;
		//  writer.append("Street Address "+i+",Supp "+i+",City "+i+",State "+i+",Country "+i+","+postalCode+"\n");
		// }
		writer.close();
		System.out.println("Number of locations in iteration" + iteration + " : " +noOfLocations);
		long epochnoOfLocations = System.currentTimeMillis()/1000;
		//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.noOfLocations", noOfLocations, epochnoOfLocations);
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			driver.get("https://login.salesforce.com/");
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id='username']")).clear();
			driver.findElement(By.xpath("//*[@id='username']")).sendKeys(prop.getProperty("userName"));
			driver.findElement(By.xpath("//*[@id='password']")).clear();
			driver.findElement(By.xpath("//*[@id='password']")).sendKeys(prop.getProperty("password"));
			Thread.sleep(10000);

			// Login to Dashboard Page DashBoard Page 
			pageLoad.start();
			driver.findElement(By.xpath("//*[@id='Login']")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Home']")));
			pageLoad.stop();
			System.out.println("ORG_LogintoDashboard" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epoch = System.currentTimeMillis()/1000;
			int timetaken =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.Loginstats", timetaken, epoch);
			Thread.sleep(10000);
			

			// //Select Account tab
			// driver.findElement(By.xpath("//span[@class='triggerLinkText selectedListView uiOutputText']")).click();
			// Thread.sleep(5000);

			// driver.findElement(By.xpath("(//span[@class=' virtualAutocompleteOptionText'])[1]")).click();
			// Thread.sleep(5000);
			// String[] s ={"PSR_20L_Root","PSR_20L_Level1_P1","PSR_20L_Level1_P2","PSR_20L_Level1_P3","PSR_20L_Level1_P4","PSR_20L_Level1_P5","PSR_20L_Level1_P6","PSR_20L_Level1_P7","PSR_20L_Level1_P8","PSR_20L_Level1_P9","PSR_20L_Level1_P10","PSR_20L_Level2_P1.1","PSR_20L_Level2_P2.1","PSR_20L_Level2_P3.1","PSR_20L_Level2_P4.1","PSR_20L_Level2_P5.1","PSR_20L_Level2_P6.1","PSR_20L_Level2_P7.1","PSR_20L_Level2_P8.1","PSR_20L_Level2_P9.1"};
			// for(String s1:s){
			// 	System.out.println(s1);
			//}
            //Select Account
			pageLoad.reset(); 				
			pageLoad.start();
			// driver.findElement(By.xpath("//*[@title='Acme']")).click();
			// driver.get(driver.getCurrentUrl().split("lightning/")[0]+"/lightning/n/vlocity_cmt__VlocityIndustryConsole");
			driver.get("https://value-core-34831--vlocity-cmt.visualforce.com/apex/VlocityIndustryConsole?sfdc.tabName=01r4x000001JWov");
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='Dashboard']")));
			pageLoad.stop();
			System.out.println("product console" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			Thread.sleep(10000);
			pageLoad.reset(); 				
			pageLoad.start();
			driver.findElement(By.xpath("(//span[@class='slds-icon_container action'])[1]")).click();
			driver.switchTo().frame(0);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='searchTerm']")));
			pageLoad.stop();
			System.out.println("search product" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			// // driver.get("https://content-management-92395.lightning.force.com/lightning/r/Account/"+prop.getProperty("ACME_accountID")+"/view");
			// wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.xpath("//iframe[@title='Vlocity Product Console']")));
			// //driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@title='Vlocity Product Console']")));
			// //driver.findElement(By.xpath("//span[@class='slds-icon_container action'])[1]")).click();
			// pageLoad.stop();
			// System.out.println("ClickproductConsole" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			// long epochSelectAccount = System.currentTimeMillis()/1000;
			// int timetakenSelectAccount =(int)pageLoad.getTime();
			// //simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.SelectAccount", timetakenSelectAccount, epochSelectAccount);
			// driver.findElement(By.xpath("(//span[@class='slds-icon_container action'])[1]")).click();
			Thread.sleep(10000);
			//driver.switchTo().frame(0);
			driver.findElement(By.id("searchTerm")).click();
			driver.findElement(By.id("searchTerm")).sendKeys(s1);
			driver.findElement(By.cssSelector(".slds-button")).click();
			Thread.sleep(10000);
			driver.findElement(By.cssSelector(".ng-scope:nth-child(2) > .ng-isolate-scope .ng-binding")).click();
			Thread.sleep(5000);
			driver.switchTo().defaultContent();
			driver.switchTo().frame(1);
			driver.findElement(By.linkText("Attributes and Fields")).click();
			Thread.sleep(10000);
			driver.findElement(By.xpath("//button[text()='Assign Attributes/Fields']")).click();
			Thread.sleep(10000);
			driver.findElement(By.xpath("(//label[@class='slds-checkbox'])[3]")).click();
			driver.findElement(By.xpath("(//label[@class='slds-checkbox'])[7]")).click();
			driver.findElement(By.xpath("(//label[@class='slds-checkbox'])[12]")).click();
			driver.findElement(By.xpath("(//label[@class='slds-checkbox'])[23]")).click();
			driver.findElement(By.xpath("(//label[@class='slds-checkbox'])[62]")).click();
			Thread.sleep(10000);
			driver.findElement(By.xpath("//button[text()='Assign']")).click();
			Thread.sleep(10000);
			driver.findElement(By.linkText("Appointment Date/Time")).click();
			Thread.sleep(10000);
			driver.findElement(By.xpath("//input[@name='defaultValue']")).clear();
			driver.findElement(By.xpath("//input[@name='defaultValue']")).sendKeys("12/5/20");
			Thread.sleep(10000);
			driver.findElement(By.xpath("(//button[text()='Save'])[2]")).click();
			Thread.sleep(10000);			
			driver.findElement(By.linkText("Contact First Name")).click();
			Thread.sleep(10000);
			driver.findElement(By.xpath("//input[@name='defaultValue']")).clear();
			driver.findElement(By.xpath("//input[@name='defaultValue']")).sendKeys("Rupesh");
			Thread.sleep(10000);
			driver.findElement(By.xpath("(//button[text()='Save'])[2]")).click();
			Thread.sleep(10000);
			driver.findElement(By.linkText("DC IMSI")).click();
			Thread.sleep(10000);
			driver.findElement(By.xpath("//input[@name='defaultValue']")).clear();
			driver.findElement(By.xpath("//input[@name='defaultValue']")).sendKeys("100");
			Thread.sleep(10000);
			driver.findElement(By.xpath("(//button[text()='Save'])[2]")).click();
			Thread.sleep(10000);
			driver.findElement(By.linkText("Tangible")).click();
			Thread.sleep(10000);
			driver.findElement(By.cssSelector(".vloc-attribute-default-value .slds-checkbox--faux")).click();
			Thread.sleep(10000);
			driver.findElement(By.xpath("(//button[text()='Save'])[2]")).click();
			Thread.sleep(10000);
			driver.findElement(By.linkText("CPE Deployment Option")).click();
			Thread.sleep(10000);
			driver.findElement(By.xpath("//select[@name='defaultValue']")).click();
			driver.findElement(By.xpath("//option[text()='Reuse Existing CPE']")).click();
			Thread.sleep(10000);
			driver.findElement(By.xpath("(//button[text()='Save'])[2]")).click();
			Thread.sleep(10000);
				}
			return driver;
		
			}

				@AfterTest
				public void endTest() throws IOException {
					driver.quit();
				}

			}
			
