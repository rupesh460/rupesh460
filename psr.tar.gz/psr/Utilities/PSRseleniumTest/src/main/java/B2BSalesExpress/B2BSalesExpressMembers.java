package B2BSalesExpress;

import org.testng.annotations.Test;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.JavascriptExecutor;
import org.apache.commons.lang3.time.StopWatch;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.chrome.ChromeDriver;
import net.lightbody.bmp.BrowserMobProxyServer;
import Automation.seleniumtest.SimpleGraphiteClient;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import Automation.seleniumtest.Utilities;

public class B2BSalesExpressMembers {

	WebDriver driver = null;
	B2BSalesExpressMembers b2bSalesExpressMemberFlow;
	Utilities util = new Utilities();
	int iteration = 0;
	Properties prop = null;
	//SimpleGraphiteClient simpleGraphiteClient  = new SimpleGraphiteClient("10.1.240.150",2003);

	@BeforeTest
	public void beforeTest() throws IOException, InterruptedException {
		b2bSalesExpressMemberFlow = new B2BSalesExpressMembers();
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		// ChromeOptions chromeOptions = new ChromeOptions();
		// chromeOptions.addArguments("--headless", "--disable-gpu", "--window-size=1920,1200","--ignore-certificate-errors");
        // driver = new ChromeDriver(chromeOptions);


	}

	@Test
	public void test() throws IOException, InterruptedException {
		iteration++;
		WebDriver drivertest = null;
		drivertest = b2bSalesExpressMemberFlow.runTest(driver, iteration);
	}


	public WebDriver runTest(WebDriver driver, int iteration)
			throws IOException, InterruptedException {

		StopWatch pageLoad = new StopWatch();
		WebDriverWait wait = new WebDriverWait(driver, 600);
		Properties prop= util.readProperties();
		BufferedWriter writer = new BufferedWriter(new FileWriter(System.getProperty("user.dir")+"/"+prop.getProperty("output_filename")));
		BufferedReader b = new BufferedReader(new FileReader(System.getProperty("user.dir")+"/"+prop.getProperty("input_filename")));
		String s;
		// while((s = b.readLine()) != null){
		// System.out.println(s);}
		writer.write("Street Address,Street Supplement 1,City,State,Country,Postal Code"+"\n");
		int noOfLocations=Integer.parseInt(prop.getProperty("noOfLocations"));
		for(int i=1;i<=noOfLocations;i++){
		 int postalCode=100000+i;
		 writer.append(b.readLine()+"\n");
		}
		writer.close();
		System.out.println("Number of locations in iteration" + iteration + " : " +noOfLocations);
		long epochnoOfLocations = System.currentTimeMillis()/1000;
		//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.noOfLocations", noOfLocations, epochnoOfLocations);
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			driver.get("https://esmb2b-dev-ed.lightning.dbl35.soma.force.com/");
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id='username']")).clear();
			driver.findElement(By.xpath("//*[@id='username']")).sendKeys(prop.getProperty("userName"));
			driver.findElement(By.xpath("//*[@id='password']")).clear();
			driver.findElement(By.xpath("//*[@id='password']")).sendKeys(prop.getProperty("password"));
			Thread.sleep(5000);

			// Login to Dashboard Page DashBoard Page 
			pageLoad.start();
			driver.findElement(By.xpath("//*[@id='Login']")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"title slds-truncate\"]")));
			pageLoad.stop();
			System.out.println("ORG_LogintoDashboard" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epoch = System.currentTimeMillis()/1000;
			int timetaken =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.Loginstats", timetaken, epoch);
			Thread.sleep(5000);
			

			// //Select Account tab
			// driver.findElement(By.xpath("//span[@class='triggerLinkText selectedListView uiOutputText']")).click();
			// Thread.sleep(5000);

			// driver.findElement(By.xpath("(//span[@class=' virtualAutocompleteOptionText'])[1]")).click();
			// Thread.sleep(5000);
            
            //Select Account
			pageLoad.reset(); 				
			pageLoad.start();
			// driver.findElement(By.xpath("//*[@title='Acme']")).click();
			driver.get(driver.getCurrentUrl().split("lightning/")[0]+prop.getProperty("ACME_accountID"));
			// driver.get("https://content-management-92395.lightning.force.com/lightning/r/Account/"+prop.getProperty("ACME_accountID")+"/view");
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[text()='Create Enterprise Quote']")));
			pageLoad.stop();
			System.out.println("SelectAccount" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochSelectAccount = System.currentTimeMillis()/1000;
			int timetakenSelectAccount =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.SelectAccount", timetakenSelectAccount, epochSelectAccount);
			Thread.sleep(5000);

            //Click Create Enterprise Quote
			pageLoad.reset(); 				
			pageLoad.start();			
			driver.findElement(By.xpath("//button[text()='Create Enterprise Quote']")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class='vlocity-btn nds-button nds-button_brand nds-button_stretch nds-p-around_xx-small nds-size_1-of-1']")));
			pageLoad.stop();
			System.out.println("ClickCreateEnterpriseQuote" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochCreateEnterpriseQuote = System.currentTimeMillis()/1000;
			int timetakenCreateEnterpriseQuote =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.CreateEnterpriseQuote", timetakenCreateEnterpriseQuote, epochCreateEnterpriseQuote);
			Thread.sleep(5000);

            //Input details
			driver.findElement(By.xpath("(//input[@class=\"vlocity-input nds-input nds-input_mask\"])[1]")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//span[text()=\"GenePoint SLA\"]/parent::span")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("(//input[@class=\"vlocity-input nds-input nds-input_mask\"])[1]")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//span[text()='B2B Pricelist']")).click();
			Thread.sleep(5000);			
			driver.findElement(By.xpath("(//input[@class=\"vlocity-input nds-input nds-input_mask\"])[1]")).clear();
			driver.findElement(By.xpath("(//input[@class=\"vlocity-input nds-input nds-input_mask\"])[1]")).sendKeys("Quote"+String.valueOf(System.currentTimeMillis()/1000));
			Thread.sleep(5000);

            //Click next after putting details
			pageLoad.reset(); 				
			pageLoad.start();
			driver.findElement(By.xpath("//button[@class='vlocity-btn nds-button nds-button_brand nds-button_stretch nds-p-around_xx-small nds-size_1-of-1']")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()=\"Upload\"]//parent::button")));
			pageLoad.stop();
			System.out.println("EnterQuoteDetailAndClickNext" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochQuoteDetail = System.currentTimeMillis()/1000;
			int timetakenQuoteDetail =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.EnterQuoteDetailAndClickNext", timetakenQuoteDetail, epochQuoteDetail);
			Thread.sleep(5000);


            //Upload location file
			driver.findElement(By.xpath("//span[text()=\"Upload\"]//parent::button")).click();
			Thread.sleep(10000);
			pageLoad.reset(); 				
			pageLoad.start();
			WebElement uploadElement = driver.findElement(By.xpath("//input[@class='nds-file-selector__input nds-assistive-text nds-b2b-file-selector']"));
			uploadElement.sendKeys(System.getProperty("user.dir")+"/"+prop.getProperty("output_filename"));
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class='vlocity-btn nds-button nds-button_brand']")));
			pageLoad.stop();
			System.out.println("UploadLocationFile" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochUploadLocation = System.currentTimeMillis()/1000;
			int timetakenUploadLocation =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.UploadLocation", timetakenUploadLocation, epochUploadLocation);
			Thread.sleep(10000);


            //Submit location detail after mapping
			driver.findElement(By.xpath("//button[@class='vlocity-btn nds-button nds-button_brand']")).click();
			pageLoad.reset(); 				
			pageLoad.start();
			driver.findElement(By.xpath("//button[@class='vlocity-btn nds-button nds-button_brand']")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[@class='nds-checkbox_faux'])[2]")));
			pageLoad.stop();
			System.out.println("SubmitFeildMapping" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochSubmitFeildMapping = System.currentTimeMillis()/1000;
			int timetakenSubmitFeildMapping =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.SubmitFeildMapping", timetakenSubmitFeildMapping, epochSubmitFeildMapping);
			Thread.sleep(5000);

            //Select locations
			pageLoad.reset(); 				
			pageLoad.start();
			driver.findElement(By.xpath("(//span[@class='nds-checkbox_faux'])[2]")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class='vlocity-btn nds-button nds-button_brand nds-b2b-button']")));
			pageLoad.stop();
			System.out.println("SelectLocations" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochSelectLocations1 = System.currentTimeMillis()/1000;
			int timetakenSelectLocations1 =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.SelectLocations", timetakenSelectLocations1, epochSelectLocations1);
			Thread.sleep(5000);
			
			//View Map
			// pageLoad.reset(); 				
			// pageLoad.start();
			// driver.findElement(By.xpath("(//span[@class='nds-checkbox_faux'])[1]")).click();
			// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='slds-spinner_container']")));
			// wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='slds-spinner_container']")));			pageLoad.stop();
			// System.out.println("ViewMap" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			// long epochViewMap = System.currentTimeMillis()/1000;
			// int timetakenViewMap =(int)pageLoad.getTime();
			// //simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.ViewMap", timetakenViewMap, epochViewMap);
			// Thread.sleep(5000);
            
            // //Click add to group
			// pageLoad.reset(); 				
			// pageLoad.start();
			// driver.findElement(By.xpath("//button[@class='vlocity-btn nds-button nds-button_brand nds-m-right_small nds-b2b-button']")).click();
			// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Add to Group']")));
			// pageLoad.stop();
			// System.out.println("ClickAddToGroup" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			// long epochAddToGroup = System.currentTimeMillis()/1000;
			// int timetakenAddToGroup =(int)pageLoad.getTime();
			// //simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.AddToGroup", timetakenAddToGroup, epochAddToGroup);
			// Thread.sleep(5000);


            // //div[text()='Create a new group']
            // driver.findElement(By.xpath("//div[text()='Create a new group']")).click();
            // driver.findElement(By.xpath("//input[@class='vlocity-input nds-input_mask nds-input']")).clear();
			// driver.findElement(By.xpath("//input[@class='vlocity-input nds-input_mask nds-input']")).sendKeys("testGrp");
			
			// pageLoad.reset(); 				
            // pageLoad.start();
            // driver.findElement(By.xpath("//button[@class='vlocity-btn nds-button nds-button_brand']")).click();
            // wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Group updated']")));
            // pageLoad.stop();
			// System.out.println("createGroup" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			// long epochcreateGroup = System.currentTimeMillis()/1000;
			// int timetakencreateGroup =(int)pageLoad.getTime();
			// //simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.CreateGroup", timetakencreateGroup, epochcreateGroup);
			// Thread.sleep(5000);
		  

			// driver.findElement(By.xpath("(//vlocity_cmt-combobox[@class='nds-b2b-input'])[1]")).click();
			// Thread.sleep(5000);
			// driver.findElement(By.xpath("//span[text()='Custom Group']")).click();
			// Thread.sleep(5000);

			// //Select group
			// pageLoad.reset(); 				
			// pageLoad.start();
			// driver.findElement(By.xpath("(//span[@class='nds-checkbox_faux'])[2]")).click();
			// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class='vlocity-btn nds-button nds-button_brand nds-b2b-button']")));
			// pageLoad.stop();
			// System.out.println("SelectGroup" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			// long epochSelectSelectGroup = System.currentTimeMillis()/1000;
			// int timetakenSelectSelectGroup =(int)pageLoad.getTime();
			// //simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.SelectGroup", timetakenSelectSelectGroup, epochSelectSelectGroup);
			// Thread.sleep(5000);

            //Click add product
			for(int i =0; i<=5;i++){
			pageLoad.reset(); 				
			pageLoad.start();
			driver.findElement(By.xpath("//button[@class='vlocity-btn nds-button nds-button_brand nds-b2b-button']")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[@class='nds-b2b-product-item'])[1]")));
			pageLoad.stop();
			System.out.println("ClickAddProduct" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochAddProduct = System.currentTimeMillis()/1000;
			int timetakenAddProduct =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.AddProduct", timetakenAddProduct, epochAddProduct);
            Thread.sleep(5000);
            
			//select product
			driver.findElement(By.xpath("//div[@class='via-nds']/li/label[@data-catalog-code='q4 catalog']")).click();
			Thread.sleep(5000);
			pageLoad.reset(); 				
			pageLoad.start();
			driver.findElement(By.xpath("(//div[@class='nds-b2b-product-item'])[5]")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='nds-b2b-configure-offer-container b2b-config-offer']")));
			pageLoad.stop();
			System.out.println("SelectProduct" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochSelectProduct = System.currentTimeMillis()/1000;
			int timetakenSelectProduct =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.SelectProduct", timetakenSelectProduct, epochSelectProduct);
			Thread.sleep(5000);
            //Click Add To Location
			pageLoad.reset(); 				
			pageLoad.start();
			driver.findElement(By.xpath("//button[@class='nds-button nds-b2b-location-button']")).click();
			// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Total records selected = ']")));
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Products Added Successfully to Enterprise cart.' or text()='Background process to load products is completed, please checkout summary section.']")));
			pageLoad.stop();
			System.out.println("AddToLocation" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochAddToLocation = System.currentTimeMillis()/1000;
			int timetakenAddToLocation =(int)pageLoad.getTime();
			Thread.sleep(5000);
			//Click Summary
			pageLoad.reset(); 				
			pageLoad.start();
			driver.findElement(By.xpath("//span[contains(text(),'Summary')]")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@title='Member/Group']")));
			pageLoad.stop();
			System.out.println("ClickSummary" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochClickSummary = System.currentTimeMillis()/1000;
			int timetakenClickSummary =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.ClickSummary", timetakenClickSummary, epochClickSummary);
			Thread.sleep(5000);
			if(driver.findElements(By.xpath("//span[text()='Summary (2)']")).size() > 0){
				//System.exit(1);
				break;
			}
			driver.findElement(By.xpath("//span[contains(text(),'Location ')]")).click();
			Thread.sleep(5000);
			}

			//Create Order
			pageLoad.reset(); 				
			pageLoad.start();
			driver.findElement(By.xpath("(//button[@class='vlocity-btn nds-button nds-button_neutral nds-b2b-button'])[2]")).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='slds-spinner_container']")));
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='slds-spinner_container']")));
			pageLoad.stop();
			System.out.println("CreateOrder" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			long epochCreateOrder = System.currentTimeMillis()/1000;
			int timetakenCreateOrder =(int)pageLoad.getTime();
			//simpleGraphiteClient.sendMetrics("Selenium.B2BExpress.CreateOrder", timetakenCreateOrder, epochCreateOrder);
			Thread.sleep(5000);
			
			return driver;
		
			}

				@AfterTest
				public void endTest() throws IOException {
					driver.quit();
				}

			}
			
