package ComputeUIFlows;

import org.testng.annotations.Test;
import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.lang3.time.StopWatch;
import org.influxdb.InfluxDB;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.chrome.ChromeDriver;
import Automation.seleniumtest.InfluxDBDAO;
import Automation.seleniumtest.Utilities;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.mitm.manager.ImpersonatingMitmManager;
import net.lightbody.bmp.proxy.CaptureType;

public class ComputeLogin_3UK {

	WebDriver driver = null;
	//Utilities util = new Utilities();
	ComputeLogin_3UK compueloginorg;
	BrowserMobProxyServer browserMobProxy = null;
	InfluxDBDAO conn = null;
	int iteration = 0;
	Properties prop = null;

	@BeforeTest
	public void beforeTest() throws IOException, InterruptedException {
		compueloginorg = new ComputeLogin_3UK();
		/*browserMobProxy = new BrowserMobProxyServer();
		browserMobProxy.setTrustAllServers(true);
		browserMobProxy.setMitmManager(ImpersonatingMitmManager.builder().trustAllServers(true).build());
		browserMobProxy.enableHarCaptureTypes(CaptureType.REQUEST_CONTENT, CaptureType.RESPONSE_CONTENT,
				CaptureType.RESPONSE_HEADERS);
		browserMobProxy.start(0); */
	//	System.out.println("Port Started On: " + browserMobProxy.getPort());

		conn = new InfluxDBDAO();
		//driver = Utilities.getDriver_CapProxyChrome();
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();


	}

	@Test
	public void test() throws IOException, InterruptedException {
		iteration++;
		WebDriver drivertest = null;
		drivertest = compueloginorg.runTest(driver, iteration, conn);
	}


	public WebDriver runTest(WebDriver driver, int iteration, InfluxDBDAO conn)
			throws IOException, InterruptedException {

		InfluxDB influxDB = conn.establishConnection();
		Date now = new Date();
		StopWatch pageLoad = new StopWatch();
		WebDriverWait wait = new WebDriverWait(driver, 60);
		
			driver.manage().deleteAllCookies();
			driver.get("https://login.salesforce.com/");
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id='username']")).clear();
			driver.findElement(By.xpath("//*[@id='username']")).sendKeys("cmtchs-perftest-106@vlocity.com");
			driver.findElement(By.xpath("//*[@id='password']")).clear();
			driver.findElement(By.xpath("//*[@id='password']")).sendKeys("Salesforce999$");
			Thread.sleep(2000);

			// Login to Dashboard Page DashBoard Page
			pageLoad.start();
			driver.findElement(By.xpath("//*[@id='Login']")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("[title=\"Accounts Tab\"]")));
			pageLoad.stop();
			System.out.println("ORG_LogintoDashboard" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			conn.writeData(influxDB, "ORG_LogintoDashboard", pageLoad.getTime(), "PSRDemo", iteration);
			Thread.sleep(10000);
			

			//Click on Order Transaction
			
			pageLoad.reset(); 				
			pageLoad.start();
			driver.findElement(By.cssSelector("[title=\"Orders Tab\"]")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("[title=\"Display Selection\"]")));
			pageLoad.stop();
			System.out.println("ORG_ClickOrderTab" + iteration + ":" + pageLoad.getTime() + "milliseconds");
			conn.writeData(influxDB, "ORG_ClickOrderTab", pageLoad.getTime(), "PSRDemo", iteration);
			Thread.sleep(10000);
			
			
			return driver;
		
			}

				@AfterTest
				public void endTest() throws IOException {
					driver.quit();
				}

			}
			
