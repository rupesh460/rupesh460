#!/bin/bash
# Scripts to add attribute to products 
# Help Link :# TODO
# Limitation : TODO 
# Author sranjan@vlocity.com
#
####################################### environment details #######################################
userName=rkasi@perftest2.ldv.org
passWord=***********
envtype=test
input_Product_file=$1
###################################################################################################

apex_code_part1="for(String p : product_list )\n
                {"
code="list<Attribute__c> attrbutes =[SELECT Id,Name,DisplaySequence__c,ValueType__c,AttributeCategoryId__c From Attribute__c LIMIT 30 offset:rand];\n
	List<AttributeAssignment__c> AttrList = new List<AttributeAssignment__c>();\n
	for(Attribute__c a : attrbutes)\n
	{\n
	AttributeAssignment__c a0 = new AttributeAssignment__c();\n
	a0.AttributeId__c = a.Id;\n
 	a0.ObjectId__c = [SELECT Id  From Product2 where  Name = :p].Id;\n
  	a0.AttributeCategoryId__c = a.AttributeCategoryId__c;\n
 	a0.AttributeDisplayNameOverride__c = a.Name;\n
 	a0.AttributeDisplaySequence__c = String.valueOf(a.DisplaySequence__c);\n
 	a0.ValueDataType__c = a.ValueType__c;\n
  	a0.DisplaySequence__c = null;\n
 	a0.ObjectType__c = 'Product2';\n
  	insert a0;\n
  	ObjectFieldAttribute__c o = new ObjectFieldAttribute__c();\n
  	o.AttributeId__c = a.Id;\n
 	o.SubclassId__c = [SELECT Id  From Product2 where  Name = :p].Id;\n
  	o.ObjectType__c = 'Product2';\n
  	o.ObjectClassId__c  = 'a2VL0000000l6vsMAA';\n
//  	insert o;\n
	}\n
	}\n"


while read -r line;do

echo "List<String> product_list = new list<String> {'$line'}; " > test.apex
echo $apex_code_part1 >> test.apex
echo "Integer rand = Math.floor(6 * 6).intValue();" >> test.apex
echo $code  >> test.apex
        ./force login -i=${envtype} -u=${userName} -p=${passWord}
        ./force apex test.apex
echo "done $line"
sleep 20s
done < "${input_Product_file}"

