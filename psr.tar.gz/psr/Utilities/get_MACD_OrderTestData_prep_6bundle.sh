#!/bin/bash
#This script is helpful in getting test data for MACD order scenerio
#requirement force client, pandas and numpy
# Author: sranjan@vlocity.com

######## input #########################################################################################
StartTime=2020-04-19T11:58:44.000Z
EndTime=2020-04-19T23:45:00.000Z

username=kasi@perftest3.sbx
password=************
logs=nalogs_19april_2

############################################################################################################

echo "script started at `date`"

#python script to parse the simulation file
read -r -d '' parse_xom_python_Script <<-"EOF"
import pandas as pd
import sys
import numpy as np

input_file_name = sys.argv[1]
output_file_name = sys.argv[2]
data = pd.read_csv(input_file_name, encoding='ISO-8859\xe2\x80\x931')

data1 = data[['RootItemId__c', 'Id']]

grp = data1.groupby('RootItemId__c').agg(Id=('Id', list))
assetid_list = grp['Id'].tolist()
data2 = pd.DataFrame(assetid_list, columns=[
    'Id',
    'AssetId_add02',
    'AssetId_add03',
    'AssetId_add04',
    'AssetId_add05',
    'AssetId_add06',
    ])
data2.to_csv('results_tem.csv', index=False)

asset_data = pd.read_csv('results_tem.csv',
                         encoding='ISO-8859\xe2\x80\x931')
data = data[['AccountId', 'RootItemId__c', 'Account.Name', 'Id']]
result_df = pd.merge(data, asset_data, on='Id', how='left')

result_df.rename(columns={'RootItemId__c': 'AssetId'}, inplace=True)
result_df.rename(columns={'Account.Name': 'AccountName'}, inplace=True)
result_df.rename(columns={'AccountId': 'AccountId'}, inplace=True)

result_df1 = result_df[pd.notnull(result_df['AssetId_add06'])]
result_df1.to_csv(output_file_name, index=False)
EOF

function collectDataUsingForceCli(){
        outputFile=$1
        SQL_getAssetDetails="SELECT AccountId,ID,Rootitemid__c,Account.Name from Asset WHERE CreatedDate > ${StartTime} AND CreatedDate < ${EndTime}"
        ./force login -i=test -u=${username} -p=${password}
        ./force query ${SQL_getAssetDetails}| tr -d '"' > $outputFile
}
mkdir -p $logs

collectDataUsingForceCli ${logs}/sqloutput_py.csv

python3 -c "$parse_xom_python_Script" ${logs}/sqloutput_py.csv ${logs}/Result_py.csv 

echo "script started at `date`"
 rm results_tem.csv
