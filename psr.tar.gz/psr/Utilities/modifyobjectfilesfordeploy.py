import string

fileList = ['../../via_contract/objects/ContractVersion__c.object',
			'../../via_contract/objects/ContractEnvelope__c.object',
			'../../via_core/objects/CustomerInteraction__c.object',
			'../../via_core/objects/Contact.object',
			'../../via_core/objects/Attribute__c.object',
			'../../via_core/objects/Party__c.object',
			'../../via_cpq/layouts/VlocityAttachment__c-Vlocity Attachment Layout.layout',
			'../../via_rm/objects/Attribute__c.object',
			'../../via_rm/objects/CampaignMember.object',
			'../../via_rm/objects/Contact.object',
			'../../via_rm/objects/Lead.object',
			'../../via_telco/objects/ContractLineItem__c.object',
			]

print ('inside python script')

for file in fileList:
	try:
		s = open(file).read()
	except IOError:
		print (file + ' : File does not exist')
	else:
		if (file == '../../via_cpq/layouts/VlocityAttachment__c-Vlocity Attachment Layout.layout'):
			s = s.replace('<fields>','<!-- <fields>') 
			s = s.replace('</fields>','</fields> -->')
		s = s.replace('<availableFields>','<!-- <availableFields>')
		s = s.replace('</availableFields>','</availableFields> -->')
		f = open(file,'w')
		f.write(s)
		f.close()
