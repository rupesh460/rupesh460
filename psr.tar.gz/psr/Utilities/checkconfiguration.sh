#!/bin/bash

environment_Name=$1
org_namespace=$2
environmentDetailsFile=resources/environmental_details.csv



envtype=`grep -w ${environment_Name} ${environmentDetailsFile}|awk -F "," '{print $7}'`
userName=`grep -w ${environment_Name} ${environmentDetailsFile}|awk -F "," '{print $2}'`
passWord_encoded=`grep -w ${environment_Name} ${environmentDetailsFile}|awk -F "," '{print $3}'`
passWord=`echo $passWord_encoded| base64 --decode`

read -r -d '' check_configuration <<-"EOF"
#!/usr/bin/python
# -*- coding: utf-8 -*-
import pandas as pd
import sys
import numpy as np


inputdir = "expected_config"
print(inputdir)



def mergedf(filename1,filename2,outputfilename):


    data = pd.read_csv(filename1, encoding='ISO-8859\xe2\x80\x931')


    data1 = pd.read_csv(filename2, encoding='ISO-8859\xe2\x80\x931')

    result_df = pd.merge(data, data1, on='Name', how='outer')
    result_df.columns = ['Name', 'Expected_value', 'Actual_value']
    result_df .to_csv(outputfilename, index=False)





if __name__ == "__main__":

    filename1 = inputdir + "/" + "CPQ_Configurations.csv"
    filename2 = "current_CPQ_Configurations.csv"
    mergedf(filename1,filename2,"CPQ_Delta.csv")

    filename1 = inputdir + "/" + "GeneralSettings.csv"
    filename2 = "current_GeneralSettings.csv"
    mergedf(filename1, filename2,"GeneralSettings_Delta.csv")
EOF


function getcurrentconfig(){
	if [ -e force ]
	then
   		echo "Okay : force client is  present in current folder "
	else

   		echo "Warning : force client is not present in current folder "
   		echo "please download it from https://force-cli.heroku.com/  and save it in current folder, change permission to excecutable chmod 755 force"
   		exit
	fi

	function runSql(){
		if [ ${envtype} == "login" ]
		then
			./force login -i=${envtype} -u=${userName} -p=${passWord}
        		./force query "SELECT Name,${org_namespace}__SetupValue__c FROM ${org_namespace}__CpqConfigurationSetup__c" > results_temp.log
        		sed -e 's/"//g' results_temp.log > current_CPQ_Configurations.csv

        		./force query "SELECT Name,${org_namespace}__Value__c FROM ${org_namespace}__GeneralSettings__c" > results_temp.log
        		sed -e 's/"//g' results_temp.log > current_GeneralSettings.csv
        		rm -rf results_temp.log
		else
        		./force login -i=${envtype} -u=${userName} -p=${passWord}
        		./force query "SELECT Name,SetupValue__c FROM CpqConfigurationSetup__c" > results_temp.log
        		sed -e 's/"//g' results_temp.log > current_CPQ_Configurations.csv

        		./force query "SELECT Name,Value__c FROM GeneralSettings__c" > results_temp.log
        		sed -e 's/"//g' results_temp.log > current_GeneralSettings.csv
        		rm -rf results_temp.log
		fi
	}
	runSql
}



function csvToHtmlConvertor(){
inputFileName1=$1
inputFileName2=$2
 echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">"
 echo "<html>"
 echo "<style type=\"text/css\">
nulltable a:link {
        color: #666;
        font-weight: bold;
        text-decoration:none;
}
table a:visited {
        color: #999999;
        font-weight:bold;
        text-decoration:none;
}
table a:active,
table a:hover {
        text-decoration:underline;
}
table {
        font-family:Arial, Helvetica, sans-serif;
        color:#666;
        font-size:12px;
        background:#fafafa;
        border:#ccc 1px solid;
        border-radius:3px;
        border-collapse:collapse;
        border-spacing: 0;
        box-shadow: 0 1px 2px #d1d1d1;
}
table th {
        color: white;
        text-align: center;
        vertical-align: bottom;
        height:15px;
        padding-bottom: 3px;
        padding-left: 5px;
        padding-right: 5px;
        background-color:#006BB2;
}
.verticalText {
        text-align: center;
        vertical-align: middle;
        width: 15px;
        margin: 0px;
        padding:1px 1px 0;
        background-color:#006BB2;
        white-space: nowrap;
        -ms-transform: rotate(-90deg);          /* IE9+ */
        -webkit-transform: rotate(-90deg);      /* Safari 3.1+, Chrome */
        -moz-transform: rotate(-90deg);         /* FF3.5+ */
        -o-transform: rotate(-90.0deg);         /* Opera 10.5 */
}
table th:first-child {
        text-align: left;
}
table tr:first-child th:first-child {
        border-top-left-radius:3px;
        table tr:first-child th:last-child {
        border-top-right-radius:3px;
}
table tr {
        text-align: center;
}
tr.increased {background: #FFB2B2;}
table td:first-child {
        text-align: left;
        border-left: 0;
}
table td {
        padding:5px 5px 5px;
        border-right:1px solid #e0e0e0;
        border-bottom:1px solid #e0e0e0;
        border-left: 1px solid #e0e0e0;
}
table tr:last-child td {
        border-bottom:0;
}
table tr:last-child td:first-child {
        border-bottom-left-radius:3px;
}
table tr:last-child td:last-child {
        border-bottom-right-radius:3px;
}
</style>
<body style=\"margin: 10px; padding: 10px 50px 0px; font-family:Arial, Helvetica, sans-serif;\">"
echo "<h3 style=\"text-align:left\"><a id=\"top\"> Perf2 Config check Report</a></h3>"
echo "<table align=\"left\" border=1>"
echo "<tr><td>Report Generated at :</td><td>`date`</td></tr>"
echo "</table>"
echo "</p>"
echo "<hr>"


function createHTML() {
    isheader="true";
 fileName=$1
echo "<table border=1>" ;
    while read INPUT ; do
    if [[ "$isheader" == "true" ]];then
        isheader=false;
      echo "<tr><th>${INPUT//,/</th><th>}</th></tr>" ;
      continue;
    fi
    if [[ $INPUT == TOTAL* ]]; then
      echo "<tr><td align="center" bgcolor=\"FFFF66\">${INPUT//,/</td><td bgcolor=\"FFFF66\">}</td></tr>" ;
    else
        value=`echo $INPUT |awk -F "," '{print $NF}'`

        if [[ ${value} < 0 ]]; then
            echo "<tr bgcolor=\"ffb399\"><td>${INPUT//,/</td><td align="center" bgcolor=\"ffb399\">}</td></tr>" ;
        else
            echo "<tr><td>${INPUT//,/</td><td align=center>}</td></tr>" ;

        fi
    fi
    done < $1;
 echo "</table>"
 echo "<br></br>"
}
echo "<br></br>"

echo "<h4 style=\"text-align:left\"><a id=\"top\"> <u>CPQ Config:</u></a></h3>"

createHTML $inputFileName1

echo "<h4 style=\"text-align:left\"><a id=\"top\"> <u>General Settings:</u></a></h3>"

createHTML $inputFileName2
#echo "<a href="https://vlocity.atlassian.net/wiki/spaces/EP/pages/471269696/OM+Report+Preparation+Automation+script+details">Details of  script</a>"
echo "</body> </HTML>"
}


function main(){
	rm -rf current_CPQ_Configurations.csv current_GeneralSettings.csv GeneralSettings_Delta.csv CPQ_Delta.csv
	getcurrentconfig
	python3 -c "$check_configuration"
	csvToHtmlConvertor "CPQ_Delta.csv" "GeneralSettings_Delta.csv" > report.html
	rm -rf current_CPQ_Configurations.csv current_GeneralSettings.csv GeneralSettings_Delta.csv CPQ_Delta.csv
}
main
