import time
import re
import sys,getopt,getpass,os

file = ''
rampup_seconds = 0

if(len(sys.argv)==4):
	rampup_seconds = sys.argv[2]
	file = sys.argv[1]
	scn = sys.argv[3]
	try:
		s = open(file).read()
	except IOError:
		print (file + ' : File does not exist')
	else:
		r = re.compile(scn+'\t(.+?)\tnull')
		m = r.search(s)
		timestamp=m.group(1)
		#print('Start time in epoch:::'+timestamp)
		trimmed_timestamp = int(timestamp[:-3])
		#print(trimmed_timestamp)

		cutdowm_time = trimmed_timestamp + int(rampup_seconds)


		starttime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(trimmed_timestamp))
		#print('Start time of the test is:::'+ starttime)

		rampuptime_loc = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(cutdowm_time))
		#print('Ramp up time loc:::'+ rampuptime_loc)

		rampup_epoch = int(time.mktime(time.strptime(rampuptime_loc, '%Y-%m-%d %H:%M:%S')))
		#print('ramp up epoch time is :::'+str(rampup_epoch))

		fin = open(file, 'r')
		data_list = fin.readlines()
		fin.close()
		r = re.compile(str(rampup_epoch))
		count = 0
		#print(len(data_list))
		for i in range(len(data_list)):
			if r.search(data_list[i]):
				#print('ramp up ending line:::'+ data_list[i],i)
				count = i
				break

		data_list[0] = data_list[0].replace(timestamp,str(rampup_epoch)+'000')
		#print ('Start line modified with rampup_epoch:::'+data_list[0])
		#print(data_list[0])
		del data_list[1:count]

		whoami = getpass.getuser()
		os.mkdir('/Users/'+whoami+'/'+file[:-4]+'2',0o755)
		path = '/Users/'+whoami+'/'+file[:-4]+'2/'
		filename = file[:-4]+'2.log'

		fout = open(path+filename, 'w')
		fout.writelines(data_list)
		fout.close()
		print('The path for your result folder now is ---->'+path)
		print('The cutdown simulation log file is ---->'+file[:-4]+'2.log')
else:
	if (file == '' or rampup_minutes == '' or scn == '' ):
		print('Please pass the simulation log file name,rampup duration in seconds and scenario name as you see in gatling report in order')
		sys.exit()
		

