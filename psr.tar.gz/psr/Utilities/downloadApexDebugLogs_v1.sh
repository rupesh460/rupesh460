#!/bin/bash
# Scripts to download debug logs and calculate #SOQL,#DML for each API
#Readme file readme/readme_downloadApexDebugLogs.txt
#
#
# Author version 1:sranjan@vlocity.com
# Modified by syathiraju@vlocity.com

####### default value  ###############
responseTime=10
logSize=100
outputFolderDir=logs1
environmentDetailsFile=resources/environmental_details.csv
########################################
echo "HELP: sh downloadApexDebugLogs.sh -e|--environment_Name  -dir|--outputFolderDir -rt|--responseTime -s|--logSize"
echo "Example/Defaults: sh downloadApexDebugLogs.sh -e perf2 -d logs -rt 2000  -s 45880"
while [[ $# > 1 ]]
do
key="$1"

case $key in

    -e|--environment_Name)
    environment_Name="$2"
    shift # past argument
    ;;
    -rt|--responseTime)
    responseTime="$2"
    shift # past argument
    ;;
    -s|--logSize)
    logSize="$2"
    shift # past argument
    ;;
    -a|--api)
    api="$2"
    shift # past argument
    ;;
    -d|--dir)
    outputFolderDir="$2"
    shift # past argument
    ;;
    *)
            # unknown option
    ;;
esac
shift # past argument or value
done


envtype=`grep -w ${environment_Name} ${environmentDetailsFile}|awk -F "," '{print $7}'`
userName=`grep -w ${environment_Name} ${environmentDetailsFile}|awk -F "," '{print $2}'`
passWord_encoded=`grep -w ${environment_Name} ${environmentDetailsFile}|awk -F "," '{print $3}'`

passWord=`echo $passWord_encoded| base64 --decode`



#check if force client binary  output folder if not present
if [ -e force ]
then
   echo "Okay : force client is  present in current folder "
else

   echo "Warning : force client is not present in current folder "
   echo "please download it from https://force-cli.heroku.com/  and save it in current folder, change permission to excecutable chmod 755 force"
   exit
fi

#create output folder if not present
if [ ! -d $outputFolderDir ]
then
   echo "Creating output directory ${outputFolderDir} "
	mkdir -p ${outputFolderDir}
fi

echo "log size is equal to $logSize "
echo "RT is $responseTime"
#login to sandbox salesforce org
./force login -i=${envtype} -u=${userName} -p=${passWord}

for each in $(./force query "select id from apexlog where LogLength >= ${logSize} and DurationMilliseconds >= ${responseTime}" ); do
	log=$(echo $each | sed -e 's/"//g')

	if [ "$log" == "Id" ]; then
		echo "ignoring $log"
		continue
	fi
	echo "writing ${outputFolderDir}/${log}.debug"
	./force log $log > ${outputFolderDir}/$log.debug
done

#get unique api name
for i in ${outputFolderDir}/*.debug; do echo "$i : $(sed -n '4p' "$i")"; done|awk -F "|" '{print $NF}' |sort| uniq|grep -v .debug > /tmp/.000012378
while read -r line ; do
        dirName=`echo $line |sed "s/ /_/g" |tr -d ":()"|sed "s/\./_/g"`
        mkdir -p  ${outputFolderDir}/${dirName}
        filesToBeMove=`grep "${line}" ${outputFolderDir}/*.debug|awk -F ":" '{print $1}'|sort|uniq|tr "\n" " "`
        mv ${filesToBeMove} ${outputFolderDir}/${dirName}
	SOQL_Count=`grep -c "SOQL_EXECUTE_BEGIN" ${outputFolderDir}/${dirName}/* | awk -F ":" '{print $2}' | sort | uniq | paste -d "|" -s`
	DML_Count=`grep -c "DML_BEGIN" ${outputFolderDir}/${dirName}/* | awk -F ":" '{print $2}' | sort | uniq | paste -d "|" -s`
	echo "${dirName},${SOQL_Count},${DML_Count}" >> ${outputFolderDir}/SOQL_DML_COUNT.CSV
done < "/tmp/.000012378"
