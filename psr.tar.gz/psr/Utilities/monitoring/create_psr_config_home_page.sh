#!/bin/bash
# Scripts to Create PSR Home page config HTML File by reading the environment details file
#input is environment file and host name on which html file is present
# Author sranjan@vlocity.com
###################################### Please provide Input details here #########################################################
inputFileName=$1
hostName=ec2-52-13-34-187.us-west-2.compute.amazonaws.com

echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">"
echo "<html>"
echo "<body style=\"margin: 10px; padding: 10px 50px 0px; font-family:Arial, Helvetica, sans-serif;\">"
echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"psr_org_config.css\">"
echo "<h1></span>PSR ORG Configurations</span></h1>"
echo "<h2>PSR SF Org wise breakdown of configuations and their values </h2>"
echo "<table class=\"container\">"
echo "<thead>"

function createHTML() {
 fileName=$1
 hostName=$2
 count=`wc -l $fileName|awk '{print $1}'`

 for (( i=0; i<=$count; i++ ))
 do
    if [ $i = 0 ]
    then
        echo "<tr>"
    else
         INPUT=`sed -n ${i}p ${fileName} `
	    echo "<th><h1> ${INPUT//,/</th><th>}</h1></th>" ;

    fi
 done
echo "</thead>"
echo "</tr>"
echo "<tbody>"
# below block need to be repeated if extra thing added for monitoring 
######################
    echo "<tr>"
    for (( i=1; i<=$count; i++ ))
    do
        INPUT=`sed -n ${i}p ${fileName} `
        echo "<td><a href=\"http://${hostName}/${INPUT}_org_triggers.html\" style=\"color:White\">${INPUT} Triggers</a></td>"
    done
    echo "</tr>"
######################
######################
    echo "<tr>"
    for (( i=1; i<=$count; i++ ))
    do
        INPUT=`sed -n ${i}p ${fileName} `
        echo "<td><a href=\"http://${hostName}/cpq_config_${INPUT}.html\" style=\"color:White\">${INPUT} CPQ Config</a></td>"
    done
    echo "</tr>"
######################

 echo "</table>"
 echo "<br></br>"
}
echo "<br></br>"

createHTML $inputFileName $hostName

echo "</body> </HTML>"