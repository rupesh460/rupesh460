#!/bin/sh

##Script run sql using Rest API on workbench and gather data for performance test run
#sample running this script
# sh get_SqlData.sh  2019-01-08T12:45:00.000Z 2019-01-09T23:15:00.000Z outputFileName
####### input #######
username=rkasi@perftest2.ldv.org
password=********
client_secret=5644903920226338215
client_id=3MVG9MHOv_bskkhR5LPzqvofeG92uGkYzDJ8QAGeB7zALujRr0TGKmehi5HFuZZU6l2GxF76.Ddpoz1NpptCX
url=cs8.salesforce.com
orgname=perf2
orgurl=cs8.salesforce.com
####### input #######

access_token=`curl -X POST -H "content-type: application/x-www-form-urlencoded" -d "username=$username&password=$password&client_secret=$client_secret&client_id=$client_id&grant_type=password" https://test.salesforce.com/services/oauth2/token |awk -F '"' '{print $4}'`

curl -X GET   -H "Authorization:Bearer $access_token" "https://$orgurl/services/data/v20.0/query/?q=SELECT+IsTriggerOn__c,Name+FROM+TriggerSetup__c" | jq --raw-output '.records[] | "\(.Name)\t\t\(.IsTriggerOn__c)"' > /var/www/html/perf2_org_triggers.txt


awk 'BEGIN{
        FS = "\t\t";
        {IGNORECASE = 1};
        print "<!DOCTYPE html>";
        print "<html>"
        print "<head>"
        print"<link rel=\"stylesheet\" type=\"text/css\" href=\"psr_org_config.css\">"
        print"</head>"
        print"<body>"

        print"<h3><span class="blue"></span>Triggers & Their Values<span class="blue"></span></h3>"

        print"<table class="container">"
        print"<thead>"
        print"<tr>"
        print "<th><h1>Trigger Name</h1></th>"
        print"<th><h1>Value</h1></th>"

        print "</tr>"
        print"</thead>"
        }

        {
        printf "<tbody>"
        print "<tr>"
        for(i=1;i<=NF;i++)
         {
            printf "%s", "<td"
            if (tolower($i)~/false/) printf " bgcolor=red"
            else printf " bgcolor=green"
            printf ">" $i "</td>"
         }
        print "</tr>"



        }



         END{
        printf "</tbody>"
        print "</table>\n</body>\n</html>"
}' /var/www/html/perf2_org_triggers.txt > /var/www/html/perf2_org_triggers.html
