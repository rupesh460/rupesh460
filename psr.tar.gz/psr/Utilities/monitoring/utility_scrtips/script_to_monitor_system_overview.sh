#!/bin/bash
# Scripts to monitor system overview of all performance salesforce instances
# How script work :
#  Step 1 : Collect the system overview from all salesforce environment by running apex code using force client
# Step 2 : Parse the html file to get the required value ( current , usasge in % and Max allocated value
# Step 3 : Create a pipe separated file from parsed data
# Step 4 : Create html file from the pipe separated data
# Author version 1:  sranjan@vlocity.com
############################################################

code_apex="string partialURL = '/setup/systemOverview.apexp?setupid=SystemOverview';\n
				Pagereference systemOverviewPr = new PageReference(partialURL);\n
				System.debug(systemOverviewPr.getContent().toString());"

function parse_htmlFile_and_get_csv(){

input_html_file=$1
env_name=$2
output_file_name=$3

##########Schema##########
#Data Storage
data_storage=`grep "Go to storage usage" $input_html_file |awk -F ">" '{print $3}'|tr "&" "<"|tr ";" "<"|awk -F "<" '{print $1  $3}'`
data_usage_per=`grep -A20 "Go to storage usage" $input_html_file |grep maximum|head -n 1|awk -F "<" '{print $2}'|awk -F ">" '{print $2}'`
data_storage_max=`grep -A20 "Go to storage usage" $input_html_file |grep maximum|head -n 1|awk -F "maximum" '{print $2}'|tr ";" "|"|tr "&" "|"|tr ")" "|"|awk -F "|" '{print $1  $3}'`


#Your Custom Objects + Your Custom Settings
your_custom_current=`grep -A 5 "Your Custom Objects + Your Custom Settings" $input_html_file|grep CustomObjectsPage|awk -F "<" '{print $3}'|awk -F ">" '{print $NF}'`
your_custom_current_per=`grep -A30 "Your Custom Objects + Your Custom Settings" $input_html_file|grep -i maximum|head -n1|awk -F "<" '{print $2}'|awk -F ">" '{print $NF}'`
your_custom_total=`grep -A30 "Your Custom Objects + Your Custom Settings" $input_html_file|grep -i maximum|head -n1|awk -F "maximum" '{print $2}'|tr -d ")"`

#TOTAL CUSTOM OBJECTS + Total Custom Settings
total_custom_current=`grep -A 5 "Total Custom Objects + Total Custom Settings" $input_html_file|grep CustomObjectsPage|awk -F "<" '{print $3}'|awk -F ">" '{print $NF}'`
total_custom_current_per=`grep -A30 "Total Custom Objects + Total Custom Settings" $input_html_file|grep -i maximum|head -n1|awk -F "<" '{print $2}'|awk -F ">" '{print $NF}'`
total_custom_total=`grep -A30 "Total Custom Objects + Total Custom Settings" $input_html_file|grep -i maximum|head -n1|awk -F "maximum" '{print $2}'|tr -d ")"`


#CUSTOM METADATA TYPES
meta_custom_current=`grep -A 5 "Custom  Metadata Types" $input_html_file|grep CustomMetadataTypeListPage|awk -F "<" '{print $3}'|awk -F ">" '{print $NF}'`
meta_custom_current_per=`grep -A30 "Custom  Metadata Types" $input_html_file|grep -i maximum|head -n1|awk -F "<" '{print $2}'|awk -F ">" '{print $NF}'`
meta_custom_total=`grep -A30 "Custom  Metadata Types" $input_html_file|grep -i maximum|head -n1|awk -F "maximum" '{print $2}'|tr -d ")"`

#CUSTOM METADATA TYPE USAGE
metadata_custom_current_per=`grep -A 30 "Custom Metadata Type Usage" $input_html_file|grep "characters)"|head -n 1|awk -F "<" '{print $2}'|awk -F ">" '{print $NF}'`
metadata_custom_current_char=`grep -A30 "Custom Metadata Type Usage" $input_html_file|grep "characters)"|awk -F "of" '{print $1}'|awk -F "(" '{print $NF}'`
metadata_custom_total=`grep -A30 "Custom Metadata Type Usage" $input_html_file|grep "characters)"|awk -F "of" '{print $2}'|awk '{print $1 " " $2}'|tr -d ")"`

echo "Schema usage for ${env_name}| Current usage %| Current Value| Max Value" > $output_file_name
echo "YOUR CUSTOM OBJECTS + YOUR CUSTOM SETTINGS|$your_custom_current_per| $your_custom_current|$your_custom_total " >>  $output_file_name
echo "TOTAL CUSTOM OBJECTS + Total Custom Settings|$total_custom_current_per| $total_custom_current|$total_custom_total " >>  $output_file_name
echo "CUSTOM METADATA TYPES|$meta_custom_current_per| $meta_custom_current|$your_custom_total " >>  $output_file_name
echo "CUSTOM METADATA TYPE USAGE|$metadata_custom_current_per| $metadata_custom_current_char|$your_custom_total " >>  $output_file_name
echo "DATA STORAGE|$data_usage_per| $data_storage|$data_storage_max " >>  $output_file_name

}

function main(){

while read -r line ;do

userName=`echo $line |awk -F "|" '{print $2}'`
passWord=`echo $line |awk -F "|" '{print $3}'`
org_name=`echo $line |awk -F "|" '{print $1}'`
envtype=`echo $line |awk -F "|" '{print $7}'`

if [[ "${org_name}" != "orgname" ]] ; then
#-e option required if run on ubuntu
	echo -e $code_apex > test.apex
	./force login -i=${envtype} -u=${userName} -p=${passWord}
	./force apex test.apex > /tmp/test.html
	parse_htmlFile_and_get_csv /tmp/test.html $org_name test.csv
	sh pipeToHtmlConvertor.sh test.csv $org_name >> /tmp/system_overview.html
	rm  test.csv
fi

done < "environment_details.txt"
mv /tmp/system_overview.html /var/www/html/perf_env_systemoerview_.html
}
main
