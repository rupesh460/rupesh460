#!/bin/bash
# Scripts to collect SalesForce org configuration details 
# Help Link : .
# Author sranjan@vlocity.com
#
#How it works 
# Step 1 : Read enviroment details from enviroment details file 
# Step 2:  Get Access to in order to run sql on corresponding database 
# Step 3: Run Query against DB and fetch required data 
# Step 4: Parse and create HTML file 

#enviroment files which has all environmental details 
environmentDetailsFile=/home/ec2-user/utility_scrtips/environment_details.txt
isheader="true";
while read -r line ;do
        if [[ "$isheader" == "true" ]];then
             isheader=false;
             continue;
        fi
# reading enviroment details
        environmentType=`echo $line|awk -F "|" '{print $7}'`
        username=`echo $line|awk -F "|" '{print $2}'`
        password=`echo $line|awk -F "|" '{print $3}'`
        client_secret=`echo $line|awk -F "|" '{print $4}'`
        client_id=`echo $line|awk -F "|" '{print $5}'`
        orgurl=`echo $line|awk -F "|" '{print $6}'`
        cpq_query=`echo $line|awk -F "|" '{print $8}'`
        trigger_query=`echo $line|awk -F "|" '{print $9}'`
        environment_name=`echo $line|awk -F "|" '{print $1}'`
        namespace=`echo $line|awk -F "|" '{print $8}'`
#Get Access token 
        access_token=`curl -X POST -H "content-type: application/x-www-form-urlencoded" -d "username=$username&password=$password&client_secret=$client_secret&client_id=$client_id&grant_type=password" https://${environmentType}.salesforce.com/services/oauth2/token |awk -F '"' '{print $4}'`
      
#Getting CPQ Config
        echo "Property,Value" > /var/www/html/cpq_config_${environment_name}.txt
        curl -X GET   -H "Authorization:Bearer $access_token" "https://$orgurl/services/data/v20.0/query/?q=SELECT+Name,${namespace}SetupValue__c+FROM+${namespace}CpqConfigurationSetup__c" | jq --raw-output '.records[] | "\(.Name) ',' \(.'${namespace}'SetupValue__c)"' >> /var/www/html/cpq_config_${environment_name}.txt
        sh csvToHtmlConvertor.sh  /var/www/html/cpq_config_${environment_name}.txt  "${environment_name}" "CPQ Configuration Setting & Value"  > /var/www/html/cpq_config_${environment_name}.html

#Getting Trigger Config
        echo "Property,Value" > /var/www/html/trigger_config_${environment_name}.txt
        curl -X GET   -H "Authorization:Bearer $access_token" "https://$orgurl/services/data/v20.0/query/?q=SELECT+Name,${namespace}IsTriggerOn__c+FROM+${namespace}TriggerSetup__c" | jq --raw-output '.records[] | "\(.Name) ',' \(.'${namespace}'IsTriggerOn__c)"' >> /var/www/html/trigger_config_${environment_name}.txt
        sh csvToHtmlConvertor.sh /var/www/html/trigger_config_${environment_name}.txt ${environment_name} "Triggers & Their Values" > /var/www/html/${environment_name}_org_triggers.html

#removing unwanted files 
        rm /var/www/html/cpq_config_${environment_name}.txt /var/www/html/trigger_config_${environment_name}.txt
done < "${environmentDetailsFile}"
