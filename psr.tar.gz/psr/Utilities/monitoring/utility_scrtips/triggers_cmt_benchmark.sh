#!/bin/sh

##Script run sql using Rest API on workbench and gather data for performance test run
#sample running this script
# sh get_SqlData.sh  2019-01-08T12:45:00.000Z 2019-01-09T23:15:00.000Z outputFileName
####### input #######
username=perf-cmt-release-bmk@vlocity.com
password=*********
client_secret=2847028618258912343
client_id=3MVG9KsVczVNcM8xeKy2xCeFKhU5cLqUWx_oOlMOvZw3mINnx7tqn7vQL3YFko0YLGC_k8FBSC.DVtC_g4GWH
url=na85.salesforce.com
orgname=cmt-benchmark
orgurl=na85.salesforce.com
####### input #######

access_token=`curl -X POST -H "content-type: application/x-www-form-urlencoded" -d "username=$username&password=$password&client_secret=$client_secret&client_id=$client_id&grant_type=password" https://na85.salesforce.com/services/oauth2/token |awk -F '"' '{print $4}'`

curl -X GET   -H "Authorization:Bearer $access_token" "https://$orgurl/services/data/v20.0/query/?q=SELECT+Name,vlocity_perf__IsTriggerOn__c+FROM+vlocity_perf__TriggerSetup__c" | jq --raw-output '.records[] | "\(.Name)\t\t\(.vlocity_perf__IsTriggerOn__c)"' > /var/www/html/cmt_benchmark_org_triggers.txt


awk 'BEGIN{
        FS = "\t\t";
        {IGNORECASE = 1};
        print "<!DOCTYPE html>";
        print "<html>"
        print "<head>"
        print"<link rel=\"stylesheet\" type=\"text/css\" href=\"psr_org_config.css\">"
        print"</head>"
        print"<body>"

        print"<h3><span class="blue"></span>Triggers & Their Values<span class="blue"></span></h3>"

        print"<table class="container">"
        print"<thead>"
        print"<tr>"
        print "<th><h1>Trigger Name</h1></th>"
        print"<th><h1>Value</h1></th>"

        print "</tr>"
        print"</thead>"
        }

        {
        printf "<tbody>"
        print "<tr>"
        for(i=1;i<=NF;i++)
         {
            printf "%s", "<td"
            if (tolower($i)~/false/) printf " bgcolor=red"
            else printf " bgcolor=green"
            printf ">" $i "</td>"
         }
        print "</tr>"



        }



         END{
        printf "</tbody>"
        print "</table>\n</body>\n</html>"
         }' /var/www/html/cmt_benchmark_org_triggers.txt > /var/www/html/cmt_benchmark_org_triggers.html
