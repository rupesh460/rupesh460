import re,sys,os
import collections
import csv

file1 = ''
outputfile = ''
path = '.'

files = os.listdir(path)

for file in files:
    if('.log' in file):
        print('Writing summary table for this file:::'+file) 
        if(len(sys.argv)==1):
            outputfile = file[:-4]+'.csv'#sys.argv[3]
            reader1 = open(file,'r').read()
            hmap = collections.OrderedDict()
            lines = list()
            lines.append(['SOQL/DML','Count'])

            soql_pattern = 'SOQL_EXECUTE_BEGIN\|(.+?)[SsEeLlEeCcTt](.+?)[\n](.+?)SOQL_EXECUTE_END'
            dml_pattern = 'DML_BEGIN\|(.+?)]\|(.+?)\|Rows(.+?)[\n](.+?)CODE_UNIT_STARTED\|(.+?)\|[a-zA-Z0-9]{15}\|(.+?)[\n]'
            soql_r = re.compile(soql_pattern)
            soql_m = soql_r.findall(reader1)
            #print(len(soql_m))
            if(soql_m != None):
                for soql_match in soql_m:
                    index = soql_match[1].index('|')
                    soql_match_string = soql_match[1][10:]
                    if(soql_match_string not in hmap):
                            hmap[soql_match_string] = 1
                    else:
                        hmap[soql_match_string] = hmap.get(soql_match_string) + 1
                    #print('SOQL MATCH:::'+soql_match[1][10:])
            else:
                print ('NO SOQL MATCHES')

            dml_r = re.compile(dml_pattern)
            dml_m = dml_r.findall(reader1)
            #print(len(dml_m))
            if(dml_m != None):
                for dml_match in dml_m:
                    dml_match_string = dml_match[1]+' -->: Rows:'+dml_match[2][1:]+' -->: '+dml_match[5]
                    if(dml_match_string not in hmap):
                            hmap[dml_match_string] = 1
                    else:
                        hmap[dml_match_string] = hmap.get(dml_match_string) + 1
                    #print(dml_match[1]+' -->: Rows:'+dml_match[2][1:]+' -->: '+dml_match[5])
            else:
                print('NO DML MATCHES')
        else:
            if (file1 == '' or outputfile == '' ):
                print('Please input the logfile')
                sys.exit()
        #print(lines)
        lines.append(['TOTAL SOQL',len(soql_m)])
        lines.append(['TOTAL DML',len(dml_m)])

        for key in hmap.keys():
            lines.append([key,hmap.get(key)])

        with open(outputfile, 'w') as writeFile:
            writer = csv.writer(writeFile)
            writer.writerows(lines)
        writeFile.close()
    else:
        print('NO LOG FILES IN THIS FOLDER/OR THIS IS NOT A LOG FILE')