# This Python file uses the following encoding: utf-8
# note: the comment above is functional - don't remove it. it allows use of the
# micron character below (representing microseconds)

import sys
import locale
import operator
import json

class HandledEvents:

    METHOD_ENTRY = 'METHOD_ENTRY'
    METHOD_EXIT = 'METHOD_EXIT'
    USER_DEBUG = 'USER_DEBUG'
    CODE_UNIT_STARTED = 'CODE_UNIT_STARTED'
    CODE_UNIT_FINISHED = 'CODE_UNIT_FINISHED'
    SOQL_EXECUTE_BEGIN = 'SOQL_EXECUTE_BEGIN'
    SOQL_EXECUTE_END = 'SOQL_EXECUTE_END'
    CONSTRUCTOR_ENTRY = 'CONSTRUCTOR_ENTRY'
    CONSTRUCTOR_EXIT = 'CONSTRUCTOR_EXIT'
    VLOCITY_METHOD_ENTRY = 'VLOCITY_METHOD_ENTRY'
    VLOCITY_METHOD_EXIT = 'VLOCITY_METHOD_EXIT'
    DML_BEGIN = 'DML_BEGIN'
    DML_END = 'DML_END'
    CALLOUT_REQUEST = 'CALLOUT_REQUEST'
    CALLOUT_RESPONSE = 'CALLOUT_RESPONSE'

class OutputFormats:

    JSON = 1
    TEXT = 2

class NanosToMicros:

    @staticmethod
    def convert_and_format(delta_time_nanos):
        """
        convert the supplied delta time in nanos to micros, format, and return string representation
        """
        delta_time_micros = (delta_time_nanos + 500) / 1000
        return locale.format('%d', delta_time_micros, grouping=True) + 'µs'

    @staticmethod
    def convert(delta_time_nanos):
        """
        convert the supplied delta time in nanos to micros, format, and return string representation
        """
        delta_time_micros = (delta_time_nanos + 500) / 1000
        return delta_time_micros

class CallInfo:

    def __init__(self, entry_event_parse_info):
        self.set_entry_fields(entry_event_parse_info)
        self.call_exit_time_nanos = None
        self.exit_line_number = None
        self.time_in_child_nodes_nanos = 0

    def set_entry_fields(self, entry_event_parse_info):
        self.method_name = entry_event_parse_info.get_unit_name()
        self.call_start_time_nanos = entry_event_parse_info.get_time_nanos()
        self.entry_line_number = entry_event_parse_info.get_line_number()
        self.entry_event_name = entry_event_parse_info.get_event_name()
        self.sequence_number = entry_event_parse_info.get_sequence_number()
        self.code_line_number = entry_event_parse_info.get_code_line_number()

    def get_start_time_nanos(self):
        return self.call_start_time_nanos

    def get_exit_time_nanos(self):
        return self.call_exit_time_nanos

    def set_exit_time(self, exit_time_nanos):
        self.call_exit_time_nanos = exit_time_nanos

    def set_exit_line_number(self, exit_line_number):
        self.exit_line_number = exit_line_number

    def get_time_in_call_nanos(self):
        if (self.call_start_time_nanos is None) or \
           (self.call_exit_time_nanos is None) or \
           (self.call_start_time_nanos > self.call_exit_time_nanos):

            return -1

        return self.call_exit_time_nanos - self.call_start_time_nanos

    def get_method_name(self):
        return self.method_name

    def set_method_name(self, method_name):
        self.method_name = method_name

    def get_entry_event_name(self):
        return self.entry_event_name

    def get_code_line_number(self):
        return self.code_line_number

    # return the unique sequence number for the call. this could easily be None if
    # the call was not recorded using Vlocity-specific logs (e.g. SF generated trace
    # logs).
    def get_sequence_number(self):
        return self.sequence_number

    def __str__(self):
        """
        return name appropriate for debugging purposes - contains most info but
        in concise form suitable for identifying the offending line in the log.
        """
        desc = self.method_name + '@' + str(self.entry_line_number)
        if (self.exit_line_number is not None):
            desc += '/' + str(self.exit_line_number)
        return desc

    def get_time_in_call_description(self, unmatched_exit):
        durationNanos = self.get_time_in_call_nanos()
        if (durationNanos < 0):
            return 'n/a'
        description = ''
        if unmatched_exit:
            # unmatched exits occur when we have a matching exit for some caller but not for this node.
            # the exit time recorded in these cases will always be greater than the actual time since
            # we only have a timestamp for an exit that occurred later.
            description = '?? <'
        # round to nearest microseconds
        description += NanosToMicros.convert_and_format(durationNanos)
        return description

    def get_time_in_call(self):
        durationNanos = self.get_time_in_call_nanos()
        if (durationNanos < 0):
            return 'n/a'
        # round to nearest microseconds
        return NanosToMicros.convert(durationNanos)

    def get_time_in_children_description(self):
        if (self.time_in_child_nodes_nanos < 0):
            return 'n/a'
        # round to nearest microseconds
        return NanosToMicros.convert_and_format(self.time_in_child_nodes_nanos)

    def get_complete_text_description(self, unmatched_exit):
        """
        return description appropriate for the output tree - including method name, elapsed time, and line
        number
        """

        desc = '[' + self.get_time_in_call_description(unmatched_exit) + '] ' + self.method_name + '@' + \
            str(self.entry_line_number)

        if self.time_in_child_nodes_nanos > 0:
            desc += '  (time in children: ' + \
                self.get_time_in_children_description() + ')'

        return desc

    def get_complete_json_description(self):
        """
        return description appropriate for the output tree - including method name and line number
        """

        desc = self.method_name + '@' + str(self.entry_line_number)

        if self.time_in_child_nodes_nanos > 0:
            desc += '  (time in children: ' + self.get_time_in_children_description() + ')'

        return desc

    def add_time_in_child_nodes(self, child_time_nanos):
        self.time_in_child_nodes_nanos += child_time_nanos


class CallNode:

    def __init__(self, calling_node, entry_event_parse_info):
        self.calling_node = calling_node
        self.call_info = CallInfo(entry_event_parse_info)
        # next_call_node links this call to at most one sibling call
        # (a call next in sequence from same parent method)
        self.next_call_node = None
        self.first_child_call_node = None
        self.last_child_call_node = None
        self.has_exited = False
        self.unmatched_exit = False
        self.children = []
        if calling_node != None:
            self.level = calling_node.level + 1
        else:
            self.level = 1

    def set_fields(self, entry_event_parse_info):
        """
        set fields after creation - useful primarily for root which is created before
        the CODE_UNIT_STARTED line is parsed
        """
        self.call_info.set_fields(entry_event_parse_info)

    def set_method_name(self, method_name):
        self.call_info.set_method_name(method_name)

    def get_text_summary(self):
        """
        return a summary of the call, line and duration - that is, everything
        but the linking info. expected use is to print a line representing the
        node in a tree within a text file
        """
        return self.call_info.get_complete_text_description(self.unmatched_exit)

    def get_json_summary(self):
        """
        return a summary of the call, line and duration - that is, everything
        but the linking info. expected use is to display a line representing the
        node in a tree by a client-side application consuming json output
        """
        return self.call_info.get_complete_json_description()

    def get_call_time(self):
        return self.call_info.get_time_in_call()

    def get_calling_node(self):
        return self.calling_node

    def get_next_call_node(self):
        """ Return sibling call, if any. None otherwise. """
        return self.next_call_node

    def get_first_child_call_node(self):
        return self.first_child_call_node

    def set_next_call_node(self, next_call_node):
        """ set the sibling call node - there can be at most one of these """
        assert self.next_call_node is None, "next_call_node already set"
        self.next_call_node = next_call_node

    def add_child_call_node(self, child_call_node):
        """
        store a child call node. there can be any number of these. they
        are chained together via the next_call_node. the first_child_call_node
        points to the first call made by this call, and the last_child_call_node
        points to the last (for efficiency).
        """

        assert child_call_node is not None, "null child node"
        assert self.has_exited == False, "can't add child to exited call: " + \
            self.call_info

        if self.first_child_call_node is None:
            self.first_child_call_node = child_call_node

        if self.last_child_call_node is not None:
            self.last_child_call_node.set_next_call_node(child_call_node)

        self.last_child_call_node = child_call_node
        if self.last_child_call_node is not None:
            self.children.append(child_call_node)

    def get_method_name(self):
        return self.call_info.get_method_name()

    def get_sequence_number(self):
        return self.call_info.get_sequence_number()

    def get_entry_event_name(self):
        return self.call_info.get_entry_event_name()

    def get_time_in_call_nanos(self):
        return self.call_info.get_time_in_call_nanos()

    def get_entry_time_nanos(self):
        return self.call_info.get_start_time_nanos()

    def get_exit_time_nanos(self):
        return self.call_info.get_exit_time_nanos()

    def get_code_location_hint(self):
        # the most likely location is the calling node's class and method at the line number specified in both the
        # entry and exit logs of this node.
        if (self.calling_node is None):
            return None
        calling_method = self.calling_node.get_method_name()
        if not calling_method:
            return None
        code_line_number = self.call_info.get_code_line_number()
        if (code_line_number is None):
            return calling_method

        location_hint = calling_method + '@' + str(code_line_number)
        return location_hint

    def __str__(self):
        return self.call_info.__str__()

    def record_exit(self, exit_event_parse_info):
        self.call_info.set_exit_time(exit_event_parse_info.get_time_nanos())
        self.call_info.set_exit_line_number(exit_event_parse_info.get_line_number())
        self.has_exited = True

    # called when a non-matching exit event causes us to unwind the call tree
    def record_implied_exit(self, non_matching_exit_event_parse_info):
        self.call_info.set_exit_time(non_matching_exit_event_parse_info.get_time_nanos())
        self.call_info.set_exit_line_number(non_matching_exit_event_parse_info.get_line_number())
        self.has_exited = True
        self.unmatched_exit = True

    def record_child_exit(self, child_node):
        assert child_node.has_exited, "child node should have exited"
        # ignore if child is unmatched. in these cases the time can be a gross overestimate.
        if child_node.unmatched_exit:
            return

        self.call_info.add_time_in_child_nodes(child_node.get_time_in_call_nanos())

class NodeNavigator:

    def __init__(self, root_node):

        self.current_node = root_node
        self.previous_node = None
        self.current_level = 0

    def get_current_node(self):
        return self.current_node

    def increment_level(self):
        self.current_level += 1

    def decrement_level(self):
        assert self.current_level > 0, \
            'insufficient level to decrement at node: ' + str(self.current_node)
        self.current_level -= 1

    def get_current_level(self):
        return self.current_level

    def navigate_to_next_node(self):
        """
        Navigate to next node in sequence. This will be the first child of the
        current node - if it has any children. Otherwise it will be the next
        sibling in sequence. If no children and no next sibling it will be the
        next sibling in sequence for some ancestor.
        """

        assert self.current_node is not None, 'no current node'

        self.previous_node = self.current_node

        first_child = self.current_node.get_first_child_call_node()
        if first_child is not None:
            self.increment_level()
            self.current_node = first_child
            return True
        next_sibling_in_sequence = self.current_node.get_next_call_node()
        if next_sibling_in_sequence is not None:
            self.current_node = next_sibling_in_sequence
            return True

        # if we get here the current node has no children and no next sibling.
        # next node in this case will be the next-sibling-in-sequence for the
        # nearest ancestor that has one (or we're done).

        ancestor_node = self.current_node.get_calling_node()
        while (ancestor_node is not None):
            self.decrement_level()
            if ancestor_node.get_next_call_node() is not None:
                break
            # keep looking
            ancestor_node = ancestor_node.get_calling_node()

        # if we failed to find an ancestor with a next-sibling we're done
        if ancestor_node is None:
            return False

        self.current_node = ancestor_node.get_next_call_node()

        return True

class TreeBuilder:

    default_root_unit_name = 'root'

    def __init__(self):
        dummy_entry_event = ParseInfo("", TreeBuilder.default_root_unit_name, 0, 0)
        self.root_node = CallNode(None, dummy_entry_event)
        # the running context (e.g. the last call entered that hasn't yet exited)
        self.active_node = self.root_node

    def get_handler_method_for_event(self, event_name):
        if not self.event_name_to_handler_method_map.has_key(event_name):
            return None
        return self.event_name_to_handler_method_map[event_name]

    def handle_event(self, event_parse_info):
        handler_method = self.get_handler_method_for_event(event_parse_info.get_event_name())
        if handler_method is None:
            return
        handler_method(self, event_parse_info)

    def handle_code_unit_started(self, parsed_event_info):
        self.handle_method_entry(parsed_event_info)

    def handle_code_unit_finished(self, finish_event_info):
        self.handle_method_exit(finish_event_info)

    def handle_method_entry(self, entry_event_info):
        new_call_node = CallNode(self.active_node, entry_event_info)
        self.active_node.add_child_call_node(new_call_node)
        self.active_node = new_call_node

    def handle_method_exit(self, exit_event_info):

        if exit_event_info.get_variant() == 'constructor_exit':
            return self.handle_constructor_exit_via_method_exit(exit_event_info)

        if not self.does_exit_event_match_node(exit_event_info, self.active_node):
            self.resolve_mismatch(exit_event_info)
            return

        self.match_active_node(exit_event_info)

    def match_active_node(self, exit_event_info):

        # normal matched event handling
        self.active_node.record_exit(exit_event_info)
        calling_node = self.active_node.get_calling_node()
        calling_node.record_child_exit(self.active_node)

        # when active method exits new active method is the one that called it
        self.active_node = calling_node

    def handle_callout_request(self, request_event_info):
        new_call_node = CallNode(self.active_node, request_event_info)
        self.active_node.add_child_call_node(new_call_node)
        self.active_node = new_call_node

    def handle_callout_response(self, response_event_info):

        # the names of the request and response won't match exactly, so we need tailored code.
        # further, for a synchronous callout we assume that if the matching request exists at all it is the active
        # node (otherwise, we'll assume the response is present and the matching request is absent)

        if self.active_node.get_entry_event_name() != HandledEvents.CALLOUT_REQUEST:
            print 'no match for callout response: ' + str(response_event_info) + '. ignoring.'
            return

        # add the name of the exit event to the node - it contains vital info on disposition of the call (status, etc)
        self.active_node.set_method_name(self.active_node.get_method_name() + ' / ' + \
            response_event_info.get_unit_name())

        self.match_active_node(response_event_info)

    def does_exit_event_match_node(self, exit_event_info, call_node):

        # check name first - if they aren't equal then there's a mismatch
        if exit_event_info.get_unit_name() != call_node.get_method_name():
            return False

        # check sequence number. it's quite possible that both are None - but in
        # that case they will be equal.
        if exit_event_info.get_sequence_number() != call_node.get_sequence_number():
            return False

        return True

    # called when the supplied exit event does not match the active node. this method may assert if it
    # can't find a way to resolve the mismatch. if it can resolve the mismatch the active_node will be
    # left in a state suitable for further event processing (active node may have to be rewound to an earlier
    # node). in all cases the exit_event_info should be considered handled.
    def resolve_mismatch(self, exit_event_info):

        # special handling for System.Type.newInstance - these sometimes are logged without matching exits.
        if self.is_active_node_system_type_newinstance():
            print 'mismatched exit found within System.Type.newInstance: ' \
                + exit_event_info.get_unit_name() + '@' + str(exit_event_info.get_line_number()) \
                + '. Ignoring.'
            return

        # if both the active node and the exit event have sequence numbers then use the sequence numbers
        # to resolve the mismatch
        if ((self.active_node.get_sequence_number() != None) and
            (exit_event_info.get_sequence_number() != None)):

            self.resolve_mismatch_using_seq_numbers(exit_event_info)

            return

        self.resolve_mismatch_without_seq_numbers(exit_event_info)

    def resolve_mismatch_without_seq_numbers(self, exit_event_info):

        # first look up the call sequence for a match. for now we're just seeing if there is one - not
        # unwinding the call tree.
        an_ancestor_matches = False
        calling_node = self.active_node.get_calling_node()
        while (calling_node != None):
            if (calling_node.get_method_name() == exit_event_info.get_unit_name()):
                an_ancestor_matches = True
                break
            calling_node = calling_node.get_calling_node()

        # if we found match then we'll assume the issue is that we're missing some exit logs. this is
        # really just an assumption - it's possible that the earlier call has a real matching exit later, but
        # without sequence numbers we can't know for su
        if an_ancestor_matches:
            while (self.active_node.get_method_name() != exit_event_info.get_unit_name()):
                print 'no exit found for entry: ' + str(self.active_node) + '. estimating time.'
                # there is an ancestor matching the exit event - record implicit exits for all callers in-between
                self.active_node.record_implied_exit(exit_event_info)
                calling_node = self.active_node.get_calling_node()
                # we've already searched so we should eventually find a match - unless some error has blocked it
                assert calling_node != None, 'could not find match on second search for: ' \
                    + str(exit_event_info)
                calling_node.record_child_exit(self.active_node)
                self.active_node = calling_node

            # at this point we've found a matching node. we need to close it normally
            self.match_active_node(exit_event_info)

            return

        # if we reach here we've determined that there is no matching ancestor - only possibility left is
        # that we missed an entry
        print 'no match for exit: ' + str(exit_event_info) + '. ignoring.'
        return

    def resolve_mismatch_using_seq_numbers(self, exit_event_info):

        active_node_sequence_number = self.active_node.get_sequence_number()
        exit_event_sequence_number = exit_event_info.get_sequence_number()

        # sanity check - if the sequence number match then this method shouldn't have been called
        # unless the method names didn't match. in that case there's probably an error in the method
        # names.
        if (active_node_sequence_number == exit_event_sequence_number):
            print 'mismatched names with matching sequence numbers. active node: ' \
                + str(self.active_node) + ', exit event: ' + exit_event_info.get_description()
            # since sequence number match - good guess is that these are a match anyway.
            return

        # if the exit event sequence number is higher than the active node, then likely there's
        # a missing entry log for a call within the active node. best remedy in this case is to
        # just throw away the exit and continue.
        if (exit_event_sequence_number > active_node_sequence_number):
            print 'mismatched exit found: ' + exit_event_info.get_description() + '. Ignoring'
            return

        # only other possibility is that the exit event sequence number is less than the active node.
        # this is an indication that the exit event is actually for a call prior to the active node and
        # that the exit event for the active node (and any number of ancestor nodes) is missing. remedy
        # is to close calling nodes until we find one that matches the exit sequence number - and assert
        # out if we can't. closed nodes will have estimated end times.
        while (self.active_node.get_sequence_number() != exit_event_sequence_number):
            print 'no exit found for entry: ' + str(self.active_node) + '. estimating time.'
            self.active_node.record_implied_exit(exit_event_info)
            calling_node = self.active_node.get_calling_node()
            if (calling_node == None):
                message = 'unable to find matching call for event: ' + exit_event_info.get_description()
                assert False, message
            # record the exit with the parent. likely the parent node will disregard child time due to
            # the mismatch.
            calling_node.record_child_exit(self.active_node)
            self.active_node = calling_node

        # after unwinding a bit we've found a matching record - make sure to pair it with the active node
        self.match_active_node(exit_event_info)

    def handle_constructor_entry_event(self, constr_entry_event_info):
        self.handle_method_entry(constr_entry_event_info)

    def handle_constructor_exit_event(self, constr_exit_event_info):
        self.handle_method_exit(constr_exit_event_info)

    def handle_constructor_exit_via_method_exit(self, exit_event_info):

        method_name = exit_event_info.get_unit_name()
        exit_line_number = exit_event_info.get_line_number()

        # names are considered matched the exit name appears anywhere in the entry name
        exit_matches_entry = self.active_node.get_method_name().find(method_name) != -1

        if not exit_matches_entry:
            # lot of examples of this happening within System.type.newInstance() - ignore those
            if self.is_active_node_system_type_newinstance():
                # don't abort but don't do anything else for this exit - in examples we've seen
                # the rest of the log is still consistent
                print 'mismatched constructor exit found within System.Type.newInstance: ' \
                    + method_name + '@' + str(exit_line_number) + '. Ignoring.'
                return
            assert False, 'mismatched entry/exit method names: ' + str(self.active_node) \
                + ' / ' + method_name + '@' + str(exit_line_number)

        self.active_node.record_exit(exit_event_info)
        calling_node = self.active_node.get_calling_node()
        calling_node.record_child_exit(self.active_node)
        # when active method exits new active method is the one that called it
        self.active_node = self.active_node.get_calling_node()

    def handle_SOQL_begin(self, begin_event_info):
        new_call_node = CallNode(self.active_node, begin_event_info)
        self.active_node.add_child_call_node(new_call_node)
        self.active_node = new_call_node

    def handle_SOQL_end(self, end_event_info):
        if self.active_node.get_entry_event_name() != HandledEvents.SOQL_EXECUTE_BEGIN:
            assert False, 'found unpaired SOQL_EXECUTE_END at line: ' \
                + str(end_event_info.get_line_number())
        self.active_node.record_exit(end_event_info)
        calling_node = self.active_node.get_calling_node()
        calling_node.record_child_exit(self.active_node)
        self.active_node = calling_node

    def handle_DML_begin(self, begin_event_info):
        new_call_node = CallNode(self.active_node, begin_event_info)
        self.active_node.add_child_call_node(new_call_node)
        self.active_node = new_call_node

    def handle_DML_end(self, end_event_info):
        if self.active_node.get_entry_event_name() != HandledEvents.DML_BEGIN:
            assert False, 'found unpaired DML_END at line: ' \
                + str(end_event_info.get_line_number())
        self.active_node.record_exit(end_event_info)
        calling_node = self.active_node.get_calling_node()
        calling_node.record_child_exit(self.active_node)
        self.active_node = calling_node

    def is_active_node_system_type_newinstance(self):
        return self.active_node.get_method_name().find('System.Type.newInstance') != -1

    def get_root_node(self):
        return self.root_node

    event_name_to_handler_method_map = {\
        HandledEvents.METHOD_ENTRY : handle_method_entry,\
        HandledEvents.METHOD_EXIT : handle_method_exit,\
        HandledEvents.VLOCITY_METHOD_ENTRY : handle_method_entry,\
        HandledEvents.VLOCITY_METHOD_EXIT : handle_method_exit,\
        HandledEvents.CODE_UNIT_STARTED : handle_code_unit_started,\
        HandledEvents.CODE_UNIT_FINISHED : handle_code_unit_finished,\
        HandledEvents.SOQL_EXECUTE_BEGIN : handle_SOQL_begin,\
        HandledEvents.SOQL_EXECUTE_END : handle_SOQL_end,\
        HandledEvents.CONSTRUCTOR_ENTRY : handle_constructor_entry_event,\
        HandledEvents.CONSTRUCTOR_EXIT : handle_constructor_exit_event, \
        HandledEvents.DML_BEGIN : handle_DML_begin, \
        HandledEvents.DML_END : handle_DML_end, \
        HandledEvents.CALLOUT_REQUEST : handle_callout_request, \
        HandledEvents.CALLOUT_RESPONSE : handle_callout_response \
    }

class BaseTreeWriter:

    def write_gaps_between_sequential_nodes(self, previous_node, latter_node):

        if previous_node is None:
            # first node - no gap to report
            return

        if previous_node == self.root_node:
            # don't attempt to compute a gap from the root node
            return

        # previous node is either calling node (if latter is first child), previous sibling, or simply the next call in
        # sequence sharing some common ancestor. if previous is calling node then gap time is start of calling node to
        # start of latter node.

        # if previous node is caller of latter node...
        if latter_node.get_calling_node() == previous_node:
            # write single gap with delta between starting time of previous node and starting time of latter node
            self.write_single_gap(latter_node.level, previous_node, previous_node.get_entry_time_nanos(), \
                latter_node.get_entry_time_nanos())

        # if nodes are siblings (that is - have the same caller)
        elif latter_node.get_calling_node() == previous_node.get_calling_node():
            # write single gap with delta betwen ending time of previous node and starting time of latter node
            self.write_single_gap(latter_node.level, latter_node.get_calling_node(), \
                previous_node.get_exit_time_nanos(), latter_node.get_entry_time_nanos())

        # only remaining possiblity is that the previous node is the very end of the call tree of some ancestor and the
        # latter node is the sibling node of that ancestor. in this case we need to add gaps at the end of all the
        # terminated call trees and a gap between the two siblings (one being the ancestor of the previous node and the
        # other being the latter node).
        else:
            latter_node_parent = latter_node.get_calling_node()

            # in the following loop, the iterating_prior_node's exit time will always be the prior time for the delta
            # calculation while the iterating_parent_node's exit time will be the latter time
            iterating_prior_node = previous_node
            iterating_parent_node = iterating_prior_node.get_calling_node()

            while (iterating_parent_node != None) and (iterating_parent_node != latter_node_parent):

                # add gap at end of call tree of iterating_parent_node. the delta time will be between the end of
                # iterating_prior_node (either the previous node or one of its direct-line ancestors) and the end of its
                # parent (iterating_parent_node)
                self.write_single_gap(iterating_prior_node.level, iterating_parent_node, \
                    iterating_prior_node.get_exit_time_nanos(), iterating_parent_node.get_exit_time_nanos())

                iterating_prior_node = iterating_parent_node
                iterating_parent_node = iterating_parent_node.get_calling_node()

            # create gap between the siblings
            if (iterating_parent_node != None):

                # find the previous sibling (we could do this more efficiently in the loop above - but that loop is
                # already complicated enough)
                current_node = latter_node_parent.get_first_child_call_node()
                previous_node = None

                while (current_node is not None) and (current_node != latter_node):
                    previous_node = current_node
                    current_node = current_node.get_next_call_node()

                if (current_node is not None) and (previous_node is not None):
                    self.write_single_gap(latter_node.level, latter_node.get_calling_node(), \
                        previous_node.get_exit_time_nanos(), latter_node.get_entry_time_nanos())


class JsonTreeWriter(BaseTreeWriter):

    # failsafe to prevent using up all disk space
    max_lines = 10 * 1000000

    def __init__(self, root_node):
        assert root_node is not None, 'no root node'
        self.root_node = root_node
        self.current_node = None
        self.previous_node = None
        self.write_line_count = 0

    def write_single_gap(self, level, parent_node, gap_start_time_nanos, gap_end_time_nanos):
        if parent_node is None:
            return
        if parent_node.dict_node is None:
            return

        parent_calls = parent_node.dict_node['calls']

        if parent_calls is None:
            return

        delta_time_nanos = gap_end_time_nanos - gap_start_time_nanos

        delta_time_micros = NanosToMicros.convert(delta_time_nanos)

        gap = {}
        gap['level'] = level
        gap['title'] = 'gap time'
        gap['time'] = delta_time_micros

        parent_calls.append(gap)

    def write_node(self, node):
        self.previous_node = node
        mainNode = {}
        node.dict_node = mainNode
        mainNode['title'] = node.get_json_summary()
        mainNode['time'] = node.get_call_time()
        location_hint = node.get_code_location_hint()
        if location_hint is not None:
            mainNode['location'] = location_hint
        if node.unmatched_exit:
            mainNode['unmatched'] = True
        mainNode['level'] = node.level
        if len(node.children) > 0:
            mainNode['calls'] = []
            for child in node.children:
                self.write_gaps_between_sequential_nodes(self.previous_node, child)
                mainNode['calls'].append(self.write_node(child))
        return mainNode

    def write_tree(self):
        tree = [self.write_node(self.root_node)]
        return json.dumps(tree)


class TextTreeWriter(BaseTreeWriter):

    spaces_per_indent = 2

    # failsafe to prevent using up all disk space
    max_lines = 10 * 1000000

    def __init__(self, root_node, threshold_nanos, write_gaps):
        assert root_node is not None, 'no root node'
        self.root_node = root_node
        self.current_node = None
        self.previous_node = None
        self.write_line_count = 0
        self.threshold_nanos = threshold_nanos
        self.write_gaps = write_gaps
        self.output_string = ''

    def write_line_with_indent(self, indent, line):
        self.write_line_count += 1
        assert self.write_line_count < TextTreeWriter.max_lines, \
            'aborting, max output lines reached: ' + self.max_lines
        self.output_string += ' ' * indent * TextTreeWriter.spaces_per_indent + line + '\n'

    def write_current_node_if_over_threshold(self):
        if self.threshold_nanos is not None:
            if self.current_node.get_time_in_call_nanos() < self.threshold_nanos:
                return
        self.write_current_node()

    def write_single_gap(self, level, parent_node, gap_start_time_nanos, gap_end_time_nanos):
        delta_time_nanos = gap_end_time_nanos - gap_start_time_nanos

        if self.threshold_nanos is not None:
            if delta_time_nanos < self.threshold_nanos:
                return

        delta_time_micros_formatted = NanosToMicros.convert_and_format(delta_time_nanos)

        self.write_line_with_indent(level, '[' + delta_time_micros_formatted + '] gap time')


    def write_current_node(self):
        assert self.current_node, 'no current node to write'
        self.write_line_with_indent(self.current_node.level, self.current_node.get_text_summary())

    def navigate_to_next_node(self):
        """
        Navigate to next node in sequence. This will be the first child of the
        current node - if it has any children. Otherwise it will be the next
        sibling in sequence. If no children and no next sibling it will be the
        next sibling in sequence for some ancestor.
        """
        assert self.current_node is not None, 'no current node'
        self.previous_node = self.current_node
        first_child = self.current_node.get_first_child_call_node()
        if first_child is not None:
            self.current_node = first_child
            return True
        next_sibling_in_sequence = self.current_node.get_next_call_node()
        if next_sibling_in_sequence is not None:
            self.current_node = next_sibling_in_sequence
            return True

        # if we get here the current node has no children and no next sibling.
        # next node in this case will be the next-sibling-in-sequence for the
        # nearest ancestor that has one (or we're done).

        ancestor_node = self.current_node.get_calling_node()
        while (ancestor_node is not None):
            if ancestor_node.get_next_call_node() is not None:
                break
            # keep looking
            ancestor_node = ancestor_node.get_calling_node()

        # if we failed to find an ancestor with a next-sibling we're done
        if ancestor_node is None:
            return False

        self.current_node = ancestor_node.get_next_call_node()

        return True

    def write_tree(self):
        self.current_node = self.root_node
        self.write_line_with_indent(0, 'root')
        while (self.navigate_to_next_node()):
            if self.write_gaps:
                # report any time between sibling calls or between start of parent and first child call.
                self.write_gaps_between_sequential_nodes(self.previous_node, self.current_node)
            self.write_current_node_if_over_threshold()

        return self.output_string

class SingleItemAggregationInfo:

    def __init__(self, initial_time_nanos):
        self.count = 1
        self.total_time_nanos = initial_time_nanos

    def add_call_time(self, time_in_nanos):
        self.total_time_nanos += time_in_nanos
        self.count += 1

    def get_count(self):
        return self.count

    def inc_count(self):
        self.count += 1

    def get_total_time_nanos(self):
        return self.total_time_nanos

    def __eq__(self, other):
        return self.total_time_nanos == other.total_time_nanos

    def __lt__(self, other):
        return self.total_time_nanos < other.total_time_nanos

class AggregationWriter:

    MAX_TITLE_LENGTH = 100

    def __init__(self, root_node):
        assert root_node is not None, 'no root node'
        self.root_node = root_node
        self.aggregation = {}

    def calculate_aggregation(self):

        navigator = NodeNavigator(self.root_node)

        while (navigator.navigate_to_next_node()):
            current_node = navigator.get_current_node()
            node_name = current_node.get_method_name()

            # Skip adding time if this node has an ancestor with the same name.
            # In that situation (a recursive call) the aggregation is already
            # accounted for by the ancestor's time.
            if self.has_ancestor_same_name(current_node):
                # the count still needs to be incremented
                self.aggregation[node_name].inc_count()
                continue

            time_in_call_nanos = current_node.get_time_in_call_nanos()

            if node_name in self.aggregation:
                self.aggregation[node_name].add_call_time(time_in_call_nanos)
            else:
                self.aggregation[node_name] = SingleItemAggregationInfo(time_in_call_nanos)

    def has_ancestor_same_name(self, node):

        starting_node = node
        current_node = starting_node.get_calling_node()

        while (current_node != None and current_node != self.root_node):
            if current_node.get_method_name() == starting_node.get_method_name():
                return True
            current_node = current_node.get_calling_node()

        return False

    def write_json_aggregation(self):

        self.calculate_aggregation()

        # create a list version of the aggregation dictionary sorted on the 2nd item
        # (the total duration)
        sorted_aggregation = sorted(self.aggregation.items(), key=operator.itemgetter(1), reverse=True)
        summaries = []
        for entry in sorted_aggregation:
            node = {}
            summaries.append(node)
            statement = entry[0]
            aggregation_info = entry[1]
            time_micros = NanosToMicros.convert(aggregation_info.get_total_time_nanos())
            title = statement[0 : AggregationWriter.MAX_TITLE_LENGTH]
            if len(statement) > AggregationWriter.MAX_TITLE_LENGTH:
                title += "..."
            node["title"] = title
            node["full_statement"] = statement
            node["time"] = time_micros
            node["count"] = aggregation_info.get_count()
        return json.dumps(summaries)

    def write_text_aggregation(self):

        self.calculate_aggregation()

        text_summary = '\n\nSummary:\n'

        # create a list version of the aggregation dictionary sorted on the 2nd item
        # (the total duration)
        sorted_aggregation = sorted(self.aggregation.items(), key=operator.itemgetter(1), reverse=True)

        for entry in sorted_aggregation:
            name = entry[0]
            aggregation_info = entry[1]
            formatted_time_micros = NanosToMicros.convert_and_format(\
                aggregation_info.get_total_time_nanos())
            title = name[0 : AggregationWriter.MAX_TITLE_LENGTH]
            if len(name) > AggregationWriter.MAX_TITLE_LENGTH:
                title += '...'
            text_summary += '[' + formatted_time_micros + '] total of ' + \
                str(aggregation_info.get_count()) + ' calls of: ' + title + '\n'

        return text_summary


class ParseInfo:

    def __init__(self, event_name, unit_name, time_nanos, line_number):
        self.event_name = event_name
        self.unit_name = unit_name
        self.time_nanos = time_nanos
        self.line_number = line_number
        self.code_line_number = None
        self.variant = None
        self.sequence_number = None

    def get_event_name(self):
        return self.event_name

    def get_unit_name(self):
        return self.unit_name

    def get_time_nanos(self):
        return self.time_nanos

    def set_variant(self, variant):
        self.variant = variant

    def set_sequence_number(self, sequence_number):
        self.sequence_number = sequence_number

    def set_code_line_number(self, code_line_number):
        self.code_line_number = code_line_number

    # returns the line number in the log from which this parse info was taken
    def get_line_number(self):
        return self.line_number

    # returns the code line number field parsed from the log text (if any)
    def get_code_line_number(self):
        return self.code_line_number

    def get_variant(self):
        return self.variant

    def get_sequence_number(self):
        return self.sequence_number

    def get_description(self):
        return self.get_unit_name() + '@' + str(self.get_line_number())

    def __str__(self):
        return self.get_description()

class Parser:

    event_name_to_parser_class_map = {\
        HandledEvents.METHOD_ENTRY : 'MethodEntryParser',\
        HandledEvents.METHOD_EXIT : 'MethodExitParser',\
        HandledEvents.USER_DEBUG : 'UserDebugParser',\
        HandledEvents.CODE_UNIT_STARTED : 'CodeUnitStartedParser',\
        HandledEvents.CODE_UNIT_FINISHED : 'CodeUnitFinishedParser',\
        HandledEvents.SOQL_EXECUTE_BEGIN : 'SOQLExecuteBeginParser',\
        HandledEvents.SOQL_EXECUTE_END : 'SOQLExecuteEndParser',\
        HandledEvents.CONSTRUCTOR_ENTRY : 'ConstructorEntryParser',\
        HandledEvents.CONSTRUCTOR_EXIT : 'ConstructorExitParser',\
        HandledEvents.DML_BEGIN : 'DMLBeginParser',\
        HandledEvents.DML_END : 'DMLEndParser',\
        HandledEvents.CALLOUT_REQUEST : 'CalloutRequestParser',\
        HandledEvents.CALLOUT_RESPONSE : 'CalloutResponseParser'\
    }

    @staticmethod
    def get_parser_class_for_event(event_name):
        if not Parser.event_name_to_parser_class_map.has_key(event_name):
            return None
        return Parser.event_name_to_parser_class_map[event_name]

    def __init__(self, event_name, line_number):
        self.line_number = line_number
        self.event_name = event_name

    def get_line_number(self):
        return self.line_number

    def parse(self, fields):
        raise NotImplementedError("Please Implement this method")

    def check_field_count(self, fields, expected_count):
        assert len(fields) == expected_count, 'unexpected number of fields for ' + \
            self.event_name + ' at line: ' + str(self.line_number)

    def check_field_count_range(self, fields, lower_limit, upper_limit):
        assert len(fields) in range(lower_limit, upper_limit + 1), \
            'unexpected number of fields for ' + self.event_name + ' at line: ' + str(self.line_number)

    def parse_timestamp(self, fields):
        return self.parse_nanos(fields[0])

    def parse_nanos(self, timestamp):
        time_sections = timestamp.split(':')
        if (len(time_sections) != 3):
            raise ValueError('unexpected timestamp: ' + timestamp)
        elapsed_time_section = time_sections[2]
        start_index = elapsed_time_section.find('(')
        end_index = elapsed_time_section.find(')')
        if (start_index < 0) or (end_index < 0) or (start_index >= end_index):
            raise ValueError('unexpected elapsed time format: ' + elapsed_time_section)
        elapsed_time_nanos_str = elapsed_time_section[start_index+1:end_index]
        return long(elapsed_time_nanos_str)

    def parse_unit_name_at_end(self, fields):
        return fields[-1].strip()

    def parse_code_line_number(self, fields):

        if len(fields) < 3:
            return None

        code_line_number = None
        code_line_number_string = fields[2].strip()

        if (code_line_number_string) and (len(code_line_number_string) > 2) and \
           (code_line_number_string[0] == '[') and (code_line_number_string[-1] == ']'):

            try:
                code_line_number = int(code_line_number_string[1:-1])
            except ValueError:
                code_line_number = None

        return code_line_number


class VlocityParser:
    """
    A helper class for UserDebugParser - recognizes and handles vlocity performance logs
    """

    keywords = ['VLOCITY_METHOD_ENTRY', 'VLOCITY_METHOD_EXIT']
    divider = '&#124;' # this is actually escaped code for '|' character

    @staticmethod
    def recognizes(log_string):

        for keyword in VlocityParser.keywords:
            if log_string.startswith(keyword):
                return True

        return False

    @staticmethod
    def get_parse_info(log_string, time_nanos, line_number):

        sections = log_string.split(VlocityParser.divider)

        # expect either 2 fields - if no sequence number - or 3 if there is a sequence number
        assert len(sections) in range(2,4), 'unexpected number of fields for vlocity log: ' + log_string

        keyword = sections[0]

        assert keyword in VlocityParser.keywords

        method_name = sections[1].strip()

        parse_info = ParseInfo(keyword, method_name, time_nanos, line_number)

        if len(sections) == 3:
            sequence_number_string = sections[2].strip()
            assert sequence_number_string.startswith('S')
            sequence_number = int(sequence_number_string[1:])
            parse_info.set_sequence_number(sequence_number)

        return parse_info

class UserDebugParser(Parser):

    def __init__(self, event_name, line_number):
        Parser.__init__(self, event_name, line_number)

    def parse(self, fields):

        if len(fields) < 4:
            return None

        log_field = fields[4]

        if not VlocityParser.recognizes(log_field):
            return None

        time_nanos = self.parse_timestamp(fields)

        return VlocityParser.get_parse_info(log_field, time_nanos, self.line_number)

class MethodEntryParser(Parser):

    def __init__(self, event_name, line_number):
        Parser.__init__(self, event_name, line_number)

    def parse(self, fields):
        assert self.event_name == HandledEvents.METHOD_ENTRY
        self.check_field_count(fields, 5)
        time_nanos = self.parse_timestamp(fields)
        method_name = fields[4].strip()

        parse_info = ParseInfo(self.event_name, method_name, time_nanos, self.get_line_number())

        parse_info.set_code_line_number(self.parse_code_line_number(fields))

        return parse_info

class MethodExitParser(Parser):

    def __init__(self, event_name, line_number):
        Parser.__init__(self, event_name, line_number)

    def parse(self, fields):
        assert self.event_name == HandledEvents.METHOD_EXIT
        self.check_field_count_range(fields, 4, 5)
        time_nanos = self.parse_timestamp(fields)
        method_name = self.parse_unit_name_at_end(fields)
        parse_info = ParseInfo(self.event_name, method_name, time_nanos, \
            self.get_line_number())
        if (len(fields) == 4):
            parse_info.set_variant("constructor_exit")
        else:
            parse_info.set_variant("method_exit")
        return parse_info

class CalloutRequestParser(Parser):

    def __init__(self, event_name, line_number):
        Parser.__init__(self, event_name, line_number)

    def parse(self, fields):

        assert self.event_name == HandledEvents.CALLOUT_REQUEST
        self.check_field_count(fields, 4)
        time_nanos = self.parse_timestamp(fields)
        request_description = fields[3].strip()

        parse_info = ParseInfo(self.event_name, request_description, time_nanos, self.get_line_number())

        parse_info.set_code_line_number(self.parse_code_line_number(fields))

        return parse_info

class CalloutResponseParser(Parser):

    def __init__(self, event_name, line_number):
        Parser.__init__(self, event_name, line_number)

    def parse(self, fields):
        assert self.event_name == HandledEvents.CALLOUT_RESPONSE
        self.check_field_count(fields, 4)
        time_nanos = self.parse_timestamp(fields)
        response_description = fields[3].strip()
        parse_info = ParseInfo(self.event_name, response_description, time_nanos, self.get_line_number())
        return parse_info

class ConstructorEntryParser(Parser):
    def __init__(self, event_name, line_number):
        Parser.__init__(self, event_name, line_number)

    def parse(self, fields):
        assert self.event_name == HandledEvents.CONSTRUCTOR_ENTRY
        self.check_field_count_range(fields, 5, 6)
        time_nanos = self.parse_timestamp(fields)
        constructor_name = self.parse_unit_name_at_end(fields)
        parse_info = ParseInfo(self.event_name, constructor_name, time_nanos, self.get_line_number())
        parse_info.set_code_line_number(self.parse_code_line_number(fields))
        return parse_info

class ConstructorExitParser(Parser):
    def __init__(self, event_name, line_number):
        Parser.__init__(self, event_name, line_number)

    def parse(self, fields):
        assert self.event_name == HandledEvents.CONSTRUCTOR_EXIT
        self.check_field_count_range(fields, 5, 6)
        time_nanos = self.parse_timestamp(fields)
        constructor_name = self.parse_unit_name_at_end(fields)
        parse_info = ParseInfo(self.event_name, constructor_name, time_nanos, \
            self.get_line_number())
        return parse_info

class CodeUnitStartedParser(Parser):

    def __init__(self, event_name, line_number):
        Parser.__init__(self, event_name, line_number)

    def parse(self, fields):
        assert self.event_name == HandledEvents.CODE_UNIT_STARTED
        self.check_field_count_range(fields, 4, 6)
        time_nanos = self.parse_timestamp(fields)

        if (len(fields) <= 5):
            code_unit_name = self.parse_unit_name_at_end(fields)
        else:
            # trigger code units have two fields that compose the full name
            code_unit_name = fields[4].strip() + fields[5].strip()


        return ParseInfo(self.event_name, code_unit_name, time_nanos, self.get_line_number())

class CodeUnitFinishedParser(Parser):

    def __init__(self, event_name, line_number):
        Parser.__init__(self, event_name, line_number)

    def parse(self, fields):
        assert self.event_name == HandledEvents.CODE_UNIT_FINISHED
        self.check_field_count_range(fields, 3, 4)
        time_nanos = self.parse_timestamp(fields)

        if (len(fields) == 3):
            code_unit_name = self.parse_unit_name_at_end(fields)
        else:
            code_unit_name = fields[2].strip() + fields[3].strip()

        return ParseInfo(self.event_name, code_unit_name, time_nanos, self.get_line_number())

class SOQLExecuteBeginParser(Parser):

    def __init__(self, event_name, line_number):
        Parser.__init__(self, event_name, line_number)

    def parse(self, fields):
        assert self.event_name == HandledEvents.SOQL_EXECUTE_BEGIN
        self.check_field_count(fields, 5)
        time_nanos = self.parse_timestamp(fields)
        full_SOQL = self.parse_unit_name_at_end(fields)
        name = 'SOQL ' + full_SOQL

        parse_info = ParseInfo(self.event_name, name, time_nanos, self.get_line_number())

        parse_info.set_code_line_number(self.parse_code_line_number(fields))

        return parse_info


class SOQLExecuteEndParser(Parser):

    def __init__(self, event_name, line_number):
        Parser.__init__(self, event_name, line_number)

    def parse(self, fields):
        assert self.event_name == HandledEvents.SOQL_EXECUTE_END
        self.check_field_count(fields, 4)
        time_nanos = self.parse_timestamp(fields)
        rows_returned_desc = self.parse_unit_name_at_end(fields)

        return ParseInfo(self.event_name, rows_returned_desc, time_nanos, \
            self.get_line_number())

class DMLBeginParser(Parser):
    def __init__(self, event_name, line_number):
        Parser.__init__(self, event_name, line_number)

    def parse(self, fields):
        assert self.event_name == HandledEvents.DML_BEGIN
        self.check_field_count(fields, 6)
        time_nanos = self.parse_timestamp(fields)
        # name is formed from last 3 fields
        full_name = 'DML ' + fields[3].strip() + ' ' + fields[4].strip() + \
            ' ' + fields[5].strip()

        parse_info = ParseInfo(self.event_name, full_name, time_nanos, self.get_line_number())

        parse_info.set_code_line_number(self.parse_code_line_number(fields))

        return parse_info

class DMLEndParser(Parser):

    def __init__(self, event_name, line_number):
        Parser.__init__(self, event_name, line_number)

    def parse(self, fields):
        assert self.event_name == HandledEvents.DML_END
        self.check_field_count(fields, 3)
        time_nanos = self.parse_timestamp(fields)

        return ParseInfo(self.event_name, None, time_nanos, \
            self.get_line_number())

class LogAnalyzer:

    def __init__(self, log, output_format, threshold_nanos, write_gaps, aggregate):
        '''
        log analyzer constructor - accepts parameters to be used when 'analyze' is called

           parameters:

           log             - the entire text of the log to be analyzed
           output_format   - specifies format of output returned from analyze. must be a value from one of the
                             fields defined in the OutputFormats class (above).
           threshold_nanos - integer. specifies minimum number of nanoseconds for a call to be included in the
                             report. set value to 0 to inlude all calls.
           write_gaps      - boolean. set to true to include gaps in returned analysis. gaps are the intervals
                             between logged calls.
        '''
        self.log = log
        self.threshold_nanos = threshold_nanos
        self.write_gaps = write_gaps
        self.output_format = output_format
        self.aggregate = aggregate

        if self.output_format == OutputFormats.JSON:
            assert self.threshold_nanos == 0, 'non-zero threshold not supported for JSON output'
            assert self.write_gaps, 'gap-suppression not supported for JSON output'

    def analyze(self):
        '''performs analysis based on parameters supplied in constructor'''
        tree_builder = TreeBuilder()
        line_number = 0
        for line in self.log.splitlines():
            line_number += 1
            fields = line.split('|')
            # ignore commented-out lines. these are intended to allow post-editing of
            # log file to remove anomalies without removing the lines entirely
            if (len(line) < 2) or (line[0:2] == '//'):
                continue
            # we don't handle anything that doesn't have at least 3 fields (timestamp,
            # event name and unit name)
            if len(fields) < 3:
                continue

            event_name = fields[1]

            parsed_event_info = self.parse_event(event_name, line_number, fields)
            if parsed_event_info is None:
                continue

            tree_builder.handle_event(parsed_event_info)

        # write results
        if self.output_format == OutputFormats.JSON:
            tree_writer = JsonTreeWriter(tree_builder.get_root_node())
            json = [tree_writer.write_tree()]
            if (self.aggregate):
                aggregation_writer = AggregationWriter(tree_builder.get_root_node())
                summary = aggregation_writer.write_json_aggregation()
                json.append(summary)
            return json

        elif self.output_format == OutputFormats.TEXT:
            tree_writer = TextTreeWriter(tree_builder.get_root_node(), self.threshold_nanos, self.write_gaps)
            text = tree_writer.write_tree()
            if (self.aggregate):
                aggregation_writer = AggregationWriter(tree_builder.get_root_node())
                summary = aggregation_writer.write_text_aggregation()
                text += summary
            return text

        else:
            assert False, 'unrecognized output format: ' + str(self.output_format)


    def parse_event(self, event_name, line_number, fields):

        parser_class_name = Parser.get_parser_class_for_event(event_name)
        if parser_class_name == None:
            return None
        parser_class = getattr(sys.modules[__name__], parser_class_name)
        parser = parser_class(event_name, line_number)
        return parser.parse(fields)
