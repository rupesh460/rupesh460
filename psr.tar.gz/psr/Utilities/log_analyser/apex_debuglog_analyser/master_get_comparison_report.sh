#get comparison  report of Debug logs 

input_file1=$1
input_file2=$2
output_file=$3
output_reverse=`echo ${output_file}|awk -F ".csv" '{print $1}'`_reverse.csv
function get_summary_files(){
	input_file1=$1
	input_file2=$2
    output_file=$3
	output_reverse=$4
	
	if [ -f ${input_file1}.txt ]
	then
		rm  ${input_file1}.txt ${input_file2}.txt
	fi
        python log_analyzer_cli.py --min-time 100  ${input_file1} ${input_file1}.txt
        python log_analyzer_cli.py --min-time 100  ${input_file2} ${input_file2}.txt

 		python3 compareTextFiles.py ${input_file1}.txt ${input_file2}.txt $output_file
        python3 compareTextFiles.py ${input_file2}.txt ${input_file1}.txt ${output_reverse}
       rm ${input_file1}.txt ${input_file2}.txt
        
}
function check_if_both_file_debug_level(){

		input_file1=$1
		input_file2=$2

		APEX_CODE=`head -n 1 ${input_file1}|awk -F "APEX_CODE," '{print $2}' |awk -F ";" '{print $1}'`
		APEX_PROFILING=`head -n 1 ${input_file1}|awk -F "APEX_PROFILING," '{print $2}' |awk -F ";" '{print $1}'`
		CALLOUT=`head -n 1 ${input_file1}|awk -F "CALLOUT," '{print $2}' |awk -F ";" '{print $1}'`
		DB=`head -n 1 ${input_file1}|awk -F "DB," '{print $2}' |awk -F ";" '{print $1}'`
		NBA=`head -n 1 ${input_file1}|awk -F "NBA," '{print $2}' |awk -F ";" '{print $1}'`
		SYSTEM=`head -n 1 ${input_file1}|awk -F "SYSTEM," '{print $2}' |awk -F ";" '{print $1}'`
		VALIDATION=`head -n 1 ${input_file1}|awk -F "VALIDATION," '{print $2}' |awk -F ";" '{print $1}'`
		VISUALFORCE=`head -n 1 ${input_file1}|awk -F "VISUALFORCE," '{print $2}' |awk -F ";" '{print $1}'`
		WAVE=`head -n 1 ${input_file1}|awk -F "WAVE," '{print $2}' |awk -F ";" '{print $1}'`
		WORKFLOW=`head -n 1 ${input_file1}|awk -F "WORKFLOW," '{print $2}' |awk -F ";" '{print $1}'`


		APEX_CODE_1=`head -n 1 ${input_file2}|awk -F "APEX_CODE," '{print $2}' |awk -F ";" '{print $1}'`
		APEX_PROFILING_1=`head -n 1 ${input_file2}|awk -F "APEX_PROFILING," '{print $2}' |awk -F ";" '{print $1}'`
		CALLOUT_1=`head -n 1 ${input_file2}|awk -F "CALLOUT," '{print $2}' |awk -F ";" '{print $1}'`
		DB_1=`head -n 1 ${input_file2}|awk -F "DB," '{print $2}' |awk -F ";" '{print $1}'`
		NBA_1=`head -n 1 ${input_file2}|awk -F "NBA," '{print $2}' |awk -F ";" '{print $1}'`
		SYSTEM_1=`head -n 1 ${input_file2}|awk -F "SYSTEM," '{print $2}' |awk -F ";" '{print $1}'`
		VALIDATION_1=`head -n 1 ${input_file2}|awk -F "VALIDATION," '{print $2}' |awk -F ";" '{print $1}'`
		VISUALFORCE_1=`head -n 1 ${input_file2}|awk -F "VISUALFORCE," '{print $2}' |awk -F ";" '{print $1}'`
		WAVE_1=`head -n 1 ${input_file2}|awk -F "WAVE," '{print $2}' |awk -F ";" '{print $1}'`
		WORKFLOW_1=`head -n 1 ${input_file2}|awk -F "WORKFLOW," '{print $2}' |awk -F ";" '{print $1}'`

		if [ "${APEX_CODE}" != "${APEX_CODE_1}" ] ||  [ "${APEX_PROFILING}" !=  "${APEX_PROFILING_1}" ] ||  [ "${CALLOUT}" !=  "${CALLOUT_1}"  ] ||  [ "${DB}" !=  "${DB_1}"  ] ||  [ "${NBA}" !=  "${NBA_1}"  ] ||  [ "${SYSTEM}" !=  "${SYSTEM_1}"  ] ||  [ "${VALIDATION}" !=  "${VALIDATION_1}"  ] ||  [ "${VISUALFORCE}" !=  "${VISUALFORCE_1}"  ] ||  [ "${WAVE}" !=  "${WAVE_1}" ] ||  [ "${WORKFLOW}" !=  "${WORKFLOW_1}" ] ;

		then 
			echo "both files are not having same debug level : exit"
			exit
		fi


}

function get_dml_soql_count(){
	input_file1=$1
	input_file2=$2
	i_fname1=`echo $input_file1|awk -F "/" '{print $NF}'`
	i_fname2=`echo $input_file2|awk -F "/" '{print $NF}'`

		dml_count=`grep DML_BEGIN ${input_file1}|wc -l|awk '{print $1}'`
        soql_count=`grep SOQL_EXECUTE_BEGIN ${input_file1}|wc -l|awk '{print $1}'`
        dml_count_1=`grep DML_BEGIN ${input_file2}|wc -l|awk '{print $1}'`
        soql_count_1=`grep SOQL_EXECUTE_BEGIN ${input_file2}|wc -l|awk '{print $1}'`
        echo "FileName/Count |DML Count| SOQL Count "
 		echo "${i_fname1}|${dml_count}|${soql_count}"
 		echo "${i_fname2}|${dml_count_1}|${soql_count_1}"

}
function get_pipe_separated_file(){
	input_result_file=$1
	head -n 1 $input_result_file|sed 's/.txt//g'|sed  's/,/|/g'
	i=0
	while read -r line 
	do
		if [[ $i == 0 ]] ; then 

				i=i+1;
			else
			if [[ ${line:0:1} == '"' ]] ; then   
				query=`echo ${line}|sed 's/\",/|/g'|tr -d '"'|awk -F "|" '{print $1}'`	
				RT=`echo ${line}|sed 's/\",/|/g'|tr -d '"'|awk -F "|" '{print $2}'|sed  's/,/|/g'`
				echo "${query} | ${RT} "
			else
		
				query=`echo ${line}|sed 's/,/|/g'|awk -F "|" '{ for(i=1; i<=NF-3; i++) {print $i} }'`
				RT=`echo ${line}|sed 's/,/|/g'|awk -F "|" '{ for(i=NF-2; i<=NF; i++) {print $i} }'|tr "\n" "|"|sed 's/.$//'`
				echo "${query} | ${RT}"
			fi
		fi

	done < "${input_result_file}"

}

check_if_both_file_debug_level $input_file1 $input_file2

get_summary_files $input_file1 $input_file2 $output_file $output_reverse
get_pipe_separated_file $output_file > /tmp/.0012_DebugCountDetails
get_pipe_separated_file ${output_reverse} > /tmp/.0012_DebugCountDetails_reverse

get_dml_soql_count $input_file1 $input_file2 > /tmp/.012dmlCountDetails 
sh csvToHtmlConvertor.sh /tmp/.0012_DebugCountDetails /tmp/.012dmlCountDetails /tmp/.0012_DebugCountDetails_reverse > report.html

#clear unwanted files 
rm /tmp/.0012_DebugCountDetails  /tmp/.012dmlCountDetails /tmp/.0012_DebugCountDetails_reverse

