
#!/bin/bash
inputFileName=$1
inputFileName_1=$3
count_inputFile1=$2

 echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">"
 echo "<html>"
 echo "<style type=\"text/css\">
nulltable a:link {
        color: #666;
        font-weight: bold;
        text-decoration:none;
}
table a:visited {
        color: #999999;
        font-weight:bold;
        text-decoration:none;
}
table a:active,
table a:hover {
        text-decoration:underline;
}
table {
        font-family:Arial, Helvetica, sans-serif;
        color:#666;
        font-size:12px;
        background:#fafafa;
        border:#ccc 1px solid;
        border-radius:3px;
        border-collapse:collapse;
        border-spacing: 0;
        box-shadow: 0 1px 2px #d1d1d1;
}
table th {
        color: white;
        text-align: center;
        vertical-align: bottom;
        height:15px;
        padding-bottom: 3px;
        padding-left: 5px;
        padding-right: 5px;
        background-color:#006BB2;
}
.verticalText {
        text-align: center;
        vertical-align: middle;
        width: 15px;
        margin: 0px;
        padding:1px 1px 0;
        background-color:#006BB2;
        white-space: nowrap;
        -ms-transform: rotate(-90deg);          /* IE9+ */
        -webkit-transform: rotate(-90deg);      /* Safari 3.1+, Chrome */
        -moz-transform: rotate(-90deg);         /* FF3.5+ */
        -o-transform: rotate(-90.0deg);         /* Opera 10.5 */
}
table th:first-child {
        text-align: left;
}
table tr:first-child th:first-child {
        border-top-left-radius:3px;
        table tr:first-child th:last-child {
        border-top-right-radius:3px;
}
table tr {
        text-align: center;
}
tr.increased {background: #FFB2B2;}
table td:first-child {
        text-align: left;
        border-left: 0;
}
table td {
        padding:5px 5px 5px;
        border-right:1px solid #e0e0e0;
        border-bottom:1px solid #e0e0e0;
        border-left: 1px solid #e0e0e0;
}
table tr:last-child td {
        border-bottom:0;
}
table tr:last-child td:first-child {
        border-bottom-left-radius:3px;
}
table tr:last-child td:last-child {
        border-bottom-right-radius:3px;
}
</style>
<body style=\"margin: 10px; padding: 10px 50px 0px; font-family:Arial, Helvetica, sans-serif;\">"
echo "<h3 style=\"text-align:left\"><a id=\"top\"> Apex Debug Log Analysis Report</a></h3>"
echo "<table align=\"left\" border=1>"
echo "<tr><td>Report Generated at :</td><td>`date`</td></tr>"
echo "</table>"
echo "</p>"
echo "<hr>"


function createHTML() {
    isheader="true";
 fileName=$1
echo "<table border=1>" ;
    while read INPUT ; do
    if [[ "$isheader" == "true" ]];then
        isheader=false;
      echo "<tr><th>${INPUT//|/</th><th>}</th></tr>" ;
      continue;
    fi
    if [[ $INPUT == TOTAL* ]]; then
      echo "<tr><td align="center" bgcolor=\"FFFF66\">${INPUT//|/</td><td bgcolor=\"FFFF66\">}</td></tr>" ;
    else
        value=`echo $INPUT |awk -F "|" '{print $NF}'`
        
        if [[ ${value} < 0 ]]; then
            echo "<tr bgcolor=\"ffb399\"><td>${INPUT//|/</td><td align="center" bgcolor=\"ffb399\">}</td></tr>" ;
        else
            echo "<tr><td>${INPUT//|/</td><td align=center>}</td></tr>" ;

        fi 
    fi
    done < $1;
 echo "</table>"
 echo "<br></br>"
}
echo "<br></br>" 

echo "<h4 style=\"text-align:left\"><a id=\"top\"><u> DML/SOQL Count :</u></a></h3>"

createHTML $count_inputFile1

echo "<h4 style=\"text-align:left\"><a id=\"top\"> <u>Debug Logs Comparison ( File 2 - File1 ):</u></a></h3>"

createHTML $inputFileName

echo "<h4 style=\"text-align:left\"><a id=\"top\"> <u>Debug Logs Comparison ( File 1 - File2 ) :</u></a></h3>"

createHTML $inputFileName_1

#echo "<a href="https://vlocity.atlassian.net/wiki/spaces/EP/pages/471269696/OM+Report+Preparation+Automation+script+details">Details of  script</a>"
echo "</body> </HTML>"
