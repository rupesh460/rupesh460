import os.path
import locale
import sys
import argparse
import log_analyzer

class LogFileAnalyzer:

    def __init__(self, input_file, output_file, params):

        self.input_file = input_file
        self.output_file = output_file
        self.params = params

    def analyze(self):

        input_log_body = self.input_file.read()

        core_analyzer = log_analyzer.LogAnalyzer(input_log_body, log_analyzer.OutputFormats.TEXT, \
            self.params.get_threshold_nanos(), self.params.get_add_gaps(), self.params.get_aggregate())

        analysis_text = core_analyzer.analyze()

        self.output_file.write(analysis_text)


class Parameters:

    def parse_arguments(self, argv):

        self.parser = argparse.ArgumentParser(description='Creates a call tree from a Salesforce debug log')

        self.parser.add_argument('input_logfile', help='required. input logfile name')
        self.parser.add_argument('output_treefile', help='required. output tree file. must not already exist.')
        self.parser.add_argument('--min-time', type=int, help='number of milliseconds minimum below which an entry ' \
            '(call record) is filtered out. if unspecified all entries are reported.')
        self.parser.add_argument('--add-gaps', action='store_true', help='if specified, gaps are reported in '\
            'output tree. Gaps are the time between recorded calls. Only gaps that exceed min-time are reported.')
        self.parser.add_argument('--aggregate', action='store_true', help='if specified, calculates total time ' \
            'for each method called at least once and prints summary at end of output file.')

        self.args = self.parser.parse_args(argv)
        args = self.args

        self.log_filename = args.input_logfile
        if not os.path.isfile(self.log_filename):
            print 'input log file: ' + self.log_filename + ' is not a file'
            return False

        self.out_filename = args.output_treefile
        if os.path.exists(self.out_filename):
            print 'output file: ' + self.out_filename + ' already exists. aborting.'
            return False

        self.threshold_nanos = None
        threshold_millis = args.min_time
        if (threshold_millis != None) and (threshold_millis > 0):
            self.threshold_nanos = threshold_millis * 1000 * 1000

        return True

    def get_log_filename(self):

        return self.log_filename

    def get_out_filename(self):

        return self.out_filename

    def get_threshold_nanos(self):

        return self.threshold_nanos

    def get_add_gaps(self):

        return self.args.add_gaps

    def get_aggregate(self):

        return self.args.aggregate

    def display_usage(self):

        self.parser.print_help()

def main(argv):

    params = Parameters()
    if params.parse_arguments(argv) == False:
        return

    log_file = open(params.get_log_filename())
    out_file = open(params.get_out_filename(), 'w')

    print 'input log file is : ' + params.get_log_filename()
    print 'output log file is: ' + params.get_out_filename()

    analyzer = LogFileAnalyzer(log_file, out_file, params)
    analyzer.analyze()

    out_file.close()
    log_file.close()

if __name__ == "__main__":
    locale.setlocale(locale.LC_ALL, 'en_US')
    main(sys.argv[1:])
