# This file should be saved in UTF-8 format 
import re,sys
import collections
import csv

file1 = ''
file2 = ''
outputfile = ''

if(len(sys.argv)==4):
    file1 = sys.argv[1]
    file2 = sys.argv[2]
    outputfile = sys.argv[3]
    reader1 = open(file1,'r').readlines()
    hmap = collections.OrderedDict()
    lines = list()
    lines.append(['Query/Method Call',file1+' Timing ',file2+' Timing','Difference in micro second'])
    
    areEqual = 'true'
    lineNum = 1

    for line in reader1[1:]:
        if(line == ''):
            areEqual = 'false'
            continue
        #print('line'+str(lineNum)+'::'+line)
        pattern = '\\s\\[(.+?)µs](.+?)@'
        r = re.compile(pattern)
        m = r.search(line)
        if(m != None):
            if('SOQL' in m.group(0) and '=' in m.group(0)):
                #print('Found value::  '+m.group(0).replace('\\s','',1))
                #print('Method Timing::  '+m.group(1).replace('\\s','').replace(',',''))
                i = m.group(2).index('=')
                #print('Method Call::  '+m.group(2)[0:i-1].replace('\\s','',1))
                key = m.group(2)[0:i-1].replace('\\s','',1)
                value = m.group(1).replace('\\s','').replace(',','')
                if(key not in hmap):
                    hmap[key] = value
            else:
                #print('Found value::  '+m.group(0).replace('\\s','',1))
                #print('Method Timing::  '+m.group(1).replace('\\s','').replace(',',''))
                #print('Method Call::  '+m.group(2).replace('\\s','',1))
                key = m.group(2).replace('\\s','',1)
                value = m.group(1).replace('\\s','').replace(',','')
                if(key not in hmap):
                    hmap[key] = value
        else:
            print('NOMATCH')

        lineNum += 1
        #print(hmap)

    reader2 = open(file2,'r').readlines()
    keyset = set(hmap.keys())
    for key in keyset:
        for line in reader2[1:]:
            if(key in line):
                #print('line2::'+line)
                pattern = '\\s\\[(.+?)µs](.+?)@'
                r = re.compile(pattern)
                m = r.search(line)
                if(m != None):
                    if('SOQL' in m.group(0) and '=' in m.group(0)):
                        #print('Found value::  '+m.group(0).replace('\\s','',1))
                        #print('Method Timing::  '+m.group(1).replace('\\s','').replace(',',''))
                        i = m.group(2).index('=')
                        #print('Method Call::  '+m.group(2)[0:i-1].replace('\\s','',1))
                        key = m.group(2)[0:i-1].replace('\\s','',1)
                        value = m.group(1).replace('\\s','').replace(',','')
                        if(key in hmap.keys()):
                            diff = int(hmap.get(key)) - int(value)
                            #print('this is the difference:::'+str(diff))
                            lines.append([key,hmap.get(key),value,diff])
                        else:
                            lines.append([key,0,value,0-int(value)])
                    else:
                        #print('Found value::  '+m.group(0).replace('\\s','',1))
                        #print('Method Timing::  '+m.group(1).replace('\\s','').replace(',',''))
                        #print('Method Call::  '+m.group(2).replace('\\s','',1))
                        key = m.group(2).replace('\\s','',1)
                        value = m.group(1).replace('\\s','').replace(',','')
                        if(key in hmap.keys()):
                            diff = int(hmap.get(key)) - int(value)
                            #print('this is the difference:::'+str(diff))
                            lines.append([key,hmap.get(key),value,diff])
                        else:
                            lines.append([key,0,value,0-int(value)])
                else:
                    print('NOMATCH')
else:
    if (file1 == '' or file2 == '' or outputfile == '' ):
        print('Please input the logfile1,logfile2,outputfilename in order')
        sys.exit()
#print(lines)
with open(outputfile, 'w') as writeFile:
    writer = csv.writer(writeFile)
    writer.writerows(lines)
writeFile.close()
