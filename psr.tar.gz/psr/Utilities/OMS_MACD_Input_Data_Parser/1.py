import pandas as pd
import sys
import numpy as np

filename1="sqloutput2.csv"
filename2="results_tem.csv"
data = pd.read_csv(filename1, encoding='ISO-8859\xe2\x80\x931')
data1 = pd.read_csv(filename2, encoding='ISO-8859\xe2\x80\x931')
result_df = pd.merge(data, data1, on='RootItemId__c', how='left')


#result_df.rename(columns={'RootItemId__c':'AssetId_add'}, inplace=True)
#result_df.rename(columns={'Account.Name':'AccountName'}, inplace=True)

#comment below 3 lines for assetize
result_df.rename(columns={'RootItemId__c':'AssetId_addNonAssetize'}, inplace=True)
result_df.rename(columns={'Account.Name':'AccountNameNonAssetize'}, inplace=True)
result_df.rename(columns={'AccountId':'AccountIdNonAssetize'}, inplace=True)

#result_df.drop_duplicates(subset ="Id",inplace = True)
#result_df.dropna(self, axis=0, how='any', thresh=None, subset=None, inplace=False)

#result_df1=result_df[pd.notnull(result_df['AssetId_add08'])]

result_df1=result_df[pd.notnull(result_df['AssetId_add06NonAssetize'])]
result_df1.to_csv("results.csv", index=False)
