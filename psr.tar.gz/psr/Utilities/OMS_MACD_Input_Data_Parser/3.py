import pandas as pd
import sys
import numpy as np

filename1="sqloutput1.csv"
data = pd.read_csv(filename1, encoding='ISO-8859\xe2\x80\x931')

data1= data[["RootItemId__c","Id"]]
super_assetid_list = []
grp = data1.groupby('RootItemId__c').agg(Id=('Id', list)).reset_index()
assetid_list=grp['Id'].tolist()
data2 = pd.DataFrame(assetid_list,columns=['RootItemId__c','AssetId_add02NonAssetize','AssetId_add03NonAssetize','AssetId_add04NonAssetize','AssetId_add05NonAssetize','AssetId_add06NonAssetize','AssetId_add07NonAssetize'])
#data2 = pd.DataFrame(assetid_list,columns=['RootItemId__c','AssetId_add02','AssetId_add03','AssetId_add04','AssetId_add05','AssetId_add06','AssetId_add07','AssetId_add08','AssetId_add09','AssetId_add10'])
data2.to_csv("results_tem.csv",index=False)
