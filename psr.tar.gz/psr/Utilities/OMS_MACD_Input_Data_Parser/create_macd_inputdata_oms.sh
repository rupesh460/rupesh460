userName=rkasi@perftest2.ldv.org
passWord=**********
envtype=test


StartTime=2020-03-31T04:00:00.000Z
EndTime=2020-03-31T06:50:00.000Z
#StartTime=2020-01-14T11:32:00.000Z
#EndTime=2020-01-14T15:51:00.000Z
#StartTime=2019-11-19T14:22:00.000Z
#EndTime=2019-11-19T15:22:00.000Z

if [ -e force ]
then
	SQL_getAssetDetails="SELECT AccountId,ID,Rootitemid__c,Account.Name from Asset WHERE CreatedDate > ${StartTime} AND CreatedDate < ${EndTime} AND PriceListId__c = 'a2rL0000000qD5XIAU'"
	./force login -i=${envtype} -u=${userName} -p=${passWord}
	./force query ${SQL_getAssetDetails}| tr -d '"' > sqloutput1.csv

#	SQL_getAssetReferenceDetails="SELECT AccountId,AssetReferenceId__c,Account.Name,Rootitemid__c  from Asset WHERE Name = 'Plan Prepago Nacional-10' and  CreatedDate > ${StartTime} AND CreatedDate < ${EndTime}"		
	SQL_getAssetReferenceDetails="SELECT AccountId,AssetReferenceId__c,Account.Name,Rootitemid__c  from Asset WHERE Name = 'Non-Assetize-10' and  CreatedDate > ${StartTime} AND CreatedDate < ${EndTime}"
	./force login -i=${envtype} -u=${userName} -p=${passWord}
	./force query ${SQL_getAssetReferenceDetails}| tr -d '"' > sqloutput2.csv
	
	python3 3.py
	python3 1.py
	
else
	echo "Warning : force client is not present in current folder "
	echo "please download it from https://force-cli.heroku.com/  and save it in current folder, change permission to excecutable chmod 755 force"
	exit
fi


