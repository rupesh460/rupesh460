#!/bin/bash
#This script is helpful in getting test data for MACD order scenerio
# Author: sranjan@vlocity.com

StartTime=2019-03-08T00:31:00.000Z
EndTime=2019-03-08T00:35:00.000Z

#Below inputs need to be change if you want to run for some other environment or you want to run with more number of threads to process more amount of data 
username=kasi@perftest3.sbx
password=*******
logs=logs_new
no_of_thread=20

echo "script started at `date`"

function collectDataUsingForceCli(){
        outputFile=$1
	SQL_getAssetDetails="SELECT AccountId,ID,Rootitemid__c,Account.Name from Asset WHERE CreatedDate > ${StartTime} AND CreatedDate < ${EndTime}"
	./force login -i=test -u=${username} -p=${password}
	./force query ${SQL_getAssetDetails}| tr -d '"' > $outputFile
}
mkdir -p $logs
collectDataUsingForceCli ${logs}/sqloutput.csv

awk -F "," '{print $4}' ${logs}/sqloutput.csv|uniq > ${logs}/unique_RootId.csv 
#Divide files into 20 Parts for fast processing 

count_unique_root_id=`wc -l ${logs}/unique_RootId.csv|awk '{print $1}'`
count_get_processed_per_file=$((count_unique_root_id / no_of_thread))
startLine=2
endLine=$count_get_processed_per_file
inputFile=${logs}/unique_RootId.csv

function parse_the_sql_output(){
        inputFile=$1
        > ${inputFile}_result
        while read -r line ; do
                AccountId=`grep $line ${logs}/sqloutput.csv |awk -F "," '{print $2}'|sort|uniq|head -n1`
                Rootitemid_add=`grep $line ${logs}/sqloutput.csv |awk -F "," '{print $4}'|sort|uniq|head -n1`
                AccountName=`grep $line ${logs}/sqloutput.csv |awk -F "," '{print $1}'|sort|uniq|head -n1`
                AssetIds=`grep $line ${logs}/sqloutput.csv |awk -F "," '{print $3}'|tr "\n" ","|sed 's/.$//'`
                echo $AccountId,$Rootitemid_add,$AccountName,$AssetIds >> ${inputFile}_result

        done < "$inputFile"
}


for((i=1; i<=${no_of_thread}; i++))
do
sed -n "${startLine} , ${endLine}p" $inputFile > ${inputFile}_$i
	if [ "$i" != "$no_of_thread" ]
		then
		parse_the_sql_output ${inputFile}_$i &
        else 
		parse_the_sql_output ${inputFile}_$i
                sleep 300
        fi
startLine=$(( $endLine + 1 ))
endLine=$(( $startLine + $count_get_processed_per_file ))

done 

>${logs}/Result.csv
for((i=1; i<=${no_of_thread}; i++))
do
	cat ${logs}/unique_RootId.csv_${i}_result  >> ${logs}/Result.csv
done
echo "script completed at `date`"
rm ${logs}/unique*

