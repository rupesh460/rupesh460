import requests
import json
import re
import datetime
import os,sys

params = {
    "grant_type": "password",
    "client_id": "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG", # Consumer Key
    "client_secret": "7119599995527965426", # Consumer Secret
    "username": "kasi@perftest3.sbx", # The email you use to login
    "password": "**********" # Concat your password and your security token
}
r = requests.post("https://test.salesforce.com/services/oauth2/token", params=params)
access_token = r.json().get("access_token")
instance_url = r.json().get("instance_url")
#print("Access Token:", access_token)
#print("Instance URL", instance_url)

headers = {
        'Content-type': 'application/json',
        'Accept-Encoding': 'gzip',
        'Authorization': 'Bearer %s' % access_token
}

def sf_api_call(action, parameters = {}, method = 'get', data = {}):
    """
    Helper function to make calls to Salesforce REST API.
    Parameters: action (the URL), URL params, method (get, post or patch), data for POST/PATCH.
    """
    if method == 'get':
        r = requests.request(method, instance_url+action, headers=headers, timeout=30)
    elif method in ['post']:
        r = requests.request(method, instance_url+action, headers=headers, json=data, timeout=10)
    else:
        # other methods not implemented in this example
        raise ValueError('Method should be get or post or patch.')
    print('Debug: API %s call: %s' % (method, r.url) )
    if r.status_code < 300:
        if method=='patch':
            return None
        else:
            return r.json()
    else:
        raise Exception('API error when calling %s : %s' % (r.url, r.content))

startTime = '2018-06-28T10:11:23.000Z'
endTime = '2018-06-30T10:10:50.000Z'
#SELECT CreatedDate,Id FROM EventLogFile WHERE CreatedDate <= 2018-06-30T10:10:50.000Z AND CreatedDate >= 2018-06-28T10:11:23.000Z

r = sf_api_call('/services/data/v43.0/query/?q=SELECT CreatedDate,Id FROM EventLogFile WHERE CreatedDate <= 2018-06-30T10:10:50.000Z AND CreatedDate >= 2018-06-28T10:11:23.000Z')
json_encoded = json.dumps(r)
#print json_encoded
logfileids = re.findall('\"Id\": \"(.*?)\"',json_encoded)

path = datetime.datetime.now()
print (path.strftime("%Y-%m-%d %H:%M"))
#os.mkdir(, 0755 );

for id in logfileids:
	log = requests.request('get','https://cs17.salesforce.com/services/data/v43.0/sobjects/EventLogFile/'+id+'/LogFile',headers=headers,timeout=30)
	#print log.text
	file = open(id+".csv", "w")
	file.write(log.text)
	file.close()

