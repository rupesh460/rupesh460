#!/bin/bash
# Scripts to purge accounts and orders
# What script does : Get the list of accounts corresponds to given timeframe and delete all the orders and accounts as well
# Author:  syathiraju@vlocity.com
# prerequisites : force client
############# How to Run the script ########
#sh cleanup.sh '2019-11-13T00:00:00.000Z' '2019-11-14T00:00:00.000Z'
####################################### environment details #######################################
userName=perf-cmt-release-bmk@vlocity.com
passWord=***********
envtype=login
#input_account_list=$1
startdate=$1
enddate=$2
###################################################################################################

code1="for(Order o : oList)
{
    o.Status = 'Draft';
}
update oList;
delete oList;"

code2="delete aList;"
#check if force client binary  output folder if not present
if [ -e force ]
then
	./force login -i=${envtype} -u=${userName} -p=${passWord}
	./force query "SELECT Id FROM Account where CreatedDate > ${startdate} and CreatedDate < ${enddate}  order by CreatedDate desc"  > results_temp.log
	sed -e 's/"//g' results_temp.log > 1.csv
	sed 's/.000+0000//g' 1.csv |tail -n +2 | head -n-1 > 1.txt
	rm -rf results_temp.log 1.csv
	while read -r line;do
		echo "List<Order> oList = [SELECT Id, Status From Order where AccountId = '${line}'];" > test.apex
		echo "$code1" >> test.apex
		echo "List<Account> aList = [SELECT Id FROM Account where Id ='${line}'];" >> test.apex
		echo "$code2" >> test.apex
		./force login -i=${envtype} -u=${userName} -p=${passWord}
		./force apex test.apex
	done < "1.txt"
else
	echo "Warning : force client is not present in current folder "
	echo "please download it from https://force-cli.heroku.com/  and save it in current folder, change permission to excecutable chmod 755 force"
	exit
fi
