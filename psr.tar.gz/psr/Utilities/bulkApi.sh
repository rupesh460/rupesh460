#!/bin/bash
# Scripts to Use Salesforce BulkApi in order to generate Test Data for performance testing
# Help Link : https://vlocity.atlassian.net/wiki/spaces/EP/pages/454754828/SalesForce+Bulk+API+usage#SalesForceBulkAPIusage-UsingBulkAPIsfromthescript.
# Limitation : One Test data file can not contains more than 150 MB  of data
# Author sranjan@vlocity.com
###################################### Please provide Input details here #########################################################
############# Salesforce Org Details #############
username=rkasi@perftest2.ldv.org
password=***********
client_secret=5644903920226338215
client_id=3MVG9MHOv_bskkhR5LPzqvofeG92uGkYzDJ8QAGeB7zALujRr0TGKmehi5HFuZZU6l2GxF76.Ddpoz1NpptCX
orgurl="cs8.salesforce.com"
############# Format of file and Data file details to be uploaded #############
format_file=accountFormat.json
fileToUpload=Test_accounts_Perf2.csv
##############################################################################################

#Get access token
access_token=`curl -X POST -H "content-type: application/x-www-form-urlencoded" -d "username=$username&password=$password&client_secret=$client_secret&client_id=$client_id&grant_type=password" https://test.salesforce.com/services/oauth2/token |awk -F '"' '{print $4}'`
#step 1 - Bulk API  Create Job Using POST Method
jobid=`curl -X POST -H "Authorization:Bearer $access_token" -H "Content-Type: application/json; charset=UTF-8" -H "Accept: application/json" --data "@${format_file}" https://${orgurl}/services/data/v44.0/jobs/ingest/ |awk -F "ingest" '{print $2}'|awk -F "/" '{print $2}'`

#2 Upload CSV Using PUT Method (we can submit CSV data that does not in total exceed 150 MB in size (after base64 encoding), If more than one than need to submit multiple CSV files)
UploadCSV_Details=`curl -X PUT -H "Authorization:Bearer $access_token" -H "Content-Type: text/csv" -H "Accept: application/json"  --data-binary @${fileToUpload} "https://${orgurl}/services/data/v44.0/jobs/ingest/$jobid/batches/"`
echo "Status of Uploading CSV File ${fileToUpload} :  is ------ ${UploadCSV_Details}"

#3 Close Job (Once we're done submitting data, we can inform Salesforce that the job is ready for processing by closing the job)
CloseJob_Status=`curl -X PATCH  -H "Authorization:Bearer $access_token" -H "Content-Type: application/json; charset=UTF-8" -H "Accept: application/json" --data "{\"state\" : \"UploadComplete\"}" https://${orgurl}/services/data/v44.0/jobs/ingest/$jobid/`
echo "Status of Closing the Jobs is ${CloseJob_Status}"

#4 Get status
Status=`curl -X GET  -H "Authorization:Bearer $access_token" -H "Content-Type: application/json; charset=UTF-8" -H "Accept: application/json" https://${orgurl}/services/data/v44.0/jobs/ingest/$jobid/`
echo "Status of Job id : ${jobid} is ------ ${Status}"

JobState=`echo ${Status} |awk -F "state" '{print $2}'|awk -F "," '{print $1}'|tr -d ':"'`
#checking the state of job completion every 5 min
while [ "${JobState}" != "JobComplete" ]
		do
		sleep 300
		Status=`curl -X GET  -H "Authorization:Bearer $access_token" -H "Content-Type: application/json; charset=UTF-8" -H "Accept: application/json" https://${orgurl}/services/data/v44.0/jobs/ingest/$jobid/`
		JobState=`echo ${Status} |awk -F "state" '{print $2}'|awk -F "," '{print $1}'|tr -d ':"'`
		echo $Status
	done
echo "Job completed with status $Status"

