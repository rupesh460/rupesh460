#!/bin/bash
# Scripts to get Averrage response time of 11th to 60th  samples with minimum RT over the test for gatling result
# What script does : sort the RT in decending order for each transaction and then calculate the average response time 
# Author version 1:  syathiraju@vlocity.com
# Modified by sranjan@vlocity.com
# prerequisites : python3 and pandas should be installed on the system
#input gatling simulation file
############# How to Run the script ########
#  sh get_avg_11_60th_sample_RT.sh simulation.log 

###################################### Input  #########################################################
input_simulation_file=$1
##################################################################################################################################

grep "REQUEST" $input_simulation_file | grep "OK" | awk '{print $3}' | sort -r | uniq  > transaction_name.log
rm -rf final_results_logs rawlogs
mkdir rawlogs final_results_logs 

#python script to parse the simulation file
read -r -d '' parse_Script <<-"EOF"
	import pandas as pd
	import sys
	import numpy as np

	inputfile1 =sys.argv[1]
	inputfile_name = "rawlogs" + "/" + inputfile1 + ".csv"
	dir= sys.argv[2]
	filename= dir +  "/" + inputfile1 + ".csv"
	df = pd.read_csv(inputfile_name)
	#print(df.head())

	df['RT'] = df['End']-df['Start']
	#print(df.head())

	df.to_csv(filename,index=False)
	df1= df.sort_values('RT')
	df2 = df1[10:60]

	res=df2["RT"].mean()
	results = inputfile1 + " " + str(res)
	print(results)
	#print(df2.head())
	#print(df2.tail())
EOF


while read -r line
do

	echo "TransactionName,Start,End,Status" > rawlogs/${line}.csv
	grep  -w ${line} ${input_simulation_file} |grep OK |grep -v "KO" | awk '{print $3,$4,$5,$6}'| sed  's/ /,/g' >> rawlogs/${line}.csv
	python3 -c "$parse_Script" ${line} final_results_logs
done < "transaction_name.log"
rm -rf rawlogs raw
