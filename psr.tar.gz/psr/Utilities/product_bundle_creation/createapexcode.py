#!/usr/bin/python
# -*- coding: utf-8 -*-
import pandas as pd
import sys
import numpy as np



inputdir = sys.argv[1]
outputdir = sys.argv[2]


def createapexcode(filename,outdir,output_filename,obj_name,obj_instance_name_prefix,obj_instance_list_name):
    data = pd.read_csv(filename, encoding='ISO-8859\xe2\x80\x931')
    col_names = list(data.columns)
    outputfile = outdir + '/' + output_filename
    f = open(outputfile, 'a+')

    tmp_string1='List<'+obj_name+'> '+obj_instance_list_name+' = new '+'List<'+obj_name+'>();'
    f.write(tmp_string1)
    f.write('\n')

    for i in range(data.shape[0]):
        obj_instance_name = obj_instance_name_prefix + str(i)
        tmp_string2= obj_name + ' ' + obj_instance_name  + ' = new ' + obj_name +'();'
        f.write(tmp_string2)
        f.write('\n')
        for col in col_names:
            if data.iloc[i][col] != 'NotAvailable':
                code = obj_instance_name + '.' +  col + ' = ' \
                    + str(data.iloc[i][col]) + ';'
                f.write(code)
                f.write('\n')

            continue;

        tmp_string3 = obj_instance_list_name+ '.add(' + obj_instance_name + ');'
        f.write(tmp_string3)
        f.write('\n')
    f.close()



if __name__ == "__main__":

    ifile=inputdir +"/"+"pricebook.csv"
    createapexcode(ifile,outputdir,'createpricebook','Pricebook2','pb','PriceBookList')

    ifile=inputdir +"/"+"pricelist.csv"
    createapexcode(ifile,outputdir,'createpricelist','PriceList__c','pl','PriceListList')

    ifile=inputdir +"/"+"product.csv"
    createapexcode(ifile,outputdir,'createproduct','Product2','p','ProductList')


    ifile=inputdir +"/"+"pricelistentry.csv"
    createapexcode(ifile,outputdir,'createpricelistentry','PriceListEntry__c','ple','PriceListEntryList')

    ifile=inputdir +"/"+"parent_child_relation.csv"
    createapexcode(ifile,outputdir,'createparentchildrelation','ProductChildItem__c','pcr','ParentChildRelList')

    ifile = inputdir + "/" + "orcplandef.csv"
    createapexcode(ifile, outputdir, 'createorcplandef', 'OrchestrationPlanDefinition__c', 'opd', 'OrcPlanDefList')

    ifile = inputdir + "/" + "orcitemdef.csv"
    createapexcode(ifile, outputdir, 'createorcitemdef', 'OrchestrationItemDefinition__c', 'oid', 'OrcItemDefList')


    ifile = inputdir + "/" + "orcdepdef.csv"
    createapexcode(ifile, outputdir, 'createorcdepdef', 'OrchestrationDependencyDefinition__c', 'odd', 'OrcDepDefList')

    ifile = inputdir + "/" + "orcscn.csv"
    createapexcode(ifile, outputdir, 'createorcscn', 'OrchestrationScenario__c', 'os', 'OrcScnList')

    ifile = inputdir + "/" + "decomrel.csv"
    createapexcode(ifile, outputdir, 'createdecmrel', 'DecompositionRelationship__c', 'dr', 'DecomRelList')


