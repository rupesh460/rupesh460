#!/bin/bash
#ActivatedDate","XOMDecompEndTime__c","XOMDecompStartTime__c","XOMOrchStartTime__c","XOMOrderStartTime__c"
#2019-01-15 07:06:13,2019-01-15 07:06:02,2019-01-15 07:05:59,2019-01-15 07:06:02,2019-01-15 07:05:59
#Orchestration time = Activation time - XOMOrchStartTime__c =(A2-D2)*86400
#Decomposition time = XOMDecompEndTime__c - XOMDecompStartTime__c =(B2-C2)*86400
inputFileName=$1
outputDirectoryName=$2 
dateTag=$(date +%Y%m%d-%H%M%S)
outPut_FileName=OrchestrationDetails
#####function convertDateTimetoTimeStamp convert date time to timestamp on mac system
#input 2018-12-26 14:01:04
#output 1545813064
#output=$(date -j -f "%Y-%m-%d %T" "${input}" "+%s")
## provide Start Time and End time in timestamp format 
##input 1545813064, 1545813124 
##output 60
function getResponseTime(){
    T1=$1
    T2=$2
    echo $(( T1 - T2 ))
}
    
while read -r line ; do 
    ActivationDate=`echo $line |awk -F "," '{print $1}'`
    XOMOrchStartTime_c=`echo $line |awk -F "," '{print $4}'`
    XOMDecompEndTime_c=`echo $line |awk -F "," '{print $2}'`
    XOMDecompStartTime_c=`echo $line |awk -F "," '{print $3}'`
 #echo $ActivationDate $XOMOrchStartTime_c $XOMDecompEndTime_c $XOMDecompStartTime_c
    ActivationDate_TM=$(date -j -f "%Y-%m-%d %T" "${ActivationDate}" "+%s")
    XOMOrchStartTime_TM=$(date -j -f "%Y-%m-%d %T" "${XOMOrchStartTime_c}" "+%s")
    XOMDecompEndTime_TM=$(date -j -f "%Y-%m-%d %T" "${XOMDecompEndTime_c}" "+%s")
    XOMDecompStartTime_TM=$(date -j -f "%Y-%m-%d %T" "${XOMDecompStartTime_c}" "+%s")
#echo $ActivationDate_TM $XOMOrchStartTime_TM $XOMDecompEndTime_TM  $XOMDecompStartTime_TM
    orderprocessingtime=`getResponseTime ${ActivationDate_TM} ${XOMOrchStartTime_TM}`
    decompositionTime=`getResponseTime ${XOMDecompEndTime_TM} ${XOMDecompStartTime_TM}` 
    echo "${ActivationDate} " "  ${decompositionTime} " >> ${outputDirectoryName}/decom_${outPut_FileName}.log
    echo "${ActivationDate} " " ${orderprocessingtime}" >> ${outputDirectoryName}/order_${outPut_FileName}.log
done < "${inputFileName}"