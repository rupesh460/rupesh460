#Provide input as start time and EndTime "2019-02-28T07:40:49.000Z" 
#################################################################################
StartTime="2019-02-26T12:48:49.000Z"
EndTime="2019-02-26T13:53:49.000Z"
TestDir=/Users/sranjan/logs/cmttest
#Number of Hours/ Interval you want to split orchestration timing  
NoOfSplit=6
#Provide the interval into which
input_intervalInSecond=600
#################################################################################
#########Change salesforce details if you want to run against other environment(Default is perf2) 
#Provide Salesforce Org Details
username=rkasi@perftest2.ldv.org
password=***********
client_secret=5644903920226338215
client_id=3MVG9MHOv_bskkhR5LPzqvofeG92uGkYzDJ8QAGeB7zALujRr0TGKmehi5HFuZZU6l2GxF76.Ddpoz1NpptCX
orgurl="cs8.salesforce.com"

#How to run the script 
#sh downloadResultWorkbench.sh "2019-02-26T12:48:49.000Z" "2019-02-26T14:53:49.000Z" /Users/sranjan/logs/ 15 3600 rkasi@perftest2.ldv.org password  5644903920226338215  3MVG9MHOv_bskkhR5LPzqvofeG92uGkYzDJ8QAGeB7zALujRr0TGKmehi5HFuZZU6l2GxF76.Ddpoz1NpptCX cs8.salesforce.com

sh downloadResultWorkbench.sh $StartTime $EndTime ${TestDir} $NoOfSplit $input_intervalInSecond $username  $password $client_secret $client_id "${orgurl}"
