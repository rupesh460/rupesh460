#!/usr/bin/env python
# encoding=utf8
import sys
#reload(sys)
#sys.setdefaultencoding('utf8')
import json

from pprint import pprint


json_file=sys.argv[1]
json_data=open(json_file)
j = json.load(json_data)

def main():
  print ("TimestampReady__c" ',' "LeadTimeRunning__c" ',' "LeadTimeCompleted__c" ',' "Name" ',' "State__c" ',' "OrchestrationItemType__c" ',' "ID" ',' "TimestampRunning__c" ',' "TimestampCompleted__c" ',' "OrchestrationQueueId__c")
  for entry in j['records']:
     try: print (entry['TimestampReady__c'], ',' ,entry['LeadTimeRunning__c'], ',', entry['LeadTimeCompleted__c'], ',' , entry['Name'], ',' , entry['State__c'], ',' ,entry['OrchestrationItemType__c'], ',',  entry['Id'], ',' ,entry['TimestampRunning__c'], ',',  entry['TimestampCompleted__c'], ',',  entry['OrchestrationQueueId__c']) 
     except KeyError: pass

if __name__ == "__main__":
	    main()

