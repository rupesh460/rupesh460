#!/usr/bin/env python
# encoding=utf8
import sys
#reload(sys)
#sys.setdefaultencoding('utf8')
import json

from pprint import pprint


json_file=sys.argv[1]
json_data=open(json_file)
j = json.load(json_data)

def main():
  print ("ActivatedDate" ',' "XOMDecompEndTime__c" ',' "XOMDecompStartTime__c" ',' "XOMOrchStartTime__c" ',' "XOMOrderStartTime__c" ',' "Id" ',' "Status" ',' "FulfilmentStatus__c")
  for entry in j['records']:
     try: print (entry['ActivatedDate'], ',' ,entry['XOMDecompEndTime__c'], ',' ,entry['XOMDecompStartTime__c'], ',' , entry['XOMOrchStartTime__c'], ',' , entry['XOMOrderStartTime__c'], ',' , entry['Id'], ',' , entry['Status'], ',' , entry['FulfilmentStatus__c'])
     except KeyError: pass

if __name__ == "__main__":
	    main()
