#source ~/.profile
#Provide input as start time and EndTime "2019-02-28T07:40:49.000Z" 
#################################################################################
StartTime=$1
EndTime=$2
TestDir=$3
#Number of Hours/ Interval you want to split orchestration timing  
NoOfSplit=$4
#Provide the interval in second to get break down of data 
input_intervalInSecond=$5
################################################################################# 
#Provide Salesforce Org Details
username=$6
password=$7
client_secret=$8
client_id=$9
orgurl=${10}
echo "started script at"
date
outputDir=${TestDir}/rawLogs
if [ ! -d $outputDir ]
then
   echo "Creating output directory ${outputDir} "
        mkdir -p ${outputDir}
fi
#Define Sqls
SQL_Order="q=SELECT+ActivatedDate,XOMDecompEndTime__c,XOMDecompStartTime__c,XOMOrchStartTime__c,XOMOrderStartTime__c,id,status,FulfilmentStatus__c+FROM+Order+WHERE+XOMDecompEndTime__c+!=+null+and+CreatedDate+>+${StartTime}+AND+CreatedDate+<+${EndTime}+AND+Status+=+'Activated'+order+by+activateddate+asc" 
SQL_Callout="q=select+name,state__c,orchestrationItemType__c,id,LeadTimeRunning__c,LeadTimeCompleted__c,TimestampReady__c,TimestampRunning__c,TimestampCompleted__c,OrchestrationQueueId__c+from+OrchestrationItem__c+where+orchestrationItemType__c='Callout'+and+CreatedDate+>+${StartTime}+AND+CreatedDate+<+${EndTime}+order+by+TimestampReady__c+asc"
SQL_Autotask="q=select+name,state__c,orchestrationItemType__c,id,LeadTimeRunning__c,LeadTimeCompleted__c,TimestampReady__c,TimestampRunning__c,TimestampCompleted__c,OrchestrationQueueId__c+from+OrchestrationItem__c+where+Name='Update+inventory+items'+and+CreatedDate+>+${StartTime}+AND+CreatedDate+<+${EndTime}+order+by+TimestampReady__c+asc"
SQL_AutoTask_Callout="q=select+TimestampReady__c,LeadTimeRunning__c,LeadTimeCompleted__c,name,state__c,orchestrationItemType__c,id,TimestampRunning__c,TimestampCompleted__c,OrchestrationQueueId__c+from+OrchestrationItem__c+where+orchestrationItemType__c+in+('AutoTask',+'Callout')+And+CreatedDate+>+${StartTime}++AND+CreatedDate+<+${EndTime}+order+by+TimestampReady__c+asc"


#Function to get sql data from salesforce workbench
function getDataUsingSFWorkbench(){
	SQL=$1
# Get Workbench Oath query and save it to file access_token
	access_token=`curl -X POST -H "content-type: application/x-www-form-urlencoded" -d "username=$username&password=$password&client_secret=$client_secret&client_id=$client_id&grant_type=password" https://test.salesforce.com/services/oauth2/token |awk -F '"' '{print $4}'`

	order_SQLOutput=`curl -X GET   -H "Authorization:Bearer $access_token" "https://$orgurl/services/data/v43.0/query?${SQL}"`
	isSqlExecutionDone=`echo $order_SQLOutput|awk -F "done" '{print $2}'|awk -F ":" '{print $2}'|awk -F "," '{print $1}'`
if [ "$isSqlExecutionDone" = "true" ]
	then
          echo $order_SQLOutput 
	else
		echo $order_SQLOutput |awk -F "}]}" '{print $1 "}"}' 
		while [ "${isSqlExecutionDone}" != "true" ]
		do
			order_nextUrl=`echo $order_SQLOutput|awk -F "records" '{print $1}'|awk -F "nextRecordsUrl" '{print $2}'|tr -d '":,'`
			order_SQLOutput=`curl -X GET   -H "Authorization:Bearer $access_token" "https://$orgurl${order_nextUrl}"`
			isSqlExecutionDone=`echo $order_SQLOutput|awk -F "done" '{print $2}'|awk -F ":" '{print $2}'|awk -F "," '{print $1}'`
				if [ "$isSqlExecutionDone" = "false" ]
				then
          			echo $order_SQLOutput |awk -F "records" '{print $2}'|cut -c 4-|sed 's/^/,/' |awk -F "}]}" '{print $1 "}"}' 
				else
					echo $order_SQLOutput |awk -F "records" '{print $2}'|cut -c 4-|sed 's/^/,/'  
				fi
		done
fi
}
function runSql(){

	getDataUsingSFWorkbench ${SQL_Order} > ${outputDir}/orderDetails.json
	getDataUsingSFWorkbench ${SQL_Callout} > ${outputDir}/calloutDetails.json
	getDataUsingSFWorkbench ${SQL_Autotask} > ${outputDir}/autoTaskDetails.json
	getDataUsingSFWorkbench ${SQL_AutoTask_Callout} > ${outputDir}/autoTaskCalloutDetails.json
}
#Parse and plot graph for Autotask, Callout completion and running
function getCsvFiles(){
	python3 pythonJsonParser/parseDownlodedJson_DecomOrder.py ${outputDir}/orderDetails.json |sed 's/.000+0000//g' >  ${outputDir}/OrderOrchestration.csv
	python3 pythonJsonParser/parseDownlodedJson_Callout_Autotask.py ${outputDir}/calloutDetails.json |sed 's/.000+0000//g'> ${outputDir}/calloutDetails_OrchDetails.csv
	python3 pythonJsonParser/parseDownlodedJson_Callout_Autotask.py ${outputDir}/autoTaskDetails.json |sed 's/.000+0000//g'> ${outputDir}/autoTaskDetails_OrchDetails.csv
	python3 pythonJsonParser/parseDownlodedJson_Callout_Autotask.py ${outputDir}/autoTaskCalloutDetails.json|sed 's/.000+0000//g' > ${outputDir}/LeadTimeRunning.csv	
}
function PraseCallOutAutoTaskDetails(){
		grep Completed ${outputDir}/LeadTimeRunning.csv|sed 1d|sed  's/T/ /g'|awk -F ","  '{ print $1 " " $2*.001 }'|awk '{print $2 " " $3}'|tr -d "'" > ${outputDir}/LeadTimeRunning.txt
		grep Completed ${outputDir}/LeadTimeRunning.csv|sed 1d|grep AutoTask|sed  's/T/ /g'|awk -F ","  '{ print $1 " " $3*.001 }'|awk '{print $2 " " $3}'|tr -d "'" > ${outputDir}/LeadTimeCompleted_Autotask.txt
		grep Completed ${outputDir}/LeadTimeRunning.csv|sed 1d|grep Callout |sed  's/T/ /g'|awk -F ","  '{ print $1 " " $3*.001 }'|awk '{print $2 " " $3}'|tr -d "'" >  ${outputDir}/LeadTimeCompleted_Callout.txt
}

#Plot Graph for Callout and Autotask 
function plotCalloutAutotaskDetailsGraphs(){
	sh data2Graph.sh ${outputDir}/LeadTimeRunning.txt ${outputDir}/LeadTimeRunning.html  "Lead time running (Waiting in queue)" "Lead time running in second" lead
	sh data2Graph.sh ${outputDir}/LeadTimeCompleted_Autotask.txt ${outputDir}/LeadTimeCompleted_Autotask.html  "LeadTimeCompletedTime_C(Autotask) vs Time" "Lead Time Completion(Autotask) in second" leadcomp
	sh data2Graph.sh ${outputDir}/LeadTimeCompleted_Callout.txt ${outputDir}/LeadTimeCompleted_Callout.html "LeadTimeCompletedTime_C(Callout) vs Time" "Lead Time Completion(Callout) in second" leadTime
}
#Parse and get order orchestration timing in second
function ParseOrdersOrchestrationDetails_PlotGraphs(){
	grep Activated ${outputDir}/OrderOrchestration.csv|sed 1d|sed  's/T/ /g'|sed  's/T/ /g' |sed 's/, /,/g'|sed 's/ ,/,/g' > ${outputDir}/OrderOrchestration.txt
	sh getOrderProcessingTime.sh  ${outputDir}/OrderOrchestration.txt ${outputDir} 
	awk '{print $2 " " $3}' ${outputDir}/order_OrchestrationDetails.log > ${outputDir}/order.log
	awk '{print $2 " " $3}' ${outputDir}/decom_OrchestrationDetails.log > ${outputDir}/decom.log
	sh data2Graph.sh ${outputDir}/order.log ${outputDir}/order.html  "Order process time" "Order processing time running in second" order
	sh data2Graph.sh ${outputDir}/decom.log  ${outputDir}/decom.html  "Decomposition Time" "Decomposition time running in second"   decom
}

function ParseAutotaskCalloutOrchestrationDetails(){
	grep Completed ${outputDir}/autoTaskDetails_OrchDetails.csv|sed 1d|awk -F ","  '{ print $1 "," $2*.001}'|sed  's/.000+0000//g'|sed 's/, /,/g' |sed 's/ ,/ /g'|sed 's/T/ /g' > ${outputDir}/autoTask_LeadTimeRunningOrchDetails.log
	grep Completed ${outputDir}/autoTaskDetails_OrchDetails.csv|sed 1d|awk -F ","  '{ print $1 "," $3*.001}'|sed  's/.000+0000//g'|sed 's/, /,/g' |sed 's/ ,/ /g'|sed 's/T/ /g' > ${outputDir}/autoTask_LeadTimecompletedOrchDetails.log
	grep Completed ${outputDir}/calloutDetails_OrchDetails.csv |sed 1d|awk -F ","  '{ print $1 "," $2*.001}'|sed  's/.000+0000//g'|sed 's/ ,/ /g'|sed 's/T/ /g' > ${outputDir}/calloutLeadTimeRunning_OrchDetails.log
	grep Completed ${outputDir}/calloutDetails_OrchDetails.csv |sed 1d|awk -F ","  '{ print $1 "," $3*.001}'|sed  's/.000+0000//g'|sed 's/ ,/ /g'|sed 's/T/ /g' > ${outputDir}/calloutLeadTimeCompleted_OrchDetails.log
}
function getOrdersCount(){
    inputFile=$1
    NoOfSplit=$2
    input_intervalInSecond=$3
    Name=$4
    echo $Name
    StartTime=`head -n 1 ${inputFile}|awk '{print $1 " "$2}'`
    outPutFileName=`echo $inputFile|awk -F ".log" '{print $1}'|awk -F "/" '{print $NF}'`
    Time_FORMAT="+%F%T"
    StartTimeStamp=$(date -j -f "%Y-%m-%d %T" "${StartTime}" "+%s")
        for((i=1; i<=${NoOfSplit}; i++))
          do
			if [ "$i" = "$NoOfSplit" ]
				then
             	startTime=`date -r ${StartTimeStamp} ${Time_FORMAT}|awk '{print $1 }'|sed 's/.\{2\}$//'| sed 's/^\(.\{10\}\)/\1 /'`
             	StartTimeStamp=$endHour_TimeStamp
        		startLine=`grep -n "${startTime}" ${inputFile}|head -n 1|awk -F ":" '{print $1}'`
        		endLine=`wc -l $inputFile |awk  '{print $1}'`
        		count=$(( endLine - startLine ))
                echo $count 
			else              
             endHour_TimeStamp=$(( $StartTimeStamp + $input_intervalInSecond ))           
             startTime=`date -r ${StartTimeStamp} ${Time_FORMAT}|awk '{print $1 }'|sed 's/.\{2\}$//'| sed 's/^\(.\{10\}\)/\1 /'`
             endTime=`date -r ${endHour_TimeStamp} ${Time_FORMAT}|awk '{print $1 }'|sed 's/.\{2\}$//'| sed 's/^\(.\{10\}\)/\1 /'`
	     	StartTimeStamp=$endHour_TimeStamp
			startLine=`grep -n "${startTime}" ${inputFile}|head -n 1|awk -F ":" '{print $1}'`              
			endLine=`grep -n "${endTime}" ${inputFile}|head -n 1|awk -F ":" '{print $1}'`
            count=$(( endLine - startLine ))
            echo $count                 
	fi
          done
}
function splitTestTime(){
    inputFile=$1
    NoOfSplit=$2
    input_intervalInSecond=$3
    Name=$4
    echo $Name
    StartTime=`head -n 1 ${inputFile}|awk '{print $1 " "$2}'`
    outPutFileName=`echo $inputFile|awk -F ".log" '{print $1}'|awk -F "/" '{print $NF}'`
    Time_FORMAT="+%F%T"
    StartTimeStamp=$(date -j -f "%Y-%m-%d %T" "${StartTime}" "+%s")
        for((i=1; i<=${NoOfSplit}; i++))
          do
			if [ "$i" = "$NoOfSplit" ]
				then
             	startTime=`date -r ${StartTimeStamp} ${Time_FORMAT}|awk '{print $1 }'|sed 's/.\{2\}$//'| sed 's/^\(.\{10\}\)/\1 /'`
             	StartTimeStamp=$endHour_TimeStamp
        		startLine=`grep -n "${startTime}" ${inputFile}|head -n 1|awk -F ":" '{print $1}'`
        		endLine=`wc -l $inputFile |awk  '{print $1}'`
                RT=`sed -n "${startLine} , ${endLine}p" $inputFile|awk '{print $3}'|sort -n|awk 'BEGIN{i=0} {s[i]=$1; i++} END{print s[int(NR*0.95-0.5)]}'|bc -l | xargs printf "%.2f"`
                echo $RT 
			else              
             endHour_TimeStamp=$(( $StartTimeStamp + $input_intervalInSecond ))           
             startTime=`date -r ${StartTimeStamp} ${Time_FORMAT}|awk '{print $1 }'|sed 's/.\{2\}$//'| sed 's/^\(.\{10\}\)/\1 /'`
             endTime=`date -r ${endHour_TimeStamp} ${Time_FORMAT}|awk '{print $1 }'|sed 's/.\{2\}$//'| sed 's/^\(.\{10\}\)/\1 /'`
           
#Added 60 to eliminate last 1 min repeated samples
	     	StartTimeStamp=$endHour_TimeStamp
			startLine=`grep -n "${startTime}" ${inputFile}|head -n 1|awk -F ":" '{print $1}'`              
			endLine=`grep -n "${endTime}" ${inputFile}|head -n 1|awk -F ":" '{print $1}'`
            #Below can be uncommented to get the separate files 
			#sed -n "${startLine} , ${endLine}p" $inputFile|awk '{print $2 " " $3}' > ${outputDir}/${outPutFileName}_Hour_${i}.csv
            #calculating 95th percentile from output file 
            RT=`sed -n "${startLine} , ${endLine}p" $inputFile|awk '{print $3}'|sort -n|awk 'BEGIN{i=0} {s[i]=$1; i++} END{print s[int(NR*0.95-0.5)]}'|bc -l | xargs printf "%.2f"`
            echo $RT           
	fi
          done
}
function calculateorchestrationDetailsBrackDownTiming(){

	for((i=0; i<=${NoOfSplit}; i++)) do
		if [ "$i" = "0" ]
		then
	 	echo "95th percentile RT (data interval =${input_intervalInSecond} sec)" 
		else  
		echo "Interval-${i}"
		fi
	 done |tr "\n" ","|sed 's/.$//'
	echo "" 
	splitTestTime ${outputDir}/order_OrchestrationDetails.log ${NoOfSplit} ${input_intervalInSecond} "Orchestration time" |tr "\n" "," |sed 's/.$//'
	echo "" 
	splitTestTime ${outputDir}/decom_OrchestrationDetails.log ${NoOfSplit} ${input_intervalInSecond} "Decomposition Time" |tr "\n" "," |sed 's/.$//'
	echo "" 
	splitTestTime ${outputDir}/calloutLeadTimeRunning_OrchDetails.log ${NoOfSplit} ${input_intervalInSecond} "Callout Lead time running" |tr "\n" "," |sed 's/.$//'
	echo "" 
	splitTestTime ${outputDir}/calloutLeadTimeCompleted_OrchDetails.log ${NoOfSplit} ${input_intervalInSecond} "Call out lead time completion" |tr "\n" "," |sed 's/.$//'
    echo "" 
	splitTestTime ${outputDir}/autoTask_LeadTimeRunningOrchDetails.log ${NoOfSplit} ${input_intervalInSecond} "Auto task Lead time running" |tr "\n" ","|sed 's/.$//' 
	echo "" 
	splitTestTime ${outputDir}/autoTask_LeadTimecompletedOrchDetails.log ${NoOfSplit} ${input_intervalInSecond} "Auto task Lead time completion" |tr "\n" ","|sed 's/.$//'
	echo "" 
	getOrdersCount ${outputDir}/order_OrchestrationDetails.log ${NoOfSplit} ${input_intervalInSecond} "No. Of Order Processed" |tr "\n" ","|sed 's/.$//'
	echo ""
}

function getPerQueueThroughPut(){
    inputFile=$1
    NoOfSplit=$2
    input_intervalInSecond=$3
    Name=$4
    echo $Name  
    StartTime=`grep Completed ${inputFile}|sed 1d|head -n 1|awk -F "," '{print $1}'|tr "T" " " |awk '{print $1 " "$2}'`
    Time_FORMAT="+%F%T"
    StartTimeStamp=$(date -j -f "%Y-%m-%d %T" "${StartTime}" "+%s")
        for((i=1; i<=${NoOfSplit}; i++))
          do
			if [ "$i" = "$NoOfSplit" ]
				then
             	startTime=`date -r ${StartTimeStamp} ${Time_FORMAT}|awk '{print $1 }'|sed 's/.\{2\}$//'| sed 's/^\(.\{10\}\)/\1 /'|tr " " "T"`
             	StartTimeStamp=$endHour_TimeStamp
        		startLine=`grep -n "${startTime}" ${inputFile}|head -n 1|awk -F ":" '{print $1}'`
        		endLine=`wc -l $inputFile |awk  '{print $1}'`
                count=`sed -n "${startLine} , ${endLine}p" $inputFile|grep $Name|wc -l|awk '{print $1}'`
                echo $count 
			else              
             endHour_TimeStamp=$(( $StartTimeStamp + $input_intervalInSecond ))           
             startTime=`date -r ${StartTimeStamp} ${Time_FORMAT}|awk '{print $1 }'|sed 's/.\{2\}$//'| sed 's/^\(.\{10\}\)/\1 /'|tr " " "T"`
             endTime=`date -r ${endHour_TimeStamp} ${Time_FORMAT}|awk '{print $1 }'|sed 's/.\{2\}$//'| sed 's/^\(.\{10\}\)/\1 /'|tr " " "T"`
	     	StartTimeStamp=$endHour_TimeStamp
			startLine=`grep -n "${startTime}" ${inputFile}|head -n 1|awk -F ":" '{print $1}'`              
			endLine=`grep -n "${endTime}" ${inputFile}|head -n 1|awk -F ":" '{print $1}'`
            count=`sed -n "${startLine} , ${endLine}p" $inputFile|grep $Name|wc -l|awk '{print $1}'`
            echo $count          
	fi
          done
}
function getOrchestrationThroughput(){
	inputFile=$1
    NoOfSplit=$2
    input_intervalInSecond=$3

    	for((i=0; i<=${NoOfSplit}; i++)) do
		if [ "$i" = "0" ]
		then
	 	echo "Orchestrations created in interval = ${input_intervalInSecond} sec " 
		else  
		echo "Interval-${i}"
		fi
	 done |tr "\n" ","|sed 's/.$//'
	echo "" 

	queue_Names=`awk -F "," '{print $10}' $inputFile|grep -v OrchestrationQueueId__c|sort|uniq|tr "\n" ","|sed 's/.$//'`
	getPerQueueThroughPut $inputFile $NoOfSplit $input_intervalInSecond  `echo $queue_Names|awk -F "," '{print $1}'` |tr "\n" ","|sed 's/.$//'
	echo ""
	getPerQueueThroughPut $inputFile $NoOfSplit $input_intervalInSecond  `echo $queue_Names|awk -F "," '{print $2}'` |tr "\n" ","|sed 's/.$//'
	echo ""
	getPerQueueThroughPut $inputFile $NoOfSplit $input_intervalInSecond  `echo $queue_Names|awk -F "," '{print $3}'` |tr "\n" ","|sed 's/.$//'
	echo ""
	getPerQueueThroughPut $inputFile $NoOfSplit $input_intervalInSecond  `echo $queue_Names|awk -F "," '{print $4}'` |tr "\n" ","|sed 's/.$//'

}

function getLeadTimeRunningPerQueue(){
	inputFile=$1
	queue_Names=`awk -F "," '{print $10}' $inputFile|grep -v OrchestrationQueueId__c|sort|uniq|tr "\n" ","|sed 's/.$//'`

	#Grep for 4 different queues and create a new file
	grep Completed $inputFile|sed 1d|grep `echo $queue_Names|awk -F "," '{print $1}'`|sed  's/T/ /g'|awk -F ","  '{ print $1 " " $2*.001 }'|awk '{print $2 " " $3}'|tr -d "'" > ${outputDir}/LeadTimeRunning_queue1.txt
	grep Completed $inputFile|sed 1d|grep `echo $queue_Names|awk -F "," '{print $2}'`|sed  's/T/ /g'|awk -F ","  '{ print $1 " " $2*.001 }'|awk '{print $2 " " $3}'|tr -d "'" > ${outputDir}/LeadTimeRunning_queue2.txt
	grep Completed $inputFile|sed 1d|grep `echo $queue_Names|awk -F "," '{print $3}'`|sed  's/T/ /g'|awk -F ","  '{ print $1 " " $2*.001 }'|awk '{print $2 " " $3}'|tr -d "'" > ${outputDir}/LeadTimeRunning_queue3.txt
	grep Completed $inputFile|sed 1d|grep `echo $queue_Names|awk -F "," '{print $4}'`|sed  's/T/ /g'|awk -F ","  '{ print $1 " " $2*.001 }'|awk '{print $2 " " $3}'|tr -d "'" > ${outputDir}/LeadTimeRunning_queue4.txt
	#create  Lead time running per queue graph 
	sh data2Graph.sh ${outputDir}/LeadTimeRunning_queue1.txt ${outputDir}/LeadTimeRunning_queue1.html  "Lead time running (Waiting in queue1)" "Lead time running in second" leadqueue1
	sh data2Graph.sh ${outputDir}/LeadTimeRunning_queue2.txt ${outputDir}/LeadTimeRunning_queue2.html  "Lead time running (Waiting in queue2)" "Lead time running in second" leadqueue2
	sh data2Graph.sh ${outputDir}/LeadTimeRunning_queue3.txt ${outputDir}/LeadTimeRunning_queue3.html  "Lead time running (Waiting in queue3)" "Lead time running in second" leadqueue3
	sh data2Graph.sh ${outputDir}/LeadTimeRunning_queue4.txt ${outputDir}/LeadTimeRunning_queue4.html  "Lead time running (Waiting in queue4)" "Lead time running in second" leadqueue4
	#remove unnecessary files 
	rm ${outputDir}/LeadTimeRunning_queue1.txt ${outputDir}/LeadTimeRunning_queue2.txt ${outputDir}/LeadTimeRunning_queue3.txt ${outputDir}/LeadTimeRunning_queue4.txt

}

function combineHtmlreport(){

	orchestrationDetailsInputFile=$1
	AllOrchestrationInputFile=$2
	AutoTaskOrchestationInputFile=$3

	sh csvToHtmlConvertor.sh $StartTime $EndTime $orchestrationDetailsInputFile  $AllOrchestrationInputFile $AutoTaskOrchestationInputFile
	#echo "<br></br>"
	echo "<h4 style=\"text-align:left\"><a id=\"top\"> <u> Decomposition time chart:</u> </a></h3>"
	cat ${outputDir}/decom.html  
	echo "<br></br>"
	echo "<h4 style=\"text-align:left\"><a id=\"top\"> <u>  Order processing time chart:</u> </a></h3>"
	cat ${outputDir}/order.html 
	echo "<br></br>"
	echo "<h4 style=\"text-align:left\"><a id=\"top\"> <u> Lead time running(Waiting in queue) chart</u> </a></h3>"
	cat ${outputDir}/LeadTimeRunning.html  
	echo "<br></br>"
	echo "<h4 style=\"text-align:left\"><a id=\"top\"> <u> Lead time completion(AutoTask) chart</u> </a></h3>"
	cat ${outputDir}/LeadTimeCompleted_Autotask.html  
	echo "<br></br>"
	echo "<h4 style=\"text-align:left\"><a id=\"top\"><u>  Lead time completion(Callout) chart</u></a></h3>"
	cat ${outputDir}/LeadTimeCompleted_Callout.html
	echo "<br></br>"
	echo "<h4 style=\"text-align:left\"><a id=\"top\"><u> Lead time Running (Queue1) chart</u></a></h3>"
	cat ${outputDir}/LeadTimeRunning_queue1.html 
	echo "<br></br>"
	echo "<br></br>"
	echo "<h4 style=\"text-align:left\"><a id=\"top\"><u> Lead time Running (Queue2) chart</u></a></h3>"
	cat ${outputDir}/LeadTimeRunning_queue2.html 
	echo "<br></br>"
	echo "<br></br>"
	echo "<h4 style=\"text-align:left\"><a id=\"top\"><u>Lead time Running (Queue3) chart</u></a></h3>"
	cat ${outputDir}/LeadTimeRunning_queue3.html 
	echo "<br></br>"
	echo "<br></br>"
	echo "<h4 style=\"text-align:left\"><a id=\"top\"> <u>Lead time Running (Queue4) chart</u></a></h3>"
	cat ${outputDir}/LeadTimeRunning_queue4.html 
	echo "<br></br>"
	echo "<br></br>"

	echo "<a href="https://vlocity.atlassian.net/wiki/spaces/EP/pages/471269696/OM+Report+Preparation+Automation+script+details">For more Details of this report refer here</a>"
}


function main(){
rm ${outputDir}/*.log ${outputDir}/*.txt ${outputDir}/Autotask.csv ${outputDir}/*.html
	runSql	
	getCsvFiles
	PraseCallOutAutoTaskDetails
	plotCalloutAutotaskDetailsGraphs
	ParseOrdersOrchestrationDetails_PlotGraphs
	ParseAutotaskCalloutOrchestrationDetails
	calculateorchestrationDetailsBrackDownTiming > ${outputDir}/summary_orchestration.csv
	getLeadTimeRunningPerQueue ${outputDir}/LeadTimeRunning.csv
	getOrchestrationThroughput ${outputDir}/LeadTimeRunning.csv ${NoOfSplit} ${input_intervalInSecond} > ${outputDir}/summary_autotask_callout_queueThrougput.csv
	#get only Autotask Throughput 
	grep AutoTask ${outputDir}/LeadTimeRunning.csv > ${outputDir}/Autotask.csv
	getOrchestrationThroughput ${outputDir}/Autotask.csv ${NoOfSplit} ${input_intervalInSecond}  > ${outputDir}/summary_Autotask_queueThrougput.csv

	combineHtmlreport ${outputDir}/summary_orchestration.csv ${outputDir}/summary_autotask_callout_queueThrougput.csv ${outputDir}/summary_Autotask_queueThrougput.csv > ${TestDir}/summary_orchestration.html
	
	rm ${outputDir}/*.log ${outputDir}/*.txt ${outputDir}/Autotask.csv ${outputDir}/*.html
	echo "Script completed at"
	date
}
main

