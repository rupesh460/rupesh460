#!/bin/bash

#This script help in creating html chart with the help of google chart API  
#
#
#Sample input value in file 
#  12:46:19  10
#  10:23:10  30 
#How to Execute the script 
#  sh data2Graph.sh  /Users/sranjan/logs/i 1.html "Order process Time" "Order processing Time in second"

#input Details from command 
input_FileName=$1
output_FileName=$2
title=$3
y_Axis_Title=$4
drawChart_Chartdiv=$5

header="<html>\n
	<head>\n
	<script type=\"text/javascript\" src=\"https://www.gstatic.com/charts/loader.js\"></script>\n
	<script type=\"text/javascript\">\n
	google.charts.load('current', {'packages':['corechart']});\n
	google.charts.setOnLoadCallback(drawChart_${drawChart_Chartdiv});\n
	function drawChart_${drawChart_Chartdiv}() {\n
	var data = google.visualization.arrayToDataTable([\n
	['Time', ' '],"

footer="]);\n
	var options = {\n
	title: '${title}',\n
	hAxis: {title: 'Time',  titleTextStyle: {color: '#333'}},\n
	vAxis: {title: '${y_Axis_Title}', minValue: 0}\n
	};\n
	var chart = new google.visualization.AreaChart(document.getElementById('chart_div_${drawChart_Chartdiv}'));\n
	chart.draw(data, options);\n
	}\n
	</script>\n
	</head>\n
	<body>\n
	<div id=\"chart_div_${drawChart_Chartdiv}\" style=\"width: 100%; height: 500px;\"></div>\n
	</body>\n
	</html>"

echo $header > $output_FileName
cat ${input_FileName}|awk '{print "["  "\x27" $1 "\x27" "," $2  "]" ","}' >> $output_FileName
echo $footer >> $output_FileName