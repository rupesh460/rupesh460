#!/bin/bash
# Scripts to download debug logs and get SOQL,DML count for each api along with table details
#prerequisites : python3 and force client
#Author syathiraju@vlocity.com



#default values
responseTime=10
logSize=100
outputFolderDir=logs1
environmentDetailsFile=resources/environmental_details.csv




echo "HELP: sh downloadApexDebugLogs_v2.sh -e|--environment_Name  -dir|--outputFolderDir -rt|--responseTime -s|--logSize"
echo "Example/Defaults: sh downloadApexDebugLogs_v2.sh -e perf2 -d logs -rt 2000  -s 45880"
while [[ $# > 1 ]]
do
key="$1"

case $key in

    -e|--environment_Name)
    environment_Name="$2"
    shift # past argument
    ;;
    -rt|--responseTime)
    responseTime="$2"
    shift # past argument
    ;;
    -s|--logSize)
    logSize="$2"
    shift # past argument
    ;;
    -a|--api)
    api="$2"
    shift # past argument
    ;;
    -d|--dir)
    outputFolderDir="$2"
    shift # past argument
    ;;
    *)
            # unknown option
    ;;
esac
shift # past argument or value
done


envtype=`grep -w ${environment_Name} ${environmentDetailsFile}|awk -F "," '{print $7}'`
userName=`grep -w ${environment_Name} ${environmentDetailsFile}|awk -F "," '{print $2}'`
passWord_encoded=`grep -w ${environment_Name} ${environmentDetailsFile}|awk -F "," '{print $3}'`

passWord=`echo $passWord_encoded| base64 --decode`


#python script to parse SOQL

read -r -d '' parse_Script <<-"EOF"
import re
import sys

def tables_in_query(sql_str):

    # string tokenisation
    q = re.sub(r"/\*[^*]*\*+(?:[^*/][^*]*\*+)*/", "", sql_str)
    lines = [line for line in q.splitlines() if not re.match("^\s*(--|#)", line)]
    q = " ".join([re.split("--|#", line)[0] for line in lines])
    tokens = re.split(r"[\s)(;]+", q)


    result_set = set()
    result_list = list()
    get_next = False
    for tok in tokens:
        if get_next:
            if tok.lower() not in ["", "select"]:
                result_list.append(tok)
            get_next = False
        get_next = tok.lower() in ["from", "join"]

    result_set = set(result_list)
    result_dict  = {}
    for tablename in result_set:
        freg=result_list.count(tablename)
        result_dict.update({tablename :freg} )
    return result_dict


s=sys.argv[1]
res=tables_in_query(s)
print(res)
EOF

#check if force client is present in current directory and download the debug logs
function download_debuglogs(){
if [ -e force ]
then
	echo "Okay : force client is  present in current folder "
	./force login -i=${envtype} -u=${userName} -p=${passWord}
	for each in $(./force query "select id from apexlog where LogLength >= ${logSize} and DurationMilliseconds >= ${responseTime}" ); do
        	log=$(echo $each | sed -e 's/"//g')

        	if [ "$log" == "Id" ]; then
                	echo "ignoring $log"
                	continue
        	fi
        		echo "writing ${outputFolderDir}/${log}.debug"
        		./force log $log > ${outputFolderDir}/$log.debug
    	done
else
	echo "Warning : force client is not present in current folder "
	echo "please download it from https://force-cli.heroku.com/  and save it in current folder, change permission to excecutable chmod 755 force"
   	exit
fi
}

function create_outputdir(){

#create output folder if not present
if [ ! -d $outputFolderDir ]
then
	echo "Creating output directory ${outputFolderDir} "
	mkdir -p ${outputFolderDir}
fi

echo "log size is equal to $logSize "
echo "RT is $responseTime"

}

function get_tablename(){
str=$1
api=$2
outputFolderDir=$3
IFS='|'
read -ra ADDR <<< "$str"
for i in "${ADDR[@]}"; do
	filename=`echo $i | awk -F ":" '{print $1}'`
	count=`echo $i | awk -F ":" '{print $2}'`
	query_string=`grep "SOQL_EXECUTE_BEGIN" ${filename}`
	parse_res=`python3 -c "$parse_Script" """${query_string}"""`
	echo "${parse_res}"
	table_names=`echo ${parse_res} |sed 's/{//g' | sed 's/}//g' | sed 's/,/|/g'`
	echo "${api},${count},${table_names}" >> ${outputFolderDir}/SOQL_TABLE_DETAILS.CSV
done
IFS=' '

}

function get_apiname(){
#get unique api name
echo "API_NAME,#SOQL,#DML" >> ${outputFolderDir}/SOQL_DML_COUNT.CSV
echo "API_NAME,#SOQL,TABLE_NAMES" >> ${outputFolderDir}/SOQL_TABLE_DETAILS.CSV
for i in ${outputFolderDir}/*.debug; do echo "$i : $(sed -n '4p' "$i")"; done|awk -F "|" '{print $NF}' |sort| uniq|grep -v .debug > /tmp/.000012378
while read -r line ; do
        dirName=`echo $line |sed "s/ /_/g" |tr -d ":()"|sed "s/\./_/g"`
        mkdir -p  ${outputFolderDir}/${dirName}
        filesToBeMove=`grep "${line}" ${outputFolderDir}/*.debug|awk -F ":" '{print $1}'|sort|uniq|tr "\n" " "`
        mv ${filesToBeMove} ${outputFolderDir}/${dirName}
	SOQL_Count=`grep -c "SOQL_EXECUTE_BEGIN" ${outputFolderDir}/${dirName}/* | awk -F ":" '{print $2}' | sort | uniq | paste -d "|" -s`
	DML_Count=`grep -c "DML_BEGIN" ${outputFolderDir}/${dirName}/* | awk -F ":" '{print $2}' | sort | uniq | paste -d "|" -s`
	fnames=`grep -c "SOQL_EXECUTE_BEGIN" ${outputFolderDir}/${dirName}/* | sort -u -t: -k2 | paste -d "|" -s`
	get_tablename ${fnames} ${dirName} ${outputFolderDir}

	echo "${dirName},${SOQL_Count},${DML_Count}" >> ${outputFolderDir}/SOQL_DML_COUNT.CSV
done < "/tmp/.000012378"
}

function main(){
create_outputdir
download_debuglogs
get_apiname
}
main
