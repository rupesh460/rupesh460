listColors = ['Red','Black','Grey','Silver','Gold','White','Yellow','Blue','Rose Gold','Green']
listRams = ['16GB','32GB','64GB','128GB','256GB','512GB','1TB','2TB','3TB','4TB']
listScreens =  ['4','4.5','5','5.5','6','6.5','7','7.5','8','8.5']
listBandwidth = ['100mbps','200mbps','300mbps','400mbps','500mbps']
listHDD = ['500GB','1TB']
dataList = []

for color in listColors:
	for ram in listRams:
		for screen in listScreens:
			for bandwidth in listBandwidth:
					for hdd in listHDD:
						dataList.append(color+';'+ram+';'+screen+';'+bandwidth+';'+hdd)
			

dataFile = open('10000rowsdata.xls','w')
for row in dataList:
	dataFile.write("%s\n" % row)