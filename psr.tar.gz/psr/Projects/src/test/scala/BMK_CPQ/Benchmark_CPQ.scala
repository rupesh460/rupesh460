//THe script takes Account ID, PriceList for which order has tb created ,
//PriceList entry ID for which add to cart to be done
package BMK_CPQ

  import scala.concurrent.duration._
  import io.gatling.core.Predef._
  import io.gatling.core.structure.ChainBuilder
  import io.gatling.http.Predef._
  import io.gatling.jdbc.Predef._
  import io.gatling.jsonpath._
  import Headers._
  import scala.collection._
  import java.time.format.DateTimeFormatter
  import java.time.LocalDateTime
  import java.time.LocalDate

import io.gatling.core.feeder._
import java.util.Base64
import java.nio.charset.StandardCharsets
import scala.util.matching.Regex


   object Benchmark_CPQ {

       val uri01 = Configuration.Uri01
      val uri06 = Configuration.Uri06
      val uri07 = Configuration.Uri07
      val uri05 = Configuration.Uri05
      val uri10 = Configuration.Uri10
      val uri11 = Configuration.Uri11
      val product_feeder = csv("./src/test/resources/data/bmk_cpq/ProductIds.csv").circular
    val promotion_feeder = csv("./src/test/resources/data/bmk_cpq/PromoIds.csv").random

    var modifiedItemJson = new StringBuilder()
    val origItemAttrHeirarchy = new StringBuilder()
    val modItemAttrHeirarchy = new StringBuilder()
    val randomNumber = new scala.util.Random
    var randomLineItem = new StringBuilder()
    var pbeEntriesList = Vector[String]()
    var promotionList = Vector[String]()
    var lineItemsList = Vector[String]()
    var randomPBEntry = new StringBuilder()
    var accountName = new StringBuilder()
    var randomPromoId = new StringBuilder()
    var final_formatted_date = new StringBuilder()
    val testDuration = Integer.getInteger("testDuration",1)
    var Date =  Configuration.date

 val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
  val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
  val password_v = (passwordByEnv.get("perf3").toString)
  val password_encoded = password_v.substring(12,(password_v.length - 2 ))
  val credentials = new String(Base64.getDecoder.decode(password_encoded))




    /* ************COP Scenarios************* */
    val cpq_base_apis = scenario("cpq_base_apis")
    //.exec(session => session.set("Pricebook2Id",Configuration.Pricebook2Id))
    .exec(session => session.set("PromotionID1",Configuration.Promotion3PI))
    .exec(session => session.set("PromotionID2",Configuration.Promotion5PI))
    .exec(session => session.set("UpdatePromotionID",Configuration.UpdatePromotion))
    .exec(session => session.set("UpdatePromotionItemID",Configuration.UpdatePromotionItem))
    .exec(session => session.set("PenaltyRulePromotionID",Configuration.PenaltyRulePromotion))

    .exec(session => session.set("PriceListId",Configuration.PriceListId))

.exec(session => session.set("password",credentials))

     .repeat(100)
      //.repeat(1)
    {

    //.feed(userFeeder)
        exec(http("Login")
        .post(uri01 + "/")
        .headers(headers_35)
    //     .formParam("pqs", "?startURL=%2Fvisualforce%2Fsession%3Furl%3Dhttps%253A%252F%252Fperf-ins-testing.lightning.force.com%252Fone%252Fone.app&ec=302")
        .formParam("un", "perf-cmt-release-bmk@vlocity.com")
        .formParam("width", "1440")
        .formParam("height", "900")
        .formParam("hasRememberUn", "true")
        // .formParam("startURL", "/visualforce/session?url=https%3A%2F%2Fperf-ins-testing.lightning.force.com%2Fone%2Fone.app")
        .formParam("loginURL", "")
        .formParam("loginType", "")
        .formParam("useSecure", "true")
        .formParam("local", "")
        .formParam("lt", "standard")
        // .formParam("qs", "r=https%3A%2F%2Fperf-ins-testing.my.salesforce.com%2Fvisualforce%2Fsession%3Furl%3Dhttps%253A%252F%252Fperf-ins-testing.lightning.force.com%252Fone%252Fone.app")
        .formParam("locale", "")
        .formParam("oauth_token", "")
        .formParam("oauth_callback", "")
        .formParam("login", "")
        .formParam("serverid", "")
        .formParam("QCQQ", "R6m6RfkuV7R")
        .formParam("display", "page")
        .formParam("username", "perf-cmt-release-bmk@vlocity.com")
        // .formParam("ExtraLog", "%5B%7B%22width%22:1440%7D,%7B%22height%22:900%7D,%7B%22language%22:%22en-GB%22%7D,%7B%22offset%22:-5.5%7D,%7B%22scripts%22:%5B%7B%22size%22:249,%22summary%22:%22if%20(self%20==%20top)%20%7Bdocument.documentElement.style.v%22%7D,%7B%22size%22:578,%22summary%22:%22var%20SFDCSessionVars=%7B%5C%22server%5C%22:%5C%22https:%5C%5C/%5C%5C/login.sal%22%7D,%7B%22url%22:%22https://perf-ins-testing.my.salesforce.com/jslibrary/SfdcSessionBase208.js%22%7D,%7B%22url%22:%22https://perf-ins-testing.my.salesforce.com/jslibrary/LoginHint208.js%22%7D,%7B%22size%22:26,%22summary%22:%22LoginHint.hideLoginForm();%22%7D,%7B%22size%22:36,%22summary%22:%22LoginHint.getSavedIdentities(false);%22%7D,%7B%22url%22:%22https://perf-ins-testing.my.salesforce.com/jslibrary/baselogin4.js%22%7D,%7B%22url%22:%22https://perf-ins-testing.my.salesforce.com/jslibrary/LoginMarketingSurveyResponse.js%22%7D,%7B%22url%22:%22https://perf-ins-testing.my.salesforce.com/marketing/survey/survey1/1380%22%7D,%7B%22url%22:%22https://perf-ins-testing.my.salesforce.com/marketing/survey/survey4/1380%22%7D,%7B%22size%22:517,%22summary%22:%22function%20handleLogin()%7Bdocument.login.un.value=doc%22%7D%5D%7D,%7B%22scriptCount%22:11%7D,%7B%22iframes%22:%5B%22https://c.salesforce.com/login-messages/promos.html?r=https%253A%252F%252Fperf-ins-testing.my.salesforce.com%252Fvisualforce%252Fsession%253Furl%253Dhttps%25253A%25252F%25252Fperf-ins-testing.lightning.force.com%25252Fone%25252Fone.app%22,%22https://login.salesforce.com/login/sessionserver212.html%22%5D%7D,%7B%22iframeCount%22:2%7D,%7B%22referrer%22:%22https://perf-ins-testing.my.salesforce.com/visualforce/session?url=https%253A%252F%252Fperf-ins-testing.lightning.force.com%252Fone%252Fone.app%22%7D%5D")
        // .formParam("Fingerprint", "%7B%22platform%22:%22MacIntel%22,%22window%22:%22836x1440%22,%22screen%22:%22900x1440%22,%22color%22:%2224-24%22,%22timezoneOffset%22:%22-330%22,%22canvas%22:%22-2102302436%22,%22sessionStorage%22:%22true%22,%22LocalStorage%22:%22true%22,%22indexDB%22:%22true%22,%22webSockets%22:%22true%22,%22plugins%22:%22Chrome%20PDF%20Plugin:Portable%20Document%20Format%5CnChrome%20PDF%20Viewer:%5CnNative%20Client:%5Cn%22,%22drm%22:1,%22languages%22:%5B%22en-GB%22,%22en-US%22,%22en%22%5D,%22fonts%22:%22%22,%22codecs%22:%22gIEIqgoIQqoCqH4=%22,%22mediaDevices%22:%22audioinput::default%5Cnaudioinput::c2f087d07e9625d58196c1dcdc8b4744d952e59c71f9c67f5ba00634cba94017%5Cnvideoinput::2a7fcbffc79af1068cbcd7487db6acdebd3f83a581aacd563a08b34d51595c7e%5Cnaudiooutput::default%5Cnaudiooutput::3c9bcf25320d95ed9593f8228ca811913eea05330387f4dbb5fe130b3d0565a1%5Cn%22%7D")
        .formParam("pw", "${password}")
        .formParam("Login", "Log In"))


    .exec(http("RESTGetOAuthToken")
    .post("https://login.salesforce.com/services/oauth2/token")
    .header("Content-Type", "application/x-www-form-urlencoded")
    .formParam("password", "${password}")
    .formParam("username", "perf-cmt-release-bmk@vlocity.com")
    .formParam("client_secret", "2847028618258912343")
    .formParam("client_id", "3MVG9KsVczVNcM8xeKy2xCeFKhU5cLqUWx_oOlMOvZw3mINnx7tqn7vQL3YFko0YLGC_k8FBSC.DVtC_g4GWH")
    .formParam("grant_type", "password")
    .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
    .check(status.is(200)))

    .exec(session => session.set("AccountName",""))
    .exec( session => {
      val random_index = randomNumber.nextInt(100000)
      accountName.append("Acc-"+random_index)
      session
    })
    .exec(session => session.set("AccountName",accountName))
    .exec( session => {
      accountName = new StringBuilder()
      session
    })

    /* *********** CreateAccount *********** */
    .exec(http("01_B_CreateAccount")
      .post(uri07 +"/services/data/v44.0/sobjects/account")
      .headers(header_100)
      .check(regex(""""id":"(.*?)"""").find.exists.saveAs("AccountId"))
      .body( StringBody("""
      {
        "Name" : "${AccountName}",
        "ShippingCity" : "San Francisco",
        "RecordTypeId" : "0121U000000IuOgQAK",
        "vlocity_perf__Status__c": "Active"
      }""")).asJson)

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    /* *********** CreateOrder *********** */
    .exec(http("02_B_Create_a_neworder")
      .post(uri07 +"/services/apexrest/vlocity_perf/v2/carts")
      .headers(header_100)
      .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
      .body( StringBody("""{"subaction":"createOrder",
        "inputFields":[
        {"AccountId":"${AccountId}"},
        {"vlocity_perf__PriceListId__c":"${PriceListId}"},
        {"Name":"Bmk-Order"},{"Status":"Draft"},
        {"EffectiveDate":"2/2/2019"}
        ]}""")).asJson)

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    /* ********** get CSRF Token *********** */
    .exec(http("03_B_getCsrf")
    .get(uri06 + "/apex/hybridcpq?id=${OrderID}")
    .headers(headers_99)
    .check(regex("""\{"name":"doGenericInvoke","len":4,"ns":"vlocity_perf","ver":41.0,"csrf":"(.*)"\},\{"name":"doNamedCredentialCallout""").find.exists.saveAs("CSRFToken"))
    .check(regex("""vid":"(.+?)","xhr""").find.exists.saveAs("vid")))
    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    /* ********** ViewPriceLists *********** */
     .exec(http("004_New_ViewPriceLists")
       .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/pricelists")
       .check(jsonPath("$.records[*].Id").findAll.saveAs("ListOfPBEntries"))
       .headers(header_1))

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

       /* ********** SetPriceListForCart *********** */
       .exec(http("005_New_SetPriceListfortheOrder")
         .put(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/")
         .headers(header_1)
         .body(StringBody("""{
           "inputFields":
           [
           {
             "vlocity_perf__PriceListId__c": "${PriceListId}"
           }
           ],
           "cartId": "${OrderID}",
           "methodName": "updateCarts"
         }""")).asJson
         .check(regex(""""Id":"${OrderID}"""").find.exists))

         .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

              /* ********** GetListOfProductsForCart *********** */
         .exec(http("006_New_Getlistofproductsforcart")
         .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/products?pagesize=10")
         .check(jsonPath("$.records[*].Id").findAll.saveAs("ListOfPBEntries"))
         .headers(header_1))

         .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

               /* ********** RetrieveFilterableProducts *********** */
       .exec(http("007_New_RetrieveFilterableProducts")
         .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/attributes")
         .check(regex(""""totalSize":1,""").find.exists)
         .headers(header_1))

         .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

         /* ********** RetrievePromotions *********** */
     .exec(http("008_New_RetrievePromotions")
     .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/promotions?pagesize=10")
     .check(jsonPath("$.records[0].id").find.saveAs("PromotionID"))
     .check(jsonPath("$.records[*].id").findAll.saveAs("PromotionList"))
     .headers(header_1))

  .exec( session => {
     promotionList = session("PromotionList").as[Vector[String]]
     session
   })

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


    .repeat(1)
    {
          /* ********** AddItemsToCart *********** */
          feed(product_feeder)
          .exec(http("09_New_Additemstocart")
            .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items")
            .headers(header_1)
            .body( StringBody("""{
              "items":[{
                "itemId":"${Product24LI_ID}"
              }],
              "price":"true",
              "validate":"true",
              "pagesize":20
            }""")).asJson
            .check(regex("""productHierarchyPath":"(.*?)","name":"COMMS-P0-Prod-With-Child-23LineItem""").find.exists.saveAs("c_productHierarchyPath"))
          .check(jsonPath("$.records[0].lineItems.records[0].actions.updateitems.rest.params.items[0]..itemId").find.saveAs("CloneLineItem")))

          .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
    }


    /* ********** ExpandParentItemtoDisplayNextLevelChildren *********** */
    .exec(http("010_New_ExpandParentItemtoDisplayNextLevelChildren")
    .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items/${CloneLineItem}/expand?productHierarchyPath=${c_productHierarchyPath}")
    .headers(header_1)
    .check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))

      /* ********** GetCartLineItems *********** */
    .exec(http("011_New_GetCartLineItems")
    .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items?pagesize=10&price=false&validate=false")
    .headers(header_1)
    .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1")))

// discount 

 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("012_New_getcartsDiscount")
    .post(uri11 + "/apexremote")
    .headers(header_discount)
    .check(regex(""""statusCode":200,"""").find.exists)
    .body(ElFileBody("./src/test/resources/bodies/bmk/getcartdiscount.txt")))

 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

/* ********** CreateNew Discount *********** */
      .exec(http("013_New_CreateNewDiscount")
       .post(uri11 + "/apexremote")
       .headers(header_discount)
       .check(regex(""""statusCode":200,"""").find.exists)
      .body(ElFileBody("./src/test/resources/bodies/bmk/create_discount.txt")))

 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

//

/* ********** Apply Discount *********** */
        .exec(http("014_New_ApplyDiscount")
         .post(uri11 + "/apexremote")
         .headers(header_discount)
         .check(regex(""""statusCode":200,"""").find.exists)
         .body(ElFileBody("./src/test/resources/bodies/bmk/add_discount.txt")))

 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

           /* ********** Retrieve Discount *********** */
              .exec(http("015_New_RetrieveDiscount")
               .post(uri11 + "/apexremote")
               .headers(header_discount)
               .check(regex(""""statusCode":200,"""").find.exists)
                .check(regex("""vlocity_perf__OrderDiscountId__c\\":\{\\\"value\\":\\"(.+?)\\",\\"previousValue\\":n""").find.exists.saveAs("DeleteDiscountID"))
                .body(ElFileBody("./src/test/resources/bodies/bmk/retrieve_discount.txt")))

 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
//{"action":"CardCanvasController","method":"doGenericInvoke","data":["CpqAppHandler","deleteCartDiscount","{\"methodName\":\"deleteCartDiscount\",\"id\":\"a4qJ00000006iyYIAQ\",\"cartId\":\"801J0000002DD0VIAW\"}","{\"vlcClass\":\"CpqAppHandler\"}"],"type":"rpc","tid":29,"ctx":{"csrf":"VmpFPSxNakF5TUMwd05TMHdNbFF3TmpvME9Eb3lNaTQzTlROYSxWR0U2YnlObkVab3Q0YWllVTE0b3B3LE1HRmpORE5q","vid":"066J00000011CJa","ns":"","ver":41}}
//configure_discount.txt
/* ********** Modify Discount *********** */
      .exec(http("016_New_ModifyDiscount")
       .post(uri11 + "/apexremote")
       .headers(header_discount)
       .check(regex(""""statusCode":200,"""").find.exists)
        .body(ElFileBody("./src/test/resources/bodies/bmk/configure_discount.txt")))

           .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


       /* ********** Delete Discount *********** */
          .exec(http("017_New_DeleteDiscount")
           .post(uri11 + "/apexremote")
           .headers(header_discount)
           .check(regex(""""statusCode":200,"""").find.exists)
           .body(ElFileBody("./src/test/resources/bodies/bmk/delete_discount.txt")))

 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


            /* ********** ViewProductDetails *********** */
     .feed(product_feeder)
     .exec(http("018_New_ViewProductDetails")
     .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/products/${Product24LI_ID}?maxProdListHierarchy=5&includeAttachment=true&filters=AppliesTo__c%3AAccount_Contract&fields=Id%2CName&includeAttributes=true")
     .headers(header_1)
      .check(regex("""totalSize":1""").find.exists))

       .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

       /* ********** CloneCartLineItem ********** */
       .exec(http("019_New_Cloneacartlineitem")
       .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items/clone")
        .headers(header_1)
        .body( StringBody("""{
         "items": [
         {"itemId":"${CloneLineItem}"}
         ],
          "hierarchy": 1,
          "lastItemId": "",
          "pagesize": 20
         }""")).asJson
         .check(regex("""INFO","message":"Clone Successful.""").find.exists))

         .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

                  /* ********** GetCartLineItems *********** */
                  .exec(http("020_New_GetCartLineItems")
                    .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items?pagesize=10&price=false&validate=false")
                    .headers(header_1)
                    .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1")))
                    //.check(jsonPath("$.records[1].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem2")))

            .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
                  

                  /* ********** GetCartItemsByItemId *********** */
                  .exec(http("021_New_Getlineitemdetails")
                    .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items")
                    .queryParamSeq(Seq(("id", "${LineItem1}")))
                    .headers(header_1)
                    .check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))

                  .exec(session => {
                    //originalItemJson.append(session("capturedItemHierarchy").as[String])
                    modifiedItemJson = new StringBuilder()
                    modifiedItemJson.append("""{"items":{"records":[{"displaySequence":-1,""").append(session("capturedItemHierarchy").as[String]).append("}]}}")
                    session
                  })

                 // .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

                  /* ********** UpdateItemsInCart *********** */
                  /* Updating the Quantity from default 1.00 to 3.00 */
                  .exec(http("022_New_Updatecartlineitem")
                    .put(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items")
                    .headers(header_1)
                    .body(StringBody(session =>  modifiedItemJson.replaceAllLiterally(""""Quantity":{"value":1.00""",""""Quantity":{"value":3.00""").toString() )).asJson
                    .check(regex("""INFO","message":"Successfully updated.""").find.exists))

                  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


                  /* ********** VIewPriceWaterfall *********** */
                  .exec(http("023_New_VIewPriceWaterfall")
                    .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items/${LineItem1}/pricing?fields=Id%2CName")
                    .headers(header_1)
                   .check(regex(""""totalSize":1,"""").find.exists))
                    
                    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

               /* ********** AddPromotionToCart *********** */
                   .feed(promotion_feeder)
                   .exec(http("024_New_Addapromotion")
                    .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/promotions")
                    .headers(header_1)
                    .body( StringBody("""{
                      "items": [{"itemId":"${PromoID}"}],
                      "promotionId":"${PromoID}",
                      "cartId":"${OrderID}",
                      "methodName":"postCartsPromoItems"
                    }""")).asJson
                    .check(status.is(200)))

                    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

                    /* ********** DeleteItemFromCart********** */
                    .exec(http("025_New_Deleteanitemfromthecart")
                      .delete(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items/${CloneLineItem}")
                      .headers(header_1)
                      .check(regex("""INFO","message":"Successfully deleted.""").find.exists))

                .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

                /* *********** GetPromotionsAppliedToCart ********** */
                .exec(http("026_New_Getpromotionsappliedtocart")
                  .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/promotions?subaction=getPromotionsAppliedToCart")
                  .check(jsonPath("$.records[0].Id.value").find.exists.saveAs("AppliedPromotionId1"))
                  .headers(header_1))

                   /* *********** DeletePromotionAppliedToCart ********** */
                 .exec(http("027_New_Deleteanappliedpromotioninthecart")
                  .delete(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/promotions?id=${AppliedPromotionId1}")
                  .headers(header_1)
                  .check(regex("""INFO","message":"Successfully deleted.""").find.exists))

                 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

                   /* ********** RetrieveCartSummary *********** */
                   .exec(http("028_New_RetrieveCartSummary")
                     .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}?price=false&validate=false")
                     .headers(header_1))

                 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

               /* ********** RetrieveCartItems *********** */
               .exec(http("029_New_RetrieveCartItems")
                 .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items?pagesize=10&price=false&validate=false")
                 .headers(header_1)
                 .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1")))

                  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


                 /* ********** SubmitOrder ********** */
                 .exec(http("030_New_SubmitOrder")
                 .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items/checkout")
                 .headers(header_1)
                 .check(regex("""SUBMIT-100""").find.exists)
                 .body( StringBody("""{
                   "items":[
                   {"itemId":"${LineItem1}"}
                   ],
                   "hierarchy":1,
                   "lastItemId":"",
                   "pagesize":20
                 }""")).asJson)

                  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

               .exec(http("030_New_SubmitOrder_SendNotification")
             .post(uri10 +"/services/apexrest/vlocity_perf/odin/v1/notifications")
             .headers(header_1)
             .check(regex("""successful""").find.exists)
             .body( StringBody("""[
               {
                   "orderId": "${OrderID}",
                   "state": "Activated"
               }
           ]""")).asJson)

            .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

           /* --------------------------------MACD-----------------------------------*/

             /* ********** RetrieveAccount ********** */
             .exec(http("031_MACD_RetrieveAccount")
             .get(uri10 +"/services/apexrest/vlocity_perf/v2/accounts/${AccountId}")
             .headers(header_1)
              .check(regex("""totalSize":1,""").find.exists))

             .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


             /* ********** RetrieveAssetsForAccount ********** */
             .exec(http("032_MACD_RetrieveAssetsForAccount")
             .get(uri10 +"/services/apexrest/vlocity_perf/v2/accounts/${AccountId}/assets")
             .headers(header_1)
             .check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfAssetIds")))

             .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


             /* ************ GetAssetID *********** */
             .exec(http("033_MACD_GetAssetId")
               .get(uri10 +"/services/data/v39.0/query/?q=SELECT Id,Name FROM Asset WHERE AccountId = '${AccountId}' AND Name >= 'COMMS-P0-Prod-With-Child-' LIMIT 1")
               .check(regex("<Id>(.*?)</Id>").find.saveAs("AssetId"))
               .headers(header_1))

               .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

           //.get(uri05 +"/apex/MACDFdo?id=${AssetId_add}")
           //{"name":"GenericInvoke2","len":4,"ns":"","ver":38.0,"csrf":"VmpFPSxNakF5TUMwd05DMHlOMVF3TmpvMU16b3dNaTQxTlRKYSw0cXhCc2JqTnB4R3lKdXFCMDdqWk83LE1XRmhPVGxt"},{"name":"Ge

               /* ********** get CSRF Token *********** */
               .exec(http("034_MACD_getCsrf1")
               .get(uri06 + "/apex/MACDFdo?id=${AssetId}")
               .headers(headers_99)
               .check(regex("""\{"name":"GenericInvoke2","len":4,"ns":"vlocity_perf","ver":38.0,"csrf":"(.*)"\},\{"name":"Ge""").find.exists.saveAs("CSRFToken1"))
               .check(regex("""vid":"(.+?)","xhr""").find.exists.saveAs("vid")))



             .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


               /* ********** GetRequestDateDetailsForOrderItem *********** */
             .exec(http("035_MACD_GetRequestDateDetailsForOrderItem")
               .get(uri10 +"/services/data/v39.0/query/?q=SELECT+vlocity_perf__RequestDate__c+FROM+OrderItem+WHERE+vlocity_perf__RequestDate__c+!=+null+LIMIT+10")
               .check(regex("""<vlocity_perf__RequestDate__c>(.*?)</vlocity_perf__RequestDate__c>""").findAll.exists.saveAs("RequestDatesList"))
               .headers(header_1))

             .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

             .exec( session => {
               val maxdate = Date
               val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
               val dateforcurrentrun = LocalDate.parse(maxdate,formatter).plusDays(1)
               final_formatted_date.append(dateforcurrentrun)
               session
             })

             .exec( session => session.set("DATE", final_formatted_date ) )
             .exec( session => {
               final_formatted_date = new StringBuilder()
               session
             })

             /* ************ AssetChangeToOrder *********** */
             .exec(http("036_MACD_AssettoOrder")
               .post(uri10 +"/services/apexrest/vlocity_perf/v2/carts")
               .headers(header_1)
               .check(jsonPath("$.records[0].cartId").find.saveAs("Asset_OrderId"))
               .body(StringBody("""{
                 "subaction": "assetToOrder",
                 "id":"${AssetId}",
                 "accountId": "${AccountId}",
                 "requestDate": "${DATE}"
               }""")).asJson)


               /* ************ RetrieveAssetPriceDetails *********** */
 .exec(http("037_MACD_RetrieveAssetPriceDetails")
   .get(uri10 +"/services/apexrest/vlocity_perf/v2/assets/${AssetId}/pricing?accountId=${AccountId}")
   .check(regex(""""totalSize":1,""").find.exists)
   .headers(header_1))

 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

       /* ********** GetListOfProductsForCart *********** */
     .exec(http("038_MACD_Getlistofproductsforcart")
       .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${Asset_OrderId}/products?pagesize=10")
       .check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfPBEntries"))
       .headers(header_1))


             .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


               /* ********** RetrieveFilterableProducts *********** */
      .exec(http("039_MACD_RetrieveFilterableProducts")
        .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${Asset_OrderId}/attributes")
      .check(regex(""""totalSize":1,""").find.exists)
        .headers(header_1))

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        /* ********** RetrievePromotions *********** */
        .exec(http("040_MACD_RetrievePromotions")
        .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${Asset_OrderId}/promotions?pagesize=10")
        .check(jsonPath("$.records[0].id").find.saveAs("PromotionID"))
        .check(jsonPath("$.records[*].id").findAll.saveAs("PromotionList"))
        .headers(header_1))

     .exec( session => {
        promotionList = session("PromotionList").as[Vector[String]]
        session
      })

     .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

     /* ********** ViewProductDetails *********** */
     .feed(product_feeder)
     .exec(http("041_MACD_ViewProductDetails")
       .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${Asset_OrderId}/products/01u1U000000lb02QAA?maxProdListHierarchy=5&includeAttachment=true&filters=AppliesTo__c%3AAccount_Contract&fields=Id%2CName&includeAttributes=true")
       .headers(header_1)
       .check(regex("""totalSize":1""").find.exists))

 // .post(uri11 + "/apexremote")
  //  .headers(header_discount)

       /* ********** CreateNew Discount *********** */
             .exec(http("042_MACD_CreateNewDiscount")
              .post(uri11 + "/apexremote")
              .headers(header_discount)
              .check(regex(""""statusCode":200,"""").find.exists)
              .body(ElFileBody("./src/test/resources/bodies/bmk/create_discount_macd.txt")))

                  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


            /* ********** Apply Discount *********** */
               .exec(http("043_MACD_ApplyDiscount")
                .post(uri11 + "/apexremote")
                .headers(header_discount)
                .check(regex(""""statusCode":200,"""").find.exists)
                .body(ElFileBody("./src/test/resources/bodies/bmk/apply_discount_macd.txt")))

                 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

                  /* ********** Retrieve Discount *********** */
                     .exec(http("044_MACD_RetrieveDiscount")
                      .post(uri11 + "/apexremote")
                      .headers(header_discount)
                      .check(regex(""""statusCode":200,"""").find.exists)
                       .check(regex("""vlocity_perf__OrderDiscountId__c\\":\{\\\"value\\":\\"(.+?)\\",\\"previousValue\\":n""").find.exists.saveAs("DeleteDiscountID"))
                     .body(ElFileBody("./src/test/resources/bodies/bmk/retrive_discount_macd.txt")))
                     
                      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

       

       /* ********** GetCartLineItems *********** */
       .exec(http("045_MACD_GetCartLineItems")
         .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${Asset_OrderId}/items?pagesize=10&price=false&validate=false")
         .headers(header_1)
         .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1")))
          
          .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


    .exec(http("046_MACD_Additemstocart")
          .post(uri11 +"/apexremote")
          .headers(headers_055)
          .check(regex("""Successfully added.""").find.exists)
          .body(ElFileBody("./src/test/resources/bodies/bmk/MACD_ADD23LI_Addtocart.txt")))

          /* ********** GetCartLineItems *********** */
          .exec(http("047_MACD_GetCartLineItems")
            .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${Asset_OrderId}/items?pagesize=10&price=false&validate=false")
            .headers(header_1)
            .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1"))
            .check(jsonPath("$..records[0].lineItems.records[1].actions.updateitems.rest.params.items[0]..itemId").find.saveAs("DeleteLineItem"))
            .check(jsonPath("$..records[0].lineItems.records[3].actions.updateitems.rest.params.items[0]..itemId").find.saveAs("CloneLineItem")))

            //.records[0].lineItems.records[2].actions.updateitems.rest.params.items[0]..itemId

         /* ********** VIewPriceWaterfall *********** */
         .exec(http("048_MACD_VIewPriceWaterfall")
           .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${Asset_OrderId}/items/${LineItem1}/pricing?fields=Id%2CName")
           .headers(header_1)
          .check(regex(""""totalSize":1,"""").find.exists))


//x.records[0].lineItems.records[10].actions.updateitems.rest.params.items[0].itemId
         /* ********** Getlineitemdetails *********** */
         .exec(http("049_MACD_Getlineitemdetails")
           .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${Asset_OrderId}/items")
           .queryParamSeq(Seq(("id", "${LineItem1}")))
           .headers(header_1)
           .check(jsonPath("$.records[0].lineItems.records[8].actions.updateitems.rest.params.items[0]..itemId").find.saveAs("MACDCloneItem"))
           .check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))

         .exec(session => {
           //originalItemJson.append(session("capturedItemHierarchy").as[String])
           modifiedItemJson = new StringBuilder()
           modifiedItemJson.append("""{"items":{"records":[{"displaySequence":-1,""").append(session("capturedItemHierarchy").as[String]).append("}]}}")
           session
         })

        // .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

         /* ********** UpdateItemsInCart *********** */
         /* Updating the Quantity from default 1.00 to 3.00 */
         .exec(http("050_MACD_Updatecartlineitem")
           .put(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${Asset_OrderId}/items")
           .headers(header_1)
           .body(StringBody(session =>  modifiedItemJson.replaceAllLiterally(""""Quantity":{"value":1.00""",""""Quantity":{"value":3.00""").toString() )).asJson
           .check(regex("""INFO","message":"Successfully updated.""").find.exists))

         .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

//    .post(uri11 + "/apexremote")
    //.headers(header_discount)
                /* ********** Modify Discount *********** */
                      .exec(http("051_MACD_ModifyDiscount")
                       .post(uri11 + "/apexremote")
                       .headers(header_discount)
                       .check(regex(""""statusCode":200,"""").find.exists)
                       .body(ElFileBody("./src/test/resources/bodies/bmk/modify_discount_macd.txt")))

                           .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

                       /* ********** Delete Discount *********** */
                          .exec(http("052_MACD_DeleteDiscount")
                           .post(uri11 + "/apexremote")
                           .headers(header_discount)
                           .check(regex(""""statusCode":200,"""").find.exists)
                           .body(ElFileBody("./src/test/resources/bodies/bmk/delte_discount_52macd.txt")))
                           

         .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)



  /* ********** DeleteItemFromCart********** */
  .exec(http("053_MACD_Deleteanitemfromthecart")
    .delete(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${Asset_OrderId}/items/${DeleteLineItem}")
    .headers(header_1)
    .check(regex("""itempricesupdated""").find.exists))

.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


             /* ********** AddPromotionToCart *********** */
                 .feed(promotion_feeder)
                 .exec(http("054_MACD_Addapromotion")
                  .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${Asset_OrderId}/promotions")
                  .headers(header_1)
                  .body( StringBody("""{
                    "items": [{"itemId":"${PromoID}"}],
                    "promotionId":"${PromoID}",
                    "cartId":"${Asset_OrderId}",
                    "methodName":"postCartsPromoItems"
                  }""")).asJson
                  .check(status.is(200)))

                  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


                  /* *********** GetPromotionsAppliedToCart ********** */
                  .exec(http("055_MACD_Getpromotionsappliedtocart")
                    .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${Asset_OrderId}/promotions?subaction=getPromotionsAppliedToCart")
                    .check(jsonPath("$.records[0].Id.value").find.exists.saveAs("AppliedPromotionId1"))
                    .headers(header_1))

                 /* *********** DeletePromotionAppliedToCart ********** */
               .exec(http("056_MACD_Deleteanappliedpromotioninthecart")
                .delete(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${Asset_OrderId}/promotions?id=${AppliedPromotionId1}")
                .headers(header_1)
                .check(regex("""INFO","message":"Successfully deleted.""").find.exists))

               .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

               /* ********** Adjustment by Percentage ********** */
               .exec(http("057_MACD_PriceAdjustmentByPercentage")
                .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${Asset_OrderId}/items/${LineItem1}/pricing")
                .headers(header_1)
                .body( StringBody("""{
                     "adjustments": [
                       {
                         "AdjustmentValue": -10,
                         "AdjustmentMethod": "Absolute",
                         "DetailType": "ADJUSTMENT",
                         "PricingVariableCode": "OT_STD_PRC",
                         "Field": "OneTimeCharge__c"
                       }
                     ]
                   }""")).asJson
                .check(status.is(200)))

                .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

                /* ********** Adjustment by Code ********** */
                .exec(http("058_MACD__PriceAdjustmentByCode")
                 .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${Asset_OrderId}/items/${LineItem1}/pricing")
                 .headers(header_1)
                 .body( StringBody("""{
                     "adjustments": [
                       {
                         "AdjustmentValue": 0,
                         "AdjustmentCode":"PE-CODE-54",
                         "AdjustmentMethod": "Absolute",
                         "DetailType": "ADJUSTMENT",
                         "PricingVariableCode": "OT_STD_PRC",
                         "Field": "OneTimeCharge__c",
                         "AdjustmentType":"Adjustment"
                       }
                     ]
                   }""")).asJson
                 .check(status.is(200)))

                 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

                 /* ********** CloneCartLineItem ********** */
                .exec(http("059_MACD_Cloneacartlineitem")
                 .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${Asset_OrderId}/items/clone")
                 .headers(header_1)
                 .body( StringBody("""{
                 "items": [
                 {"itemId":"${MACDCloneItem}"}
                 ],
                 "hierarchy": 1,
                 "lastItemId": "",
                 "pagesize": 20
                 }""")).asJson
                 .check(regex("""INFO","message":"Clone Successful.""").find.exists))

                 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


                 /* ********** RetrieveCartSummary *********** */
                 .exec(http("060_MACD_RetrieveCartSummary")
                   .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}?price=false&validate=false")
                   .headers(header_1))

               .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

               /* ********** RetrieveCartItems *********** */
               .exec(http("061_MACD_RetrieveCartItems")
               .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items?pagesize=10&price=false&validate=false")
               .headers(header_1)
               .check(regex(""""totalSize":1""").find.exists))

               .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
            

                 /* ********** SubmitOrder ********** */
                 .exec(http("062_MACD_SubmitOrder")
                 .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${Asset_OrderId}/items/checkout")
                 .headers(header_1)
                 .check(regex("""SUBMIT-100""").find.exists)
                 .body( StringBody("""{
                     "cartId": "${Asset_OrderId}",
                     "skipCheckoutValidation": true
                     }""")).asJson)
                 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        }


}
