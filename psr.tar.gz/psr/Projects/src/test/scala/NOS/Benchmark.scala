  /*
  *
  *
  *Scripts for Config#1 to #5 can be found at
  * /resources/data/NOS
  *
  *
  *
  *
  */

  package NOS

  import scala.concurrent.duration._
  import io.gatling.core.Predef._
  import io.gatling.core.structure.ChainBuilder
  import io.gatling.http.Predef._
  import io.gatling.jdbc.Predef._
  import io.gatling.jsonpath._
  import Headers._
  import scala.collection._
  import java.time.format.DateTimeFormatter
  import java.time.LocalDateTime
  import java.time.LocalDate
  import io.gatling.core.feeder._
  import java.util.Base64
  import java.nio.charset.StandardCharsets
  import scala.util.matching.Regex


  object Benchmark {

    val uri01 = Configuration.Uri01
    val uri05 = Configuration.Uri05
    val uri10 = Configuration.Uri10
    var modifiedItemJson = new StringBuilder()
    val origItemAttrHeirarchy = new StringBuilder()
    val modItemAttrHeirarchy = new StringBuilder()
    val randomNumber = new scala.util.Random
    var randomLineItem = new StringBuilder()
    var pbeEntriesList = Vector[String]()
    var promotionList = Vector[String]()
    var lineItemsList = Vector[String]()
    var randomPBEntry = new StringBuilder()
    var accountName = new StringBuilder()
    var randomPromoId = new StringBuilder()
    var final_formatted_date = new StringBuilder()
    
    //Below CSV file uses PricebookEntry IDs not Product IDs
    val product_feeder = csv("./src/test/resources/data/NOS/ProductIds.csv").random
    val userFeeder = csv("./src/test/resources/data/NOS/TestUsers.csv").random
    val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
  val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
  val password_v = (passwordByEnv.get("nos").toString)
  val password_encoded = password_v.substring(12,(password_v.length - 2 ))
  val credentials = new String(Base64.getDecoder.decode(password_encoded))
    val cpq_base_apis = scenario("cpq_base_apis")
    
    .exec(session => session.set("PriceListId",Configuration.PriceListId))
    .exec(session => session.set("password",credentials))
    
    .feed(userFeeder)
    .exec(http("RESTGetOAuthToken")
      .post("https://login.salesforce.com/services/oauth2/token")
      .header("Content-Type", "application/x-www-form-urlencoded")
      .formParam("password", "${password}")
      .formParam("username", "${p_username}")
      .formParam("client_secret", "${p_client_secret}")
      .formParam("client_id", "${p_clientid}")
      .formParam("grant_type", "password")
      .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
      .check(status.is(200)))

    .repeat(1)
    {

      exec(session => session.set("AccountName",""))

      .exec( session => {
        val random_index = randomNumber.nextInt(100000)
        accountName.append("PerfBA_"+random_index)
        session
      })

      .exec(session => session.set("AccountName",accountName))
      
      .exec( session => {
        accountName = new StringBuilder()
        session
      })
      
      /* *********** CreateAccount *********** */
      .exec(http("CreateAccount")
        .post(uri10 +"/services/data/v44.0/sobjects/account")
        .headers(header_1)
        .check(regex(""""id":"(.*?)"""").find.exists.saveAs("AccountId"))
        .body( StringBody("""
        {
          "Name" : "${AccountName}",
          "ShippingCity" : "San Francisco",
          "RecordTypeId" : "0125w000000WWIfAAO",
          "vlocity_cmt__Status__c": "Active"
        }""")).asJson)

      /* *********** CreateOrder *********** */
      .exec(http("CreateNewOrder")
        .post(uri10 +"/services/apexrest/vlocity_cmt/v2/carts")
        .headers(header_1)
        .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
        .body( StringBody("""{"subaction":"createOrder",
          "inputFields":[
          {"AccountId":"${AccountId}"},
          {"vlocity_cmt__PriceListId__c":"${PriceListId}"},
          {"Name":"PerfOrder"},{"Status":"Draft"},
          {"EffectiveDate":"5/3/2020"}
          ]}""")).asJson)

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      /* ********** SetPriceListForCart *********** */
      .exec(http("SetPriceListforOrder")
        .put(uri10 +"/services/apexrest/vlocity_cmt/v2/cpq/carts/${OrderID}/")
        .headers(header_1)
        .body(StringBody("""{
          "inputFields": 
          [
          {
            "vlocity_cmt__PriceListId__c": "${PriceListId}"
          }
          ],
          "cartId": "${OrderID}",
          "methodName": "updateCarts"
        }""")).asJson
        .check(regex(""""Id":"${OrderID}"""").find.exists))

        /* ********** GetListOfProductsForCart *********** */
      .exec(http("GetListOfProductsForCart")
        .get(uri10 +"/services/apexrest/vlocity_cmt/v2/cpq/carts/${OrderID}/products?pagesize=10")
        .check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfPBEntries"))
        .headers(header_1))

        /* ********** AddItemsToCart *********** */
        //.feed(product_feeder) 
        .exec(http("AddItemsToCart")
        .post(uri10 +"/services/apexrest/vlocity_cmt/v2/cpq/carts/${OrderID}/items")
        .headers(header_1)
        .body( StringBody("""{
          "items":[{
            "itemId":"01u5w00000RdDZjAAN"
          }],
          "price":"true",
          "validate":"true",
          "pagesize":20
          }""")).asJson)
        //.check(regex("""INFO","message":"Successfully added.""").find.exists))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      /* ********** GetCarts *********** */
    .exec(http("GetCartsPricing")
      .get(uri10 +"/services/apexrest/vlocity_cmt/v2/cpq/carts/${OrderID}?price=false&validate=false")
      .headers(header_1))

    /* ********** GetCartLineItems_202LI_InCart *********** */
    .exec(http("GetCartLineItems")
      .get(uri10 +"/services/apexrest/vlocity_cmt/v2/cpq/carts/${OrderID}/items?pagesize=10&price=false&validate=false")
      .headers(header_1)
      .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1")))
      //.check(jsonPath("$.records[1].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem2"))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    /* ********** GetCartItemsByItemId *********** */
    .exec(http("GetLineItemDetails")
      .get(uri10 +"/services/apexrest/vlocity_cmt/v2/cpq/carts/${OrderID}/items")
      .queryParamSeq(Seq(("id", "${LineItem1}")))
      .headers(header_1)
      .check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))

    .exec(session => { 
      //originalItemJson.append(session("capturedItemHierarchy").as[String])
      modifiedItemJson = new StringBuilder()
      modifiedItemJson.append("""{"items":{"records":[{"displaySequence":-1,""").append(session("capturedItemHierarchy").as[String]).append("}]}}")
      session
      })
    
      /* ********** UpdateItemsInCart *********** */
      /* Updating the Quantity from default 1.00 to 2.00 */
      .exec(http("UpdateCartLineItem")
        .put(uri10 +"/services/apexrest/vlocity_cmt/v2/cpq/carts/${OrderID}/items")
        .headers(header_1)
        .body(StringBody(session =>  modifiedItemJson.replaceAllLiterally(""""Quantity":{"value":1.00""",""""Quantity":{"value":2.00""").toString() )).asJson)
        //.check(regex("""INFO","message":"Successfully updated.""").find.exists))
      
      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
      
      /* ********** DeleteItemFromCart********** */
      .exec(http("DeleteItemFromCart")
        .delete(uri10 +"/services/apexrest/vlocity_cmt/v2/cpq/carts/${OrderID}/items/${LineItem1}")
        .headers(header_1)
        .check(regex("""INFO","message":"Successfully deleted.""").find.exists))

      /* ********** AddItemsToCart *********** */
        .feed(product_feeder) 
        .exec(http("AddItemsToCart2")
        .post(uri10 +"/services/apexrest/vlocity_cmt/v2/cpq/carts/${OrderID}/items")
        .headers(header_1)
        .body( StringBody("""{
          "items":[{
            "itemId":"01u5w00000RdDZjAAN"
          }],
          "price":"true",
          "validate":"true",
          "pagesize":20
          }""")).asJson)
        //.check(regex("""INFO","message":"Successfully added.""").find.exists))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
    
      /* ********** AddItemsToCart *********** */
      /*  .feed(product_feeder) 
        .exec(http("Add Items to Cart")
        .post(uri10 +"/services/apexrest/vlocity_cmt/v2/cpq/carts/${OrderID}/items")
        .headers(header_1)
        .body( StringBody("""{
          "items":[{
            "itemId":"${ProductID}"
          }],
          "price":"true",
          "validate":"true",
          "pagesize":20
          }""")).asJson
        .check(regex("""INFO","message":"Successfully added.""").find.exists))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)*/

      /* ********** GetPricingDetailsForCartLineItem *********** */
      /*.exec(http("GetPricingDetailsForCartLineItem")
        .get(uri10 +"/services/apexrest/vlocity_cmt/v2/cpq/carts/${OrderID}/items/${LineItem1}/pricing?fields=vlocity_cmt__RecurringCharge__c,vlocity_cmt__OneTimeCharge__c")
        .headers(header_1)) */

      /* ********** SubmitOrder ********** */ 
    .exec(http("SubmitOrder")
      .post(uri10 +"/services/apexrest/vlocity_cmt/v2/cpq/carts/${OrderID}/items/checkout")
      .headers(header_1)
      //.check(regex("""Account""").find.exists)
      .body( StringBody("""{
        "items":[
        {"itemId":"${LineItem1}"}
        ],
        "hierarchy":1,
        "lastItemId":"",
        "pagesize":20
      }""")).asJson)

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  }
}