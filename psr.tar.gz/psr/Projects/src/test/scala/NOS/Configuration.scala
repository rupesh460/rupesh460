package NOS

object Configuration
 {
	val BaseUrl = "https://na172.visual.force.com"
	val Uri01 = "https://login.salesforce.com"
	val Uri05 = "https://vlocity-cmt.na172.visual.force.com"
	val Uri10 = "https://na172.salesforce.com"

	val PriceListId = "a3T5w000000ANmFEAW" // NOS_PL

	/*val Promotion3PI = "a341U000000cc9ZQAQ" // BMK-Promo-1549615808521
	val Promotion5PI = "a341U000000ccJQQAY" //BMK-Promo-1549615894869 

	val UpdatePromotion = "a341U000000ccJLQAY" // BMK-Promo-1549615893377   
	val UpdatePromotionItem = "01u1U000000lc0JQAQ" // BMK-Promo-1549615893377-Prod

	val PenaltyRulePromotion = "a341U000000ccJGQAY" // BMK-Promo-1549615890400*/

	val MinWaitMs = 2000
	val MaxWaitMs = 3000

}