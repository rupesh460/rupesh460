package eComm_v106_loggedin

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import eComm_v106_loggedin.Headers._
import eComm_v106_loggedin.Configuration._

object eComm_AWS {
  val uri01 = Configuration.Uri01
  val uri02 = Configuration.Uri02_AWS
  val userFeeder = csv("./src/test/resources/data/datagen/Perf2users.csv").random
  val offerFeeder = csv("./src/test/resources/data/eComm/offercodes.csv").random
  val contextFeeder = csv("./src/test/resources/data/eComm/contextdimensions.csv").random
  val promoFeeder = csv("./src/test/resources/data/eComm/promocodes.csv").random
  val childOfferFeeder = csv("./src/test/resources/data/eComm/childoffercodes.csv").random
  val accountFeeder = csv("./src/test/resources/data/eComm/accounts.csv").random
  val attrFeeder = csv("./src/test/resources/data/eComm/eCom-Prod-Bnd-15399454256600.csv").random
  val rootAssetFeeder = csv("./src/test/resources/data/eComm/eCom-root-asset-id.csv").random
  val updBasketJson = "./src/test/resources/bodies/eComm/eCom-Prod-Bnd-15399454256600_updatebasket.txt"
  val assetToBasket= csv("./src/test/resources/data/eComm/assettobasketIds.csv").random


  /* ******************************************** KNOWN USER FLOWS **************************************************************************** */

  val productViewsLoggedinScn = scenario("AWS_DC_Loggedin_ProductViews")

    .repeat(108000) {

      /* ********* Call to get contextKey  ************* */
      feed(contextFeeder)
        .feed(accountFeeder)
        .exec(http("getLoggedinCK")
          .get(uri02 + """/v3/catalogs/ECOM-CATALOG/offers?context={"accountId":"${AccountId}"}&isloggedin=true""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex("""contextKey":"(.+?)".""").find.exists.saveAs("LoggedinCK")))

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* ********** GetOffersByCatalogKnownUser V105 *********** */
        //  .feed(accountFeeder)
        .exec(http("GetOffersByCatalogKnownUser")
          .get(uri02 + """/v3/catalogs/ECOM-CATALOG/offers?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex("""contextKey""").find.exists)
          .check(jsonPath("$.offers[*].ProductCode").findAll.saveAs("ProductOffersListKnownUser")))

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        .exec(flushSessionCookies)
            .exec(flushCookieJar)
            .exec(flushHttpCache)
    }

  /* ******************************************************************************************************************* */

  val addToCartLoggedinScn = scenario("AWS_DC_Loggedin_AddToCart")

    .repeat(6000) {
      /* ********* Call to get contextKey  ************* */
      feed(contextFeeder)
        .feed(accountFeeder)
        .exec(http("getLoggedinCK")
          .get(uri02 + """/v3/catalogs/ECOM-CATALOG/offers?context={"accountId":"${AccountId}"}&isloggedin=true""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex("""contextKey":"(.+?)".""").find.exists.saveAs("LoggedinCK")))

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* ********** GetOfferDetails V105 *********** */
        .feed(offerFeeder)
        .exec(http("GetOfferDetailsKnownUser")
          .get(uri02 + """/v3/catalogs/ECOM-CATALOG/offers/${OfferCode}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex("""contextKey""").find.exists)
          .check(bodyString.saveAs("OfferDetailsResKnownUser")).asJson)

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* ********** ConfigureOffer  V105 *********** */
        .exec(http("ConfigureOfferKnownUser")
          .post(uri02 + """/v3/catalogs/ECOM-CATALOG/offers/${OfferCode}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .body(StringBody("""${OfferDetailsResKnownUser}""")).asJson
          .check(regex("""contextKey""").find.exists)
          //.body(ElFileBody("./src/test/resources/bodies/eComm/eCom-Prod-Bnd-15399454256600.txt")).asJson
          .check(regex(""""result":(.+?)."errorCode":"INVOKE""").find.exists.saveAs("AddWithConfigKnownUser")))

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* ********** AddWithNoConfig V105 *********** */
        .exec(http("AddToCartWithNoConfigKnownUser")
          .post(uri02 + """/v3/catalogs/ECOM-CATALOG/basket?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKeyAddToCartWithNoConfigKnownUser")).asJson
          //.check(regex("""bundleContextKey":"(.+?)","lineItemKey""").find.optional.saveAs("ProdBundleContextKeyKnownUser")).asJson
          .check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").find.optional.saveAs("ProdBundleContextKeyKnownUser")).asJson
          .check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").find.optional.saveAs("ProdLineItemKeyKnownUser")).asJson
          .body(StringBody("""{"offer":"${OfferCode}","basketAction":"AddWithNoConfig"}""")).asJson)

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* ********** AddWithConfig V105 *********** */
        .exec(http("AddToCartWithConfigKnownUser")
          .post(uri02 + """/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKeyAddToCartWithConfigKnownUser"))
          .check(regex("""result":(.+?)."errorCode""").find.exists.saveAs("CreateCartKnownUser"))
          .body(StringBody("""{"basketAction":"AddAfterConfig","productConfig":${AddWithConfigKnownUser}}""")).asJson)

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /*.feed(assetToBasket)
        .exec(http("getLoggedinCKForAsset")
          .get(uri02 + """/v3/catalogs/ECOM-CATALOG/offers?context={"accountId":"${AccountIdAsset}"}&isloggedin=true""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex("""contextKey":"(.+?)".""").find.exists.saveAs("LoggedinCKAsset")))

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* ********** AssetToBasket V105 *********** */
        .exec(http("AssetToBasketKnownUser")
          .post(uri02 + """/v3/catalogs/ECOM-CATALOG/basket?context={"accountId":"${AccountIdAsset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex("""assetReferenceKey":"(.+?)",""").optional.saveAs("AssetRefKeyKnownUser"))
          .check(regex("""assetReferenceKey":"(.+?)",""").count.saveAs("AssetRefKeyCountKnownUser"))
          .check(regex("""cartContextKey":"(.+?)",""").find.exists.saveAs("CartContextKeyAssetToBasketKnownUser"))
          .check(regex("""result":(.+?)."errorCode""").find.exists.saveAs("CreateCartAssetKnownUser"))
          .body(StringBody("""{"rootAssetIds":"${RootItemId__c_Asset}","basketAction":"assetToBasket","requestDateTime":"2020-03-21T00:00:00.000z"}""")).asJson)

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        .doIf("${AssetRefKeyCountKnownUser}" != null) {
          /* ********** AssetToBasketCreateCart V105 *********** */
          exec(http("AssetToBasketCreateCartKnownUser")
            .post(uri02 + """/v3/carts?context={"accountId":"${AccountIdAsset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
            .headers(header_1)
            .check(status.is(200))
            .check(status.not(404), status.not(500),status.not(504),status.not(503))
            .check(regex("""orderId":"(.+?)"""").find.exists.saveAs("OrderIdKnownUser"))
            //.body(StringBody("""{"JSONResult":${CreateCartAssetKnownUser},"cartContextKey":"${CartContextKeyAssetToBasketKnownUser}","assetReferenceKey":"${AssetRefKeyKnownUser}","accountId": "${AccountId}","catalogCode": "ECOM-CATALOG"}""")).asJson)
            .body(StringBody("""{"JSONResult":${CreateCartAssetKnownUser},"accountId": "${AccountIdAsset}","catalogCode": "ECOM-CATALOG"}""")).asJson)
            
        }

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)*/

        /* *** UpdateExistingBasket-UpdQty V105 ******* */
        .exec(http("UpdateBasketQtyKnownUser")
          .put(uri02 + """/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyAddToCartWithConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKeyUpdateBasketQtyKnownUser"))
          .check(jsonPath("""$.result.records[1].actions.updateBasketAction.rest.params.bundleContextKey""").find.exists.saveAs("PromoBundleContextKeyKnownUser")).asJson
          .check(jsonPath("""$.result.records[1].actions.updateBasketAction.rest.params.lineItemKey""").find.exists.saveAs("PromoLineItemKeyKnownUser")).asJson
          .body(StringBody("""{"bundleContextKey":"${ProdBundleContextKeyKnownUser}","lineItemKey":"${ProdLineItemKeyKnownUser}","basketAction":"updateBasket","Quantity":"3"}""")).asJson)

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* **** UpdateExistingBasket-UpdAttrib V105 *** */
        .exec(http("UpdateBasketAttribKnownUser")
          .put(uri02 + """/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyUpdateBasketQtyKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex(""""cartContextKey":"(.+?)","result"""").find.exists.saveAs("CartContextKeyUpdateBasketAttribKnownUsers"))
          .body(ElFileBody("./src/test/resources/bodies/eComm/eCom-Prod-Bnd-15399454256600_updatebasket.txt")).asJson)

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* ***** AddPromotion-Step1 V105 ******* */
        .feed(promoFeeder)
        .exec(http("AddPromotion-Step1KnownUser")
          .post(uri02 + """/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyUpdateBasketAttribKnownUsers}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex("""cartContextKey":"(.+?)"."result""").optional.saveAs("CartContextKeyAddPromotion-Step1KnownUser"))
          .check(regex(""""transactionKey":"(.+?)"""").optional.saveAs("TransKeyKnownUser"))
          .check(regex("""result":(.+?)."errorCode""").optional.saveAs("CreateCartKnownUser"))
          .check(regex(""""transactionKey":"(.+?)"""").count.saveAs("TransKeyCountKnownUser"))
          .check(regex(""""AddWithNoConfig","offer":"(.+?)"},"link"""").count.saveAs("OfferFromDelete"))
          .body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}"}""")).asJson)

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* Transaction Key Count = 1 then enter this loop */
        .doIfEquals("${TransKeyCountKnownUser}", 1) {

          /* ********** AddPromotion-Step2 V105 *********** */
          feed(promoFeeder)
            .exec(http("AddPromotion-Step2KnownUser")
              .post(uri02 + """/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyUpdateBasketAttribKnownUsers}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
              .headers(header_1)
              .check(status.is(200))
              .check(status.not(404), status.not(500),status.not(504),status.not(503))
              .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKeyAddPromotion-Step2KnownUser"))
              .check(regex("""result":(.+?)."errorCode""").find.exists.saveAs("CreateCartKnownUser"))
              .body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}","transactionKey":"${TransKeyKnownUser}"}""")).asJson)

            .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

            /* ****** GetBasketDetailsKnownUser V105 ***** */
            .exec(http("GetBasketDetailsKnownUser")
              .get(uri02 + """/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyAddPromotion-Step2KnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
              .headers(header_1)
              .check(status.is(200))
              .check(status.not(404), status.not(500),status.not(504),status.not(503))
              .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKeyGetBasketDetailsKnownUser"))
              .check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").find.exists.saveAs("DelProdLineItemKeyKnownUser")).asJson
              .check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").find.exists.saveAs("DelProdBundleContextKeyKnownUser")).asJson
              .check(jsonPath("""$.result.records[0].promotions.records[0].actions.deletePromotionBasketAction.rest.params.offer""").count.saveAs("CountDelPromoKnownUser")).asJson
              .check(jsonPath("""$.result.records[0].promotions.records[0].actions.deletePromotionBasketAction.rest.params.offer""").optional.saveAs("DelPromoKnownUser")).asJson)

            .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

            /* ********** DeleteProductAPI V105 *********** */
           .exec(http("DeleteProdKnownUser")
              .post(uri02 + """/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
              .headers(header_1)
              .check(status.is(200))
              .check(status.not(404), status.not(500),status.not(504),status.not(503))
              .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKeyDeleteProdKnownUser"))
              .body(StringBody("""{"bundleContextKey":"${ProdBundleContextKeyKnownUser}","basketAction":"deleteFromBasket","itemKey":"${ProdLineItemKeyKnownUser}"}""")).asJson)

            .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

            .exec(flushSessionCookies)
            .exec(flushCookieJar)
            .exec(flushHttpCache)
            //.exec { session => println(session); session }

        }
        .doIfEquals("${TransKeyCountKnownUser}", 0) {

          /* ****** GetBasketDetailsKnownUser V105 ***** */
          exec(http("GetBasketDetailsKnownUser")
            .get(uri02 + """/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyUpdateBasketAttribKnownUsers}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
            .headers(header_1)
            .check(status.is(200))
            .check(status.not(404), status.not(500),status.not(504),status.not(503))
            .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKeyGetBasketDetailsKnownUser"))
            .check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").find.exists.saveAs("DelProdBundleContextKeyKnownUser")).asJson
            .check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").find.exists.saveAs("DelProdLineItemKeyKnownUser")).asJson
            .check(jsonPath("""$.result.records[0].promotions.records[0].actions.deletePromotionBasketAction.rest.params.offer""").count.saveAs("CountDelPromoKnownUser")).asJson
            .check(jsonPath("""$.result.records[0].promotions.records[0].actions.deletePromotionBasketAction.rest.params.offer""").optional.saveAs("DelPromoKnownUser")).asJson)

            .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

            
            /* ********** DeleteProductAPI V105 *********** */
            .exec(http("DeleteProdKnownUser")
              .post(uri02 + """/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
              .headers(header_1)
              .check(status.is(200))
              .check(status.not(404), status.not(500),status.not(504),status.not(503))
              .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKeyDeleteProdKnownUser"))
              .body(StringBody("""{"bundleContextKey":"${ProdBundleContextKeyKnownUser}","basketAction":"deleteFromBasket","itemKey":"${ProdLineItemKeyKnownUser}"}""")).asJson)

            .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

            .exec(flushSessionCookies)
            .exec(flushCookieJar)
            .exec(flushHttpCache)
            //.exec { session => println(session); session }
        }
    }
  /* ******************************************************************************************************************* */

  val checkOutLoggedinScn = scenario("AWS_DC_Loggedin_CheckOut")

    .repeat(6000) {

      /* ********* Call to get contextKey  ************* */
      feed(contextFeeder)
        .feed(accountFeeder)
        .exec(http("getLoggedinCK")
          .get(uri02 + """/v3/catalogs/ECOM-CATALOG/offers?context={"accountId":"${AccountId}"}&isloggedin=true""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex("""contextKey":"(.+?)".""").find.exists.saveAs("LoggedinCK")))

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* ********** GetOfferDetails V105 *********** */
        .feed(offerFeeder)
        .exec(http("GetOfferDetailsKnownUser")
          .get(uri02 + """/v3/catalogs/ECOM-CATALOG/offers/${OfferCode}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex("""contextKey""").find.exists)
          .check(bodyString.saveAs("OfferDetailsResKnownUser")).asJson)

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* ********** ConfigureOffer  V105 *********** */
        .exec(http("ConfigureOfferKnownUser")
          .post(uri02 + """/v3/catalogs/ECOM-CATALOG/offers/${OfferCode}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .body(StringBody("""${OfferDetailsResKnownUser}""")).asJson
          .check(regex("""contextKey""").find.exists)
          //.body(ElFileBody("./src/test/resources/bodies/eComm/eCom-Prod-Bnd-15399454256600.txt")).asJson
          .check(regex(""""result":(.+?)."errorCode":"INVOKE""").find.exists.saveAs("AddWithConfigKnownUser")))

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* ********** AddWithNoConfig V105 *********** */
        .exec(http("AddToCartWithNoConfigKnownUser")
          .post(uri02 + """/v3/catalogs/ECOM-CATALOG/basket?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKeyAddToCartWithNoConfigKnownUser")).asJson
          //.check(regex("""bundleContextKey":"(.+?)","lineItemKey""").find.optional.saveAs("ProdBundleContextKeyKnownUser")).asJson
          .check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").find.optional.saveAs("ProdBundleContextKeyKnownUser")).asJson
          .check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").find.optional.saveAs("ProdLineItemKeyKnownUser")).asJson
          .body(StringBody("""{"offer":"${OfferCode}","basketAction":"AddWithNoConfig"}""")).asJson)

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* ********** AddWithConfig V105 *********** */
        .exec(http("AddToCartWithConfigKnownUser")
          .post(uri02 + """/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKeyAddToCartWithConfigKnownUser"))
          .check(regex("""result":(.+?)."errorCode""").find.exists.saveAs("CreateCartAddToCartWithConfigKnownUser"))
          .body(StringBody("""{"basketAction":"AddAfterConfig","productConfig":${AddWithConfigKnownUser}}""")).asJson)

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        .feed(assetToBasket)
        .exec(http("getLoggedinCKForAsset")
          .get(uri02 + """/v3/catalogs/ECOM-CATALOG/offers?context={"accountId":"${AccountIdAsset}"}&isloggedin=true""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex("""contextKey":"(.+?)".""").find.exists.saveAs("LoggedinCKAsset")))

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* ********** AssetToBasket V105 *********** */
        .exec(http("AssetToBasketKnownUser")
          .post(uri02 + """/v3/catalogs/ECOM-CATALOG/basket?context={"accountId":"${AccountIdAsset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex("""assetReferenceKey":"(.+?)",""").optional.saveAs("AssetRefKeyKnownUser"))
          .check(regex("""assetReferenceKey":"(.+?)",""").count.saveAs("AssetRefKeyCountKnownUser"))
          .check(regex("""cartContextKey":"(.+?)",""").find.exists.saveAs("CartContextKeyAssetToBasketKnownUser"))
          .check(regex("""result":(.+?)."errorCode""").find.exists.saveAs("CreateCartAssetKnownUser"))
          .body(StringBody("""{"rootAssetIds":"${RootItemId__c_Asset}","basketAction":"assetToBasket","requestDateTime":"2020-03-24T00:00:00.000z"}""")).asJson)

        .pause(5 , 7 )

        .doIf("${AssetRefKeyCountKnownUser}" != null) {
          /* ********** AssetToBasketCreateCart V105 *********** */
          exec(http("AssetToBasketCreateCartKnownUser")
            .post(uri02 + """/v3/carts?context={"accountId":"${AccountIdAsset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
            .headers(header_1)
            .check(status.is(200))
            .check(status.not(404), status.not(500),status.not(504),status.not(503))
            .check(regex("""orderId":"(.+?)"""").find.exists.saveAs("OrderIdKnownUser"))
            //.body(StringBody("""{"JSONResult":${CreateCartAssetKnownUser},"cartContextKey":"${CartContextKeyAssetToBasketKnownUser}","assetReferenceKey":"${AssetRefKeyKnownUser}","accountId": "${AccountId}","catalogCode": "ECOM-CATALOG"}""")).asJson)
            .body(StringBody("""{"JSONResult":${CreateCartAssetKnownUser},"accountId": "${AccountIdAsset}","catalogCode": "ECOM-CATALOG"}""")).asJson)
            
        }

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* *** UpdateExistingBasket-UpdQty V105 ******* */
        .exec(http("UpdateBasketQtyKnownUser")
          .put(uri02 + """/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyAddToCartWithConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKeyUpdateBasketQtyKnownUser"))
          .check(jsonPath("""$.result.records[1].actions.updateBasketAction.rest.params.bundleContextKey""").find.exists.saveAs("PromoBundleContextKeyKnownUser")).asJson
          .check(jsonPath("""$.result.records[1].actions.updateBasketAction.rest.params.lineItemKey""").find.exists.saveAs("PromoLineItemKeyKnownUser")).asJson
          .body(StringBody("""{"bundleContextKey":"${ProdBundleContextKeyKnownUser}","lineItemKey":"${ProdLineItemKeyKnownUser}","basketAction":"updateBasket","Quantity":"3"}""")).asJson)

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* **** UpdateExistingBasket-UpdAttrib V105 *** */
        .exec(http("UpdateBasketAttribKnownUser")
          .put(uri02 + """/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyUpdateBasketQtyKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex(""""cartContextKey":"(.+?)","result"""").find.exists.saveAs("CartContextKeyUpdateBasketAttribKnownUsers"))
          .body(ElFileBody("./src/test/resources/bodies/eComm/eCom-Prod-Bnd-15399454256600_updatebasket.txt")).asJson)

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* ***** AddPromotion-Step1 V105 ******* */
        .feed(promoFeeder)
        .exec(http("AddPromotion-Step1KnownUser")
          .post(uri02 + """/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyUpdateBasketAttribKnownUsers}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex("""cartContextKey":"(.+?)"."result""").optional.saveAs("CartContextKeyAddPromotion-Step1KnownUser"))
          .check(regex(""""transactionKey":"(.+?)"""").optional.saveAs("TransKeyKnownUser"))
          .check(regex("""result":(.+?)."errorCode""").optional.saveAs("CreateCartAddToCartWithConfigKnownUser"))
          .check(regex(""""transactionKey":"(.+?)"""").count.saveAs("TransKeyCountKnownUser"))
          .check(regex(""""AddWithNoConfig","offer":"(.+?)"},"link"""").count.saveAs("OfferFromDelete"))
          .body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}"}""")).asJson)

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* Transaction Key Count = 1 then enter this loop */
        .doIfEquals("${TransKeyCountKnownUser}", 1) {

          /* ********** AddPromotion-Step2 V105 *********** */
          feed(promoFeeder)
            .exec(http("AddPromotion-Step2KnownUser")
              .post(uri02 + """/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyUpdateBasketAttribKnownUsers}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
              .headers(header_1)
              .check(status.is(200))
              .check(status.not(404), status.not(500),status.not(504),status.not(503))
              .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKeyAddPromotion-Step2KnownUser"))
              .check(regex("""result":(.+?)."errorCode""").find.exists.saveAs("CreateCartAddToCartWithConfigKnownUser"))
              .body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}","transactionKey":"${TransKeyKnownUser}"}""")).asJson)

            .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

            /* ****** GetBasketDetailsKnownUser V105 ***** */
            .exec(http("GetBasketDetailsKnownUser")
              .get(uri02 + """/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyAddPromotion-Step2KnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
              .headers(header_1)
              .check(status.is(200))
              .check(status.not(404), status.not(500),status.not(504),status.not(503))
              .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKeyGetBasketDetailsKnownUser"))
              .check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").find.exists.saveAs("DelProdLineItemKeyKnownUser")).asJson
              .check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").find.exists.saveAs("DelProdBundleContextKeyKnownUser")).asJson
              .check(jsonPath("""$.result.records[0].promotions.records[0].actions.deletePromotionBasketAction.rest.params.offer""").count.saveAs("CountDelPromoKnownUser")).asJson
              .check(jsonPath("""$.result.records[0].promotions.records[0].actions.deletePromotionBasketAction.rest.params.offer""").optional.saveAs("DelPromoKnownUser")).asJson)

            .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

            /* ********** DeleteProductAPI V105 *********** */
            .exec(http("DeleteProdKnownUser")
              .post(uri02 + """/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
              .headers(header_1)
              .check(status.is(200))
              .check(status.not(404), status.not(500),status.not(504),status.not(503))
              .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKeyDeleteProdKnownUser"))
              .body(StringBody("""{"bundleContextKey":"${ProdBundleContextKeyKnownUser}","basketAction":"deleteFromBasket","itemKey":"${ProdLineItemKeyKnownUser}"}""")).asJson)

            .pause(5 , 7 )

            /* ********** CreateCart V105 *********** */
            .exec(http("CreateCartKnownUser")
              .post(uri02 + """/v3/carts?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
              .headers(header_1)
              .check(status.is(200))
              .check(status.not(404), status.not(500),status.not(504),status.not(503))
              .check(regex("""orderId":"(.+?)"""").find.exists.saveAs("OrderIdKnownUser"))
              .body(StringBody("""{"JSONResult":${CreateCartAddToCartWithConfigKnownUser},"accountId": "${AccountId}","catalogCode": "ECOM-CATALOG"}""")).asJson)

            .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

            //.exec(flushSessionCookies)
            //.exec(flushCookieJar)
            //.exec(flushHttpCache)
            //.exec { session => println(session); session }

        }
        .doIfEquals("${TransKeyCountKnownUser}", 0) {

          /* ****** GetBasketDetailsKnownUser V105 ***** */
          exec(http("GetBasketDetailsKnownUser")
            .get(uri02 + """/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyUpdateBasketAttribKnownUsers}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
            .headers(header_1)
            .check(status.is(200))
            .check(status.not(404), status.not(500),status.not(504),status.not(503))
            .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKeyGetBasketDetailsKnownUser"))
            .check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").find.exists.saveAs("DelProdBundleContextKeyKnownUser")).asJson
            .check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").find.exists.saveAs("DelProdLineItemKeyKnownUser")).asJson
            .check(jsonPath("""$.result.records[0].promotions.records[0].actions.deletePromotionBasketAction.rest.params.offer""").count.saveAs("CountDelPromoKnownUser")).asJson
            .check(jsonPath("""$.result.records[0].promotions.records[0].actions.deletePromotionBasketAction.rest.params.offer""").optional.saveAs("DelPromoKnownUser")).asJson)

            .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

            /* ********** DeleteProductAPI V105 *********** */
            .exec(http("DeleteProdKnownUser")
              .post(uri02 + """/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
              .headers(header_1)
              .check(status.is(200))
              .check(status.not(404), status.not(500),status.not(504),status.not(503))
              .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKeyDeleteProdKnownUser"))
              .body(StringBody("""{"bundleContextKey":"${ProdBundleContextKeyKnownUser}","basketAction":"deleteFromBasket","itemKey":"${ProdLineItemKeyKnownUser}"}""")).asJson)

            .pause(5 , 7 )

            /* ********** CreateCart V105 *********** */
            .exec(http("CreateCartKnownUser")
              .post(uri02 + """/v3/carts?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
              .headers(header_1)
              .check(status.is(200))
              .check(status.not(404), status.not(500),status.not(504),status.not(503))
              .check(regex("""orderId":"(.+?)"""").find.exists.saveAs("OrderIdKnownUser"))
              .body(StringBody("""{"JSONResult":${CreateCartAddToCartWithConfigKnownUser},"accountId": "${AccountId}","catalogCode": "ECOM-CATALOG"}""")).asJson)

            .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

            //.exec(flushSessionCookies)
            //.exec(flushCookieJar)
            //.exec(flushHttpCache)
            //.exec { session => println(session); session }
        }
    }

              .exec(flushSessionCookies)
              .exec(flushCookieJar)
              .exec(flushHttpCache)
}
