  package XOM_Benchmark

  import scala.concurrent.duration._

  import io.gatling.core.Predef._
  import io.gatling.core.structure.ChainBuilder
  import io.gatling.http.Predef._
  import io.gatling.jdbc.Predef._
  import io.gatling.jsonpath._
  import Headers._
  import scala.collection._
  import java.time.format.DateTimeFormatter
  import java.time.LocalDateTime
  import java.time.LocalDate


   object XOM_Benchmark_Test {

      val uri01 = Configuration.Uri01
      val uri05 = Configuration.Uri05
      val uri10 = Configuration.Uri10
      var modifiedItemJson = new StringBuilder()
      val randomNumber = new scala.util.Random
      var accountName = new StringBuilder()
      val userFeeder = csv("./src/test/resources/data/xombenchmark/XOM_Benchmark_Users.csv").random
      val productFeeder = csv("./src/test/resources/data/xombenchmark/XOM_Benchmark_Products.csv").random
      
      val scn = scenario("XOM_CPQ_Benchmark")
      
      .exec(session => session.set("PriceListId",Configuration.PriceListId))
     
      .feed(userFeeder)        
      .exec(http("XOM_Benchmark_Login")
          .post(uri01 + "/")
          .headers(headers_00)
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          .formParam("startURL", "")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          .formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "M1D2l15jFvl")
          .formParam("display", "page")
          .formParam("username", "${username}")
          .formParam("pw", "${password}")
          .formParam("Login", ""))

      .exec(http("RESTGetOAuthToken")
          .post("https://test.salesforce.com/services/oauth2/token")
          .header("Content-Type", "application/x-www-form-urlencoded")
          .formParam("password", "${password}")
          .formParam("username", "${username}")
          .formParam("client_secret", "7119599995527965426")
          .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
          .formParam("grant_type", "password")
          .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
          .check(status.is(200)))


        .exec(session => session.set("AccountName",""))

        .exec( session => {
              val random_index = randomNumber.nextInt(100000)
              accountName.append("Acc-"+random_index)
              session
            })

            .exec(session => session.set("AccountName",accountName))
             
             .exec( session => {
              accountName = new StringBuilder()
              session
            })
              
      /* *********** CreateAccount *********** */
          .repeat(10)
          {
              exec(http("CreateAccount")
              .post(uri10 +"/services/data/v41.0/sobjects/account")
              .headers(header_1)
              .check(regex(""""id":"(.*?)"""").find.exists.saveAs("AccountId"))
              .body( StringBody("""
                {
                      "Name" : "${AccountName}",
                      "ShippingCity" : "San Francisco",
                      "RecordTypeId" : "012g00000005CoWAAU",
                      "Status__c"    : "Active"
                }""")).asJson)

       /* *********** CreateOrder *********** */
          .exec(http("Create a new order")
              .post(uri10 +"/services/apexrest/v2/carts")
              .headers(header_1)
              .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
              .body( StringBody("""{"subaction":"createOrder",
                        "inputFields":[
                          {"AccountId":"${AccountId}"},
                          {"PriceListId__c":"${PriceListId}"},
                          {"Name":"NewOrder1"},{"Status":"Draft"},
                          {"EffectiveDate":"6/5/2018"}
                        ]}""")).asJson)

            .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

            /* ********** SetPriceListForCart *********** */
            .exec(http("Set PriceList for the order")
              .put(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/")
              .headers(header_1)
              .body(StringBody("""{
                            "inputFields": 
                            [
                              {
                                  "PriceListId__c": "${PriceListId}"
                                }
                              ],
                            "cartId": "${OrderID}",
                            "methodName": "updateCarts"
                        }""")).asJson)

            /* ********** GetListOfProductsForCart *********** */
            .exec(http("Get list of products for cart")
              .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/products?pagesize=10")
              .check(jsonPath("$.records[*].Id.value").find.saveAs("ListOfPBEntries"))
              .headers(header_1))

              .pause(Configuration.MiniMinWaitMs milliseconds, Configuration.MiniMaxWaitMs milliseconds)


            /* ********** ADD Item to cart********** */
            .feed(productFeeder) 
            .exec(http("Add items to cart")
              .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
              .headers(header_1)
              .body( StringBody("""{
                                          "items":[{
                                          "itemId":"${ProductId}"
                                          }],
                                          "hierarchy":3,
                                          "lastItemId":"",
                                          "pagesize":20
                                          }""")).asJson)

      .pause(Configuration.MiniMinWaitMs milliseconds, Configuration.MiniMaxWaitMs milliseconds)

        .exec(http("lineitemidtoclone")
              .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items?pagesize=10&price=false&validate=false")
              .headers(header_1)
              .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItemclone")))

        /* ********** Clone line Item to cart********** */
        .exec(http("Clone a cart line item ")
              .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/clone")
              .headers(header_1)
              .body( StringBody("""{
                                      "items": [
                                                  {"itemId":"${LineItemclone}"}
                                      ],
                                      "hierarchy": 1,
                                      "lastItemId": "",
                                      "pagesize": 20
                                   }""")).asJson)

              .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


        /*********** Get Cart LineItems***********/
        .exec(http("GetCartLineItems")
              .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items?pagesize=10&price=false&validate=false")
              .headers(header_1)
              .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1"))
              .check(jsonPath("$.records[1].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem2")))

              .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        /*********** Get LineItems Details***********/
        .exec(http("Get line item details")
                .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
                .queryParamSeq(Seq(("id", "${LineItem1}")))
                .headers(header_1)
                .check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))

              .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
              
              .exec(session => { 
                //originalItemJson.append(session("capturedItemHierarchy").as[String])
                modifiedItemJson = new StringBuilder()
                modifiedItemJson.append("""{"items":{"records":[{"displaySequence":-1,""").append(session("capturedItemHierarchy").as[String]).append("}]}}")
                session
                })
                
             /* Updating the Quantity from default 1.00 to 3.00 */
              .exec(http("Update cart line item")
                .put(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
                .headers(header_1)
                .body(StringBody(session =>  modifiedItemJson.replaceAllLiterally(""""Quantity":{"value":1.00""",""""Quantity":{"value":3.00""").toString() )).asJson
                .check(regex("""message":"Successfully.updated."}]""").find.exists))

              .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

               /************ Delete one line item from cart *********** */
        .exec(http("Delete an item from the cart")
              .delete(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/${LineItem2}")
              .headers(header_1)
              .check(regex("""INFO","message":"Successfully deleted.""").find.exists))

              .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

               /************ Get pricing of total cart*********** */
        .exec(http("Get carts pricing")
              .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}?price=true&validate=true")
              .headers(header_1)
              .check(regex("""EffectiveOrderTotal__c":10272.00""").find.exists))

              .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

          /************ Get Session Id *********** */
        .exec(http("Order_Detail")
              .get(uri10 + "/${OrderID}")
              .headers(headers_05) 
              .check(regex("""sforce.connection.sessionId = '(.+)';.}[a-zA-Z0-9\s{.('_,:]*name:.'XOMSubmitOrder'}""").find.exists.saveAs("""sfdc_session_id""")))

              .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
       
         /************ Submit the Order *********** */
        .exec(http("SubmitOrder")
              .post(uri10 + "/services/Soap/package/SimpleDecompositionController")
              .headers(headers_02)
              .check(regex("""<decomposeAndCreatePlanExResponse><result>\{&quot;planId&quot;:&quot;(.+)&quot;,""").find.exists.saveAs("PlanId"))
              .body(ElFileBody("./src/test/resources/bodies/xom_benchmark/xom_benchmark_submit.txt"))) 

              .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
 }
}              