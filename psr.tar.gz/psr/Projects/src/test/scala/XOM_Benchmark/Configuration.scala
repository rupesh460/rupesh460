package XOM_Benchmark

object Configuration
 {
	val BaseUrl = "https://c.cs17.visual.force.com"
	val Uri01 = "https://test.salesforce.com"
	val Uri05 = "https://c.cs17.visual.force.com"
	val Uri10 = "https://cs17.salesforce.com"


	val PriceListId = "a2Pg0000001UvvuEAC"


	val MinWaitMs = 5000
	val MaxWaitMs = 15000

	val MiniMinWaitMs = 1000
	val MiniMaxWaitMs = 3000

}