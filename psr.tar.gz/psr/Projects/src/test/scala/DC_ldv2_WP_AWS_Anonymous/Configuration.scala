package DC_ldv2_WP_AWS_Anonymous



object Configuration {
  val BaseUrl = "https://c.cs10.visual.force.com"
  val Uri01 = "https://test.salesforce.com"
  val Uri02 = "https://cs10.salesforce.com"
  //val Uri02 = "https://api.perf.vlocity.dc.vloc-dev.com/dc/"

  val minWaitMs = Integer.getInteger("minWaitMs", 3000)
  val maxWaitMs = Integer.getInteger("maxWaitMs", 4000)
  val loginminWaitMs=Integer.getInteger("loginminWaitMs", 5000)
  val loginmaxWaitMs=Integer.getInteger("loginmaxWaitMs", 6000)
  val script1_Browsing_minWaitMs=Integer.getInteger("script1_Browsing_minWaitMs", 3000)
  val script1_Browsing_maxWaitMs=Integer.getInteger("script1_Browsing_maxWaitMs", 4000)
  val script2_BasketOperation_minWaitMs=Integer.getInteger("script2_BasketOperation_minWaitMs", 3000)
  val script2_BasketOperation_maxWaitMs=Integer.getInteger("script2_BasketOperation_maxWaitMs", 4000)
  val script3_OrderCreation_minWaitMs=Integer.getInteger("script3_OrderCreation_minWaitMs", 3000)
  val script3_OrderCreation_maxWaitMs=Integer.getInteger("script3_OrderCreation_maxWaitMs", 4000)

  val BaseUrl_AWS = "https://1fhjm3ncac.execute-api.us-east-2.amazonaws.com/test/dc/"
  val Uri02_AWS = "https://api.perf4.vlocity.dc.vloc-dev.com/dc"


}