package DC_ldv2_WP_AWS_Anonymous

object Headers {
  val header_0 = Map(
    "Accept" -> "text/javascript, text/html, application/xml, application/json, text/xml, */*",
    "Accept-Encoding" -> "gzip, deflate, br",
    "Accept-Language" -> "en-US,en;q=0.8",
    "Connection" -> "keep-alive",
    "Authorization" -> "Bearer ${Token_ID}")

  val header_1 = Map(

    // "Accept" -> "text/javascript, text/html, application/xml, application/json, text/xml, */*",
    //"Accept-Encoding" -> "gzip, deflate, br",
    // "Accept-Language" -> "en-US,en;q=0.8",
    // "Connection" -> "keep-alive",
    "Content-Type" -> "application/json",
    "charset"->"UTF-8",
    //"Authorization" -> "Bearer ${Token_ID}")
    "authorization" -> "Basic YWRtaW46VTdyRnFjZ1g0SXVlOUJMT1loSjl2b3hSQTQ5bHNXZ0J3NjJOVHlMZw==")

}