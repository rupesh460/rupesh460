package DC_ldv2_WP_SF_Loggedin_ABO_10LI

import io.gatling.core.Predef._
import io.gatling.http.Predef._

class DC_WP_Loggedin_SF_scn extends Simulation{

  val httpConf = http
    .baseUrl(Configuration.BaseUrl)
    .inferHtmlResources(BlackList(""".*\.js""", """.*\.css""", """.*\.gif""", """.*\.jpeg""", """.*\.jpg""", """.*\.ico""", """.*\.woff""", """.*\.(t|o)tf""", """.*\.png"""), WhiteList())
    .acceptHeader("*/*")
    .acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8")
    .acceptEncodingHeader("gzip, deflate, sdch")
    .acceptLanguageHeader("en-US,en;q=0.8")
    .disableCaching
    .contentTypeHeader("application/x-www-form-urlencoded; charset=UTF-8")
    .userAgentHeader("Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:41.0) Gecko/20100101 Firefox/41.0")

  //Loggedin Scenarios
  /*val loginLoggedinUsers = Integer.getInteger("SF_DC_Loggedin_Login_Users", 1)
  val loginLoggedinRampUp = Integer.getInteger("SF_DC_Loggedin_Login_RampUp", 1)

  val script1BrowsingUsers = Integer.getInteger("SF_DC_Loggedin_script1Browsing_Users", 1)
  val script1BrowsingRampUp = Integer.getInteger("SF_DC_Loggedin_script1Browsing_RampUp", 1)

  val script2BasketOperationUsers = Integer.getInteger("SF_DC_Loggedin_script2BasketOperation_Users", 1)
  val script2BasketOperationRampUp = Integer.getInteger("SF_DC_Loggedin_script2BasketOperation_RampUp", 1)

  val script3OrderCreationUsers = Integer.getInteger("SF_DC_Loggedin_script3OrderCreation_Users", 1)
  val script3OrderCreationRampUp = Integer.getInteger("SF_DC_Loggedin_script3OrderCreation_RampUp", 1)
  
  //ABO Scenarios
  val script4ABOAddUsers = Integer.getInteger("SF_DC_Loggedin_script4ABOAddUsers_Users", 1)
  val script4ABOAddRampUp = Integer.getInteger("SF_DC_Loggedin_script4ABOAddRampUp_RampUp", 1)

  val script5ABOUpdateUsers = Integer.getInteger("SF_DC_Loggedin_script5ABOUpdateUsers_Users", 1)
  val script5ABOUpdateRampUp = Integer.getInteger("SF_DC_Loggedin_script5ABOUpdateRampUp_RampUp", 1)

  val script6ABODisconnectUsers = Integer.getInteger("SF_DC_Loggedin_script6ABODisconnectUsers_Users", 1)
  val script6ABODisconnectRampUp = Integer.getInteger("SF_DC_Loggedin_script6ABODisconnectRampUp_RampUp", 1)
  
  val script7ABOACDUsers = Integer.getInteger("SF_DC_Loggedin_script7ABOACDUsers_Users", 1)
  val script7ABOACDRampUp = Integer.getInteger("SF_DC_Loggedin_script7ABOACDRampUp_RampUp", 1)*/
  
 
  val maxDurationSecs = Integer.getInteger("maxDurationSecs", 1)
  val testDuration = Integer.getInteger("testDuration", 1)
  
  val s1_incrementConcurrentUsersInTest=Integer.getInteger("s1_incrementConcurrentUsersInTest", 1)
  val s1_howManyTimesToIncrement=Integer.getInteger("s1_howManyTimesToIncrement", 1)
  val s1_eachLevelLastingInTest=Integer.getInteger("s1_eachLevelLastingInTest", 1)
  val s1_separatedByRampsLasting=Integer.getInteger("s1_separatedByRampsLasting", 1)
  val s1_startingFromHowManyUsers=Integer.getInteger("s1_startingFromHowManyUsers", 1)

  val s2_incrementConcurrentUsersInTest=Integer.getInteger("s2_incrementConcurrentUsersInTest", 1)
  val s2_howManyTimesToIncrement=Integer.getInteger("s2_howManyTimesToIncrement", 1)
  val s2_eachLevelLastingInTest=Integer.getInteger("s2_eachLevelLastingInTest", 1)
  val s2_separatedByRampsLasting=Integer.getInteger("s2_separatedByRampsLasting", 1)
  val s2_startingFromHowManyUsers=Integer.getInteger("s2_startingFromHowManyUsers", 1)

  val s3_incrementConcurrentUsersInTest=Integer.getInteger("s3_incrementConcurrentUsersInTest", 1)
  val s3_howManyTimesToIncrement=Integer.getInteger("s3_howManyTimesToIncrement", 1)
  val s3_eachLevelLastingInTest=Integer.getInteger("s3_eachLevelLastingInTest", 1)
  val s3_separatedByRampsLasting=Integer.getInteger("s3_separatedByRampsLasting", 1)
  val s3_startingFromHowManyUsers=Integer.getInteger("s3_startingFromHowManyUsers", 1)

  val s4_incrementConcurrentUsersInTest=Integer.getInteger("s4_incrementConcurrentUsersInTest", 1)
  val s4_howManyTimesToIncrement=Integer.getInteger("s4_howManyTimesToIncrement", 1)
  val s4_eachLevelLastingInTest=Integer.getInteger("s4_eachLevelLastingInTest", 1)
  val s4_separatedByRampsLasting=Integer.getInteger("s4_separatedByRampsLasting", 1)
  val s4_startingFromHowManyUsers=Integer.getInteger("s4_startingFromHowManyUsers", 1)

  val s5_incrementConcurrentUsersInTest=Integer.getInteger("s5_incrementConcurrentUsersInTest", 1)
  val s5_howManyTimesToIncrement=Integer.getInteger("s5_howManyTimesToIncrement", 1)
  val s5_eachLevelLastingInTest=Integer.getInteger("s5_eachLevelLastingInTest", 1)
  val s5_separatedByRampsLasting=Integer.getInteger("s5_separatedByRampsLasting", 1)
  val s5_startingFromHowManyUsers=Integer.getInteger("s5_startingFromHowManyUsers", 1)

  val s6_incrementConcurrentUsersInTest=Integer.getInteger("s6_incrementConcurrentUsersInTest", 1)
  val s6_howManyTimesToIncrement=Integer.getInteger("s6_howManyTimesToIncrement", 1)
  val s6_eachLevelLastingInTest=Integer.getInteger("s6_eachLevelLastingInTest", 1)
  val s6_separatedByRampsLasting=Integer.getInteger("s6_separatedByRampsLasting", 1)
  val s6_startingFromHowManyUsers=Integer.getInteger("s6_startingFromHowManyUsers", 1)

  val s7_incrementConcurrentUsersInTest=Integer.getInteger("s7_incrementConcurrentUsersInTest", 1)
  val s7_howManyTimesToIncrement=Integer.getInteger("s7_howManyTimesToIncrement", 1)
  val s7_eachLevelLastingInTest=Integer.getInteger("s7_eachLevelLastingInTest", 1)
  val s7_separatedByRampsLasting=Integer.getInteger("s7_separatedByRampsLasting", 1)
  val s7_startingFromHowManyUsers=Integer.getInteger("s7_startingFromHowManyUsers", 1)
  
  

  setUp(
	//Loggedin Scenarios
	/*DC_WP_Loggedin_SF.loginLoggedinScn.inject(rampUsers(loginLoggedinUsers) during (loginLoggedinRampUp seconds)).protocols(httpConf),
	DC_WP_Loggedin_SF.script1Browsing.inject(rampUsers(script1BrowsingUsers) during (script1BrowsingRampUp seconds)).protocols(httpConf),
    DC_WP_Loggedin_SF.script2BasketOperation.inject(rampUsers(script2BasketOperationUsers) during (script2BasketOperationRampUp seconds)).protocols(httpConf),
    DC_WP_Loggedin_SF.script3OrderCreation.inject(rampUsers(script3OrderCreationUsers) during (script3OrderCreationRampUp seconds)).protocols(httpConf),
    //ABO Scenarios
	DC_WP_Loggedin_SF.script4ABOAdd.inject(rampUsers(script4ABOAddUsers) during (script4ABOAddRampUp seconds)).protocols(httpConf),
    DC_WP_Loggedin_SF.script5ABOUpdate.inject(rampUsers(script5ABOUpdateUsers) during (script5ABOUpdateRampUp seconds)).protocols(httpConf),
    DC_WP_ABO_SF.script6ABODisconnect.inject(rampUsers(script6ABODisconnectUsers) during (script6ABODisconnectRampUp seconds)).protocols(httpConf),
	DC_WP_ABO_SF.script7ABOACD.inject(rampUsers(script7ABOACDUsers) during (script7ABOACDRampUp seconds)).protocols(httpConf)).maxDuration(maxDurationSecs seconds)*/
	
	DC_WP_Loggedin_SF.script1Browsing.inject(incrementConcurrentUsers(s1_incrementConcurrentUsersInTest).times(s1_howManyTimesToIncrement).eachLevelLasting(s1_eachLevelLastingInTest seconds).separatedByRampsLasting(s1_separatedByRampsLasting seconds).startingFrom(s1_startingFromHowManyUsers)).protocols(httpConf),

	DC_WP_Loggedin_SF.script2BasketOperation.inject(incrementConcurrentUsers(s2_incrementConcurrentUsersInTest).times(s2_howManyTimesToIncrement).eachLevelLasting(s2_eachLevelLastingInTest seconds).separatedByRampsLasting(s2_separatedByRampsLasting seconds).startingFrom(s2_startingFromHowManyUsers)).protocols(httpConf),

	DC_WP_Loggedin_SF.script3OrderCreation.inject(incrementConcurrentUsers(s3_incrementConcurrentUsersInTest).times(s3_howManyTimesToIncrement).eachLevelLasting(s3_eachLevelLastingInTest seconds).separatedByRampsLasting(s3_separatedByRampsLasting seconds).startingFrom(s3_startingFromHowManyUsers)).protocols(httpConf),
	
	//ABO ************************* //ABO
	DC_WP_Loggedin_SF.script4ABOAdd.inject(incrementConcurrentUsers(s4_incrementConcurrentUsersInTest).times(s4_howManyTimesToIncrement).eachLevelLasting(s4_eachLevelLastingInTest seconds).separatedByRampsLasting(s4_separatedByRampsLasting seconds).startingFrom(s4_startingFromHowManyUsers)).protocols(httpConf),

	DC_WP_Loggedin_SF.script5ABOUpdate.inject(incrementConcurrentUsers(s5_incrementConcurrentUsersInTest).times(s5_howManyTimesToIncrement).eachLevelLasting(s5_eachLevelLastingInTest seconds).separatedByRampsLasting(s5_separatedByRampsLasting seconds).startingFrom(s5_startingFromHowManyUsers)).protocols(httpConf),
	
	DC_WP_ABO_SF.script6ABODisconnect.inject(incrementConcurrentUsers(s6_incrementConcurrentUsersInTest).times(s6_howManyTimesToIncrement).eachLevelLasting(s6_eachLevelLastingInTest seconds).separatedByRampsLasting(s6_separatedByRampsLasting seconds).startingFrom(s6_startingFromHowManyUsers)).protocols(httpConf),

	DC_WP_ABO_SF.script7ABOACD.inject(incrementConcurrentUsers(s7_incrementConcurrentUsersInTest).times(s7_howManyTimesToIncrement).eachLevelLasting(s7_eachLevelLastingInTest seconds).separatedByRampsLasting(s7_separatedByRampsLasting seconds).startingFrom(s7_startingFromHowManyUsers)).protocols(httpConf)).maxDuration(maxDurationSecs seconds)
}