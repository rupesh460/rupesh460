/* what are all to change to work for only 23 LI are :
1. Change Update Baket Qty and Update Basket Attrib to reflect AddToCartWithNoConfig ContextKeys.
2. Update the capture position of PromoBundleContextKey , promolineitemkey to point for records[0] instead of records [1]
3. AddPromotion Step1 needs to be changed with ContextKey of AddToCartWithNoConfig instead of AddToCartWithConfig to match 23 LI only 
4. Change the context key of AddPromotion-step2 to AddToCartWithNoConfig */

package DC_ldv2_WP_SF_Loggedin_ABO_10LI

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import Headers.header_0
import Headers.header_0
import io.gatling.core.feeder._
import java.util.Base64
import java.nio.charset.StandardCharsets
import scala.util.matching.Regex


object DC_WP_Loggedin_SF 
{

	val uri01 = Configuration.Uri01
	val uri02 = Configuration.Uri02
	val offerFeeder = csv("./src/test/resources/data/DC_WP/ldv2_offercodes.csv").random
	val contextFeeder = csv("./src/test/resources/data/DC_WP/ldv2_contextdimensions.csv").random
	val promoFeeder = csv("./src/test/resources/data/DC_WP/ldv2_promocodes.csv").random
	val accountFeeder = csv("./src/test/resources/data/DC_WP/ldv2_accounts.csv").random
	val assetToBasket= csv("./src/test/resources/data/DC_WP/ldv2_10LI_assettobasketIds.csv").random
	
    val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
       val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
       val password_v = (passwordByEnv.get("perf3").toString)
       val password_encoded = password_v.substring(12,(password_v.length - 2 ))
       val credentials = new String(Base64.getDecoder.decode(password_encoded))

	val loginLoggedinScn = scenario("SF_DC_Loggedin_Login")
	
	.exec(session => session.set("password",credentials))

	/* ********* Get OAuth Token for Perf2 ************* */
	.exec(http("RESTGetOAuthToken")
	.post("https://test.salesforce.com/services/oauth2/token")
	.header("Content-Type", "application/x-www-form-urlencoded")
	.formParam("password", "${password}")
	.formParam("username", "ldvtesting2@vlocity.com")
	.formParam("client_secret", "4F1DE5B4EC987DC9138A68A1D1567ECA1DCC9583A88B3130B95D2742ADB473EA")
	.formParam("client_id", "3MVG9_7ddP9KqTzfqPTQdMvr5pwHfDxPcU4QZMHvJTbg1TlFT_Nx8_2aS.NWDGESp83ZDu7NTPhr8X3kVxfq3")
	.formParam("grant_type", "password")
	.check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
	.check(status.is(200)))

	.repeat(10000) {

		pause(Configuration.loginminWaitMs milliseconds, Configuration.loginmaxWaitMs milliseconds)
	}

	val script1Browsing = scenario("SF_DC_KnownUser_Script_1_Browsing")
	
	.exec(session => session.set("password",credentials))

	/* ********* Get OAuth Token for Perf2 ************* */
	.exec(http("RESTGetOAuthToken")
	.post("https://test.salesforce.com/services/oauth2/token")
	.header("Content-Type", "application/x-www-form-urlencoded")
	.formParam("password", "${password}")
	.formParam("username", "ldvtesting2@vlocity.com")
	.formParam("client_secret", "4F1DE5B4EC987DC9138A68A1D1567ECA1DCC9583A88B3130B95D2742ADB473EA")
	.formParam("client_id", "3MVG9_7ddP9KqTzfqPTQdMvr5pwHfDxPcU4QZMHvJTbg1TlFT_Nx8_2aS.NWDGESp83ZDu7NTPhr8X3kVxfq3")
	.formParam("grant_type", "password")
	.check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
	.check(status.is(200)))
	
	.pause(Configuration.script1_Browsing_minWaitMs milliseconds, Configuration.script1_Browsing_maxWaitMs milliseconds)

	.repeat(10000)
	{

		/* ********* Call to get contextKey  ************* */
		feed(accountFeeder)
		.exec(http("s1_getLoggedinCK")
		.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers?context={"accountId":"${AccountId}"}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""contextKey":"(.+?)".""").find.exists.saveAs("LoggedinCK")))

		.pause(Configuration.script1_Browsing_minWaitMs milliseconds, Configuration.script1_Browsing_maxWaitMs milliseconds)

		/* ********** GetOffersByCatalogKnownUser V105 *********** */
		.exec(http("s1_GetOffersByCatalogKnownUser")
		.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""contextKey""").find.exists)
		.check(jsonPath("$.offers[*].ProductCode").findAll.saveAs("ProductOffersListKnownUser")))

		.pause(Configuration.script1_Browsing_minWaitMs milliseconds, Configuration.script1_Browsing_maxWaitMs milliseconds)

		.feed(offerFeeder)
		.exec(http("s1_GetOfferDetailsKnownUser")
		.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers/${OfferCode}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""contextKey""").find.exists)
		.check(bodyString.saveAs("OfferDetailsResKnownUser")).asJson)

		.pause(Configuration.script1_Browsing_minWaitMs milliseconds, Configuration.script1_Browsing_maxWaitMs milliseconds)

		/* ********** ConfigureOffer  V105 *********** */
		.exec(http("s1_ConfigureOfferKnownUser")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers/${OfferCode}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.body(StringBody("""${OfferDetailsResKnownUser}""")).asJson
		.check(regex("""contextKey""").find.exists)
		//.body(ElFileBody("./src/test/resources/bodies/DC_WP/eCom-Prod-Bnd-15399454256600.txt")).asJson
		.check(regex(""""result":(.+?)."errorCode":"INVOKE""").find.exists.saveAs("AddWithConfigKnownUser")))

		.pause(Configuration.script1_Browsing_minWaitMs milliseconds, Configuration.script1_Browsing_maxWaitMs milliseconds)

		.exec(flushSessionCookies)
		.exec(flushCookieJar)
		.exec(flushHttpCache)

	}

	val script2BasketOperation = scenario("SF_DC_KnownUser_Script_2_Basket_Operation")
	
	.exec(session => session.set("password",credentials))

	/* ********* Get OAuth Token for Perf2 ************* */
	.exec(http("RESTGetOAuthToken")
	.post("https://test.salesforce.com/services/oauth2/token")
	.header("Content-Type", "application/x-www-form-urlencoded")
	.formParam("password", "${password}")
	.formParam("username", "ldvtesting2@vlocity.com")
	.formParam("client_secret", "4F1DE5B4EC987DC9138A68A1D1567ECA1DCC9583A88B3130B95D2742ADB473EA")
	.formParam("client_id", "3MVG9_7ddP9KqTzfqPTQdMvr5pwHfDxPcU4QZMHvJTbg1TlFT_Nx8_2aS.NWDGESp83ZDu7NTPhr8X3kVxfq3")
	.formParam("grant_type", "password")
	.check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
	.check(status.is(200)))
	
	.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

	.repeat(10000)
	{

		/* ********* Call to get contextKey  ************* */
		feed(accountFeeder)
		.exec(http("s2_getLoggedinCK")
		.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers?context={"accountId":"${AccountId}"}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""contextKey":"(.+?)".""").find.exists.saveAs("LoggedinCK")))

		.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)
		
		/* ********** GetOffersByCatalogKnownUser V105 *********** */
		.exec(http("s2_GetOffersByCatalogKnownUser")
		.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""contextKey""").find.exists)
		.check(jsonPath("$.offers[*].ProductCode").findAll.saveAs("ProductOffersListKnownUser")))

		.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)
		 
		.feed(offerFeeder)
		.exec(http("s2_GetOfferDetailsKnownUser")
		.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers/${OfferCode}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""contextKey""").find.exists)
		.check(bodyString.saveAs("OfferDetailsResKnownUser")).asJson)

		.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

		/* ********** ConfigureOffer  V105 *********** */
		.exec(http("s2_ConfigureOfferKnownUser")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers/${OfferCode}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.body(StringBody("""${OfferDetailsResKnownUser}""")).asJson
		.check(regex("""contextKey""").find.exists)
		//.body(ElFileBody("./src/test/resources/bodies/DC_WP/eCom-Prod-Bnd-15399454256600.txt")).asJson
		.check(regex(""""result":(.+?)."errorCode":"INVOKE""").find.exists.saveAs("AddWithConfigKnownUser")))

		.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

		/* ********** AddWithNoConfig V105 *********** */
		.exec(http("s2_AddToCartWithNoConfigKnownUser")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyAddToCartWithNoConfigKnownUser")).asJson
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("ProdBundleContextKeyKnownUserWNC")).asJson
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("ProdLineItemKeyKnownUserWNC")).asJson
		.body(StringBody("""{"offer":"${OfferCode}","basketAction":"AddWithNoConfig"}""")).asJson)

		.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

		/* ********** AddWithConfig V105 *********** */
		.exec(http("s2_AddToCartWithConfigKnownUser")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAddToCartWithConfigKnownUser"))
		.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_ATCWC")).asJson
		.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_ATCWC_Count"))
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("ProdBundleContextKeyKnownUser")).asJson
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("ProdLineItemKeyKnownUser")).asJson
		.body(StringBody("""{"basketAction":"AddAfterConfig","productConfig":${AddWithConfigKnownUser}}""")).asJson)

		.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)


		.doIfEquals("${MultiTransactionKeyLoggedin_ATCWC_Count}",1)
		{

			doWhile(session => session("MultiTransactionKeyLoggedin_ATCWC_Count").as[String].equals("1"))
			{

				exec {

					session =>
					val addAfterConfigSession_AddToCart = session("AddWithConfigKnownUser").as[String]
					val buildStringAddWithConfig_AddToCart = addAfterConfigSession_AddToCart.substring(1)
					val finalbuildStringAddWithConfig_AddToCart = session("MultiTransactionKeyLoggedin_ATCWC").as[String]

					session.set("AddWithConfigKnownUserATC_MTS", finalbuildStringAddWithConfig_AddToCart)

				}

				/* ********** AddWithConfig *********** */
				.exec(http("s2_AddToCartWithConfigKnownUser_MTS")
				.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
				.headers(header_0)
				.check(status.is(200))
				.check(regex("""cartContextKey""").optional.saveAs("cartContextKeyPollCheck"))
				.check(status.not(404), status.not(500), status.not(504), status.not(503))
				.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAddToCartWithConfigKnownUser"))
				.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_ATCWC")).asJson
				.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_ATCWC_Count"))
				.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("ProdBundleContextKeyKnownUser")).asJson
				.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("ProdLineItemKeyKnownUser")).asJson
				.body(StringBody("""{"basketAction":"AddAfterConfig","multiTransactionKey":"${AddWithConfigKnownUserATC_MTS}","productConfig":${AddWithConfigKnownUser}}""")).asJson)

				.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

			}

		}
		
		/* ** UpdateExistingBasket-UpdQty V105 ******* */
		.exec(http("s2_UpdateBasketQtyKnownUser")
		.put(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyUpdateBasketQtyKnownUser"))
		.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_UBQ")).asJson
		.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_UBQ_Count"))
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("PromoBundleContextKeyKnownUser")).asJson
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("PromoLineItemKeyKnownUser")).asJson
		.body(StringBody("""{"bundleContextKey":"${ProdBundleContextKeyKnownUserWNC}","lineItemKey":"${ProdLineItemKeyKnownUserWNC}","basketAction":"updateBasket","Quantity":"3"}""")).asJson)

		.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

		.doIfEquals("${MultiTransactionKeyLoggedin_UBQ_Count}",1)
		{
			doWhile(session => session("MultiTransactionKeyLoggedin_UBQ_Count").as[String].equals("1"))
			{
				/* ** UpdateExistingBasket-UpdQty V105 ******* */
				exec(http("s2_UpdateBasketQtyKnownUser_MTS")
				.put(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
				.headers(header_0)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyUpdateBasketQtyKnownUser"))
				.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_UBQ")).asJson
				.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_UBQ_Count"))
				.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("PromoBundleContextKeyKnownUser")).asJson
				.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("PromoLineItemKeyKnownUser")).asJson
				.body(StringBody("""{"bundleContextKey":"${ProdBundleContextKeyKnownUserWNC}","lineItemKey":"${ProdLineItemKeyKnownUserWNC}","basketAction":"updateBasket","Quantity":"3"}""")).asJson)
                
				.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)
			
			}
		}

		/* **** UpdateExistingBasket-UpdAttrib V105 *** CHANGE THIS ###################### */
		.exec(http("s2_UpdateBasketAttribKnownUser")
		.put(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyUpdateBasketQtyKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_UBA")).asJson
		.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_UBA_Count"))
		.check(regex(""""cartContextKey":"(.+?)",""").optional.saveAs("CartContextKeyUpdateBasketAttribKnownUsers"))
		.body(ElFileBody("./src/test/resources/bodies/DC_WP/DC_WP_Loggedin_UpdateBasketAttribute.txt")).asJson)

		.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

		.doIfEquals("${MultiTransactionKeyLoggedin_UBA_Count}",1)
		{
			doWhile(session => session("MultiTransactionKeyLoggedin_UBA_Count").as[String].equals("1"))
			{
				/* **** UpdateExistingBasket-UpdAttrib V105 *** CHANGE THIS ###################### */
				exec(http("s2_UpdateBasketAttribKnownUser_MTS")
				.put(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyUpdateBasketQtyKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
				.headers(header_0)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_UBA")).asJson
				.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_UBA_Count"))
				.check(regex(""""cartContextKey":"(.+?)",""").optional.saveAs("CartContextKeyUpdateBasketAttribKnownUsers"))
				.body(ElFileBody("./src/test/resources/bodies/DC_WP/DC_WP_Loggedin_UpdateBasketAttribute_MTS.txt")).asJson)

				.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

			}
		}

		/* ********** DeleteFromBasket *********** */
		.exec(http("s2_DeleteFromBasketKnownUser")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		//.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyDeleteFromBasketKnownUser"))
		.body(StringBody("""{"deleteBundleNumber":"0","basketAction":"DeleteFromBasket"}""")).asJson)

		.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

		/* ********** DeleteProductAPI *********** */
		.exec(http("s2_DeleteProdKnownUser")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyDeleteProdKnownUser"))
		.body(StringBody("""{"bundleContextKey":"${ProdBundleContextKeyKnownUserWNC}","basketAction":"deleteFromBasket","itemKey":"${ProdLineItemKeyKnownUserWNC}"}""")).asJson)

		.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

		/* ***** AddPromotion-Step1 V105 ******* */
		.feed(promoFeeder)
		.exec(http("s2_AddPromotion-Step1KnownUser")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAddPromotion-Step1KnownUser"))
		.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAddToCartWithNoConfigKnownUser"))
		.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("TransKeyKnownUser"))
		.check(regex("""cartContextKey(.+?)""").optional.saveAs("CreateCartKnownUser"))
		.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("TransKeyCountKnownUser"))
		.body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}"}""")).asJson)

		.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

		.doIfEquals("${TransKeyCountKnownUser}", 0) {
			/* ********** Delete Promotion Items *********** */
			exec(http("s2_DeleteFromBasketPromoKnownUser")
			.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step1KnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
			.headers(header_0)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyDeleteFromBasketPromoKnownUser"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("Del1TransKeyKnownUser"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("Del1TransKeyCountKnownUser"))
			.body(StringBody("""{"basketAction":"deleteFromBasket","offer":"${PromoOffer}","appliedAction":"Add"}""")).asJson)

			.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

			.doIfEquals("${Del1TransKeyCountKnownUser}", 1) 
			{
				doWhile(session => session("Del1TransKeyCountKnownUser").as[String].equals("1"))
				{

					exec(http("s2_DeleteFromBasketPromo_MTS_KnownUser")
					.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step1KnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
					.headers(header_0)
					.check(status.is(200))
					.check(status.not(404), status.not(500),status.not(504),status.not(503))
					.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyDeleteFromBasketPromoKnownUser"))
					.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("Del1TransKeyKnownUser"))
					.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("Del1TransKeyCountKnownUser"))
					.body(StringBody("""{"basketAction":"deleteFromBasket","offer":"${PromoOffer}","appliedAction":"Add","multiTransactionKey":"${Del1TransKeyKnownUser}"}""")).asJson)

					.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)
				}
			}

			.exec(http("s2_GetBasketDetailsKnownUser")
			.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step1KnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
			.headers(header_0)
			.check(status.is(200))
			.check(status.not(404), status.not(500), status.not(504), status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyGetBasketDetailsKnownUser"))
			.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").find.exists.saveAs("DelProdBundleContextKeyKnownUser")).asJson
			.check(jsonPath("""$.result.records[0].promotions.records[0].actions.deletePromotionBasketAction.rest.params.offer""").optional.saveAs("DelPromoKnownUser")).asJson)

			.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)
		}

		.doIfEquals("${TransKeyCountKnownUser}", 1) {

			/* ********** AddPromotion-Step2 V105 *********** */
			//feed(promoFeeder)
			exec(http("s2_AddPromotion-Step2KnownUser")
			.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
			.headers(header_0)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyAddPromotion-Step2KnownUser"))
			.check(regex("""cartContextKey(.+?)""").find.exists.saveAs("CreateCartKnownUser"))
			.body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}","multiTransactionKey":"${TransKeyKnownUser}"}""")).asJson)

			.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)


			/* ********** Delete Promotion Items *********** */
			.exec(http("s2_DeleteFromBasketPromoKnownUser")
			.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step2KnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
			.headers(header_0)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyDeleteFromBasketPromoKnownUser"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("Del2TransKeyKnownUser"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("Del2TransKeyCountKnownUser"))
			.body(StringBody("""{"basketAction":"deleteFromBasket","offer":"${PromoOffer}","appliedAction":"Add"}""")).asJson)

			.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

			.doIfEquals("${Del2TransKeyCountKnownUser}", 1) 
			{
				doWhile(session => session("Del2TransKeyCountKnownUser").as[String].equals("1"))
				{

					exec(http("s2_DeleteFromBasketPromo_MTS_KnownUser")
					.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step2KnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
					.headers(header_0)
					.check(status.is(200))
					.check(status.not(404), status.not(500),status.not(504),status.not(503))
					.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyDeleteFromBasketPromoKnownUser"))
					.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("Del2TransKeyKnownUser"))
					.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("Del2TransKeyCountKnownUser"))
					.body(StringBody("""{"basketAction":"deleteFromBasket","offer":"${PromoOffer}","appliedAction":"Add","multiTransactionKey":"${Del2TransKeyKnownUser}"}""")).asJson)

					.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)
				}
			}

			.exec(http("s2_GetBasketDetailsKnownUser")
			.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step2KnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
			.headers(header_0)
			.check(status.is(200))
			.check(status.not(404), status.not(500), status.not(504), status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyGetBasketDetailsKnownUser"))
			.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").find.exists.saveAs("DelProdBundleContextKeyKnownUser")).asJson
			.check(jsonPath("""$.result.records[0].promotions.records[0].actions.deletePromotionBasketAction.rest.params.offer""").optional.saveAs("DelPromoKnownUser")).asJson)

			.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

			.exec(flushSessionCookies)
			.exec(flushCookieJar)
			.exec(flushHttpCache)

		}
	}

	val script3OrderCreation = scenario("SF_DC_Loggedin_Script_3_Order_Creation")
	
	.exec(session => session.set("password",credentials))

	/* ********* Get OAuth Token for Perf2 ************* */
	.exec(http("RESTGetOAuthToken")
	.post("https://test.salesforce.com/services/oauth2/token")
	.header("Content-Type", "application/x-www-form-urlencoded")
	.formParam("password", "${password}")
	.formParam("username", "ldvtesting2@vlocity.com")
	.formParam("client_secret", "4F1DE5B4EC987DC9138A68A1D1567ECA1DCC9583A88B3130B95D2742ADB473EA")
	.formParam("client_id", "3MVG9_7ddP9KqTzfqPTQdMvr5pwHfDxPcU4QZMHvJTbg1TlFT_Nx8_2aS.NWDGESp83ZDu7NTPhr8X3kVxfq3")
	.formParam("grant_type", "password")
	.check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
	.check(status.is(200)))
	
	.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

	.repeat(10000)
	{

		/* ********* Call to get contextKey  ************* */
		feed(accountFeeder)
		.exec(http("s3_getLoggedinCK")
		.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers?context={"accountId":"${AccountId}"}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""contextKey":"(.+?)".""").find.exists.saveAs("LoggedinCK")))

		.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)
		 
		/* ********** GetOffersByCatalogKnownUser V105 *********** */
		.exec(http("s3_GetOffersByCatalogKnownUser")
		.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""contextKey""").find.exists)
		.check(jsonPath("$.offers[*].ProductCode").findAll.saveAs("ProductOffersListKnownUser")))

		.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)
		
		.feed(offerFeeder)
		.exec(http("s3_GetOfferDetailsKnownUser")
		.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers/${OfferCode}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""contextKey""").find.exists)
		.check(bodyString.saveAs("OfferDetailsResKnownUser")).asJson)

		.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

		 
		/* ********** ConfigureOffer  V105 *********** */
		.exec(http("s3_ConfigureOfferKnownUser")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers/${OfferCode}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.body(StringBody("""${OfferDetailsResKnownUser}""")).asJson
		.check(regex("""contextKey""").find.exists)
		//.body(ElFileBody("./src/test/resources/bodies/DC_WP/eCom-Prod-Bnd-15399454256600.txt")).asJson
		.check(regex(""""result":(.+?)."errorCode":"INVOKE""").find.exists.saveAs("AddWithConfigKnownUser")))

		.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

		/* ********** AddWithNoConfig V105 *********** */
		.exec(http("s3_AddToCartWithNoConfigKnownUser")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyAddToCartWithNoConfigKnownUser")).asJson
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("ProdBundleContextKeyKnownUserWNC")).asJson
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("ProdLineItemKeyKnownUserWNC")).asJson
		.body(StringBody("""{"offer":"${OfferCode}","basketAction":"AddWithNoConfig"}""")).asJson)

		.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

		/* ********** AddWithConfig V105 *********** */
		.exec(http("s3_AddToCartWithConfigKnownUser")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAddToCartWithConfigKnownUser"))
		.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_ATCWC")).asJson
		.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_ATCWC_Count"))
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("ProdBundleContextKeyKnownUser")).asJson
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("ProdLineItemKeyKnownUser")).asJson
		.body(StringBody("""{"basketAction":"AddAfterConfig","productConfig":${AddWithConfigKnownUser}}""")).asJson)

		.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)


		.doIfEquals("${MultiTransactionKeyLoggedin_ATCWC_Count}",1)
		{

			doWhile(session => session("MultiTransactionKeyLoggedin_ATCWC_Count").as[String].equals("1"))
			{

				exec {

					session =>
					val addAfterConfigSession_AddToCart = session("AddWithConfigKnownUser").as[String]
					val buildStringAddWithConfig_AddToCart = addAfterConfigSession_AddToCart.substring(1)
					val finalbuildStringAddWithConfig_AddToCart = session("MultiTransactionKeyLoggedin_ATCWC").as[String]

					session.set("AddWithConfigKnownUserATC_MTS", finalbuildStringAddWithConfig_AddToCart)

				}

				/* ********** AddWithConfig *********** */
				.exec(http("s3_AddToCartWithConfigKnownUser_MTS")
				.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
				.headers(header_0)
				.check(status.is(200))
				.check(regex("""cartContextKey""").optional.saveAs("cartContextKeyPollCheck"))
				.check(status.not(404), status.not(500), status.not(504), status.not(503))
				.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAddToCartWithConfigKnownUser"))
				.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_ATCWC")).asJson
				.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_ATCWC_Count"))
				.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("ProdBundleContextKeyKnownUser")).asJson
				.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("ProdLineItemKeyKnownUser")).asJson
				.body(StringBody("""{"basketAction":"AddAfterConfig","multiTransactionKey":"${AddWithConfigKnownUserATC_MTS}","productConfig":${AddWithConfigKnownUser}}""")).asJson)

				.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

			}

		}

		/* ** UpdateExistingBasket-UpdQty V105 ******* */
		.exec(http("s3_UpdateBasketQtyKnownUser")
		.put(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyUpdateBasketQtyKnownUser"))
		.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_UBQ")).asJson
		.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_UBQ_Count"))
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("PromoBundleContextKeyKnownUser")).asJson
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("PromoLineItemKeyKnownUser")).asJson
		.body(StringBody("""{"bundleContextKey":"${ProdBundleContextKeyKnownUserWNC}","lineItemKey":"${ProdLineItemKeyKnownUserWNC}","basketAction":"updateBasket","Quantity":"3"}""")).asJson)

		.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

		.doIfEquals("${MultiTransactionKeyLoggedin_UBQ_Count}",1)
		{
			doWhile(session => session("MultiTransactionKeyLoggedin_UBQ_Count").as[String].equals("1"))
			{
				/* ** UpdateExistingBasket-UpdQty V105 ******* */
				exec(http("s3_UpdateBasketQtyKnownUser_MTS")
				.put(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
				.headers(header_0)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyUpdateBasketQtyKnownUser"))
				.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_UBQ")).asJson
				.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_UBQ_Count"))
				.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("PromoBundleContextKeyKnownUser")).asJson
				.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("PromoLineItemKeyKnownUser")).asJson
				.body(StringBody("""{"bundleContextKey":"${ProdBundleContextKeyKnownUserWNC}","lineItemKey":"${ProdLineItemKeyKnownUserWNC}","basketAction":"updateBasket","Quantity":"3"}""")).asJson)
				
				.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

			}
		}

		/* **** UpdateExistingBasket-UpdAttrib V105 *** CHANGE THIS ###################### */
		.exec(http("s3_UpdateBasketAttribKnownUser")
		.put(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyUpdateBasketQtyKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_UBA")).asJson
		.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_UBA_Count"))
		.check(regex(""""cartContextKey":"(.+?)",""").optional.saveAs("CartContextKeyUpdateBasketAttribKnownUsers"))
		.body(ElFileBody("./src/test/resources/bodies/DC_WP/DC_WP_Loggedin_UpdateBasketAttribute.txt")).asJson)

		.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

		.doIfEquals("${MultiTransactionKeyLoggedin_UBA_Count}",1)
		{
			doWhile(session => session("MultiTransactionKeyLoggedin_UBA_Count").as[String].equals("1"))
			{
				/* **** UpdateExistingBasket-UpdAttrib V105 *** CHANGE THIS ###################### */
				exec(http("s3_UpdateBasketAttribKnownUser_MTS")
				.put(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyUpdateBasketQtyKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
				.headers(header_0)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_UBA")).asJson
				.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_UBA_Count"))
				.check(regex(""""cartContextKey":"(.+?)",""").optional.saveAs("CartContextKeyUpdateBasketAttribKnownUsers"))
				.body(ElFileBody("./src/test/resources/bodies/DC_WP/DC_WP_Loggedin_UpdateBasketAttribute_MTS.txt")).asJson)

				.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

			}
		}

		/* ********** DeleteFromBasket *********** */
		.exec(http("s3_DeleteFromBasketKnownUser")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		//.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyDeleteFromBasketKnownUser"))
		.body(StringBody("""{"deleteBundleNumber":"0","basketAction":"DeleteFromBasket"}""")).asJson)

		.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

		/* ********** DeleteProductAPI *********** */
		.exec(http("s3_DeleteProdKnownUser")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyDeleteProdKnownUser"))
		.body(StringBody("""{"bundleContextKey":"${ProdBundleContextKeyKnownUserWNC}","basketAction":"deleteFromBasket","itemKey":"${ProdLineItemKeyKnownUserWNC}"}""")).asJson)

		.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)


		/* ***** AddPromotion-Step1 V105 ******* */
		.feed(promoFeeder)
		.exec(http("s3_AddPromotion-Step1KnownUser")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAddPromotion-Step1KnownUser"))
		.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAddToCartWithNoConfigKnownUser"))
		.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("TransKeyKnownUser"))
		.check(regex("""cartContextKey(.+?)""").optional.saveAs("CreateCartKnownUser"))
		.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("TransKeyCountKnownUser"))
		.body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}"}""")).asJson)

		.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

		.doIfEquals("${TransKeyCountKnownUser}", 0) {
			/* ********** Delete Promotion Items *********** */
			exec(http("s3_DeleteFromBasketPromoKnownUser")
			.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step1KnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
			.headers(header_0)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyDeleteFromBasketPromoKnownUser"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("Del1TransKeyKnownUser"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("Del1TransKeyCountKnownUser"))
			.body(StringBody("""{"basketAction":"deleteFromBasket","offer":"${PromoOffer}","appliedAction":"Add"}""")).asJson)

			.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

			.doIfEquals("${Del1TransKeyCountKnownUser}", 1) 
			{
				doWhile(session => session("Del1TransKeyCountKnownUser").as[String].equals("1"))
				{

					exec(http("s3_DeleteFromBasketPromo_MTS_KnownUser")
					.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step1KnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
					.headers(header_0)
					.check(status.is(200))
					.check(status.not(404), status.not(500),status.not(504),status.not(503))
					.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyDeleteFromBasketPromoKnownUser"))
					.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("Del1TransKeyKnownUser"))
					.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("Del1TransKeyCountKnownUser"))
					.body(StringBody("""{"basketAction":"deleteFromBasket","offer":"${PromoOffer}","appliedAction":"Add","multiTransactionKey":"${Del1TransKeyKnownUser}"}""")).asJson)

					.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)
				}
			}

			.exec(http("s3_GetBasketDetailsKnownUser")
			.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step1KnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
			.headers(header_0)
			.check(status.is(200))
			.check(status.not(404), status.not(500), status.not(504), status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyGetBasketDetailsKnownUser"))
			.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").find.exists.saveAs("DelProdBundleContextKeyKnownUser")).asJson
			.check(jsonPath("""$.result.records[0].promotions.records[0].actions.deletePromotionBasketAction.rest.params.offer""").optional.saveAs("DelPromoKnownUser")).asJson)

			.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

			/* ********** CreateCart LDV2 *********** */
			.exec(http("s3_CreateCartKnownUser")
			.post(uri02 + """/services/apexrest/v3/carts?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
			.headers(header_0)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""orderId":"(.+?)"""").find.exists.saveAs("OrderIdKnownUser"))
			.body(StringBody("""{"accountId": "${AccountId}","catalogCode": "DC-WP-Cat-for-LI-products","cartContextKey":"${CartContextKeyAddPromotion-Step1KnownUser}"}""")).asJson)

			.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)
		}

		.doIfEquals("${TransKeyCountKnownUser}", 1) {

			/* ********** AddPromotion-Step2 V105 *********** */
			//feed(promoFeeder)
			exec(http("s3_AddPromotion-Step2KnownUser")
			.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
			.headers(header_0)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyAddPromotion-Step2KnownUser"))
			.check(regex("""cartContextKey(.+?)""").find.exists.saveAs("CreateCartKnownUser"))
			.body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}","multiTransactionKey":"${TransKeyKnownUser}"}""")).asJson)

			.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)


			/* ********** Delete Promotion Items *********** */
			.exec(http("s3_DeleteFromBasketPromoKnownUser")
			.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step2KnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
			.headers(header_0)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyDeleteFromBasketPromoKnownUser"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("Del2TransKeyKnownUser"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("Del2TransKeyCountKnownUser"))
			.body(StringBody("""{"basketAction":"deleteFromBasket","offer":"${PromoOffer}","appliedAction":"Add"}""")).asJson)

			.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

			.doIfEquals("${Del2TransKeyCountKnownUser}", 1) 
			{
				doWhile(session => session("Del2TransKeyCountKnownUser").as[String].equals("1"))
				{

					exec(http("s3_DeleteFromBasketPromo_MTS_KnownUser")
					.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step2KnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
					.headers(header_0)
					.check(status.is(200))
					.check(status.not(404), status.not(500),status.not(504),status.not(503))
					.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyDeleteFromBasketPromoKnownUser"))
					.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("Del2TransKeyKnownUser"))
					.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("Del2TransKeyCountKnownUser"))
					.body(StringBody("""{"basketAction":"deleteFromBasket","offer":"${PromoOffer}","appliedAction":"Add","multiTransactionKey":"${Del2TransKeyKnownUser}"}""")).asJson)

					.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)
				}
			}

			.exec(http("s3_GetBasketDetailsKnownUser")
			.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step2KnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
			.headers(header_0)
			.check(status.is(200))
			.check(status.not(404), status.not(500), status.not(504), status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyGetBasketDetailsKnownUser"))
			.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").find.exists.saveAs("DelProdBundleContextKeyKnownUser")).asJson
			.check(jsonPath("""$.result.records[0].promotions.records[0].actions.deletePromotionBasketAction.rest.params.offer""").optional.saveAs("DelPromoKnownUser")).asJson)

			.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

			/* ********** CreateCart LDV2 *********** */
			.exec(http("s3_CreateCartKnownUser")
			.post(uri02 + """/services/apexrest/v3/carts?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
			.headers(header_0)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""orderId":"(.+?)"""").find.exists.saveAs("OrderIdKnownUser"))
			.body(StringBody("""{"accountId": "${AccountId}","catalogCode": "DC-WP-Cat-for-LI-products","cartContextKey":"${CartContextKeyAddPromotion-Step2KnownUser}"}""")).asJson)

			.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

			.exec(flushSessionCookies)
			.exec(flushCookieJar)
			.exec(flushHttpCache)

		}
	}
	
	// Here we need to add ABO's scripts and scenario to be included in scn file
	// Here we need to add ABO's scripts and scenario to be included in scn file
	// Here we need to add ABO's scripts and scenario to be included in scn file
	
	val script4ABOAdd = scenario("SF_DC_KnownUser_Script_4_ABO_Add")
	
	.exec(session => session.set("password",credentials))

	/* ********* Get OAuth Token for Perf2 ************* */
	.exec(http("RESTGetOAuthToken")
	.post("https://test.salesforce.com/services/oauth2/token")
	.header("Content-Type", "application/x-www-form-urlencoded")
	.formParam("password", "${password}")
	.formParam("username", "ldvtesting2@vlocity.com")
	.formParam("client_secret", "4F1DE5B4EC987DC9138A68A1D1567ECA1DCC9583A88B3130B95D2742ADB473EA")
	.formParam("client_id", "3MVG9_7ddP9KqTzfqPTQdMvr5pwHfDxPcU4QZMHvJTbg1TlFT_Nx8_2aS.NWDGESp83ZDu7NTPhr8X3kVxfq3")
	.formParam("grant_type", "password")
	.check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
	.check(status.is(200)))
	
	.pause(Configuration.script4_ABOAdd_minWaitMs milliseconds, Configuration.script4_ABOAdd_maxWaitMs milliseconds)

	.repeat(10000)
	{
		feed(assetToBasket)
		.exec(http("s4_ABOgetLoggedinCKForAsset")
		.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers?context={"accountId":"${AccountId_Asset}"}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""contextKey":"(.+?)".""").find.exists.saveAs("LoggedinCKAsset")))

		.pause(Configuration.script4_ABOAdd_minWaitMs milliseconds, Configuration.script4_ABOAdd_maxWaitMs milliseconds)

		/* ********* Call to getOffers ************* */
		.exec(http("s4_ABOGetOffersByCatalogKnownUser")
		.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""contextKey":"(.+?)".""").find.exists.saveAs("ABOgetOffersCK")))

		.pause(Configuration.script4_ABOAdd_minWaitMs milliseconds, Configuration.script4_ABOAdd_maxWaitMs milliseconds)

		.feed(offerFeeder)
		.exec(http("s4_ABOGetOfferDetailsKnownUser")
		.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers/${OfferCode}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""contextKey""").find.exists)
		.check(bodyString.saveAs("OfferDetailsResKnownUser")).asJson)

		.pause(Configuration.script4_ABOAdd_minWaitMs milliseconds, Configuration.script4_ABOAdd_maxWaitMs milliseconds)

		/* ********** ConfigureOffer  V105 *********** */
		.exec(http("s4_ABOConfigureOfferKnownUser")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers/${OfferCode}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.body(StringBody("""${OfferDetailsResKnownUser}""")).asJson
		.check(regex("""contextKey""").find.exists)
		//.body(ElFileBody("./src/test/resources/bodies/DC_WP/eCom-Prod-Bnd-15399454256600.txt")).asJson
		.check(regex(""""result":(.+?)."errorCode":"INVOKE""").find.exists.saveAs("AddWithConfigKnownUser")))

		.pause(Configuration.script4_ABOAdd_minWaitMs milliseconds, Configuration.script4_ABOAdd_maxWaitMs milliseconds)

		/* ********** AssetToBasket V105 *********** This should be the first call as per sheet****************/

		.exec(http("s4_ABOAssetToBasketKnownUser")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket?context={"accountId":"${AccountId_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""assetReferenceKey":"(.+?)",""").optional.saveAs("AssetRefKeyKnownUser"))
		.check(regex("""assetReferenceKey":"(.+?)",""").count.saveAs("AssetRefKeyCountKnownUser"))
		.check(regex("""cartContextKey":"(.+?)",""").find.exists.saveAs("CartContextKeyAssetToBasketKnownUser"))
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("ABOProdBundleContextKeyKnownUserWNC")).asJson
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("ABOProdLineItemKeyKnownUserWNC")).asJson
		//for 10
		//                 $.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.addChildBasketAction.rest.params.parentLineItemKey
		.check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.addChildBasketAction.rest.params.parentLineItemKey""").optional.saveAs("ABOparentLineItemKeyKnownUser")).asJson
		.check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.addChildBasketAction.rest.params.parentHierarchyPath""").optional.saveAs("ABOparentHierarchyPathKnownUser")).asJson
		.check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.addChildBasketAction.rest.params.offer""").optional.saveAs("ABOofferKnownUser")).asJson
		.check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.addChildBasketAction.rest.params.basketAction""").optional.saveAs("ABObasketActionKnownUser")).asJson
		.check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.addChildBasketAction.rest.params.bundleContextKey""").optional.saveAs("ABObundleContextKeyKnownUser")).asJson
		.body(StringBody("""{"rootAssetIds":"${RootItemId__c_Asset}","basketAction":"assetToBasket","requestDateTime":"2020-07-24T00:00:00.000z"}""")).asJson)

		.pause(Configuration.script4_ABOAdd_minWaitMs milliseconds, Configuration.script4_ABOAdd_maxWaitMs milliseconds)
		
		/* ********** AddWithNoConfig *** Changed Here for ABO Changes *********** */
		.exec(http("s4_ABOAddToCartWithNoConfigKnownUser")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAssetToBasketKnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAddToCartWithNoConfigKnownUser"))
		.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_ATCWNC")).asJson
		.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_ATCWNC_Count"))
		.check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("ABOProdBundleContextKeyKnownUser")).asJson
		.check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("ABOProdLineItemKeyKnownUser")).asJson
		//.body(StringBody("""{"basketAction":"AddWithNoConfig","productConfig":${AddWithConfigKnownUser}}""")).asJson)
		.body(StringBody("""{"parentLineItemKey":"${ABOparentLineItemKeyKnownUser}","parentHierarchyPath":"${ABOparentHierarchyPathKnownUser}","offer":"${ABOofferKnownUser}","basketAction":"${ABObasketActionKnownUser}","bundleContextKey":"${ABObundleContextKeyKnownUser}"}""")).asJson)
		
			
			/* ***** AddPromotion-Step1 V105 ******* */
			.feed(promoFeeder)
			.exec(http("s4_ABOAddPromotion-Step1KnownUser")
			.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
			.headers(header_0)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAddPromotion-Step1KnownUser"))
			.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAssetToBasketKnownUser"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("TransKeyKnownUser"))
			.check(regex("""cartContextKey(.+?)""").optional.saveAs("CreateCartKnownUser"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("TransKeyCountKnownUser"))
			.body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}"}""")).asJson)

			.pause(Configuration.script4_ABOAdd_minWaitMs milliseconds, Configuration.script4_ABOAdd_maxWaitMs milliseconds)

			.doIfEquals("${TransKeyCountKnownUser}", 0) {

				exec(http("s4_ABOGetBasketDetailsKnownUser")
				.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step1KnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
				.headers(header_0)
				.check(status.is(200))
				.check(status.not(404), status.not(500), status.not(504), status.not(503))
				.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyGetBasketDetailsKnownUser"))
				.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").find.exists.saveAs("DelProdBundleContextKeyKnownUser")).asJson
				.check(jsonPath("""$.result.records[0].promotions.records[0].actions.deletePromotionBasketAction.rest.params.offer""").optional.saveAs("DelPromoKnownUser")).asJson)

				.pause(Configuration.script4_ABOAdd_minWaitMs milliseconds, Configuration.script4_ABOAdd_maxWaitMs milliseconds)

				.exec(http("s4_ABOAssetToBasketCreateCartKnownUser")
				.post(uri02 + """/services/apexrest/v3/carts?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
				.headers(header_0)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex("""orderId":"(.+?)"""").find.exists.saveAs("OrderIdKnownUser"))
				.body(StringBody("""{"cartContextKey":"${CartContextKeyAddPromotion-Step1KnownUser}","accountId": "${AccountId_Asset}","catalogCode": "DC-WP-Cat-for-LI-products"}""")).asJson)

				.pause(Configuration.script4_ABOAdd_minWaitMs milliseconds, Configuration.script4_ABOAdd_maxWaitMs milliseconds)
			}

			.doIfEquals("${TransKeyCountKnownUser}", 1) {

				/* ********** AddPromotion-Step2 V105 *********** */
				//feed(promoFeeder)
				exec(http("s4_ABOAddPromotion-Step2KnownUser")
				.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
				.headers(header_0)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyAddPromotion-Step2KnownUser"))
				.check(regex("""cartContextKey(.+?)""").find.exists.saveAs("CreateCartKnownUser"))
				.body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}","multiTransactionKey":"${TransKeyKnownUser}"}""")).asJson)

				.pause(Configuration.script4_ABOAdd_minWaitMs milliseconds, Configuration.script4_ABOAdd_maxWaitMs milliseconds)

				.exec(http("s4_ABOGetBasketDetailsKnownUser")
				.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step2KnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
				.headers(header_0)
				.check(status.is(200))
				.check(status.not(404), status.not(500), status.not(504), status.not(503))
				.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyGetBasketDetailsKnownUser"))
				.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").find.exists.saveAs("DelProdBundleContextKeyKnownUser")).asJson
				.check(jsonPath("""$.result.records[0].promotions.records[0].actions.deletePromotionBasketAction.rest.params.offer""").optional.saveAs("DelPromoKnownUser")).asJson)

				.pause(Configuration.script4_ABOAdd_minWaitMs milliseconds, Configuration.script4_ABOAdd_maxWaitMs milliseconds)

				.exec(http("s4_ABOAssetToBasketCreateCartKnownUser")
				.post(uri02 + """/services/apexrest/v3/carts?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
				.headers(header_0)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex("""orderId":"(.+?)"""").find.exists.saveAs("OrderIdKnownUser"))
				.body(StringBody("""{"cartContextKey":"${CartContextKeyAddPromotion-Step2KnownUser}","accountId": "${AccountId_Asset}","catalogCode": "DC-WP-Cat-for-LI-products"}""")).asJson)

				.pause(Configuration.script4_ABOAdd_minWaitMs milliseconds, Configuration.script4_ABOAdd_maxWaitMs milliseconds)

			}
			.exec(flushSessionCookies)
			.exec(flushCookieJar)
			.exec(flushHttpCache)
		}

		val script5ABOUpdate = scenario("SF_DC_KnownUser_Script_5_ABO_Update")
		
		.exec(session => session.set("password",credentials))

		/* ********* Get OAuth Token for Perf2 ************* */
		.exec(http("RESTGetOAuthToken")
		.post("https://test.salesforce.com/services/oauth2/token")
		.header("Content-Type", "application/x-www-form-urlencoded")
		.formParam("password", "${password}")
		.formParam("username", "ldvtesting2@vlocity.com")
		.formParam("client_secret", "4F1DE5B4EC987DC9138A68A1D1567ECA1DCC9583A88B3130B95D2742ADB473EA")
		.formParam("client_id", "3MVG9_7ddP9KqTzfqPTQdMvr5pwHfDxPcU4QZMHvJTbg1TlFT_Nx8_2aS.NWDGESp83ZDu7NTPhr8X3kVxfq3")
		.formParam("grant_type", "password")
		.check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
		.check(status.is(200)))
		
		.pause(Configuration.script5_ABOUpdate_minWaitMs milliseconds, Configuration.script5_ABOUpdate_maxWaitMs milliseconds)

		.repeat(10000)
		{
			feed(assetToBasket)
			.exec(http("s5_ABOgetLoggedinCKForAsset")
			.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers?context={"accountId":"${AccountId_Asset}"}&isloggedin=true""")
			.headers(header_0)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""contextKey":"(.+?)".""").find.exists.saveAs("LoggedinCKAsset")))

			.pause(Configuration.script5_ABOUpdate_minWaitMs milliseconds, Configuration.script5_ABOUpdate_maxWaitMs milliseconds)

			/* ********* Call to getOffers ************* */
			.exec(http("s5_ABOGetOffersByCatalogKnownUser")
			.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
			.headers(header_0)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""contextKey":"(.+?)".""").find.exists.saveAs("ABOgetOffersCK")))

			.pause(Configuration.script5_ABOUpdate_minWaitMs milliseconds, Configuration.script5_ABOUpdate_maxWaitMs milliseconds)

			.feed(offerFeeder)
			.exec(http("s5_ABOGetOfferDetailsKnownUser")
			.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers/${OfferCode}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
			.headers(header_0)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""contextKey""").find.exists)
			.check(bodyString.saveAs("OfferDetailsResKnownUser")).asJson)

			.pause(Configuration.script5_ABOUpdate_minWaitMs milliseconds, Configuration.script5_ABOUpdate_maxWaitMs milliseconds)

			/* ********** ConfigureOffer  V105 *********** */
			.exec(http("s5_ABOConfigureOfferKnownUser")
			.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers/${OfferCode}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
			.headers(header_0)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.body(StringBody("""${OfferDetailsResKnownUser}""")).asJson
			.check(regex("""contextKey""").find.exists)
			//.body(ElFileBody("./src/test/resources/bodies/DC_WP/eCom-Prod-Bnd-15399454256600.txt")).asJson
			.check(regex(""""result":(.+?)."errorCode":"INVOKE""").find.exists.saveAs("AddWithConfigKnownUser")))

			.pause(Configuration.script5_ABOUpdate_minWaitMs milliseconds, Configuration.script5_ABOUpdate_maxWaitMs milliseconds)

		/* ********** AssetToBasket V105 *********** This should be the first call as per sheet****************/

		.exec(http("s5_ABOAssetToBasketKnownUser")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket?context={"accountId":"${AccountId_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""assetReferenceKey":"(.+?)",""").optional.saveAs("AssetRefKeyKnownUser"))
		.check(regex("""assetReferenceKey":"(.+?)",""").count.saveAs("AssetRefKeyCountKnownUser"))
		.check(regex("""cartContextKey":"(.+?)",""").find.exists.saveAs("CartContextKeyAssetToBasketKnownUser"))
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("ABOProdBundleContextKeyKnownUserWNC")).asJson
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("ABOProdLineItemKeyKnownUserWNC")).asJson
		//for 10
		.check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.addChildBasketAction.rest.params.parentLineItemKey""").optional.saveAs("ABOparentLineItemKeyKnownUser")).asJson
		.check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.addChildBasketAction.rest.params.parentHierarchyPath""").optional.saveAs("ABOparentHierarchyPathKnownUser")).asJson
		.check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.addChildBasketAction.rest.params.offer""").optional.saveAs("ABOofferKnownUser")).asJson
		.check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.addChildBasketAction.rest.params.basketAction""").optional.saveAs("ABObasketActionKnownUser")).asJson
		.check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.addChildBasketAction.rest.params.bundleContextKey""").optional.saveAs("ABObundleContextKeyKnownUser")).asJson
		.body(StringBody("""{"rootAssetIds":"${RootItemId__c_Asset}","basketAction":"assetToBasket","requestDateTime":"2020-07-24T00:00:00.000z"}""")).asJson)

			.pause(Configuration.script5_ABOUpdate_minWaitMs milliseconds, Configuration.script5_ABOUpdate_maxWaitMs milliseconds)

		/* ** UpdateExistingBasket-UpdQty V105 ******* */
		.exec(http("s5_ABOUpdateBasketQtyKnownUser")
		.put(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAssetToBasketKnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyUpdateBasketQtyKnownUser"))
		.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_UBQ")).asJson
		.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_UBQ_Count"))
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("ABOPromoBundleContextKeyKnownUser")).asJson
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("ABOPromoLineItemKeyKnownUser")).asJson
		.body(StringBody("""{"bundleContextKey":"${ABOProdBundleContextKeyKnownUserWNC}","lineItemKey":"${ABOProdLineItemKeyKnownUserWNC}","basketAction":"updateBasket","Quantity":"3"}""")).asJson)

		.pause(Configuration.script5_ABOUpdate_minWaitMs milliseconds, Configuration.script5_ABOUpdate_maxWaitMs milliseconds)

		.doIfEquals("${MultiTransactionKeyLoggedin_UBQ_Count}",1)
		{
			doWhile(session => session("MultiTransactionKeyLoggedin_UBQ_Count").as[String].equals("1"))
			{
				/* ** UpdateExistingBasket-UpdQty V105 ******* */
				exec(http("s5_ABOUpdateBasketQtyKnownUser_MTS")
				.put(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAssetToBasketKnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
				.headers(header_0)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyUpdateBasketQtyKnownUser"))
				.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_UBQ")).asJson
				.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_UBQ_Count"))
				.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("ABOPromoBundleContextKeyKnownUser")).asJson
				.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("ABOPromoLineItemKeyKnownUser")).asJson
				.body(StringBody("""{"multiTransactionKey":"${MultiTransactionKeyLoggedin_UBQ}","bundleContextKey":"${ABOProdBundleContextKeyKnownUserWNC}","lineItemKey":"${ABOProdLineItemKeyKnownUserWNC}","basketAction":"updateBasket","Quantity":"3"}""")).asJson)
				
				.pause(Configuration.script5_ABOUpdate_minWaitMs milliseconds, Configuration.script5_ABOUpdate_maxWaitMs milliseconds)

			}
		}
		/* **** UpdateExistingBasket-UpdAttrib V105 *** CHANGE THIS ###################### */
		.exec(http("s5_ABOUpdateBasketAttribKnownUser")
		.put(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyUpdateBasketQtyKnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_UBA")).asJson
		.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_UBA_Count"))
		.check(regex(""""cartContextKey":"(.+?)",""").optional.saveAs("CartContextKeyUpdateBasketAttribKnownUsers"))
		.body(ElFileBody("./src/test/resources/bodies/DC_WP/DC_WP_Loggedin_UpdateBasketAttribute_ABO.txt")).asJson)

		.pause(Configuration.script5_ABOUpdate_minWaitMs milliseconds, Configuration.script5_ABOUpdate_maxWaitMs milliseconds)

		.doIfEquals("${MultiTransactionKeyLoggedin_UBA_Count}",1)
		{
			doWhile(session => session("MultiTransactionKeyLoggedin_UBA_Count").as[String].equals("1"))
			{
				/* **** UpdateExistingBasket-UpdAttrib V105 *** CHANGE THIS ###################### */
				exec(http("s5_ABOUpdateBasketAttribKnownUser_MTS")
				.put(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyUpdateBasketQtyKnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
				.headers(header_0)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_UBA")).asJson
				.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_UBA_Count"))
				.check(regex(""""cartContextKey":"(.+?)",""").optional.saveAs("CartContextKeyUpdateBasketAttribKnownUsers"))
				.body(ElFileBody("./src/test/resources/bodies/DC_WP/DC_WP_Loggedin_UpdateBasketAttribute_ABO_MTS.txt")).asJson)

				.pause(Configuration.script5_ABOUpdate_minWaitMs milliseconds, Configuration.script5_ABOUpdate_maxWaitMs milliseconds)

			}
		}
			/* ***** AddPromotion-Step1 V105 ******* */
			.feed(promoFeeder)
			.exec(http("s5_ABOAddPromotion-Step1KnownUser")
			.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAssetToBasketKnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
			.headers(header_0)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAddPromotion-Step1KnownUser"))
			.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAssetToBasketKnownUser"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("TransKeyKnownUser"))
			.check(regex("""cartContextKey(.+?)""").optional.saveAs("CreateCartKnownUser"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("TransKeyCountKnownUser"))
			.body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}"}""")).asJson)

			.pause(Configuration.script5_ABOUpdate_minWaitMs milliseconds, Configuration.script5_ABOUpdate_maxWaitMs milliseconds)

			.doIfEquals("${TransKeyCountKnownUser}", 0) {

				exec(http("s5_ABOGetBasketDetailsKnownUser")
				.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step1KnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
				.headers(header_0)
				.check(status.is(200))
				.check(status.not(404), status.not(500), status.not(504), status.not(503))
				.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyGetBasketDetailsKnownUser"))
				.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").find.exists.saveAs("DelProdBundleContextKeyKnownUser")).asJson
				.check(jsonPath("""$.result.records[0].promotions.records[0].actions.deletePromotionBasketAction.rest.params.offer""").optional.saveAs("DelPromoKnownUser")).asJson)

				.pause(Configuration.script5_ABOUpdate_minWaitMs milliseconds, Configuration.script5_ABOUpdate_maxWaitMs milliseconds)

				.exec(http("s5_ABOAssetToBasketCreateCartKnownUser")
				.post(uri02 + """/services/apexrest/v3/carts?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
				.headers(header_0)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex("""orderId":"(.+?)"""").find.exists.saveAs("OrderIdKnownUser"))
				.body(StringBody("""{"cartContextKey":"${CartContextKeyAddPromotion-Step1KnownUser}","accountId": "${AccountId_Asset}","catalogCode": "DC-WP-Cat-for-LI-products"}""")).asJson)

				.pause(Configuration.script5_ABOUpdate_minWaitMs milliseconds, Configuration.script5_ABOUpdate_maxWaitMs milliseconds)
			}

			.doIfEquals("${TransKeyCountKnownUser}", 1) {

				/* ********** AddPromotion-Step2 V105 *********** */
				//feed(promoFeeder)
				exec(http("s5_ABOAddPromotion-Step2KnownUser")
				.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAssetToBasketKnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
				.headers(header_0)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyAddPromotion-Step2KnownUser"))
				.body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}","multiTransactionKey":"${TransKeyKnownUser}"}""")).asJson)

				.pause(Configuration.script5_ABOUpdate_minWaitMs milliseconds, Configuration.script5_ABOUpdate_maxWaitMs milliseconds)

				.exec(http("s5_ABOGetBasketDetailsKnownUser")
				.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step2KnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
				.headers(header_0)
				.check(status.is(200))
				.check(status.not(404), status.not(500), status.not(504), status.not(503))
				.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyGetBasketDetailsKnownUser"))
				.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").find.exists.saveAs("DelProdBundleContextKeyKnownUser")).asJson
				.check(jsonPath("""$.result.records[0].promotions.records[0].actions.deletePromotionBasketAction.rest.params.offer""").optional.saveAs("DelPromoKnownUser")).asJson)

				.pause(Configuration.script5_ABOUpdate_minWaitMs milliseconds, Configuration.script5_ABOUpdate_maxWaitMs milliseconds)

				.exec(http("s5_ABOAssetToBasketCreateCartKnownUser")
				.post(uri02 + """/services/apexrest/v3/carts?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
				.headers(header_0)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex("""orderId":"(.+?)"""").find.exists.saveAs("OrderIdKnownUser"))
				.body(StringBody("""{"cartContextKey":"${CartContextKeyAddPromotion-Step2KnownUser}","accountId": "${AccountId_Asset}","catalogCode": "DC-WP-Cat-for-LI-products"}""")).asJson)

				.pause(Configuration.script5_ABOUpdate_minWaitMs milliseconds, Configuration.script5_ABOUpdate_maxWaitMs milliseconds)

			}

			.exec(flushSessionCookies)
			.exec(flushCookieJar)
			.exec(flushHttpCache)
		}	
		
		
}