
import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._

class H3GAccntSubscobj extends Simulation {

	val httpProtocol = http
		.baseUrl("https://c.cs17.visual.force.com")
		.inferHtmlResources(BlackList(""".*\.js""", """.*\.css""", """.*\.gif""", """.*\.jpeg""", """.*\.jpg""", """.*\.ico""", """.*\.woff""", """.*\.(t|o)tf""", """.*\.png""", """.*\.map""", """aura""", """resource"""), WhiteList())
		.acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8")
		.acceptEncodingHeader("gzip, deflate, sdch, br")
		.acceptLanguageHeader("en-US,en;q=0.8")
		.contentTypeHeader("application/x-www-form-urlencoded; charset=UTF-8")
		.userAgentHeader("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36")

    val headers_5 = Map(
		"Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Cache-Control" -> "max-age=0",
		"Origin" -> "https://test.salesforce.com",
		"Upgrade-Insecure-Requests" -> "1")

	val headers_0 = Map("Upgrade-Insecure-Requests" -> "1")

    val headers_1 = Map(
		"Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
		"Upgrade-Insecure-Requests" -> "1")

	val headers_2 = Map(
		"Accept-Encoding" -> "gzip, deflate, br",
		"Cache-Control" -> "max-age=0",
		"Origin" -> "https://c.cs17.visual.force.com",
		"Upgrade-Insecure-Requests" -> "1")

	val headers_4 = Map(
		"Accept" -> "*/*",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Origin" -> "https://c.cs17.visual.force.com")

    val uri1 = "https://c.cs17.content.force.com/servlet/servlet.ImageServer"
    val uri2 = "https://c.cs17.visual.force.com"
    val uri3 = "https://test.salesforce.com/login/sessionserver202.html"
    val uri4 = "cs17.salesforce.com"
    val uri5 = "https://test.salesforce.com"

	val scn = scenario("H3GAccntSubsc")
	
	
	
		    .feed(csv("./src/test/resources/data/h3g/H3G_Users.csv").circular)
			.exec(http("Login")
			.post("https://test.salesforce.com")
			.headers(headers_5)
			.formParam("pqs", "%3FstartURL%3D%252Fapp%252Fmgmt%252Fforceconnectedapps%252FforceAppDetail.apexp%253FapplicationId%253D06Pg00000008VWO%2526id%253D0Cig00000004Eb9%26ec%3D302")
			.formParam("un", "${Users}")
			.formParam("width", "1920")
			.formParam("height", "1080")
			.formParam("hasRememberUn", "true")
			.formParam("startURL", "%2Fapp%2Fmgmt%2Fforceconnectedapps%2FforceAppDetail.apexp%3FapplicationId%3D06Pg00000008VWO%26id%3D0Cig00000004Eb9")
			.formParam("loginURL", "")
			.formParam("loginType", "")
			.formParam("useSecure", "true")
			.formParam("local", "")
			.formParam("lt", "standard")
			.formParam("qs", "r%3Dhttps%253A%252F%252Fcs17.salesforce.com%252Fapp%252Fmgmt%252Fforceconnectedapps%252FforceAppDetail.apexp%253FapplicationId%253D06Pg00000008VWO%2526id%253D0Cig00000004Eb9")
			.formParam("locale", "")
			.formParam("oauth_token", "")
			.formParam("oauth_callback", "")
			.formParam("login", "")
			.formParam("serverid", "")
			.formParam("display", "page")
			.formParam("username", "${Users}")
			.formParam("ExtraLog", "%255B%257B%2522width%2522%3A1920%257D%2C%257B%2522height%2522%3A1080%257D%2C%257B%2522language%2522%3A%2522en-US%2522%257D%2C%257B%2522offset%2522%3A7%257D%2C%257B%2522scripts%2522%3A%255B%257B%2522size%2522%3A1634%2C%2522summary%2522%3A%2522%255Cn%2520%2520%2520%2520%2520%2520%2520%2520%2520%2520%2520%2520%2520%2520%2520%2520%2F**%2520%2520Aura%2520Inspector%2520Script%2C%2520ties%2520%2522%257D%2C%257B%2522size%2522%3A249%2C%2522summary%2522%3A%2522if%2520%28self%2520%3D%3D%2520top%29%2520%257Bdocument.documentElement.style.v%2522%257D%2C%257B%2522size%2522%3A495%2C%2522summary%2522%3A%2522var%2520SFDCSessionVars%3D%257B%255C%2522server%255C%2522%3A%255C%2522https%3A%2F%2Ftest.salesf%2522%257D%2C%257B%2522url%2522%3A%2522https%3A%2F%2Ftest.salesforce.com%2Fjslibrary%2FSfdcSessionBase202.js%2522%257D%2C%257B%2522url%2522%3A%2522https%3A%2F%2Ftest.salesforce.com%2Fjslibrary%2FLoginHint202.js%2522%257D%2C%257B%2522size%2522%3A26%2C%2522summary%2522%3A%2522LoginHint.hideLoginForm%28%29%3B%2522%257D%2C%257B%2522size%2522%3A36%2C%2522summary%2522%3A%2522LoginHint.getSavedIdentities%28false%29%3B%2522%257D%2C%257B%2522url%2522%3A%2522https%3A%2F%2Ftest.salesforce.com%2Fjslibrary%2Fbaselogin2.js%2522%257D%2C%257B%2522url%2522%3A%2522https%3A%2F%2Ftest.salesforce.com%2Fjslibrary%2FLoginMarketingSurveyResponse.js%2522%257D%2C%257B%2522size%2522%3A507%2C%2522summary%2522%3A%2522function%2520handleLogin%28%29%257Bdocument.login.un.value%3Ddoc%2522%257D%255D%257D%2C%257B%2522scriptCount%2522%3A10%257D%2C%257B%2522iframes%2522%3A%255B%2522https%3A%2F%2Fc.salesforce.com%2Flogin-messages%2Fpromos.html%3Fr%3Dhttps%25253A%25252F%25252Fcs17.salesforce.com%25252Fapp%25252Fmgmt%25252Fforceconnectedapps%25252FforceAppDetail.apexp%25253FapplicationId%25253D06Pg00000008VWO%252526id%25253D0Cig00000004Eb9%2522%2C%2522https%3A%2F%2Ftest.salesforce.com%2Flogin%2Fsessionserver202.html%2522%255D%257D%2C%257B%2522iframeCount%2522%3A2%257D%255D")
			.formParam("pw", "Vlocity425")
			.formParam("Login", "Log+In+to+Sandbox")
			.formParam("rememberUn", "on")
			.resources(http("login_1")
			.get("https://cs17.salesforce.com/app/mgmt/forceconnectedapps/forceAppDetail.apexp?applicationId=06Pg00000008VWO&id=0Cig00000004Eb9")
			.headers(headers_1))
			.check(status.is(200)))
	
		
		.pause(6 seconds)
		
		.repeat(1000){
		
		    feed(csv("./src/test/resources/data/h3g/H3Gaccntph.csv").queue)
			.exec(http("getMatrix_page1")
			.get("https://" + uri4 + "/apex/MatrixxNewAccount")
			.headers(headers_0)
			.check(regex("""name="com.salesforce.visualforce.ViewStateCSRF"\svalue\=\"([^"]+)\"\s\/\>\<\/span\>\<\/span\>""").find.exists.saveAs("""ViewStateCSRF"""))
			.check(regex("""name="com.salesforce.visualforce.ViewStateMAC" value="([^"]+)"\s""").find.exists.saveAs("""ViewStateMAC"""))
			.check(regex("""ViewStateVersion\"\svalue=\"(\d+)\"\s\/\>\<input\stype\=\"hidden\"\s\sid\=\"com\.salesforce\.visualforce\.ViewStateMAC""").find.exists.saveAs("""ViewStateVersion"""))
			.check(regex("""visualforce\.ViewState\"\svalue\=\"([^"]+)\"\s\/\>\<input\stype\=\"hidden\"\s\sid\=\"com\.salesforce\.visualforce\.ViewStateVersion""").find.exists.saveAs("""ViewState"""))
			.check(status.is(200)))


			
		.pause(6 seconds)
		
		.exec(http("getMatrix_save")
			.post("https://c.cs17.visual.force.com/apex/MatrixxNewAccount")
			.headers(headers_2)
			.formParam("j_id0:j_id1", "j_id0:j_id1")
			.formParam("j_id0:j_id1:j_id2:j_id29:j_id30", "${Account_name}")
			.formParam("j_id0:j_id1:j_id2:j_id29:j_id31", "${Phone}")
			.formParam("j_id0:j_id1:j_id2:j_id32:j_id33", "Save")
			.formParam("com.salesforce.visualforce.ViewState", "${ViewState}")
			.formParam("com.salesforce.visualforce.ViewStateVersion", "${ViewStateVersion}")
			.formParam("com.salesforce.visualforce.ViewStateMAC", "${ViewStateMAC}")
			.formParam("com.salesforce.visualforce.ViewStateCSRF", "${ViewStateCSRF}")
			.check(regex("""name="com.salesforce.visualforce.ViewStateCSRF"\svalue\=\"([^"]+)\"\s\/\>\<\/span\>\<\/span\>""").find.exists.saveAs("""ViewStateCSRF_1"""))
			.check(regex("""name="com.salesforce.visualforce.ViewStateMAC" value="([^"]+)"\s""").find.exists.saveAs("""ViewStateMAC_1"""))
			.check(regex("""ViewStateVersion\"\svalue=\"(\d+)\"\s\/\>\<input\stype\=\"hidden\"\s\sid\=\"com\.salesforce\.visualforce\.ViewStateMAC""").find.exists.saveAs("""ViewStateVersion_1"""))
			.check(regex("""visualforce\.ViewState\"\svalue\=\"([^"]+)\"\s\/\>\<input\stype\=\"hidden\"\s\sid\=\"com\.salesforce\.visualforce\.ViewStateVersion""").find.exists.saveAs("""ViewState_1"""))
			.check(status.is(200)))

		.pause(6 seconds)
		
		.exec(http("create_Subsc")
			.post("/apex/MatrixxNewAccount")
			.headers(headers_4)
			.formParam("AJAXREQUEST", "_viewRoot")
			.formParam("j_id0:j_id1", "j_id0:j_id1")
			.formParam("j_id0:j_id1:j_id2:j_id29:j_id30", "${Account_name}")
			.formParam("j_id0:j_id1:j_id2:j_id29:j_id31", "${Phone}")
			.formParam("com.salesforce.visualforce.ViewState", "${ViewState_1}")
			.formParam("com.salesforce.visualforce.ViewStateVersion", "${ViewStateVersion_1}")
			.formParam("com.salesforce.visualforce.ViewStateMAC", "${ViewStateMAC_1}")
			.formParam("com.salesforce.visualforce.ViewStateCSRF", "${ViewStateCSRF_1}")
			.formParam("j_id0:j_id1:j_id2:j_id32:j_id34", "j_id0:j_id1:j_id2:j_id32:j_id34")
			.formParam("", "")
			.check(regex("""ObjectId\&gt\;(.+)\&lt\;\/ObjectId&gt""").find.exists.saveAs("""OBJTID"""))
			.check(status.is(200)))
			
			}

	      
	      setUp(scn.inject(rampUsers(50) during (20 seconds)).protocols(httpProtocol)).maxDuration(600 seconds)
}