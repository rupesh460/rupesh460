package OM_Standard_Mix_UseCase
  import scala.concurrent.duration._

  import io.gatling.core.Predef._
  import io.gatling.core.structure.ChainBuilder
  import io.gatling.http.Predef._
  import io.gatling.jdbc.Predef._
  import io.gatling.jsonpath._
  import Headers._
  import scala.collection._
  import java.time.format.DateTimeFormatter
  import java.time.LocalDateTime
  import java.time.LocalDate

import io.gatling.core.feeder._
import java.util.Base64
import java.nio.charset.StandardCharsets
import scala.util.matching.Regex


   object Create_Account_Web {

    var userid = new StringBuilder()
    val uri10 = Configuration.Uri10
    val uri01 = Configuration.Uri01


 val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
  val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
  val password_v = (passwordByEnv.get("perf3").toString)
  val password_encoded = password_v.substring(12,(password_v.length - 2 ))
  val credentials = new String(Base64.getDecoder.decode(password_encoded))


    val scn = scenario("Create_Account")

.exec(session => session.set("password",credentials))

      .exec(http("Web_Login")
      .post(uri01 + "/")
      .headers(headers_26)
      .formParam("un", "rkasi@perftest2.ldv.org")
      .formParam("width", "1920")
      .formParam("height", "1080")
      .formParam("hasRememberUn", "true")
      .formParam("startURL", "")
      .formParam("loginURL", "")
      .formParam("loginType", "")
      .formParam("useSecure", "true")
      .formParam("local", "")
      .formParam("lt", "standard")
      .formParam("qs", "")
      .formParam("locale", "")
      .formParam("oauth_token", "")
      .formParam("oauth_callback", "")
      .formParam("login", "")
      .formParam("serverid", "")
      .formParam("display", "page")
      .formParam("username", "rkasi@perftest2.ldv.org")
      .formParam("pw", "${password}")
      .formParam("Login", "Log In to Sandbox")
      .formParam("rememberUn", "on"))

        .pause(2000 milliseconds, 2000 milliseconds)


      .exec(http("GetCONFToken")
      .get("/001/e?retURL=%2F001%2Fo&RecordType=012L0000000EP9F&ent=Account")
      .check(regex("""id="_CONFIRMATIONTOKEN" value="(.*?)"""").find.exists.saveAs("CONF_Token"))
      .headers(headers_0))



    .pause(2000 milliseconds, 2000 milliseconds)

       .repeat(1,"repeatid")
          {

              exec((s: Session) => s.set("userid",s.userId.toString))


    .exec(http("CreateAccount")
      .post(uri10 + "/001/e")
      .headers(headers_26)
      .formParam("RecordType", "012L0000000EP9F")
      .formParam("_CONFIRMATIONTOKEN", "${CONF_Token}")
      .formParam("cancelURL", "/001/o")
      .formParam("retURL", "/001/o")
      .formParam("save_new_url", "/001/e?ent=Account&retURL=%2F001%2Fo&RecordType=012L0000000EP9F")
      .formParam("save", "Saving...")
      .formParam("acc2", "Account-web4-${userid}-${repeatid}")
      .formParam("00NL0000004TxR0", "Active")
      .formParam("acc3_lkid", "0")
      .formParam("acc3_lkold", "null")
      .formParam("acc3_lktp", "1")
      .formParam("acc3_lspf", "0")
      .formParam("acc3_lspfsub", "0")
      .formParam("acc3_mod", "0")
      .formParam("acc3", "")
      .formParam("00NL0000004KE8H", "")
      .formParam("acc17street", "")
      .formParam("acc10", "")
      .formParam("acc17city", "San Francisco")
      .formParam("CF00NL0000004KE8A_lkid", "0")
      .formParam("CF00NL0000004KE8A_lkold", "null")
      .formParam("CF00NL0000004KE8A_lktp", "a2p")
      .formParam("CF00NL0000004KE8A_lspf", "0")
      .formParam("CF00NL0000004KE8A_lspfsub", "0")
      .formParam("CF00NL0000004KE8A_mod", "0")
      .formParam("CF00NL0000004KE8A", "")
      .formParam("acc17state", "California")
      .formParam("acc17zip", "94016")
      .formParam("acc17country", "")
      .formParam("00NL0000004KE8E", "")
      .formParam("00NL0000004KE83", "")
      .formParam("00NL0000004KE82", "")
      .formParam("00NL0000004KE7x", "")
      .formParam("00NL0000004KE84", "")
      .formParam("CF00NL0000004KE81_lkid", "0")
      .formParam("CF00NL0000004KE81_lkold", "null")
      .formParam("CF00NL0000004KE81_lktp", "a4E")
      .formParam("CF00NL0000004KE81_lspf", "0")
      .formParam("CF00NL0000004KE81_lspfsub", "0")
      .formParam("CF00NL0000004KE81_mod", "0")
      .formParam("CF00NL0000004KE81", "")
      .formParam("00NL0000004KE7z", "")
      .formParam("00NL0000004KE85", "")
      .formParam("00NL0000004KE86", "")
      .check(status.is(200))
      .check(regex("""handleRedirect\('\/(.+?)\'""").find.exists.saveAs("AccountId")))
     // .check(regex("""SfdcApp.projectOneNavigator.handleRedirect\(\'\/(.+)\'\)\;\s\}""").find.exists.saveAs("AccountId")))


     .exec(http("UpdateAccount")
      .post(uri10 + "/${AccountId}")
      .headers(headers_26)
      .formParam("RecordType", "012L0000000EP9F")
      .formParam("_CONFIRMATIONTOKEN", "${CONF_Token}")
      .formParam("cancelURL", "/001/o")
      .formParam("retURL", "/001/o")
      .formParam("save_new_url", "/001/e?ent=Account&retURL=%2F001%2Fo&RecordType=012L0000000EP9F")
      .formParam("save", "Saving...")
      .formParam("acc2", "Account-web4-${userid}-${repeatid}")
      .formParam("00NL0000004TxR0", "Active")
      .formParam("acc3_lkid", "0")
      .formParam("acc3_lkold", "null")
      .formParam("acc3_lktp", "1")
      .formParam("acc3_lspf", "0")
      .formParam("acc3_lspfsub", "0")
      .formParam("acc3_mod", "0")
      .formParam("acc3", "")
      .formParam("00NL0000004KE8H", "")
      .formParam("acc17street", "")
      .formParam("acc10", "")
      .formParam("acc17city", "San Francisco")
      .formParam("CF00NL0000004KE8A_lkid", "0")
      .formParam("CF00NL0000004KE8A_lkold", "null")
      .formParam("CF00NL0000004KE8A_lktp", "a2p")
      .formParam("CF00NL0000004KE8A_lspf", "0")
      .formParam("CF00NL0000004KE8A_lspfsub", "0")
      .formParam("CF00NL0000004KE8A_mod", "0")
      .formParam("CF00NL0000004KE8A", "")
      .formParam("acc17state", "California")
      .formParam("acc17zip", "94016")
      .formParam("acc17country", "USA")
      .formParam("00NL0000004KE8E", "")
      .formParam("00NL0000004KE83", "")
      .formParam("00NL0000004KE82", "")
      .formParam("00NL0000004KE7x", "")
      .formParam("00NL0000004KE84", "")
      .formParam("CF00NL0000004KE81_lkid", "0")
      .formParam("CF00NL0000004KE81_lkold", "null")
      .formParam("CF00NL0000004KE81_lktp", "a4E")
      .formParam("CF00NL0000004KE81_lspf", "0")
      .formParam("CF00NL0000004KE81_lspfsub", "0")
      .formParam("CF00NL0000004KE81_mod", "0")
      .formParam("CF00NL0000004KE81", "")
      .formParam("00NL0000004KE7z", "")
      .formParam("00NL0000004KE85", "")
      .formParam("00NL0000004KE86", "")
      .check(status.is(200))
      .check(regex("""handleRedirect\('\/(.+?)\'""").find.exists.saveAs("AccountId")))
     // .check(regex("""SfdcApp.projectOneNavigator.handleRedirect\(\'\/(.+)\'\)\;\s\}""").find.exists.saveAs("AccountId")))


      .pause(2000 milliseconds, 2000 milliseconds)



          }


    }
