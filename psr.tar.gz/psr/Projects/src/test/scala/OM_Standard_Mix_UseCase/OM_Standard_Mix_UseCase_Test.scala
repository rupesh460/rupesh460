
//THe script takes Account ID, PriceList for which order has to created ,
//PriceList entry ID for which add to cart to be done
//SELECT Id,Name FROM Account WHERE Name LIKE 'Account-3%' and id not in (select accountid from asset) LIMIT 100000
package OM_Standard_Mix_UseCase

  import scala.concurrent.duration._
  import io.gatling.core.Predef._
  import io.gatling.core.structure.ChainBuilder
  import io.gatling.http.Predef._
  import io.gatling.jdbc.Predef._
  import io.gatling.jsonpath._
  import Headers._
  import scala.collection._
  import java.time.format.DateTimeFormatter
  import java.time.LocalDateTime
  import java.time.LocalDate

import io.gatling.core.feeder._
import java.util.Base64
import java.nio.charset.StandardCharsets
import scala.util.matching.Regex



   object OM_Standard_Mix_UseCase_Test {


      val uri01 = Configuration.Uri01
      val uri05 = Configuration.Uri05
      val uri10 = Configuration.Uri10
      var session_ids = Vector[String]()
      var xomSubmitOrder = new StringBuilder()
      var parentid_del = new StringBuilder()
      var modifiedItemJson = new StringBuilder()

      val userFeeder = csv("./src/test/resources/data/OM_Standard/OM_Standard_Users.csv").random
      val orderFeeder = csv("./src/test/resources/data/OM_Standard/OM_Standard_Orders.csv").random
      val pricelistEntryFeeder = csv("./src/test/resources/data/OM_Standard/OM_Standard_PriceListEntry.csv").random
     val cpqaccountFeeder = csv("./src/test/resources/data/OM_Standard/OM_Standard_CPQ_Accounts.csv").random
//changed to circular
       val accountFeeder = csv("./src/test/resources/data/OM_Standard/OM_Standard_Accounts.csv").circular
      val pricelistFeeder = csv("./src/test/resources/data/OM_Standard/OM_Standard_Pricelist.csv").random
      val assetFeeder = csv("./src/test/resources/data/OM_Standard/OM_Assets_add_10assets.csv").circular
      val assetFeeder_delete = csv("./src/test/resources/data/OM_Standard/OM_Assets_delete_10assets.csv").circular
      val assetFeeder_update = csv("./src/test/resources/data/OM_Standard/OM_Assets_update_10assets.csv").circular
      val pricelistEntryFeeder_B2B = csv("./src/test/resources/data/OM_Standard/OM_Standard_PriceListEntry_B2B.csv").random
      val pricelistFeeder_B2B = csv("./src/test/resources/data/OM_Standard/OM_Standard_Pricelist_B2B.csv").random
      val pricelistEntryFeeder_NonAssetize = csv("./src/test/resources/data/OM_Standard/OM_Standard_PriceListEntry_NonAssetize.csv").random
      val accountFeeder_NonAssetize = csv("./src/test/resources/data/OM_Standard/OM_Standard_Accounts_NonAssetize.csv").circular
      val assetFeederNonAssetize = csv("./src/test/resources/data/OM_Standard/OM_Assets_add_10assets_NonAssetize.csv").circular


 val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
 val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
 val password_v = (passwordByEnv.get("perf3").toString)
 val password_encoded = password_v.substring(12,(password_v.length - 2 ))
 val credentials = new String(Base64.getDecoder.decode(password_encoded))
 


      val createPaymentMethodScn = scenario("OM_Standard_Mix_UseCase_Test_CreatePaymentMethod")


	 .exec(session => session.set("password",credentials)) 
 
     .feed(userFeeder)
     //.feed(passFeeder)	
      .exec(http("Web_Login")
      .post(uri01 + "/")
      .headers(headers_26)
      .formParam("un", "${username}")
      .formParam("width", "1920")
      .formParam("height", "1080")
      .formParam("hasRememberUn", "true")
      .formParam("startURL", "")
      .formParam("loginURL", "")
      .formParam("loginType", "")
      .formParam("useSecure", "true")
      .formParam("local", "")
      .formParam("lt", "standard")
      .formParam("qs", "")
      .formParam("locale", "")
      .formParam("oauth_token", "")
      .formParam("oauth_callback", "")
      .formParam("login", "")
      .formParam("serverid", "")
      .formParam("display", "page")
      .formParam("username", "${username}")
      .formParam("pw", "${password}")
      .formParam("Login", "Log In to Sandbox")
      .formParam("rememberUn", "on"))

 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("GetCONFTokenPayment")
      .get(uri05 + "/apex/PaymentMethod?retURL=%2Fa4E%2Fo&save_new=1&sfdc.override=1")
      .check(regex("""ViewStateCSRF" value="(.*?)" />""").find.exists.saveAs("ViewStateCSRF"))
       .check(regex("""ViewStateVersion" value="(.*?)" />""").find.exists.saveAs("ViewStateVersion"))
        .check(regex("""ViewStateMAC" value="(.*?)" />""").find.exists.saveAs("ViewStateMAC"))
         .check(regex("""ViewState" value="(.*?)" />""").find.exists.saveAs("ViewState"))
      .headers(headers_0))





       .repeat(10000,"repeatid")
          {

              exec(http("CreatePaymentMethod")
      .post("/apex/PaymentMethod")
      .headers(headers_01)
      .formParam("j_id0:j_id1", "j_id0:j_id1")
      .formParam("j_id0:j_id1:j_id3:rowsperlist", "")
      .formParam("j_id0:j_id1:j_id3:lsi", "")
      .formParam("j_id0:j_id1:j_id3:rowsperpage", "")
      .formParam("j_id0:j_id1:j_id3:fcf", "")
      .formParam("j_id0:j_id1:j_id3:lsr", "")
      .formParam("j_id0:j_id1:j_id3:lsc", "")
      .formParam("j_id0:j_id1:j_id3:rlx", "")
      .formParam("j_id0:j_id1:pb1:j_id4:if1", "Credit Card")
      .formParam("j_id0:j_id1:pb1:xxxpbs1:cardType", "VISA")
      .formParam("j_id0:j_id1:pb1:xxxpbs1:cardHolder", "TestName1")
      .formParam("j_id0:j_id1:pb1:xxxpbs1:cardNumber", "1234567890")
      .formParam("j_id0:j_id1:pb1:xxxpbs1:expMonth", "09")
      .formParam("j_id0:j_id1:pb1:xxxpbs1:expYear", "2025")
      .formParam("j_id0:j_id1:pb1:j_id8:Account_lkid", "001L00000169qRt")
      .formParam("j_id0:j_id1:pb1:j_id8:Account_lkold", "Account-web4-1-0")
      .formParam("j_id0:j_id1:pb1:j_id8:Account_lktp", "001")
      .formParam("j_id0:j_id1:pb1:j_id8:Account_lspf", "0")
      .formParam("j_id0:j_id1:pb1:j_id8:Account_lspfsub", "0")
      .formParam("j_id0:j_id1:pb1:j_id8:Account_mod", "0")
      .formParam("j_id0:j_id1:pb1:j_id8:Account", "Account-web4-1-0")
      .formParam("j_id0:j_id1:pb1:j_id8:isActive", "1")
      .formParam("j_id0:j_id1:pb1:j_id9:bottom:j_id10", "Save")
      .formParam("com.salesforce.visualforce.ViewState", "${ViewState}")
      .formParam("com.salesforce.visualforce.ViewStateVersion", "${ViewStateVersion}")
      .formParam("com.salesforce.visualforce.ViewStateMAC", "${ViewStateMAC}")
      .formParam("com.salesforce.visualforce.ViewStateCSRF", "${ViewStateCSRF}"))

     .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)





          }


   /*   val createOrderScn = scenario("OM_Standard_Mix_UseCase_Test_CreateOrder")

      .feed(userFeeder)
      .exec(http("OM_Standard_Login")
          .post(uri01 + "/")
          .headers(headers_00)
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          .formParam("startURL", "")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          .formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "M1D2l15jFvl")
          .formParam("display", "page")
          .formParam("username", "${username}")
          .formParam("pw", "${password}")
          .formParam("Login", ""))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("RESTGetOAuthToken")
          .post("https://test.salesforce.com/services/oauth2/token")
          .header("Content-Type", "application/x-www-form-urlencoded")
          .formParam("password", "${password}")
          .formParam("username", "${username}")
          .formParam("client_secret", "5644903920226338215")
          .formParam("client_id", "3MVG9MHOv_bskkhR5LPzqvofeG92uGkYzDJ8QAGeB7zALujRr0TGKmehi5HFuZZU6l2GxF76.Ddpoz1NpptCX")
          .formParam("grant_type", "password")
          .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
          .check(status.is(200)))

      .repeat(10000)
      {

      feed(accountFeeder)
      .feed(pricelistFeeder)
      .exec(http("Create_new_order")
          .post(uri10 +"/services/apexrest/v2/carts")
          .headers(header_1)
          .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("CreatedOrderID"))
          .body(StringBody("""{"subaction":"createOrder",
                    "inputFields":[
                      {"AccountId":"${AccountId}"},
                      {"PriceListId__c":"${PriceListId}"},
                      {"Name":"NewOrder1"},{"Status":"Draft"},
                      {"EffectiveDate":"04/23/2018"}
                    ]}""")).asJson)



    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    }
    */

    val getproductListScn = scenario("OM_Standard_Mix_UseCase_Test_getProductList")
.exec(session => session.set("password",credentials))

    .feed(userFeeder)
      .exec(http("OM_Standard_Login")
          .post(uri01 + "/")
          .headers(headers_00)
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          .formParam("startURL", "")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          .formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "M1D2l15jFvl")
          .formParam("display", "page")
          .formParam("username", "${username}")
          .formParam("pw", "${password}")
          .formParam("Login", ""))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("RESTGetOAuthToken")
          .post("https://test.salesforce.com/services/oauth2/token")
          .header("Content-Type", "application/x-www-form-urlencoded")
          .formParam("password", "${password}")
          .formParam("username", "${username}")
          .formParam("client_secret", "5644903920226338215")
          .formParam("client_id", "3MVG9MHOv_bskkhR5LPzqvofeG92uGkYzDJ8QAGeB7zALujRr0TGKmehi5HFuZZU6l2GxF76.Ddpoz1NpptCX")
          .formParam("grant_type", "password")
          .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
          .check(status.is(200)))

      .repeat(10000)
      {



                feed(cpqaccountFeeder)
              .feed(pricelistFeeder)
              .exec(http("Create_new_order_CPQ")
                  .post(uri10 +"/services/apexrest/v2/carts")
                  .headers(header_1)
                  .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("CreatedOrderID"))
                  .body(StringBody("""{"subaction":"createOrder",
                            "inputFields":[
                              {"AccountId":"${AccountId}"},
                              {"PriceListId__c":"${PriceListId}"},
                              {"Name":"NewOrder1"},{"Status":"Draft"},
                              {"EffectiveDate":"04/23/2018"}
                            ]}""")).asJson)
              .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)



           .repeat(4)
            {

               exec(http("Add items to cart CPQ")
              .post(uri10 +"/services/apexrest/v2/cpq/carts/${CreatedOrderID}/items")
              .headers(header_1)
              .check(regex("""\{"totalSize":1,"messages":\[\{"code":"150","severity":"INFO","message":"Successfully(......)""").find.exists.saveAs("AddStatus"))
              .body( StringBody("""{"methodName":"postCartsItems","items":[{"itemId":"01uL0000009i3wMIAQ"}],"cartId":"${CreatedOrderID}","price":true,"validate":true,"includeAttachment":false,"pagesize":1,"lastRecordId":null,"hierarchy":-1,"query":"plan"}""")).asJson)
              .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)



             }

            .repeat(2)
          {


                exec(http("Get list of products for cart CPQ")
                .get(uri10 +"/services/apexrest/v2/cpq/carts/${CreatedOrderID}/products?pagesize=10")
                .check(jsonPath("$.records[*].Id.value").find.saveAs("ListOfPBEntries"))
                .headers(header_1))
            .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

          }



             .exec(http("Get list of cart line items CPQ")
                    .get(uri10 +"/services/apexrest/v2/cpq/carts/${CreatedOrderID}/items?pagesize=10&price=false&validate=false")
                    .headers(header_1)
                    .check(jsonPath("$.records[0].Id.value").find.saveAs("LineItem1")))
            .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)



      .exec(http("Delete_an_item_from_the_cart_CPQ")
              .delete(uri10 +"/services/apexrest/v2/cpq/carts/${CreatedOrderID}/items/${LineItem1}")
              .headers(header_1))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


      .exec(http("Submit order - CPQ")
              .post(uri10 +"/services/apexrest/v2/cpq/carts/${CreatedOrderID}/items/checkout")
              .headers(header_1)
              .body( StringBody("""{
                                          "items":[
                                                    {"itemId":"${LineItem1}"}
                                          ],
                                          "hierarchy":1,
                                          "lastItemId":"",
                                          "pagesize":20
                                      }""")).asJson)


      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)



   }

   val getcartpricingScn = scenario("OM_Standard_Mix_UseCase_Test_getcartpricing")

.exec(session => session.set("password",credentials))

   .feed(userFeeder)
      .exec(http("OM_Standard_Login")
          .post(uri01 + "/")
          .headers(headers_00)
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          .formParam("startURL", "")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          .formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "M1D2l15jFvl")
          .formParam("display", "page")
          .formParam("username", "${username}")
          .formParam("pw", "${password}")
          .formParam("Login", ""))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("RESTGetOAuthToken")
          .post("https://test.salesforce.com/services/oauth2/token")
          .header("Content-Type", "application/x-www-form-urlencoded")
          .formParam("password", "${password}")
          .formParam("username", "${username}")
          .formParam("client_secret", "5644903920226338215")
          .formParam("client_id", "3MVG9MHOv_bskkhR5LPzqvofeG92uGkYzDJ8QAGeB7zALujRr0TGKmehi5HFuZZU6l2GxF76.Ddpoz1NpptCX")
          .formParam("grant_type", "password")
          .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
          .check(status.is(200)))

 .repeat(10000,"repeatid")
          {
              feed(orderFeeder)
              .exec(http("Get carts pricing")
              .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}?price=true&validate=true")
              .headers(header_1))

              .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      }



      val orderDetailsScn = scenario("OM_Standard_Mix_UseCase_Test_orderDetailsScn")

.exec(session => session.set("password",credentials))

   .feed(userFeeder)
      .exec(http("OM_Standard_Login")
          .post(uri01 + "/")
          .headers(headers_00)
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          .formParam("startURL", "")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          .formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "M1D2l15jFvl")
          .formParam("display", "page")
          .formParam("username", "${username}")
          .formParam("pw", "${password}")
          .formParam("Login", ""))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("RESTGetOAuthToken")
          .post("https://test.salesforce.com/services/oauth2/token")
          .header("Content-Type", "application/x-www-form-urlencoded")
          .formParam("password", "${password}")
          .formParam("username", "${username}")
          .formParam("client_secret", "5644903920226338215")
          .formParam("client_id", "3MVG9MHOv_bskkhR5LPzqvofeG92uGkYzDJ8QAGeB7zALujRr0TGKmehi5HFuZZU6l2GxF76.Ddpoz1NpptCX")
          .formParam("grant_type", "password")
          .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
          .check(status.is(200)))

 .repeat(10000,"repeatid")
          {
              feed(orderFeeder)
              .exec(http("Order_Details")
              .get(uri10 +"/${OrderID}")
              .headers(header_1))
              .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      }

      val logcaseScn = scenario("OM_Standard_Mix_UseCase_Test_LogCase")
.exec(session => session.set("password",credentials))
      .feed(userFeeder)
      .exec(http("Web_Login")
      .post(uri01 + "/")
      .headers(headers_26)
      .formParam("un", "${username}")
      .formParam("width", "1920")
      .formParam("height", "1080")
      .formParam("hasRememberUn", "true")
      .formParam("startURL", "")
      .formParam("loginURL", "")
      .formParam("loginType", "")
      .formParam("useSecure", "true")
      .formParam("local", "")
      .formParam("lt", "standard")
      .formParam("qs", "")
      .formParam("locale", "")
      .formParam("oauth_token", "")
      .formParam("oauth_callback", "")
      .formParam("login", "")
      .formParam("serverid", "")
      .formParam("display", "page")
      .formParam("username", "${username}")
      .formParam("pw", "${password}")
      .formParam("Login", "Log In to Sandbox")
      .formParam("rememberUn", "on"))

       .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


      .exec(http("GetCONFToken")
      .get("/500/e?retURL=%2F500%2Fo")
      .check(regex("""id="_CONFIRMATIONTOKEN" value="(.*?)"""").find.exists.saveAs("CONF_Token_CREATECASE"))
      .headers(headers_0))



    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

       .repeat(10000,"repeatid")
          {

              exec((s: Session) => s.set("userid",s.userId.toString))


    .exec(http("CreateCase")
      .post(uri10 + "/500/e")
      .headers(headers_26)
      .formParam("_CONFIRMATIONTOKEN", "${CONF_Token_CREATECASE}")
      .formParam("cancelURL", "/500/o")
      .formParam("retURL", "/500/o")
      .formParam("save_new_url", "/500/e?retURL=%2F500%2Fo")
      .formParam("save", "Saving...")
      .formParam("cas7", "New")
      .formParam("cas3_lkid", "000000000000000")
      .formParam("cas3_lkold", "null")
      .formParam("cas3_lktp", "003")
      .formParam("cas3_lspf", "0")
      .formParam("cas3_lspfsub", "0")
      .formParam("cas3_mod", "0")
      .formParam("cas3", "")
      .formParam("cas8", "Medium")
      .formParam("cas4_lkid", "000000000000000")
      .formParam("cas4_lkold", "null")
      .formParam("cas4_lktp", "001")
      .formParam("cas4_lspf", "0")
      .formParam("cas4_lspfsub", "0")
      .formParam("cas4_mod", "0")
      .formParam("cas4", "")
      .formParam("cas11", "Email")
      .formParam("cas5", "")
      .formParam("CF00NL0000004KE91_lkid", "000000000000000")
      .formParam("CF00NL0000004KE91_lkold", "null")
      .formParam("CF00NL0000004KE91_lktp", "a2p")
      .formParam("CF00NL0000004KE91_lspf", "0")
      .formParam("CF00NL0000004KE91_lspfsub", "0")
      .formParam("CF00NL0000004KE91_mod", "0")
      .formParam("CF00NL0000004KE91", "")
      .formParam("cas6", "")
      .formParam("CF00NL0000004KE94_lkid", "000000000000000")
      .formParam("CF00NL0000004KE94_lkold", "null")
      .formParam("CF00NL0000004KE94_lktp", "a4K")
      .formParam("CF00NL0000004KE94_lspf", "0")
      .formParam("CF00NL0000004KE94_lspfsub", "0")
      .formParam("CF00NL0000004KE94_mod", "0")
      .formParam("CF00NL0000004KE94", "")
      .formParam("CF00NL0000004KE95_lkid", "000000000000000")
      .formParam("CF00NL0000004KE95_lkold", "null")
      .formParam("CF00NL0000004KE95_lktp", "a4J")
      .formParam("CF00NL0000004KE95_lspf", "0")
      .formParam("CF00NL0000004KE95_lspfsub", "0")
      .formParam("CF00NL0000004KE95_mod", "0")
      .formParam("CF00NL0000004KE95", "")
      .formParam("cas14", "")
      .formParam("cas15", "")
      .formParam("cas16", "")
      .check(status.is(200))
      .check(regex("""handleRedirect\('\/(.+?)\'""").find.exists.saveAs("CaseId")))
     // .check(regex("""SfdcApp.projectOneNavigator.handleRedirect\(\'\/(.+)\'\)\;\s\}""").find.exists.saveAs("AccountId")))
       .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      }

      val createAccountScn = scenario("OM_Standard_Mix_UseCase_Test_CreateAccount")

.exec(session => session.set("password",credentials))

      .feed(userFeeder)
      .exec(http("Web_Login")
      .post(uri01 + "/")
      .headers(headers_26)
      .formParam("un", "${username}")
      .formParam("width", "1920")
      .formParam("height", "1080")
      .formParam("hasRememberUn", "true")
      .formParam("startURL", "")
      .formParam("loginURL", "")
      .formParam("loginType", "")
      .formParam("useSecure", "true")
      .formParam("local", "")
      .formParam("lt", "standard")
      .formParam("qs", "")
      .formParam("locale", "")
      .formParam("oauth_token", "")
      .formParam("oauth_callback", "")
      .formParam("login", "")
      .formParam("serverid", "")
      .formParam("display", "page")
      .formParam("username", "${username}")
      .formParam("pw", "${password}")
      .formParam("Login", "Log In to Sandbox")
      .formParam("rememberUn", "on"))

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


      .exec(http("GetCONFToken")
      .get("/001/e?retURL=%2F001%2Fo&RecordType=012L0000000EP9F&ent=Account")
      .check(regex("""id="_CONFIRMATIONTOKEN" value="(.*?)"""").find.exists.saveAs("CONF_Token"))
      .headers(headers_0))



    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

       .repeat(10000,"repeatid")
          {

              exec((s: Session) => s.set("userid",s.userId.toString))


    .exec(http("CreateAccount")
      .post(uri10 + "/001/e")
      .headers(headers_26)
      .formParam("RecordType", "012L0000000EP9F")
      .formParam("_CONFIRMATIONTOKEN", "${CONF_Token}")
      .formParam("cancelURL", "/001/o")
      .formParam("retURL", "/001/o")
      .formParam("save_new_url", "/001/e?ent=Account&retURL=%2F001%2Fo&RecordType=012L0000000EP9F")
      .formParam("save", "Saving...")
      .formParam("acc2", "Account-web4-${userid}-${repeatid}")
      .formParam("00NL0000004TxR0", "Active")
      .formParam("acc3_lkid", "0")
      .formParam("acc3_lkold", "null")
      .formParam("acc3_lktp", "1")
      .formParam("acc3_lspf", "0")
      .formParam("acc3_lspfsub", "0")
      .formParam("acc3_mod", "0")
      .formParam("acc3", "")
      .formParam("00NL0000004KE8H", "")
      .formParam("acc17street", "")
      .formParam("acc10", "")
      .formParam("acc17city", "San Francisco")
      .formParam("CF00NL0000004KE8A_lkid", "0")
      .formParam("CF00NL0000004KE8A_lkold", "null")
      .formParam("CF00NL0000004KE8A_lktp", "a2p")
      .formParam("CF00NL0000004KE8A_lspf", "0")
      .formParam("CF00NL0000004KE8A_lspfsub", "0")
      .formParam("CF00NL0000004KE8A_mod", "0")
      .formParam("CF00NL0000004KE8A", "")
      .formParam("acc17state", "California")
      .formParam("acc17zip", "94016")
      .formParam("acc17country", "")
      .formParam("00NL0000004KE8E", "")
      .formParam("00NL0000004KE83", "")
      .formParam("00NL0000004KE82", "")
      .formParam("00NL0000004KE7x", "")
      .formParam("00NL0000004KE84", "")
      .formParam("CF00NL0000004KE81_lkid", "0")
      .formParam("CF00NL0000004KE81_lkold", "null")
      .formParam("CF00NL0000004KE81_lktp", "a4E")
      .formParam("CF00NL0000004KE81_lspf", "0")
      .formParam("CF00NL0000004KE81_lspfsub", "0")
      .formParam("CF00NL0000004KE81_mod", "0")
      .formParam("CF00NL0000004KE81", "")
      .formParam("00NL0000004KE7z", "")
      .formParam("00NL0000004KE85", "")
      .formParam("00NL0000004KE86", "")
      .check(status.is(200))
      .check(regex("""handleRedirect\('\/(.+?)\'""").find.exists.saveAs("AccountId")))
     // .check(regex("""SfdcApp.projectOneNavigator.handleRedirect\(\'\/(.+)\'\)\;\s\}""").find.exists.saveAs("AccountId")))

     .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        .exec(http("GetCONFToken")
      .get("/${AccountId}")
      .check(regex("""CONFIRMATIONTOKEN=(.*?)&amp""").find.exists.saveAs("CONF_Token_update"))
      .headers(headers_0))

     .exec(http("UpdateAccount")
      .post(uri10 + "/${AccountId}/e")
      .headers(headers_26)
      .formParam("RecordType", "012L0000000EP9F")
      .formParam("_CONFIRMATIONTOKEN", "${CONF_Token_update}")
      .formParam("cancelURL", "/${AccountId}")
      .formParam("id", "${AccountId}")
      .formParam("retURL", "/${AccountId}")
      //.formParam("save_new_url", "/setup/ui/recordtypeselect.jsp?ent=Account&retURL=%2F001L00000169qXh&save_new_url=%2F001%2Fe%3Fcommon.udd.actions.ActionsUtilORIG_URI%3D%252F001L00000169qXh%252Fe%26retURL%3D%252F001L00000169qXh%26_CONFIRMATIONTOKEN%3DVmpFPSxNakF4T0MweE1pMHdNVlF3TnpveU5UbzFNeTR4TXpkYSxPVDhOVmJwVDNPMlZzYjVzY01FdkhoLE5qZzVOemd3")
      .formParam("save", "Saving...")
      .formParam("acc2", "Account-web4-1-0")
      .formParam("00NL0000004TxR0", "Active")
      .formParam("acc3_lkid", "000000000000000")
      .formParam("acc3_lkold", "null")
      .formParam("acc3_lktp", "001")
      .formParam("acc3_lspf", "0")
      .formParam("acc3_lspfsub", "0")
      .formParam("acc3_mod", "0")
      .formParam("acc3", "")
      .formParam("00NL0000004KE8H", "")
      .formParam("acc17street", "")
      .formParam("acc10", "")
      .formParam("acc17city", "San Francisco")
      .formParam("CF00NL0000004KE8A_lkid", "000000000000000")
      .formParam("CF00NL0000004KE8A_lkold", "null")
      .formParam("CF00NL0000004KE8A_lktp", "a2p")
      .formParam("CF00NL0000004KE8A_lspf", "0")
      .formParam("CF00NL0000004KE8A_lspfsub", "0")
      .formParam("CF00NL0000004KE8A_mod", "0")
      .formParam("CF00NL0000004KE8A", "")
      .formParam("acc17state", "California")
      .formParam("acc17zip", "94016")
      .formParam("acc17country", "usa")
      .formParam("00NL0000004KE8E", "")
      .formParam("00NL0000004KE83", "")
      .formParam("00NL0000004KE82", "")
      .formParam("00NL0000004KE7x", "")
      .formParam("00NL0000004KE84", "")
      .formParam("CF00NL0000004KE81_lkid", "000000000000000")
      .formParam("CF00NL0000004KE81_lkold", "null")
      .formParam("CF00NL0000004KE81_lktp", "a4E")
      .formParam("CF00NL0000004KE81_lspf", "0")
      .formParam("CF00NL0000004KE81_lspfsub", "0")
      .formParam("CF00NL0000004KE81_mod", "0")
      .formParam("CF00NL0000004KE81", "")
      .formParam("00NL0000004KE7z", "")
      .formParam("00NL0000004KE85", "")
      .formParam("00NL0000004KE86", "")
      .formParam("sysMod", "16759345c58")
      .check(status.is(200))
      .check(regex("""handleRedirect\('\/(.+?)\'""").find.exists.saveAs("AccountId")))
     // .check(regex("""SfdcApp.projectOneNavigator.handleRedirect\(\'\/(.+)\'\)\;\s\}""").find.exists.saveAs("AccountId")))


      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)



          }


  	  val submitOrderScn = scenario("OM_Standard_Mix_UseCase_Test")

.exec(session => session.set("password",credentials))

      .feed(userFeeder)
      .exec(http("001_OMS_AssetizeNewOrder_Login")
          .post(uri01 + "/")
          .headers(headers_00)
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          .formParam("startURL", "")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          .formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "M1D2l15jFvl")
          .formParam("display", "page")
          .formParam("username", "${username}")
          .formParam("pw", "${password}")
          .formParam("Login", ""))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("002_OMS_AssetizeNewOrder_RESTGetOAuthToken")
          .post("https://test.salesforce.com/services/oauth2/token")
          .header("Content-Type", "application/x-www-form-urlencoded")
          .formParam("password", "${password}")
          .formParam("username", "${username}")
          .formParam("client_secret", "5644903920226338215")
          .formParam("client_id", "3MVG9MHOv_bskkhR5LPzqvofeG92uGkYzDJ8QAGeB7zALujRr0TGKmehi5HFuZZU6l2GxF76.Ddpoz1NpptCX")
          .formParam("grant_type", "password")
          .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
          .check(status.is(200)))

      .repeat(10000)
      {

      feed(accountFeeder)
      .feed(pricelistFeeder)
      .exec(http("003_OMS_AssetizeNewOrder_CreateNewOrder")
          .post(uri10 +"/services/apexrest/v2/carts")
          .headers(header_1)
          .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
          .body(StringBody("""{"subaction":"createOrder",
                    "inputFields":[
                      {"AccountId":"${AccountId}"},
                      {"PriceListId__c":"${PriceListId}"},
                      {"Name":"NewOrder1"},{"Status":"Draft"},
                      {"EffectiveDate":"04/23/2018"}
                    ]}""")).asJson)



    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

     .feed(pricelistEntryFeeder)
      .exec(http("004_OMS_AssetizeNewOrder_AddItemsToCart")
          .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
          .headers(header_1)
          .check(regex("""\{"totalSize":1,"messages":\[\{"code":"150","severity":"INFO","message":"Successfully(......)""").find.exists.saveAs("AddStatus"))
          .body( StringBody("""{"methodName":"postCartsItems","items":[{"itemId":"${PriceListEntryId}"}],"cartId":"${OrderID}","price":true,"validate":true,"includeAttachment":false,"pagesize":1,"lastRecordId":null,"hierarchy":-1,"query":"plan"}""")).asJson)




    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("005_OMS_AssetizeNewOrder_SubmitOrder")
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/checkout")
      .headers(header_1)
      .check(regex("""Submission of order (.*?) was successful""").find.exists)
      .body( StringBody("""{
      "cartId": "${OrderID}",
      "skipCheckoutValidation": true
      }""")).asJson)
/*
    .exec(http("SubmitOrder")
      .get(uri05 + "/apex/XOMSubmitOrder?scontrolCaching=1&id=${OrderID}")
      .headers(headers_05)
      .check(regex("""salesforce.com/a3t(.*?)'\)""").find.exists.saveAs("OrchestrationPlanID"))


    )
*/



    }



      val submitOrderB2BScn = scenario("OM_Standard_Mix_UseCase_Test_B2B")

.exec(session => session.set("password",credentials))

      .feed(userFeeder)
      .exec(http("001_OMS_B2BAssetizeNewOrder_Login")
          .post(uri01 + "/")
          .headers(headers_00)
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          .formParam("startURL", "")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          .formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "M1D2l15jFvl")
          .formParam("display", "page")
          .formParam("username", "${username}")
          .formParam("pw", "${password}")
          .formParam("Login", ""))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("002_OMS_B2BAssetizeNewOrder_RESTGetOAuthToken")
          .post("https://test.salesforce.com/services/oauth2/token")
          .header("Content-Type", "application/x-www-form-urlencoded")
          .formParam("password", "${password}")
          .formParam("username", "${username}")
          .formParam("client_secret", "5644903920226338215")
          .formParam("client_id", "3MVG9MHOv_bskkhR5LPzqvofeG92uGkYzDJ8QAGeB7zALujRr0TGKmehi5HFuZZU6l2GxF76.Ddpoz1NpptCX")
          .formParam("grant_type", "password")
          .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
          .check(status.is(200)))

      .repeat(10000)
      {

      feed(accountFeeder)
      .feed(pricelistFeeder_B2B)
      .exec(http("003_OMS_B2BAssetizeNewOrder_CreateNewOrder")
          .post(uri10 +"/services/apexrest/v2/carts")
          .headers(header_1)
          .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
          .body(StringBody("""{"subaction":"createOrder",
                    "inputFields":[
                      {"AccountId":"${AccountId}"},
                      {"PriceListId__c":"${PriceListId}"},
                      {"Name":"NewOrder1"},{"Status":"Draft"},
                      {"EffectiveDate":"04/23/2018"}
                    ]}""")).asJson)



    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      //Add the same product for 10 times
      .repeat(10)
      {
        feed(pricelistEntryFeeder_B2B)
        .exec(http("004_OMS_B2BAssetizeNewOrder_AddItemsToCart")
          .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
          .headers(header_1)
          .check(regex("""\{"totalSize":1,"messages":\[\{"code":"150","severity":"INFO","message":"Successfully(......)""").find.exists.saveAs("AddStatus"))
          .body( StringBody("""{"methodName":"postCartsItems","items":[{"itemId":"${PriceListEntryId}"}],"cartId":"${OrderID}","price":true,"validate":true,"includeAttachment":false,"pagesize":1,"lastRecordId":null,"hierarchy":-1,"query":"plan"}""")).asJson)

      }


    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("005_OMS_B2BAssetizeNewOrder_SubmitOrder")
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/checkout")
      .headers(header_1)
      .check(regex("""Submission of order (.*?) was successful""").find.exists)
      .body( StringBody("""{
      "cartId": "${OrderID}",
      "skipCheckoutValidation": true
      }""")).asJson)

/*
    .exec(http("SubmitOrder")
      .get(uri05 + "/apex/XOMSubmitOrder?scontrolCaching=1&id=${OrderID}")
      .headers(headers_05)
      .check(regex("""salesforce.com/a3t(.*?)'\)""").find.exists.saveAs("OrchestrationPlanID")))

*/


    }



//#########################################################################################

          val NormalflowScn = scenario("OM_Standard_MACD_Normalflow")
.exec(session => session.set("password",credentials))

      .feed(userFeeder)
      .exec(http("001_OMS_AssetizeAddFlow_Login")
          .post(uri01 + "/")
          .headers(headers_00)
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          .formParam("startURL", "")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          .formParam("qs", "r=https%3A%2F%2Fcs8.salesforce.com%2Fsecur%2Flogout.jsp")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "M1D2l15jFvl")
          .formParam("display", "page")
          .formParam("username", "${username}")
          .formParam("pw", "${password}")
          .formParam("Login", ""))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("002_OMS_AssetizeAddFlow_RESTGetOAuthToken")
          .post("https://test.salesforce.com/services/oauth2/token")
          .header("Content-Type", "application/x-www-form-urlencoded")
          .formParam("password", "${password}")
          .formParam("username", "${username}")
          .formParam("client_secret", "5644903920226338215")
          .formParam("client_id", "3MVG9MHOv_bskkhR5LPzqvofeG92uGkYzDJ8QAGeB7zALujRr0TGKmehi5HFuZZU6l2GxF76.Ddpoz1NpptCX")
          .formParam("grant_type", "password")
          .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
          .check(status.is(200)))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      //.feed(assetFeeder)
      .repeat(1000000)
      //.repeat(1)
      {
      feed(assetFeeder)
      .exec(http("003_OMS_AssetizeAddFlow_ClickOnChangeToOrder")
          .get(uri05 +"/apex/MACDFdo?id=${AssetId_add}")
          .headers(headers_145)
          .check(regex("""GenericInvoke2","len":4,"ns":"","ver":38.0,"csrf":"(.+?)"}""").find.exists.saveAs("csrfToken"))
          //.check(regex(""""name":"ContentVersionAddLinkBase","len":2,"ns":"","ver":32.0,"csrf":"(.+?)"}""").find.exists.saveAs("csrfToken"))
          .check(regex("""vid":"(.+?)","xhr""").find.exists.saveAs("vid")))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("004_OMS_AssetizeAddFlow_CreateNewMacdOrder")
          .post(uri05 +"/apexremote")
          .headers(headers_001)
          .check(regex("""fdoId.":."(.+?).",."error""").find.exists.saveAs("CartId_ForAdding"))
          .body(ElFileBody("./src/test/resources/bodies/oms_macd_10Assets/createmacdorder_add_10assets.txt")))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("005_OMS_AssetizeAddFlow_GetNewCsrfToken")
          .get(uri05 +"/apex/HybridCPQ?id=${CartId_ForAdding}")
          .headers(headers_001)
          .check(regex("""vid":"(.+?)...xhr""").find.exists.saveAs("vid_add"))
          .check(regex("""len":4."ns":""."ver":41.0."csrf":"(.+?)"["$&+,:;=?@#|'<>.^*()%!-}{a-z]*doNamedCredentialCallout""").find.exists.saveAs("csrfToken_add")))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("006_OMS_AssetizeAddFlow_GetParentId")
          .post(uri05 +"/apexremote")
          .headers(headers_022)
          .check(regex("""parentId.":."(.+?).".."itemId""").find.exists.saveAs("parentid_add"))
          .body(ElFileBody("./src/test/resources/bodies/oms_macd_10Assets/OM_GetParentID_add.txt")))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("007_OMS_AssetizeAddFlow_AddItemsToCart")
          .post(uri05 +"/apexremote")
          .headers(headers_055)
          .check(regex("""Successfully added.""").find.exists)
          .body(ElFileBody("./src/test/resources/bodies/oms_macd_10Assets/OM_MACD_addTocart.txt")))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("008_OMS_AssetizeAddFlow_SubmitOrder")
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${CartId_ForAdding}/items/checkout")
      .headers(header_1)
      .check(regex("""Submission of order (.*?) was successful""").find.exists)
      .body( StringBody("""{
      "cartId": "${CartId_ForAdding}",
      "skipCheckoutValidation": true
      }""")).asJson)
/*
      .exec(http("AddFlow_SubmitOrder")
        .get(uri05 + "/apex/XOMSubmitOrder?scontrolCaching=1&id=${CartId_ForAdding}")
        .headers(headers_05)
       .check(regex("""salesforce.com/a3t(.*?)'\)""").find.exists.saveAs("OrchestrationPlanID")))


      .exec( session => {
        println( session( "CartId_ForAdding" ).as[String] )
        session
      })
*/
    }




//#########################################################################################

      val DeleteflowScn = scenario("OM_Standard_MACD_Deleteflow")

.exec(session => session.set("password",credentials))

      .feed(userFeeder)
      .exec(http("001_OMS_AssetizeDeleteFlow_Login")
          .post(uri01 + "/")
          .headers(headers_00)
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          .formParam("startURL", "")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          .formParam("qs", "r=https%3A%2F%2Fcs8.salesforce.com%2Fsecur%2Flogout.jsp")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "M1D2l15jFvl")
          .formParam("display", "page")
          .formParam("username", "${username}")
          .formParam("pw", "${password}")
          .formParam("Login", ""))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("002_OMS_AssetizeDeleteFlow_RESTGetOAuthToken")
          .post("https://test.salesforce.com/services/oauth2/token")
          .header("Content-Type", "application/x-www-form-urlencoded")
          .formParam("password", "${password}")
          .formParam("username", "${username}")
          .formParam("client_secret", "5644903920226338215")
          .formParam("client_id", "3MVG9MHOv_bskkhR5LPzqvofeG92uGkYzDJ8QAGeB7zALujRr0TGKmehi5HFuZZU6l2GxF76.Ddpoz1NpptCX")
          .formParam("grant_type", "password")
          .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
          .check(status.is(200)))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
      .repeat(1000000)
      //.repeat(1)
      {
      feed(assetFeeder_delete)
      .exec(http("003_OMS_AssetizeDeleteFlow_ClickOnChangeToOrder")
          .get(uri05 +"/apex/MACDFdo?id=${AssetId_delete}")
          .headers(headers_145)
          .check(regex("""GenericInvoke2","len":4,"ns":"","ver":38.0,"csrf":"(.+?)"}""").find.exists.saveAs("csrfToken"))
          .check(regex("""vid":"(.+?)","xhr""").find.exists.saveAs("vid")))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("004_OMS_AssetizeDeleteFlow_CreateNewMacdOrder")
          .post(uri05 +"/apexremote")
          .headers(headers_001)
          .check(regex("""fdoId.":."(.+?).",."error""").find.exists.saveAs("CartId_ForDelete"))
          .body(ElFileBody("./src/test/resources/bodies/oms_macd_10Assets/createmacdorder_delete_10assets.txt")))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("005_OMS_AssetizeDeleteFlow_GetNewCsrfToken")
          .get(uri05 +"/apex/HybridCPQ?id=${CartId_ForDelete}")
          .headers(headers_001)
          .check(regex("""vid":"(.+?)...xhr""").find.exists.saveAs("vid_del"))
          .check(regex("""len":4."ns":""."ver":41.0."csrf":"(.+?)"["$&+,:;=?@#|'<>.^*()%!-}{a-z]*doNamedCredentialCallout""").find.exists.saveAs("csrfToken_del")))


      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("006_OMS_AssetizeDeleteFlow_GetRootBundleParentId")
          .post(uri05 +"/apexremote")
          .headers(headers_022)
          .check(regex("""putCartsItems[a-z\\",:\[\]{}]*itemId[a-z\\",:\[\]{}]*(.+?)."}],."filters""").find.exists.saveAs("parentid"))
          .body(ElFileBody("./src/test/resources/bodies/oms_macd_10Assets/OM_GetParentID_delete.txt")))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec( session => session.set("parentid_delete", "" ) )

      .exec(http("007_OMS_AssetizeDeleteFlow_GetChildParentID")
        .post(uri05 +"/apexremote")
        .headers(headers_054)
        .check(regex("""putCartsItems[a-z\\",:\[\]{}]*itemId[a-z\\",:\[\]{}]*(.+?)."}],."filters""").findAll.saveAs("parentid_deletelist"))
        .body(ElFileBody("./src/test/resources/bodies/oms_macd_10Assets/OM_GetParentID_Childproduct_delete.txt")))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

/*
      .exec( session => {
        println( session( "parentid_deletelist" ).as[String] )
        session
      })
*/

      .exec( session => {
        val parentid_deletearray = session("parentid_deletelist").as[List[String]]
        parentid_del.append(parentid_deletearray(4))
      session
      })

    .exec( session => session.set("parentid_delete", parentid_del ) )


    .exec( session => {
      parentid_del = new StringBuilder()
      session
    })


//    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("008_OMS_AssetizeDeleteFlow_DeleteProductfromAsset")
      .post(uri05 +"/apexremote")
      .headers(headers_054)
      .check(regex("""Successfully deleted.""").find.exists)
      //.body(ElFileBody("./src/test/resources/bodies/oms_macd_10Assets/OM_DeleteMacD_Order.txt")))
      .body(ElFileBody("./src/test/resources/bodies/oms_macd_10Assets/OM_DeleteMacD_Order107_1.txt")))
    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("009_OMS_AssetizeDeleteFlow_SubmitOrder")
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${CartId_ForDelete}/items/checkout")
      .headers(header_1)
      .check(regex("""Submission of order (.*?) was successful""").find.exists)
      .body( StringBody("""{
      "cartId": "${CartId_ForDelete}",
      "skipCheckoutValidation": true
      }""")).asJson)
/*
      .exec( session => {
        println( session( "CartId_ForDelete" ).as[String] )
        session
      })


      .exec(http("DeleteFlow_SubmitOrder")
        .get(uri05 + "/apex/XOMSubmitOrder?scontrolCaching=1&id=${CartId_ForDelete}")
        .headers(headers_05)
        .check(regex("""salesforce.com/a3t(.*?)'\)""").find.exists.saveAs("OrchestrationPlanID")))
*/


    }




//#########################################################################################

      val UpdateflowScn = scenario("OM_Standard_MACD_Updateflow")

.exec(session => session.set("password",credentials))

      .feed(userFeeder)
      .exec(http("001_OMS_AssetizeUpdateFlow_Login")
          .post(uri01 + "/")
          .headers(headers_00)
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          .formParam("startURL", "")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          .formParam("qs", "r=https%3A%2F%2Fcs8.salesforce.com%2Fsecur%2Flogout.jsp")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "M1D2l15jFvl")
          .formParam("display", "page")
          .formParam("username", "${username}")
          .formParam("pw", "${password}")
          .formParam("Login", ""))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("002_OMS_AssetizeUpdateFlow_RESTGetOAuthToken")
          .post("https://test.salesforce.com/services/oauth2/token")
          .header("Content-Type", "application/x-www-form-urlencoded")
          .formParam("password", "${password}")
          .formParam("username", "${username}")
          .formParam("client_secret", "5644903920226338215")
          .formParam("client_id", "3MVG9MHOv_bskkhR5LPzqvofeG92uGkYzDJ8QAGeB7zALujRr0TGKmehi5HFuZZU6l2GxF76.Ddpoz1NpptCX")
          .formParam("grant_type", "password")
          .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
          .check(status.is(200)))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .repeat(1000000)
      //.repeat(1)
      {
      feed(assetFeeder_update)
      .exec(http("003_OMS_AssetizeUpdateFlow_ClickOnChangeToOrder")
          .get(uri05 +"/apex/MACDFdo?id=${AssetId_update}")
          .headers(headers_145)
          .check(regex("""GenericInvoke2","len":4,"ns":"","ver":38.0,"csrf":"(.+?)"}""").find.exists.saveAs("csrfToken"))
          .check(regex("""vid":"(.+?)","xhr""").find.exists.saveAs("vid")))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("004_OMS_AssetizeUpdateFlow_CreateNewMacdOrder")
          .post(uri05 +"/apexremote")
          .headers(headers_001)
          .check(regex("""fdoId.":."(.+?).",."error""").find.exists.saveAs("CartId_ForUpdate"))
          .body(ElFileBody("./src/test/resources/bodies/oms_macd_10Assets/createmacdorder_update_10assets.txt")))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("005_OMS_AssetizeUpdateFlow_GetNewCsrfToken")
          .get(uri05 +"/apex/HybridCPQ?id=${CartId_ForUpdate}")
          .headers(headers_001)
          .check(regex("""vid":"(.+?)...xhr""").find.exists.saveAs("vid_upd"))
          .check(regex("""len":4."ns":""."ver":41.0."csrf":"(.+?)"["$&+,:;=?@#|'<>.^*()%!-}{a-z]*doNamedCredentialCallout""").find.exists.saveAs("csrfToken_upd")))


      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

       /*********** Get Cart LineItems***********/

      .exec(http("006_OMS_AssetizeUpdateFlow_GetCartLineItems")
            .get(uri10 +"/services/apexrest/v2/cpq/carts/${CartId_ForUpdate}/items?pagesize=10&price=false&validate=false")
            .headers(header_1)
            .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.exists.saveAs("LineItem1")))
           // .check(jsonPath("$").find.exists.saveAs("response")))
            //.check(jsonPath("$.records[0].childProducts.records..productId").find.exists.saveAs("LineItem1")))

      //.exec( session => {
        //println( session( "response" ).as[String] )
       // println( session( "LineItem1" ).as[String] )
       // session
      //})
      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      /*********** Get LineItems Details***********/
      .exec(http("007_OMS_AssetizeUpdateFlow_GetLineItemDetails")
          .get(uri10 +"/services/apexrest/v2/cpq/carts/${CartId_ForUpdate}/items")
          .queryParamSeq(Seq(("id", "${LineItem1}")))
          .headers(header_1)
          //.check(jsonPath("$").find.exists.saveAs("response"))
          .check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))

      //.exec( session => {
       // println( session( "response" ).as[String] )
        //println( session( "LineItem1" ).as[String] )
       // session
     // })



      //.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(session => {
          //originalItemJson.append(session("capturedItemHierarchy").as[String])
          modifiedItemJson = new StringBuilder()
          modifiedItemJson.append("""{"items":{"records":[{"displaySequence":-1,""").append(session("capturedItemHierarchy").as[String]).append("}]}}")
          session
          })

            /* Updating the Quantity from default 1.00 to 3.00 */
        .exec(http("008_OMS_AssetizeUpdateFlow_UpdateCartLineItem")
          .put(uri10 +"/services/apexrest/v2/cpq/carts/${CartId_ForUpdate}/items")
          .headers(header_1)
          .body(StringBody(session =>  modifiedItemJson.replaceAllLiterally(""""Quantity":{"value":1.00""",""""Quantity":{"value":3.00""").toString() )).asJson
          .check(regex("""message":"Successfully.updated."}]""").find.exists))

    .exec(http("009_OMS_AssetizeUpdateFlow_SubmitOrder")
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${CartId_ForUpdate}/items/checkout")
      .headers(header_1)
      .check(regex("""Submission of order (.*?) was successful""").find.exists)
      .body( StringBody("""{
      "cartId": "${CartId_ForUpdate}",
      "skipCheckoutValidation": true
      }""")).asJson)

/*
      .exec( session => {
        println( session( "CartId_ForUpdate" ).as[String] )
        session
      })

      .exec(http("UpdateFlow_SubmitOrder")
          .get(uri05 + "/apex/XOMSubmitOrder?scontrolCaching=1&id=${CartId_ForUpdate}")
          .headers(headers_05)
          .check(regex("""salesforce.com/a3t(.*?)'\)""").find.exists.saveAs("OrchestrationPlanID")))
*/
    }


//#########################################################################################################################################


      val submitOrderNonAssetizeScn = scenario("OM_Standard_Mix_UseCase_Test_NonAssetize")
.exec(session => session.set("password",credentials))

      .feed(userFeeder)
      .exec(http("001_OMS_NonAssetizeNewOrder_Login")
          .post(uri01 + "/")
          .headers(headers_00)
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          .formParam("startURL", "")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          .formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "M1D2l15jFvl")
          .formParam("display", "page")
          .formParam("username", "${username}")
          .formParam("pw", "${password}")
          .formParam("Login", ""))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("002_OMS_NonAssetizeNewOrder_RESTGetOAuthToken")
          .post("https://test.salesforce.com/services/oauth2/token")
          .header("Content-Type", "application/x-www-form-urlencoded")
          .formParam("password", "${password}")
          .formParam("username", "${username}")
          .formParam("client_secret", "5644903920226338215")
          .formParam("client_id", "3MVG9MHOv_bskkhR5LPzqvofeG92uGkYzDJ8QAGeB7zALujRr0TGKmehi5HFuZZU6l2GxF76.Ddpoz1NpptCX")
          .formParam("grant_type", "password")
          .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
          .check(status.is(200)))

      .repeat(10000)
      {

      feed(accountFeeder_NonAssetize)
      .feed(pricelistFeeder)
      .exec(http("003_OMS_NonAssetizeNewOrder_CreateNewOrder")
          .post(uri10 +"/services/apexrest/v2/carts")
          .headers(header_1)
          .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
          .body(StringBody("""{"subaction":"createOrder",
                    "inputFields":[
                      {"AccountId":"${AccountId}"},
                      {"PriceListId__c":"${PriceListId}"},
                      {"Name":"NewOrder1"},{"Status":"Draft"},
                      {"EffectiveDate":"04/24/2018"}
                    ]}""")).asJson)



    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)



      .feed(pricelistEntryFeeder_NonAssetize)
      .exec(http("004_OMS_NonAssetizeNewOrder_AddItemsToCart")
          .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
          .headers(header_1)
          .check(regex("""\{"totalSize":1,"messages":\[\{"code":"150","severity":"INFO","message":"Successfully(......)""").find.exists.saveAs("AddStatus"))
          .body( StringBody("""{"methodName":"postCartsItems","items":[{"itemId":"${PriceListEntryId}"}],"cartId":"${OrderID}","price":true,"validate":true,"includeAttachment":false,"pagesize":1,"lastRecordId":null,"hierarchy":-1,"query":"plan"}""")).asJson)




    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


    .exec(http("005_OMS_NonAssetizeNewOrder_SubmitOrder")
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/checkout")
      .headers(header_1)
      .check(regex("""Submission of order (.*?) was successful""").find.exists)
      .body( StringBody("""{
      "cartId": "${OrderID}",
      "skipCheckoutValidation": true
      }""")).asJson)

/*
      .exec( session => {
        println( session( "OrderID" ).as[String] )
        session
      })

    .exec(http("NonAssetize_SubmitOrder")
      .get(uri05 + "/apex/XOMSubmitOrder?scontrolCaching=1&id=${OrderID}")
      .headers(headers_05)
      .check(regex("""salesforce.com/a3t(.*?)'\)""").find.exists.saveAs("OrchestrationPlanID")))

*/


    }


//#############################################################################################################################


          val NormalflowNonAssetizeScn = scenario("OM_Standard_MACD_NormalflowNonAssetize")

.exec(session => session.set("password",credentials))

      .feed(userFeeder)
      .exec(http("001_OMS_NonAssetizeAddFlow_Login")
          .post(uri01 + "/")
          .headers(headers_00)
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          .formParam("startURL", "")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          .formParam("qs", "r=https%3A%2F%2Fcs8.salesforce.com%2Fsecur%2Flogout.jsp")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "M1D2l15jFvl")
          .formParam("display", "page")
          .formParam("username", "${username}")
          .formParam("pw", "${password}")
          .formParam("Login", ""))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("002_OMS_NonAssetizeAddFlow_RESTGetOAuthToken")
          .post("https://test.salesforce.com/services/oauth2/token")
          .header("Content-Type", "application/x-www-form-urlencoded")
          .formParam("password", "${password}")
          .formParam("username", "${username}")
          .formParam("client_secret", "5644903920226338215")
          .formParam("client_id", "3MVG9MHOv_bskkhR5LPzqvofeG92uGkYzDJ8QAGeB7zALujRr0TGKmehi5HFuZZU6l2GxF76.Ddpoz1NpptCX")
          .formParam("grant_type", "password")
          .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
          .check(status.is(200)))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


      .repeat(1000000)
      //.repeat(1)
      {
      feed(assetFeederNonAssetize)
      .exec(http("003_OMS_NonAssetizeAddFlow_ClickOnChangeToOrder")
          .get(uri05 +"/apex/MACDFdo?id=${AssetId_addNonAssetize}")
          .headers(headers_145)
          .check(regex("""GenericInvoke2","len":4,"ns":"","ver":38.0,"csrf":"(.+?)"}""").find.exists.saveAs("csrfToken"))
          .check(regex("""vid":"(.+?)","xhr""").find.exists.saveAs("vid")))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("004_OMS_NonAssetizeAddFlow_CreateNewMacdOrder")
          .post(uri05 +"/apexremote")
          .headers(headers_001)
          .check(regex("""fdoId.":."(.+?).",."error""").find.exists.saveAs("CartId_ForAddingNonAssetize"))
          .body(ElFileBody("./src/test/resources/bodies/oms_macd_10Assets/NonAssetize/createmacdorder_add_10assets.txt")))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("005_OMS_NonAssetizeAddFlow_GetNewCsrfToken")
          .get(uri05 +"/apex/HybridCPQ?id=${CartId_ForAddingNonAssetize}")
          .headers(headers_001)
          .check(regex("""vid":"(.+?)...xhr""").find.exists.saveAs("vid_addNonAssetize"))
          .check(regex("""len":4."ns":""."ver":41.0."csrf":"(.+?)"["$&+,:;=?@#|'<>.^*()%!-}{a-z]*doNamedCredentialCallout""").find.exists.saveAs("csrfToken_addNonAssetize")))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("006_OMS_NonAssetizeAddFlow_GetParentId")
          .post(uri05 +"/apexremote")
          .headers(headers_022)
          .check(regex("""parentId.":."(.+?).".."itemId""").find.exists.saveAs("parentid_addNonAssetize"))
          .body(ElFileBody("./src/test/resources/bodies/oms_macd_10Assets/NonAssetize/OM_GetParentID_add.txt")))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("007_OMS_NonAssetizeAddFlow_AddItemsToCart")
          .post(uri05 +"/apexremote")
          .headers(headers_055)
          .check(regex("""Successfully added.""").find.exists)
          .body(ElFileBody("./src/test/resources/bodies/oms_macd_10Assets/NonAssetize/OM_MACD_addTocart.txt")))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


    .exec(http("008_OMS_NonAssetizeAddFlow_SubmitOrder")
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${CartId_ForAddingNonAssetize}/items/checkout")
      .headers(header_1)
      .check(regex("""Submission of order (.*?) was successful""").find.exists)
      .body( StringBody("""{
      "cartId": "${CartId_ForAddingNonAssetize}",
      "skipCheckoutValidation": true
      }""")).asJson)
/*
      .exec(http("AddFlowNonAssetize_SubmitOrder")
        .get(uri05 + "/apex/XOMSubmitOrder?scontrolCaching=1&id=${CartId_ForAddingNonAssetize}")
        .headers(headers_05)
       .check(regex("""salesforce.com/a3t(.*?)'\)""").find.exists.saveAs("OrchestrationPlanID")))
*/
/*
      .exec( session => {
        println( session( "CartId_ForAddingNonAssetize" ).as[String] )
        session
      })
*/
  }





}
