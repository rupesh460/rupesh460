package OM_Standard_Mix_UseCase

object Headers  {

	val headers_0 = Map(
		"Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-US,en;q=0.8,ms;q=0.6",
		"Connection" -> "keep-alive",
		"Upgrade-Insecure-Requests" -> "1",
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36")

	val headers_00 = Map(
		"Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-US,en;q=0.8",
		"Cache-Control" -> "max-age=0",
		"Connection" -> "keep-alive",
		"Origin" -> "https://test.salesforce.com",
		"Upgrade-Insecure-Requests" -> "1",
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3080.0 Safari/537.36")


val headers_01 = Map(
		"Content-Type" -> "application/x-www-form-urlencoded",
		"Accept-Language" -> "en-US,en;q=0.8",
		"Cache-Control" -> "max-age=0",
		"Connection" -> "keep-alive",
		"Origin" -> "https://c.cs8.visual.force.com",
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36",
		"Accept" -> "ext/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
		"Referer" -> "https://c.cs8.visual.force.com/apex/PaymentMethod",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "n-GB,en-US;q=0.9,en;q=0.8",
		"Content-Length" -> "7155",
		"Upgrade-Insecure-Requests" -> "1")

	val headers_05 = Map(
		"Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-US,en;q=0.8",
		"Connection" -> "keep-alive",
		"Upgrade-Insecure-Requests" -> "1",
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3080.0 Safari/537.36")

	val header_1 = Map(
  		"Accept" -> "text/javascript, text/html, application/xml, application/json, text/xml, */*",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-US,en;q=0.8",
		"Connection" -> "keep-alive",
  		"Authorization" -> "Bearer ${Token_ID}")

	val headers_02 = Map(
		"Accept" -> "text/xml",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-US,en;q=0.9,ms;q=0.8",
		"Connection" -> "keep-alive",
		"Content-Type" -> "text/xml; charset=UTF-8",
		"Origin" -> "https://cs8.salesforce.com",
		"Referer" -> "https://cs8.salesforce.com/${OrderID}",
		"SOAPAction" -> """ "" """,
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36",
		"X-SFDC-User-Agent" -> "SFAJAX 1.0")

	val headers_26 = Map(
		"Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-US,en;q=0.8",
		"Cache-Control" -> "max-age=0",
		"Connection" -> "keep-alive",
		"Origin" -> "https://test.salesforce.com",
		"Upgrade-Insecure-Requests" -> "1",
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3080.0 Safari/537.36")

      val headers_145 = Map(
		"Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-GB,en-US;q=0.9,en;q=0.8",
		"Connection" -> "keep-alive",
		"Upgrade-Insecure-Requests" -> "1",
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3080.0 Safari/537.36")

    	val headers_001 = Map(
		"Accept" -> "*/*",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-GB,en-US;q=0.9,en;q=0.8",
		"Connection" -> "keep-alive",
		"Content-Type" -> "application/json",
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36",
		"Origin" -> "https://c.cs8.visual.force.com",
		"X-Requested-With" -> "XMLHttpRequest",
		"X-User-Agent" -> "Visualforce-Remoting")


      val headers_022 = Map(
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.13; rv:62.0) Gecko/20100101 Firefox/62.0",
		"Accept" -> "*/*",
		"Accept-Language" -> "en-US,en;q=0.9,hi;q=0.08",
                "Accept-Encoding" -> "gzip, deflate, br",
		//"Referer" -> "https://c.cs8.visual.force.com/apex/HybridCPQ?id=${OrderID}",
		"X-User-Agent" -> "Visualforce-Remoting",
		"Content-Type" -> "application/json",
		"X-Requested-With" -> "XMLHttpRequest",
		//"Content-Length" -> "923",
		"Connection" -> "keep-alive",
		"Pragma" -> "no-cache",
		"Cache-Control" -> "no-cache")

      val headers_055 = Map(
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.13; rv:62.0) Gecko/20100101 Firefox/62.0",
		"Accept" -> "*/*",
		"Accept-Language" -> "en-US,en;q=0.5",
		"Accept-Encoding" -> "gzip, deflate, br",
		//"Referer" -> "https://c.cs8.visual.force.com/apex/HybridCPQ?id=${OrderID}",
		"Content-Type" -> "application/json",
		//"Content-Length" -> "22085",
		"Connection" -> "keep-alive",
		"Cache-Control" -> "no-cache",
                "X-Requested-With" -> "XMLHttpRequest",
                "X-User-Agent" -> "Visualforce-Remoting")

      val headers_054 = Map(
                "User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.13; rv:62.0) Gecko/20100101 Firefox/62.0",
                "Accept" -> "*/*",
                "X-User-Agent" -> "Visualforce-Remoting",
                "Content-Type" -> "application/json",
                "X-Requested-With" -> "XMLHttpRequest")

}