package OM_Standard_Mix_UseCase

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._

class OM_Standard_Mix_UseCase_Scn extends Simulation {

	val httpConf = http
		.baseUrl(Configuration.BaseUrl)
		.inferHtmlResources(BlackList(""".*\.js""", """.*\.css""", """.*\.gif""", """.*\.jpeg""", """.*\.jpg""", """.*\.ico""", """.*\.woff""", """.*\.(t|o)tf""", """.*\.png"""), WhiteList())
		.acceptHeader("*/*")
		.acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8")
		.acceptEncodingHeader("gzip, deflate, sdch")
		.acceptLanguageHeader("en-US,en;q=0.8")
		.disableCaching
		.contentTypeHeader("application/x-www-form-urlencoded; charset=UTF-8")
		.userAgentHeader("Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:41.0) Gecko/20100101 Firefox/41.0")

	val NoofuserscreatePaymentMethodScn = Integer.getInteger("NoofuserscreatePaymentMethodScn", 1)
	val NoofuserscreateOrderScn = Integer.getInteger("NoofuserscreateOrderScn", 1)
	val NoofuserslogcaseScn = Integer.getInteger("NoofuserslogcaseScn", 1)
	val NoofusersgetproductListScn = Integer.getInteger("NoofusersgetproductListScn", 1)
	val NoofusersgetcartpricingScn = Integer.getInteger("NoofusersgetcartpricingScn", 1)
	val NoofusersorderDetailsScn = Integer.getInteger("NoofusersorderDetailsScn", 1)
	val NoofuserscreateAccountScn = Integer.getInteger("NoofuserscreateAccountScn", 1)
	val NoofuserssubmitOrderScn = Integer.getInteger("NoofuserssubmitOrderScn", 1)
        val NoofuserssubmitOrderB2BScn = Integer.getInteger("NoofuserssubmitOrderB2BScn", 1)
	val NoofusersNormalflowScn = Integer.getInteger("NoofusersNormalflowScn", 1)
        val NoofusersDeleteflowScn = Integer.getInteger("NoofusersDeleteflowScn",1)
        val NoofusersUpdateflowScn = Integer.getInteger("NoofusersUpdateflowScn",1)
        val NoofuserssubmitOrderNonAssetizeScn = Integer.getInteger("NoofuserssubmitOrderNonAssetizeScn",1)
        val NoofusersNormalflowNonAssetizeScn = Integer.getInteger("NoofusersNormalflowNonAssetizeScn",1)

        val rampUpTimeSecs = Integer.getInteger("rampUpTimeSecs", 1)


        //val Noofusers = Integer.getInteger("Noofusers", 1)
	val maxDurationSecs = Integer.getInteger("maxDurationSecs", 1)
	val testDuration = Integer.getInteger("testDuration",1)

	setUp(
OM_Standard_Mix_UseCase_Test.createPaymentMethodScn.inject(rampUsers(NoofuserscreatePaymentMethodScn) during (rampUpTimeSecs seconds)).protocols(httpConf),
OM_Standard_Mix_UseCase_Test.logcaseScn.inject(rampUsers(NoofuserslogcaseScn) during (rampUpTimeSecs seconds)).protocols(httpConf),
OM_Standard_Mix_UseCase_Test.getproductListScn.inject(rampUsers(NoofusersgetproductListScn) during (rampUpTimeSecs seconds)).protocols(httpConf),
OM_Standard_Mix_UseCase_Test.getcartpricingScn.inject(rampUsers(NoofusersgetcartpricingScn) during (rampUpTimeSecs seconds)).protocols(httpConf),
OM_Standard_Mix_UseCase_Test.orderDetailsScn.inject(rampUsers(NoofusersorderDetailsScn) during (rampUpTimeSecs seconds)).protocols(httpConf),
OM_Standard_Mix_UseCase_Test.createAccountScn.inject(rampUsers(NoofuserscreateAccountScn) during (rampUpTimeSecs seconds)).protocols(httpConf),
OM_Standard_Mix_UseCase_Test.NormalflowScn.inject(rampUsers(NoofusersNormalflowScn) during (rampUpTimeSecs seconds)).protocols(httpConf),
OM_Standard_Mix_UseCase_Test.submitOrderB2BScn.inject(rampUsers(NoofuserssubmitOrderB2BScn) during (rampUpTimeSecs seconds)).protocols(httpConf),
OM_Standard_Mix_UseCase_Test.DeleteflowScn.inject(rampUsers(NoofusersDeleteflowScn) during (rampUpTimeSecs seconds)).protocols(httpConf),
OM_Standard_Mix_UseCase_Test.UpdateflowScn.inject(rampUsers(NoofusersUpdateflowScn) during (rampUpTimeSecs seconds)).protocols(httpConf),
OM_Standard_Mix_UseCase_Test.submitOrderNonAssetizeScn.inject(rampUsers(NoofuserssubmitOrderNonAssetizeScn) during (rampUpTimeSecs seconds)).protocols(httpConf),
OM_Standard_Mix_UseCase_Test.NormalflowNonAssetizeScn.inject(rampUsers(NoofusersNormalflowNonAssetizeScn) during (rampUpTimeSecs seconds)).protocols(httpConf),
OM_Standard_Mix_UseCase_Test.submitOrderScn.inject(rampUsers(NoofuserssubmitOrderScn) during (rampUpTimeSecs seconds)).protocols(httpConf)).maxDuration(maxDurationSecs)
}