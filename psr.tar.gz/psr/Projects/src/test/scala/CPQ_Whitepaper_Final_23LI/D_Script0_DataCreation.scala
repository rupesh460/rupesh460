package CPQWhitepaper_Final

import scala.concurrent.duration._
import io.gatling.core.Predef._
import io.gatling.core.structure.ChainBuilder
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._
import io.gatling.jsonpath._
import Headers._
import scala.collection._
import java.time.format.DateTimeFormatter
import java.time.LocalDateTime
import java.time.LocalDate

import io.gatling.core.feeder._
import java.util.Base64
import java.nio.charset.StandardCharsets
import scala.util.matching.Regex

object D_Script0_DataCreation {

  val uri01 = Configuration.Uri01
  val uri05 = Configuration.Uri05
  val uri10 = Configuration.Uri10
  var modifiedItemJson = new StringBuilder()
  val origItemAttrHeirarchy = new StringBuilder()
  val modItemAttrHeirarchy = new StringBuilder()
  val randomNumber = new scala.util.Random
  var randomLineItem = new StringBuilder()
  var pbeEntriesList = Vector[String]()
  var promotionList = Vector[String]()
  var lineItemsList = Vector[String]()
  var randomPBEntry = new StringBuilder()
  var accountName = new StringBuilder()
  var randomPromoId = new StringBuilder()
  var final_formatted_date = new StringBuilder()
  val userFeeder = csv("./src/test/resources/data/CPQ/CPQ_Users.csv").random
  //val product_feeder = csv("./src/test/resources/data/CPQ/ProductIds.csv").circular
  val product_feeder = csv("./src/test/resources/data/CPQ/DebugProductIds.csv").circular
  val promotion_feeder = csv("./src/test/resources/data/CPQ/PromoIds.csv").random
  //val products_ids_loy = csv("./src/test/resources/data/devorg/EPC_BMK_Loyalty_ProductIds.csv").random
  //var date = DateTimeFormatter.ofPattern(“YYYY-MM-dd”).format(java.time.LocalDate.now)
  var Date =  Configuration.date

  val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
  val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
  val password_v = (passwordByEnv.get("perf3").toString)
  val password_encoded = password_v.substring(12,(password_v.length - 2 ))
  val credentials = new String(Base64.getDecoder.decode(password_encoded))


  val D_Script0_DataCreation = scenario("D_Script0_DataCreation")

  .exec(session => session.set("PriceListId",Configuration.PriceListId))
  .exec(session => session.set("Pricebook2Id",Configuration.Pricebook2Id))
  .exec(session => session.set("PromotionID1",Configuration.Promotion3PI))
  .exec(session => session.set("PromotionID2",Configuration.Promotion5PI))
  .exec(session => session.set("UpdatePromotionID",Configuration.UpdatePromotion))
  .exec(session => session.set("UpdatePromotionItemID",Configuration.UpdatePromotionItem))
  .exec(session => session.set("PenaltyRulePromotionID",Configuration.PenaltyRulePromotion))

  .exec(session => session.set("password",credentials))

  .feed(userFeeder)
  .exec(http("LDV1_Login")
    .post(uri01 + "/")
    .headers(headers_35)
    .formParam("un", "${username}")
    .formParam("width", "1440")
    .formParam("height", "900")
    .formParam("hasRememberUn", "true")
    .formParam("startURL", "")
    .formParam("loginURL", "")
    .formParam("loginType", "")
    .formParam("useSecure", "true")
    .formParam("local", "")
    .formParam("lt", "standard")
    //.formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
    .formParam("locale", "")
    .formParam("oauth_token", "")
    .formParam("oauth_callback", "")
    .formParam("login", "")
    .formParam("serverid", "")
    .formParam("QCQQ", "M1D2l15jFvl")
    .formParam("display", "page")
    .formParam("username", "${username}")
    .formParam("pw", "${password}")
    .formParam("Login", ""))


//  .feed(userFeeder)
  .exec(http("RESTGetOAuthToken")
    .post("https://test.salesforce.com/services/oauth2/token")
    .header("Content-Type", "application/x-www-form-urlencoded")
    .formParam("password", "${password}")
    .formParam("username", "${username}")
    .formParam("client_secret", "7119599995527965426")
    .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
    .formParam("grant_type", "password")
    .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
    .check(status.is(200)))

    .repeat(1)
    {

    exec(session => session.set("AccountName",""))

    .exec( session => {
      val random_index = randomNumber.nextInt(100000)
      accountName.append("Acc-"+random_index)
      session
    })

    .exec(session => session.set("AccountName",accountName))

    .exec( session => {
      accountName = new StringBuilder()
      session
    })


// D_01_NewQuote_CPQWP_001_New_CreateAccount
// Q_02_A2QAdd_CPQWP_001_MACD_CreateAccount
// Q_03_A2QUpdate_CPQWP_001_New_CreateAccount
// Q_04_A2QMove_CPQWP_001_New_CreateAccount
// Q_05_A2QDisconnect_CPQWP_001_New_CreateAccount

    /* *********** CreateAccount *********** */
    .exec(http("D_01_NewQuote_CPQWP_001_CreateAccount")
      .post(uri10 +"/services/data/v44.0/sobjects/account")
      .headers(header_1)
      .check(regex(""""id":"(.*?)"""").find.exists.saveAs("AccountId"))
      .body( StringBody("""
      {
        "Name" : "CPQ${AccountName}",
        "ShippingCity" : "San Francisco",
        "Status__c": "Active"
      }""")).asJson)

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  //  "RecordTypeId" : "012J0000000F2q3IAC",

      /* *********** CreateOpportunity *********** */
      .exec(http("D_01_NewQuote_CPQWP_002_CreateOpportunity")
        .post(uri10 +"/services/apexrest/v2/carts")
        .headers(header_1)
        .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OpportunityID"))
        .body( StringBody("""{
        "subaction":"createOppty",
        "inputFields":[
      {"AccountId":"${AccountId}"},
      {"StageName":"Prospecting"},
      {"Name":"OppCPQ${AccountName}"},
      {"Type":"New Customer"},
      {"CloseDate":"2020-02-25"},
      {"NumberOfContractedMonths__c":24},
      {"Pricebook2Id":"${Pricebook2Id}"},
      {"pricebookName":"CPQWP-Pricebook"},
      {"pricelistName":"CPQWP-Pricelist"},
      {"OriginatingChannel__c":"Dealer"}
    ]}""")).asJson)

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      /* *********** CreateQuote *********** */
      .exec(http("D_01_NewQuote_CPQWP_003_CreateQuote")
        .post(uri10 +"/services/apexrest/v2/carts")
        .headers(header_1)
        .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("QuoteID"))
        .body( StringBody("""{
            "subaction":"createQuote",
            "inputFields":[
              {"AccountId":"${AccountId}"},
              {"OpportunityId":"${OpportunityID}"},
              {"status":"Draft"},
              {"Name":"QuoCPQ${AccountName}"},
              {"Pricebook2Id":"${Pricebook2Id}"},
              {"pricebookName":"CPQWP-Pricebook"},
              {"pricelistName":"CPQWP-Pricelist"},
              {"OriginatingChannel__c":"Retail"  }
            ]}""")).asJson)

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      /* ********** get CSRF Token *********** */
      .exec(http("D_01_NewQuote_CPQWP_004_getCsrf")
      .get(uri05 + "/apex/hybridcpq?id=${QuoteID}")
      .headers(headers_99)
      .check(regex("""\{"name":"doGenericInvoke","len":4,"ns":"","ver":41.0,"csrf":"(.*)"\},\{"name":"doNamedCredentialCallout""").find.exists.saveAs("CSRFToken"))
      .check(regex("""vid":"(.+?)","xhr""").find.exists.saveAs("vid")))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    /* ********** ViewPriceLists *********** */
  .exec(http("D_01_NewQuote_CPQWP_005_ViewPriceLists")
    .get(uri10 +"/services/apexrest/v2/cpq/carts/${QuoteID}/pricelists")
    //.check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfPBEntries"))
    .headers(header_1))

.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    /* ********** SetPriceListForCart *********** */
    .exec(http("01_Quote_006_New_SetPriceListfortheQuote")
      .put(uri10 +"/services/apexrest/v2/cpq/carts/${QuoteID}/")
      .headers(header_1)
      .body(StringBody("""{
        "inputFields":
        [
        {
          "PriceListId__c": "${PriceListId}"
        }
        ],
        "cartId": "${QuoteID}",
        "methodName": "updateCarts"
      }""")).asJson
      .check(regex(""""Id":"${QuoteID}"""").find.exists))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

     .repeat(1)
     {
           /* ********** AddItemsToCart *********** */
           feed(product_feeder)
           .exec(http("D_01_NewQuote_CPQWP_010_Additemstocart")
             .post(uri10 +"/services/apexrest/v2/cpq/carts/${QuoteID}/items")
             .headers(header_1)
             .body( StringBody("""{
               "items":[{
                 "itemId":"${Product24LI_ID}"
               }],
               "price":"true",
               "validate":"true",
               "pagesize":20
             }""")).asJson
           .check(regex("""productHierarchyPath":"(.*?)","name":"CPQ-WP-P0-Prod-""").find.exists.saveAs("c_productHierarchyPath"))
           .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("CloneLineItem")))

           //{"totalSize":1,"messages":[{"code":"150","severity":"INFO","message":"Successfully added."}],"actions":{"itempricesupdated":{"rest":{

         //    .check(regex("""totalSize":1""").find.exists))

           .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
     }


.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    /* ********** RetrieveCartItems *********** */
    .exec(http("D_01_NewQuote_CPQWP_029_RetrieveCartItems")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${QuoteID}/items?pagesize=10&price=true&validate=true")
      .headers(header_1)
      .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1")))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  /* ********** CreateOrderFromQuote ********** */
        .exec(http("D_01_NewQuote_CPQWP_030_CreateOrderFromQuote")
        .post(uri10 +"/services/apexrest/v2/cpq/carts/${QuoteID}/items/checkout")
        .headers(header_1)
        //.check(regex("""Account""").find.exists)
        .body( StringBody("""{
        "items":[
        {"itemId":"${LineItem1}"}
        ],
        "hierarchy":1,
        "lastItemId":"",
        "pagesize":20
        }""")).asJson
        .check(regex("""totalSize":1,"records":\[\{"displaySequence":-1,"id":"(.*)","objectType":"Order","clonedObjectIds":"null""").find.exists.saveAs("SubmitOrderID1")))

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  /* ********** SubmitOrder ********** */
  .exec(http("D_01_NewQuote_CPQWP_031_SubmitOrder")
  .post(uri10 +"/services/apexrest/v2/cpq/carts/${SubmitOrderID1}/items/checkout")
  .headers(header_1)
  .check(regex("""SUBMIT-100""").find.exists)
  .body( StringBody("""{
  "cartId": "${SubmitOrderID1}",
  "skipCheckoutValidation": true
  }""")).asJson)

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

          }
}
