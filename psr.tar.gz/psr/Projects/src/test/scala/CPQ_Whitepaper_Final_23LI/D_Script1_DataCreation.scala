package CPQWhitepaper_Final

import scala.concurrent.duration._
import io.gatling.core.Predef._
import io.gatling.core.structure.ChainBuilder
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._
import io.gatling.jsonpath._
import Headers._
import scala.collection._
import java.time.format.DateTimeFormatter
import java.time.LocalDateTime
import java.time.LocalDate

import io.gatling.core.feeder._
import java.util.Base64
import java.nio.charset.StandardCharsets
import scala.util.matching.Regex

object D_Script1_DataCreation {

  val uri01 = Configuration.Uri01
  val uri05 = Configuration.Uri05
  val uri10 = Configuration.Uri10
  var modifiedItemJson = new StringBuilder()
  val origItemAttrHeirarchy = new StringBuilder()
  val modItemAttrHeirarchy = new StringBuilder()
  val randomNumber = new scala.util.Random
  var randomLineItem = new StringBuilder()
  var pbeEntriesList = Vector[String]()
  var promotionList = Vector[String]()
  var lineItemsList = Vector[String]()
  var randomPBEntry = new StringBuilder()
  var accountName = new StringBuilder()
  var randomPromoId = new StringBuilder()
  var final_formatted_date = new StringBuilder()
  val userFeeder = csv("./src/test/resources/data/CPQ/CPQ_Users.csv").random
  val product_feeder = csv("./src/test/resources/data/CPQ/ProductIds.csv").circular
  //val product_feeder = csv("./src/test/resources/data/CPQ/DebugProductIds.csv").circular
  val promotion_feeder = csv("./src/test/resources/data/CPQ/PromoIds.csv").random
  //val products_ids_loy = csv("./src/test/resources/data/devorg/EPC_BMK_Loyalty_ProductIds.csv").random
  //var date = DateTimeFormatter.ofPattern(“YYYY-MM-dd”).format(java.time.LocalDate.now)
  var Date =  Configuration.date

  val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
  val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
  val password_v = (passwordByEnv.get("perf3").toString)
  val password_encoded = password_v.substring(12,(password_v.length - 2 ))
  val credentials = new String(Base64.getDecoder.decode(password_encoded))

  val D_Script1_DataCreation = scenario("D_Script1_DataCreation")

  .exec(session => session.set("PriceListId",Configuration.PriceListId))
  .exec(session => session.set("Pricebook2Id",Configuration.Pricebook2Id))
  .exec(session => session.set("PromotionID1",Configuration.Promotion3PI))
  .exec(session => session.set("PromotionID2",Configuration.Promotion5PI))
  .exec(session => session.set("UpdatePromotionID",Configuration.UpdatePromotion))
  .exec(session => session.set("UpdatePromotionItemID",Configuration.UpdatePromotionItem))
  .exec(session => session.set("PenaltyRulePromotionID",Configuration.PenaltyRulePromotion))

  .exec(session => session.set("password",credentials))

  .feed(userFeeder)
  .exec(http("LDV1_Login")
    .post(uri01 + "/")
    .headers(headers_35)
    .formParam("un", "${username}")
    .formParam("width", "1440")
    .formParam("height", "900")
    .formParam("hasRememberUn", "true")
    .formParam("startURL", "")
    .formParam("loginURL", "")
    .formParam("loginType", "")
    .formParam("useSecure", "true")
    .formParam("local", "")
    .formParam("lt", "standard")
    //.formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
    .formParam("locale", "")
    .formParam("oauth_token", "")
    .formParam("oauth_callback", "")
    .formParam("login", "")
    .formParam("serverid", "")
    .formParam("QCQQ", "M1D2l15jFvl")
    .formParam("display", "page")
    .formParam("username", "${username}")
    .formParam("pw", "${password}")
    .formParam("Login", ""))

//  .feed(userFeeder)
  .exec(http("RESTGetOAuthToken")
    .post("https://test.salesforce.com/services/oauth2/token")
    .header("Content-Type", "application/x-www-form-urlencoded")
    .formParam("password", "${password}")
    .formParam("username", "${username}")
    .formParam("client_secret", "7119599995527965426")
    .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
    .formParam("grant_type", "password")
    .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
    .check(status.is(200)))

    .repeat(25000)
    {

    exec(session => session.set("AccountName",""))

    .exec( session => {
      val random_index = randomNumber.nextInt(100000)
      accountName.append("Acc-"+random_index)
      session
    })

    .exec(session => session.set("AccountName",accountName))

    .exec( session => {
      accountName = new StringBuilder()
      session
    })

    //D_01_Testdata_CPQWP_001_New_CreateAccount

    /* *********** CreateAccount *********** */
    .exec(http("D_01_Testdata_CPQWP_001_New_CreateAccount")
      .post(uri10 +"/services/data/v44.0/sobjects/account")
      .headers(header_1)
      .check(regex(""""id":"(.*?)"""").find.exists.saveAs("AccountId"))
      .body( StringBody("""
      {
        "Name" : "CPQ${AccountName}",
        "ShippingCity" : "San Francisco",
        "Status__c": "Active"
      }""")).asJson)

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  //  "RecordTypeId" : "012J0000000F2q3IAC",


  .exec( session => {
    val maxdate = Date
    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
    val dateforcurrentrun = LocalDate.parse(maxdate,formatter).plusDays(1)
    final_formatted_date.append(dateforcurrentrun)
    session
  })

  .exec( session => session.set("DATE", final_formatted_date ) )
  .exec( session => {
    final_formatted_date = new StringBuilder()
    session
  })

  /* *********** CreateOrder *********** */
  .exec(http("D_01_Testdata_CPQWP_002_CreateOrder")
    .post(uri10 +"/services/apexrest/v2/carts")
    .headers(header_1)
    .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
    .body( StringBody("""{"subaction":"createOrder",
      "inputFields":[
      {"AccountId":"${AccountId}"},
      {"PriceListId__c":"${PriceListId}"},
      {"Name":"Bmk-Order"},{"Status":"Draft"},
      {"EffectiveDate":"4/24/2020"}
      ]}""")).asJson)

//${Date}4/24/2020

.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

/* ********** get CSRF Token *********** */
.exec(http("D_01_Testdata_CPQWP_004_New_getCsrf")
.get(uri05 + "/apex/hybridcpq?id=${OrderID}")
.headers(headers_99)
.check(regex("""\{"name":"doGenericInvoke","len":4,"ns":"","ver":41.0,"csrf":"(.*)"\},\{"name":"doNamedCredentialCallout""").find.exists.saveAs("CSRFToken"))
.check(regex("""vid":"(.+?)","xhr""").find.exists.saveAs("vid")))

.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    /* ********** SetPriceListForCart *********** */
    .exec(http("D_01_Testdata_CPQWP_005_SetPriceListfortheQuote")
      .put(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/")
      .headers(header_1)
      .body(StringBody("""{
        "inputFields":
        [
        {
          "PriceListId__c": "${PriceListId}"
        }
        ],
        "cartId": "${OrderID}",
        "methodName": "updateCarts"
      }""")).asJson
      .check(regex(""""Id":"${OrderID}"""").find.exists))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)



     .repeat(1)
     {
           /* ********** AddItemsToCart *********** */
           feed(product_feeder)
           .exec(http("D_01_Testdata_CPQWP_009_Additemstocart")
             .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
             .headers(header_1)
             .body( StringBody("""{
               "items":[{
                 "itemId":"${Product10LI_ID}"
               }],
               "price":"true",
               "validate":"true",
               "pagesize":20
             }""")).asJson
           .check(regex("""productHierarchyPath":"(.*?)","name":"CPQ-WP-P0-Prod-""").find.exists.saveAs("c_productHierarchyPath"))
           .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("CloneLineItem")))

           //{"totalSize":1,"messages":[{"code":"150","severity":"INFO","message":"Successfully added."}],"actions":{"itempricesupdated":{"rest":{

         //    .check(regex("""totalSize":1""").find.exists))

           .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
     }

       /* ********** GetCartLineItems *********** */
       .exec(http("D_01_Testdata_CPQWP_018_GetCartLineItems")
         .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items?pagesize=10&price=false&validate=false")
         .headers(header_1)
         .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1")))
         //.check(jsonPath("$.records[1].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem2")))

         .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      /* ********** SubmitOrder ********** */
      .exec(http("D_01_Testdata_CPQWP_029_SubmitOrder")
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/checkout")
      .headers(header_1)
      .check(regex("""SUBMIT-100""").find.exists)
      .body( StringBody("""{
        "items":[
        {"itemId":"${LineItem1}"}
        ],
        "hierarchy":1,
        "lastItemId":"",
        "pagesize":20
      }""")).asJson)

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
}
}
