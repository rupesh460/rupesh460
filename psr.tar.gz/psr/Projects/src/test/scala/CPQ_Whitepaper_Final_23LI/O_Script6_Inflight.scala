
//THe script takes Account ID, PriceList for which order has to created ,
//PriceList entry ID for which add to cart to be done
//SELECT Id,Name FROM Account WHERE Name LIKE 'Account-3%' and id not in (select accountid from asset) LIMIT 100000
package CPQWhitepaper_Final

  import scala.concurrent.duration._
  import io.gatling.core.Predef._
  import io.gatling.core.structure.ChainBuilder
  import io.gatling.http.Predef._
  import io.gatling.jdbc.Predef._
  import io.gatling.jsonpath._
  import Headers._
  import scala.collection._
  import java.time.format.DateTimeFormatter
  import java.time.LocalDateTime
  import java.time.LocalDate

  import io.gatling.core.feeder._
  import java.util.Base64
  import java.nio.charset.StandardCharsets
  import scala.util.matching.Regex


   object O_Script6_Inflight {


      val uri01 = Configuration.Uri01
      val uri05 = Configuration.Uri05
      val uri10 = Configuration.Uri10
      var session_ids = Vector[String]()
      var xomSubmitOrder = new StringBuilder()
      var parentid_del = new StringBuilder()
      var modifiedItemJson = new StringBuilder()


      val origItemAttrHeirarchy = new StringBuilder()
      val modItemAttrHeirarchy = new StringBuilder()
      val randomNumber = new scala.util.Random
      var randomLineItem = new StringBuilder()
      var pbeEntriesList = Vector[String]()
      var promotionList = Vector[String]()
      var lineItemsList = Vector[String]()
      var randomPBEntry = new StringBuilder()
      var accountName = new StringBuilder()
      var randomPromoId = new StringBuilder()
      var final_formatted_date = new StringBuilder()
      var Date =  Configuration.date

      val userFeeder = csv("./src/test/resources/data/CPQ/CPQ_Users.csv").circular
      val product_feeder = csv("./src/test/resources/data/CPQ/ProductIds.csv").circular
      val SubmitSupplementalOrder_input = csv("./src/test/resources/data/CPQ/Order/Inflight/SubmitSupplementalOrder_input.csv").queue
      val SubmitFollowOnOrder_input = csv("./src/test/resources/data/CPQ/Order/Inflight/SubmitFollowOnOrder_input.csv").queue
      val CancelInflightOrder_input = csv("./src/test/resources/data/CPQ/Order/Inflight/CancelInflightOrder_input.csv").queue
      val DiscardAmendmentRequest_input = csv("./src/test/resources/data/CPQ/Order/Inflight/DiscardAmendmentRequest_input.csv").queue

      val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
      val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
      val password_v = (passwordByEnv.get("perf3").toString)
      val password_encoded = password_v.substring(12,(password_v.length - 2 ))
      val credentials = new String(Base64.getDecoder.decode(password_encoded))


      val SubmitSupplementalOrderScn = scenario("SubmitSupplementalOrderScn")

      .exec(session => session.set("PriceListId",Configuration.PriceListId))
      .exec(session => session.set("Pricebook2Id",Configuration.Pricebook2Id))
      .exec(session => session.set("PromotionID1",Configuration.Promotion3PI))
      .exec(session => session.set("PromotionID2",Configuration.Promotion5PI))
      .exec(session => session.set("UpdatePromotionID",Configuration.UpdatePromotion))
      .exec(session => session.set("UpdatePromotionItemID",Configuration.UpdatePromotionItem))
      .exec(session => session.set("PenaltyRulePromotionID",Configuration.PenaltyRulePromotion))

      .exec(session => session.set("password",credentials))

      .feed(userFeeder)
      .exec(http("001_CPQWP_SubmitSupplementalOrder_001_Login")
          .post(uri01 + "/")
          .headers(headers_35)
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          .formParam("startURL", "")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          .formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "M1D2l15jFvl")
          .formParam("display", "page")
          .formParam("username", "${username}")
          .formParam("pw", "${password}")
          .formParam("Login", ""))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("RESTGetOAuthToken")
      .post("https://test.salesforce.com/services/oauth2/token")
      .header("Content-Type", "application/x-www-form-urlencoded")
      .formParam("password", "${password}")
      .formParam("username", "${username}")
      .formParam("client_secret", "7119599995527965426")
      .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
      .formParam("grant_type", "password")
      .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
      .check(status.is(200)))

      .repeat(1)
      {

      feed(SubmitSupplementalOrder_input)
/*
      exec(session => session.set("AccountName",""))

      .exec( session => {
        val random_index = randomNumber.nextInt(100000)
        accountName.append("Acc-"+random_index)
        session
      })

      .exec(session => session.set("AccountName",accountName))

      .exec( session => {
        accountName = new StringBuilder()
        session
      })


      /* *********** CreateAccount *********** */
      .exec(http("001_CPQWP_SubmitSupplementalOrder_001_New_CreateAccount")
      .post(uri10 +"/services/data/v44.0/sobjects/account")
        .headers(header_1)
        .check(regex(""""id":"(.*?)"""").find.exists.saveAs("AccountId"))
        .body( StringBody("""
        {
          "Name" : "CPQ${AccountName}",
          "ShippingCity" : "San Francisco",
          "Status__c": "Active"
        }""")).asJson)

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec( session => {
      val maxdate = Date
      val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
      val dateforcurrentrun = LocalDate.parse(maxdate,formatter).plusDays(1)
      final_formatted_date.append(dateforcurrentrun)
      session
    })

    .exec( session => session.set("DATE", final_formatted_date ) )
    .exec( session => {
      final_formatted_date = new StringBuilder()
      session
    })

    /* *********** CreateOrder *********** */
    .exec(http("001_CPQWP_SubmitSupplementalOrder_002_CreateOrder")
      .post(uri10 +"/services/apexrest/v2/carts")
      .headers(header_1)
      .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
      .body( StringBody("""{"subaction":"createOrder",
        "inputFields":[
        {"AccountId":"${AccountId}"},
        {"PriceListId__c":"${PriceListId}"},
        {"Name":"Bmk-Order"},{"Status":"Draft"},
        {"EffectiveDate":"${DATE}"}
        ]}""")).asJson)

.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


    /* ********** AddItemsToCart *********** */
        .feed(product_feeder)
        .exec(http("001_CPQWP_SubmitSupplementalOrder_003_Additemstocart")
          .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
          .headers(header_1)
          .body( StringBody("""{
            "items":[{
              "itemId":"${Product24LI_ID}"
            }],
            "price":"true",
            "validate":"true",
            "pagesize":20
          }""")).asJson
        .check(regex("""productHierarchyPath":"(.*?)","name":"CPQ-WP-P0-Prod-""").find.exists.saveAs("c_productHierarchyPath"))
        .check(jsonPath("$.records[0].lineItems.records[0].actions.updateitems.rest.params.items[0]..itemId").find.saveAs("CloneLineItem")))


.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("001_CPQWP_SubmitSupplementalOrder_004_SubmitOrder")
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/checkout")
      .headers(header_1)
      .check(regex("""Submission of order (.*?) was successful""").find.exists)
      .body( StringBody("""{
      "cartId": "${OrderID}",
      "skipCheckoutValidation": true
      }""")).asJson)

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

*/
      .exec(http("001_CPQWP_SubmitSupplementalOrder_005_GetNewCsrfToken")
          .get(uri05 +"/apex/OmniScriptUniversalPage?trackKey=1591628967270#/OmniScriptType/CPQ/OmniScriptSubType/AmendOrder/OmniScriptLang/Multi-Language/ContextId/${OrderID}/PrefillDataRaptorBundle//true")
          .headers(headers_99)
          .check(regex("""vid":"(.+?)...xhr""").find.exists.saveAs("vid_sso"))
          .check(regex("""\{"name":"GenericInvoke2","len":4,"ns":"","ver":38.0,"csrf":"(.*)"\},\{"name":"Ge""").find.exists.saveAs("csrfToken_sso")))


    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("001_CPQWP_SubmitSupplementalOrder_006_preValidate")
        .post(uri05 +"/apexremote")
        .headers(headers_007)
        .check(regex(""""OrderStatus__c\\":\\"Frozen\\",\\"IsChangesAllowed__c\\":true,\\"Id\\":\\"(.*)\\"}]}""").find.exists)
        .body(ElFileBody("./src/test/resources/bodies/CPQ/23LI/Inflight/preValidate.txt")))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("001_CPQWP_SubmitSupplementalOrder_007_createSupplementalOrder")
      .post(uri05 +"/apexremote")
      .headers(headers_007)
      .check(regex("""supplementalOrderId\\":\\"(.+?)\\"""").find.exists.saveAs("supplementalOrderId"))
      .body(ElFileBody("./src/test/resources/bodies/CPQ/23LI/Inflight/createSupplementalOrder.txt")))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("001_CPQWP_SubmitSupplementalOrder_008_GetCartLineItems")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${supplementalOrderId}/items?pagesize=10&price=false&validate=false")
      .headers(header_1)
      .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.exists.saveAs("LineItem1")))

    .exec( session => {
      println( session( "LineItem1" ).as[String] )
      session
    })

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("001_CPQWP_SubmitSupplementalOrder_009_GetLineItemDetails")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${supplementalOrderId}/items")
      .queryParamSeq(Seq(("id", "${LineItem1}")))
      .headers(header_1)
      .check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))

    .exec(session => {
      modifiedItemJson = new StringBuilder()
      modifiedItemJson.append("""{"items":{"records":[{"displaySequence":-1,""").append(session("capturedItemHierarchy").as[String]).append("}]}}")
      session
      })

     .exec(http("001_CPQWP_SubmitSupplementalOrder_010_UpdateCartLineItem")
       .put(uri10 +"/services/apexrest/v2/cpq/carts/${supplementalOrderId}/items")
       .headers(header_1)
       .body(StringBody(session =>  modifiedItemJson.replaceAllLiterally(""""Quantity":{"value":1.00""",""""Quantity":{"value":3.00""").toString() )).asJson
       .check(regex("""message":"Successfully.updated."}]""").find.exists))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("001_CPQWP_SubmitSupplementalOrder_011_SubmitOrder")
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${supplementalOrderId}/items/checkout")
      .headers(header_1)
      .check(regex("""Submission of order (.*) was successful""").find.exists)
      .body( StringBody("""{
      "cartId": "${supplementalOrderId}",
      "skipCheckoutValidation": true
      }""")).asJson)

    }

      val DiscardAmendmentRequestScn = scenario("DiscardAmendmentRequestScn")

      .exec(session => session.set("PriceListId",Configuration.PriceListId))
      .exec(session => session.set("Pricebook2Id",Configuration.Pricebook2Id))
      .exec(session => session.set("PromotionID1",Configuration.Promotion3PI))
      .exec(session => session.set("PromotionID2",Configuration.Promotion5PI))
      .exec(session => session.set("UpdatePromotionID",Configuration.UpdatePromotion))
      .exec(session => session.set("UpdatePromotionItemID",Configuration.UpdatePromotionItem))
      .exec(session => session.set("PenaltyRulePromotionID",Configuration.PenaltyRulePromotion))

      .exec(session => session.set("password",credentials))

      .feed(userFeeder)
      .exec(http("002_CPQWP_DiscardAmendment_001_Login")
          .post(uri01 + "/")
          .headers(headers_35)
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          .formParam("startURL", "")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          .formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "M1D2l15jFvl")
          .formParam("display", "page")
          .formParam("username", "${username}")
          .formParam("pw", "${password}")
          .formParam("Login", ""))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("RESTGetOAuthToken")
      .post("https://test.salesforce.com/services/oauth2/token")
      .header("Content-Type", "application/x-www-form-urlencoded")
      .formParam("password", "${password}")
      .formParam("username", "${username}")
      .formParam("client_secret", "7119599995527965426")
      .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
      .formParam("grant_type", "password")
      .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
      .check(status.is(200)))

      .repeat(1)
      {
      feed(DiscardAmendmentRequest_input)

  /*    exec(session => session.set("AccountName",""))

      .exec( session => {
        val random_index = randomNumber.nextInt(100000)
        accountName.append("Acc-"+random_index)
        session
      })

      .exec(session => session.set("AccountName",accountName))

      .exec( session => {
        accountName = new StringBuilder()
        session
      })


      /* *********** CreateAccount *********** */
      .exec(http("002_CPQWP_DiscardAmendment_002_CreateAccount")
      .post(uri10 +"/services/data/v44.0/sobjects/account")
        .headers(header_1)
        .check(regex(""""id":"(.*?)"""").find.exists.saveAs("AccountId"))
        .body( StringBody("""
        {
          "Name" : "CPQ${AccountName}",
          "ShippingCity" : "San Francisco",
          "Status__c": "Active"
        }""")).asJson)

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec( session => {
      val maxdate = Date
      val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
      val dateforcurrentrun = LocalDate.parse(maxdate,formatter).plusDays(1)
      final_formatted_date.append(dateforcurrentrun)
      session
    })

    .exec( session => session.set("DATE", final_formatted_date ) )
    .exec( session => {
      final_formatted_date = new StringBuilder()
      session
    })

    /* *********** CreateOrder *********** */
    .exec(http("002_CPQWP_DiscardAmendment_003_CreateOrder")
      .post(uri10 +"/services/apexrest/v2/carts")
      .headers(header_1)
      .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
      .body( StringBody("""{"subaction":"createOrder",
        "inputFields":[
        {"AccountId":"${AccountId}"},
        {"PriceListId__c":"${PriceListId}"},
        {"Name":"Bmk-Order"},{"Status":"Draft"},
        {"EffectiveDate":"${DATE}"}
        ]}""")).asJson)

.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


    /* ********** AddItemsToCart *********** */
        .feed(product_feeder)
        .exec(http("002_CPQWP_DiscardAmendment_004_Additemstocart")
          .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
          .headers(header_1)
          .body( StringBody("""{
            "items":[{
              "itemId":"${Product24LI_ID}"
            }],
            "price":"true",
            "validate":"true",
            "pagesize":20
          }""")).asJson
        .check(regex("""productHierarchyPath":"(.*?)","name":"CPQ-WP-P0-Prod-""").find.exists.saveAs("c_productHierarchyPath"))
        .check(jsonPath("$.records[0].lineItems.records[0].actions.updateitems.rest.params.items[0]..itemId").find.saveAs("CloneLineItem")))


.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("002_CPQWP_DiscardAmendment_005_SubmitOrder")
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/checkout")
      .headers(header_1)
      .check(regex("""Submission of order (.*?) was successful""").find.exists)
      .body( StringBody("""{
      "cartId": "${OrderID}",
      "skipCheckoutValidation": true
      }""")).asJson)

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

*/
      .exec(http("002_CPQWP_DiscardAmendment_006_GetNewCsrfToken")
          .get(uri05 +"/apex/OmniScriptUniversalPage?trackKey=1591628967270#/OmniScriptType/CPQ/OmniScriptSubType/AmendOrder/OmniScriptLang/Multi-Language/ContextId/${OrderID}/PrefillDataRaptorBundle//true")
          .headers(headers_99)
          .check(regex("""vid":"(.+?)...xhr""").find.exists.saveAs("vid_sso"))
          .check(regex("""\{"name":"GenericInvoke2","len":4,"ns":"","ver":38.0,"csrf":"(.*)"\},\{"name":"Ge""").find.exists.saveAs("csrfToken_sso")))


    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("002_CPQWP_DiscardAmendment_007_preValidate")
        .post(uri05 +"/apexremote")
        .headers(headers_007)
        .check(regex(""""OrderStatus__c\\":\\"Frozen\\",\\"IsChangesAllowed__c\\":true,\\"Id\\":\\"(.*)\\"}]}""").find.exists)
        .body(ElFileBody("./src/test/resources/bodies/CPQ/23LI/Inflight/preValidate.txt")))



    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("002_CPQWP_DiscardAmendment_008_createSupplementalOrder")
      .post(uri05 +"/apexremote")
      .headers(headers_007)
      .check(regex("""supplementalOrderId\\":\\"(.+?)\\"""").find.exists.saveAs("supplementalOrderId"))
      .body(ElFileBody("./src/test/resources/bodies/CPQ/23LI/Inflight/createSupplementalOrder.txt")))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("002_CPQWP_DiscardAmendment_009_GetCartLineItems")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${supplementalOrderId}/items?pagesize=10&price=false&validate=false")
      .headers(header_1)
      .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.exists.saveAs("LineItem1")))

    .exec( session => {
      println( session( "LineItem1" ).as[String] )
      session
    })

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("002_CPQWP_DiscardAmendment_010_GetLineItemDetails")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${supplementalOrderId}/items")
      .queryParamSeq(Seq(("id", "${LineItem1}")))
      .headers(header_1)
      .check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))

    .exec(session => {
      modifiedItemJson = new StringBuilder()
      modifiedItemJson.append("""{"items":{"records":[{"displaySequence":-1,""").append(session("capturedItemHierarchy").as[String]).append("}]}}")
      session
      })

     .exec(http("002_CPQWP_DiscardAmendment_011_UpdateCartLineItem")
       .put(uri10 +"/services/apexrest/v2/cpq/carts/${supplementalOrderId}/items")
       .headers(header_1)
       .body(StringBody(session =>  modifiedItemJson.replaceAllLiterally(""""Quantity":{"value":1.00""",""""Quantity":{"value":3.00""").toString() )).asJson
       .check(regex("""message":"Successfully.updated."}]""").find.exists))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("002_CPQWP_DiscardAmendment_012_discardOrder")
      .post(uri05 +"/apexremote")
      .headers(headers_007)
      .check(regex(""""The order was discarded successfully. The previous order has now resumed fulfilment""").find.exists)
      .body(ElFileBody("./src/test/resources/bodies/CPQ/23LI/Inflight/discardOrder.txt")))

    }


     val CancelInflightOrderScn = scenario("CancelInflightOrderScn")

     .exec(session => session.set("PriceListId",Configuration.PriceListId))
     .exec(session => session.set("Pricebook2Id",Configuration.Pricebook2Id))
     .exec(session => session.set("PromotionID1",Configuration.Promotion3PI))
     .exec(session => session.set("PromotionID2",Configuration.Promotion5PI))
     .exec(session => session.set("UpdatePromotionID",Configuration.UpdatePromotion))
     .exec(session => session.set("UpdatePromotionItemID",Configuration.UpdatePromotionItem))
     .exec(session => session.set("PenaltyRulePromotionID",Configuration.PenaltyRulePromotion))

     .exec(session => session.set("password",credentials))

     .feed(userFeeder)
     .exec(http("003_CPQWP_CancelInflightOrder_001_Login")
         .post(uri01 + "/")
         .headers(headers_35)
         .formParam("un", "${username}")
         .formParam("width", "1440")
         .formParam("height", "900")
         .formParam("hasRememberUn", "true")
         .formParam("startURL", "")
         .formParam("loginURL", "")
         .formParam("loginType", "")
         .formParam("useSecure", "true")
         .formParam("local", "")
         .formParam("lt", "standard")
         .formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
         .formParam("locale", "")
         .formParam("oauth_token", "")
         .formParam("oauth_callback", "")
         .formParam("login", "")
         .formParam("serverid", "")
         .formParam("QCQQ", "M1D2l15jFvl")
         .formParam("display", "page")
         .formParam("username", "${username}")
         .formParam("pw", "${password}")
         .formParam("Login", ""))

   .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

   .exec(http("RESTGetOAuthToken")
     .post("https://test.salesforce.com/services/oauth2/token")
     .header("Content-Type", "application/x-www-form-urlencoded")
     .formParam("password", "${password}")
     .formParam("username", "${username}")
     .formParam("client_secret", "7119599995527965426")
     .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
     .formParam("grant_type", "password")
     .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
     .check(status.is(200)))

     .repeat(1)
     {

     feed(CancelInflightOrder_input)

    /* exec(session => session.set("AccountName",""))

     .exec( session => {
       val random_index = randomNumber.nextInt(100000)
       accountName.append("Acc-"+random_index)
       session
     })

     .exec(session => session.set("AccountName",accountName))

     .exec( session => {
       accountName = new StringBuilder()
       session
     })


     /* *********** CreateAccount *********** */
     .exec(http("003_CPQWP_CancelInflightOrder_001_CreateAccount")
     .post(uri10 +"/services/data/v44.0/sobjects/account")
       .headers(header_1)
       .check(regex(""""id":"(.*?)"""").find.exists.saveAs("AccountId"))
       .body( StringBody("""
       {
         "Name" : "CPQ${AccountName}",
         "ShippingCity" : "San Francisco",
         "Status__c": "Active"
       }""")).asJson)

   .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

   .exec( session => {
     val maxdate = Date
     val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
     val dateforcurrentrun = LocalDate.parse(maxdate,formatter).plusDays(1)
     final_formatted_date.append(dateforcurrentrun)
     session
   })

   .exec( session => session.set("DATE", final_formatted_date ) )
   .exec( session => {
     final_formatted_date = new StringBuilder()
     session
   })

   /* *********** CreateOrder *********** */
   .exec(http("003_CPQWP_CancelInflightOrder_002_CreateOrder")
     .post(uri10 +"/services/apexrest/v2/carts")
     .headers(header_1)
     .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
     .body( StringBody("""{"subaction":"createOrder",
       "inputFields":[
       {"AccountId":"${AccountId}"},
       {"PriceListId__c":"${PriceListId}"},
       {"Name":"Bmk-Order"},{"Status":"Draft"},
       {"EffectiveDate":"${DATE}"}
       ]}""")).asJson)

.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


   /* ********** AddItemsToCart *********** */
       .feed(product_feeder)
       .exec(http("003_CPQWP_CancelInflightOrder_003_Additemstocart")
         .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
         .headers(header_1)
         .body( StringBody("""{
           "items":[{
             "itemId":"${Product24LI_ID}"
           }],
           "price":"true",
           "validate":"true",
           "pagesize":20
         }""")).asJson
       .check(regex("""productHierarchyPath":"(.*?)","name":"CPQ-WP-P0-Prod-""").find.exists.saveAs("c_productHierarchyPath"))
       .check(jsonPath("$.records[0].lineItems.records[0].actions.updateitems.rest.params.items[0]..itemId").find.saveAs("CloneLineItem")))


.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

   .exec(http("003_CPQWP_CancelInflightOrder_004_SubmitOrder")
     .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/checkout")
     .headers(header_1)
     .check(regex("""Submission of order (.*?) was successful""").find.exists)
     .body( StringBody("""{
     "cartId": "${OrderID}",
     "skipCheckoutValidation": true
     }""")).asJson)

   .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
*/
   .exec(http("003_CPQWP_CancelInflightOrder_005_GetNewCsrfToken")
       .get(uri05 +"/apex/HybridCPQ?id=${OrderID}")
       .headers(headers_001)
       .check(regex("""vid":"(.+?)...xhr""").find.exists.saveAs("vid_co"))
       .check(regex("""len":4."ns":""."ver":41.0."csrf":"(.+?)"["$&+,:;=?@#|'<>.^*()%!-}{a-z]*doNamedCredentialCallout""").find.exists.saveAs("csrfToken_co")))

   .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

     .exec(http("003_CPQWP_CancelInflightOrder_006_preValidate")
       .post(uri05 +"/apexremote")
       .headers(headers_007)
       .check(regex(""""OrderStatus__c\\":\\"Frozen\\",\\"IsChangesAllowed__c\\":true,\\"Id\\":\\"(.*)\\"}]}""").find.exists)
       .body(ElFileBody("./src/test/resources/bodies/CPQ/23LI/Inflight/preValidate_cancelorder.txt")))

   .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

   .exec(http("003_CPQWP_CancelInflightOrder_007_createSupplementalOrder")
     .post(uri05 +"/apexremote")
     .headers(headers_007)
     .check(regex("""cancelOrderId\\":\\"(.+?)\\",\\"cartId""").find.exists.saveAs("cancelOrderId"))
     .body(ElFileBody("./src/test/resources/bodies/CPQ/23LI/Inflight/createSupplementalOrder_cancelorder.txt")))

   .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


   .exec(http("003_CPQWP_CancelInflightOrder_008_submitCancelOrder")
      .post(uri05 +"/apexremote")
      .headers(headers_007)
      .check(regex(""""Cancellation is accepted""").find.exists)
      .body(ElFileBody("./src/test/resources/bodies/CPQ/23LI/Inflight/submitCancelOrder.txt")))

/*    .exec(http("009_OMS_CancelInflightOrder_SubmitOrder")
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${cancelOrderId}/items/checkout")
      .headers(header_1)
      .check(regex("""Submission of order (.*) was successful""").find.exists)
      .body( StringBody("""{
      "cartId": "${cancelOrderId}",
      "skipCheckoutValidation": true
      }""")).asJson)

      */

  }


     val SubmitFollowOnOrderScn = scenario("SubmitFollowOnOrderScn")


     .exec(session => session.set("PriceListId",Configuration.PriceListId))
     .exec(session => session.set("Pricebook2Id",Configuration.Pricebook2Id))
     .exec(session => session.set("PromotionID1",Configuration.Promotion3PI))
     .exec(session => session.set("PromotionID2",Configuration.Promotion5PI))
     .exec(session => session.set("UpdatePromotionID",Configuration.UpdatePromotion))
     .exec(session => session.set("UpdatePromotionItemID",Configuration.UpdatePromotionItem))
     .exec(session => session.set("PenaltyRulePromotionID",Configuration.PenaltyRulePromotion))

     .exec(session => session.set("password",credentials))

     .feed(userFeeder)
     .exec(http("004_CPQWP_SubmitFollowOnOrder_001_Login")
         .post(uri01 + "/")
         .headers(headers_35)
         .formParam("un", "${username}")
         .formParam("width", "1440")
         .formParam("height", "900")
         .formParam("hasRememberUn", "true")
         .formParam("startURL", "")
         .formParam("loginURL", "")
         .formParam("loginType", "")
         .formParam("useSecure", "true")
         .formParam("local", "")
         .formParam("lt", "standard")
         .formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
         .formParam("locale", "")
         .formParam("oauth_token", "")
         .formParam("oauth_callback", "")
         .formParam("login", "")
         .formParam("serverid", "")
         .formParam("QCQQ", "M1D2l15jFvl")
         .formParam("display", "page")
         .formParam("username", "${username}")
         .formParam("pw", "${password}")
         .formParam("Login", ""))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("RESTGetOAuthToken")
     .post("https://test.salesforce.com/services/oauth2/token")
     .header("Content-Type", "application/x-www-form-urlencoded")
     .formParam("password", "${password}")
     .formParam("username", "${username}")
     .formParam("client_secret", "7119599995527965426")
     .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
     .formParam("grant_type", "password")
     .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
     .check(status.is(200)))

     .repeat(1)
     {

     feed(SubmitFollowOnOrder_input)
/*     exec(session => session.set("AccountName",""))

     .exec( session => {
       val random_index = randomNumber.nextInt(100000)
       accountName.append("Acc-"+random_index)
       session
     })

     .exec(session => session.set("AccountName",accountName))

     .exec( session => {
       accountName = new StringBuilder()
       session
     })


     /* *********** CreateAccount *********** */
     .exec(http("004_CPQWP_SubmitFollowOnOrder_002_CreateAccount")
     .post(uri10 +"/services/data/v44.0/sobjects/account")
       .headers(header_1)
       .check(regex(""""id":"(.*?)"""").find.exists.saveAs("AccountId"))
       .body( StringBody("""
       {
         "Name" : "CPQ${AccountName}",
         "ShippingCity" : "San Francisco",
         "Status__c": "Active"
       }""")).asJson)

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec( session => {
     val maxdate = Date
     val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
     val dateforcurrentrun = LocalDate.parse(maxdate,formatter).plusDays(1)
     final_formatted_date.append(dateforcurrentrun)
     session
    })

    .exec( session => session.set("DATE", final_formatted_date ) )
    .exec( session => {
     final_formatted_date = new StringBuilder()
     session
    })

    /* *********** CreateOrder *********** */
    .exec(http("004_CPQWP_SubmitFollowOnOrder_003_CreateOrder")
     .post(uri10 +"/services/apexrest/v2/carts")
     .headers(header_1)
     .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
     .body( StringBody("""{"subaction":"createOrder",
       "inputFields":[
       {"AccountId":"${AccountId}"},
       {"PriceListId__c":"${PriceListId}"},
       {"Name":"Bmk-Order"},{"Status":"Draft"},
       {"EffectiveDate":"${DATE}"}
       ]}""")).asJson)

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


    /* ********** AddItemsToCart *********** */
       .feed(product_feeder)
       .exec(http("004_CPQWP_SubmitFollowOnOrder_004_Additemstocart")
         .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
         .headers(header_1)
         .body( StringBody("""{
           "items":[{
             "itemId":"${Product24LI_ID}"
           }],
           "price":"true",
           "validate":"true",
           "pagesize":20
         }""")).asJson
       .check(regex("""productHierarchyPath":"(.*?)","name":"CPQ-WP-P0-Prod-""").find.exists.saveAs("c_productHierarchyPath"))
       .check(jsonPath("$.records[0].lineItems.records[0].actions.updateitems.rest.params.items[0]..itemId").find.saveAs("CloneLineItem")))


    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("004_CPQWP_SubmitFollowOnOrder_005_SubmitOrder")
     .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/checkout")
     .headers(header_1)
     .check(regex("""Submission of order (.*?) was successful""").find.exists)
     .body( StringBody("""{
     "cartId": "${OrderID}",
     "skipCheckoutValidation": true
     }""")).asJson)

*/
    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("004_CPQWP_SubmitFollowOnOrder_006_GetNewCsrfToken")
          .get(uri05 +"/apex/OmniScriptUniversalPage?trackKey=1591628967270#/OmniScriptType/CPQ/OmniScriptSubType/AmendOrder/OmniScriptLang/Multi-Language/ContextId/${OrderID}/PrefillDataRaptorBundle//true")
          .headers(headers_001)
          .check(regex("""vid":"(.+?)...xhr""").find.exists.saveAs("vid_foo"))
          .check(regex("""\{"name":"GenericInvoke2","len":4,"ns":"","ver":38.0,"csrf":"(.*)"\},\{"name":"Ge""").find.exists.saveAs("csrfToken_foo"))
          .check(regex("""BuildJSONWithPrefillV2","len":6,"ns":"","ver":38.0,"csrf":"(.*)"\},\{"name":"CompleteScript""").find.exists.saveAs("csrfToken_foo2")))

/*
    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        .exec(http("007_OMS_SubmitFollowOnOrder_AmendOrder")
          .post(uri05 +"/apexremote")
          .headers(headers_007)
          .check(regex(""""The order fulfilment could not be paused. Do you want to create a Follow-On order""").find.exists)
          body(ElFileBody("./src/test/resources/bodies/CPQ/23LI/Inflight/AmendOrder_FollowOnOrder.txt")))
*/
    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
      .exec(http("004_CPQWP_SubmitFollowOnOrder_007_preValidate")
        .post(uri05 +"/apexremote")
        .headers(headers_007)
        .check(regex(""""Request was rejected. The original order (.*) has progressed too far to be cancelled or amended. You can create a follow-on order to capture your changes""").find.exists)
        .body(ElFileBody("./src/test/resources/bodies/CPQ/23LI/Inflight/preValidate_FollowOnOrder.txt")))


    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
      .exec(http("004_CPQWP_SubmitFollowOnOrder_008_createFollowOnOrder")
        .post(uri05 +"/apexremote")
        .headers(headers_007)
        .check(regex("""followOnOrderId\\":\\"(.+?)\\"}""").find.exists.saveAs("followOnOrderId"))
        .body(ElFileBody("./src/test/resources/bodies/CPQ/23LI/Inflight/createFollowOnOrder.txt")))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("004_CPQWP_SubmitFollowOnOrder_009_canSubmitOrder")
        .post(uri05 +"/apexremote")
        .headers(headers_007)
        .check(regex("""Order queued successfully""").find.exists)
        .body(ElFileBody("./src/test/resources/bodies/CPQ/23LI/Inflight/canSubmitOrder.txt")))
}


}
