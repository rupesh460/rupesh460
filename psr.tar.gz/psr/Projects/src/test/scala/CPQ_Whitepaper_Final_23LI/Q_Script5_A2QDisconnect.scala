package CPQWhitepaper_Final

import scala.concurrent.duration._
import io.gatling.core.Predef._
import io.gatling.core.structure.ChainBuilder
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._
import io.gatling.jsonpath._
import Headers._
import scala.collection._
import java.time.format.DateTimeFormatter
import java.time.LocalDateTime
import java.time.LocalDate

import io.gatling.core.feeder._
import java.util.Base64
import java.nio.charset.StandardCharsets
import scala.util.matching.Regex


object Q_Script5_A2QDisconnect {

  val uri01 = Configuration.Uri01
  val uri05 = Configuration.Uri05
  val uri10 = Configuration.Uri10
  var modifiedItemJson = new StringBuilder()
  val origItemAttrHeirarchy = new StringBuilder()
  val modItemAttrHeirarchy = new StringBuilder()
  val randomNumber = new scala.util.Random
  var randomLineItem = new StringBuilder()
  var pbeEntriesList = Vector[String]()
  var promotionList = Vector[String]()
  var lineItemsList = Vector[String]()
  var randomPBEntry = new StringBuilder()
  var accountName = new StringBuilder()
  var randomPromoId = new StringBuilder()
  var final_formatted_date = new StringBuilder()
  val userFeeder = csv("./src/test/resources/data/CPQ/CPQ_Users.csv").random
  val product_feeder = csv("./src/test/resources/data/CPQ/ProductIds.csv").circular
  //val product_feeder = csv("./src/test/resources/data/CPQ/DebugProductIds.csv").circular
  val account_feeder = csv("./src/test/resources/data/CPQ/Quote/Disconnect_AccountIds.csv").queue
  val promotion_feeder = csv("./src/test/resources/data/CPQ/PromoIds.csv").random
  //val products_ids_loy = csv("./src/test/resources/data/devorg/EPC_BMK_Loyalty_ProductIds.csv").random
  //var date = DateTimeFormatter.ofPattern(“YYYY-MM-dd”).format(java.time.LocalDate.now)
  var Date =  Configuration.date

  val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
  val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
  val password_v = (passwordByEnv.get("perf3").toString)
  val password_encoded = password_v.substring(12,(password_v.length - 2 ))
  val credentials = new String(Base64.getDecoder.decode(password_encoded))


  val Q_Script5_A2QDisconnect = scenario("Q_Script5_A2QDisconnect")

  .exec(session => session.set("PriceListId",Configuration.PriceListId))
  .exec(session => session.set("Pricebook2Id",Configuration.Pricebook2Id))
  .exec(session => session.set("PromotionID1",Configuration.Promotion3PI))
  .exec(session => session.set("PromotionID2",Configuration.Promotion5PI))
  .exec(session => session.set("UpdatePromotionID",Configuration.UpdatePromotion))
  .exec(session => session.set("UpdatePromotionItemID",Configuration.UpdatePromotionItem))
  .exec(session => session.set("PenaltyRulePromotionID",Configuration.PenaltyRulePromotion))

  .exec(session => session.set("password",credentials))

  .feed(userFeeder)
  .exec(http("LDV1_Login")
    .post(uri01 + "/")
    .headers(headers_35)
    .formParam("un", "${username}")
    .formParam("width", "1440")
    .formParam("height", "900")
    .formParam("hasRememberUn", "true")
    .formParam("startURL", "")
    .formParam("loginURL", "")
    .formParam("loginType", "")
    .formParam("useSecure", "true")
    .formParam("local", "")
    .formParam("lt", "standard")
    //.formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
    .formParam("locale", "")
    .formParam("oauth_token", "")
    .formParam("oauth_callback", "")
    .formParam("login", "")
    .formParam("serverid", "")
    .formParam("QCQQ", "M1D2l15jFvl")
    .formParam("display", "page")
    .formParam("username", "${username}")
    .formParam("pw", "${password}")
    .formParam("Login", ""))


//  .feed(userFeeder)
  .exec(http("RESTGetOAuthToken")
    .post("https://test.salesforce.com/services/oauth2/token")
    .header("Content-Type", "application/x-www-form-urlencoded")
    .formParam("password", "${password}")
    .formParam("username", "${username}")
    .formParam("client_secret", "7119599995527965426")
    .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
    .formParam("grant_type", "password")
    .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
    .check(status.is(200)))

    .repeat(25)
    {

  /* ********** RetrieveAccount ********** */
  feed(account_feeder)
  .exec(http("Q_05_A2QDisconnect_CPQWP_001_MACD_RetrieveAccount")
  .get(uri10 +"/services/apexrest/v2/accounts/${AccountId}")
  .headers(header_1)
   .check(regex("""totalSize":1,""").find.exists))

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


  /* ********** RetrieveAssetsForAccount ********** */
  .exec(http("Q_05_A2QDisconnect_CPQWP_002_MACD_RetrieveAssetsForAccount")
  .get(uri10 +"/services/apexrest/v2/accounts/${AccountId}/assets")
  .headers(header_1)
  .check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfAssetIds")))

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


  /* ************ GetAssetID *********** */
  .exec(http("Q_05_A2QDisconnect_CPQWP_003_MACD_GetAssetId")
    .get(uri10 +"/services/data/v39.0/query/?q=SELECT Id,Name FROM Asset WHERE AccountId = '${AccountId}' AND Name >= 'CPQ-WP-P0-Prod-' LIMIT 1")
    .check(regex("<Id>(.*?)</Id>").find.saveAs("AssetId"))
    .headers(header_1))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

//.get(uri05 +"/apex/MACDFdo?id=${AssetId_add}")
//{"name":"GenericInvoke2","len":4,"ns":"","ver":38.0,"csrf":"VmpFPSxNakF5TUMwd05DMHlOMVF3TmpvMU16b3dNaTQxTlRKYSw0cXhCc2JqTnB4R3lKdXFCMDdqWk83LE1XRmhPVGxt"},{"name":"Ge

    /* ********** get CSRF Token *********** */
    .exec(http("Q_05_A2QDisconnect_CPQWP_004_MACD_getCsrf1")
    .get(uri05 + "/apex/MACDFdo?id=${AssetId}")
    .headers(headers_99)
    .check(regex("""\{"name":"GenericInvoke2","len":4,"ns":"","ver":38.0,"csrf":"(.*)"\},\{"name":"Ge""").find.exists.saveAs("CSRFToken1"))
    .check(regex("""vid":"(.+?)","xhr""").find.exists.saveAs("vid")))

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)



    /* ********** GetRequestDateDetailsForOrderItem *********** */
  .exec(http("Q_05_A2QDisconnect_CPQWP_005_MACD_GetRequestDateDetailsForOrderItem")
    .get(uri10 +"/services/data/v39.0/query/?q=SELECT+RequestDate__c+FROM+OrderItem+WHERE+RequestDate__c+!=+null+LIMIT+10")
    .check(regex("""<RequestDate__c>(.*?)</RequestDate__c>""").findAll.exists.saveAs("RequestDatesList"))
    .headers(header_1))

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  .exec( session => {
    val maxdate = Date
    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
    val dateforcurrentrun = LocalDate.parse(maxdate,formatter).plusDays(1)
    final_formatted_date.append(dateforcurrentrun)
    session
  })

  .exec( session => session.set("DATE", final_formatted_date ) )
  .exec( session => {
    final_formatted_date = new StringBuilder()
    session
  })

/* ********** AssettoQuote *********** */
  .exec(http("Q_05_A2QDisconnect_CPQWP_006_MACD_AssettoQuote")
    .post(uri05 +"/apexremote")
    .headers(headers_01)
    .check(regex(""""\{\\"quoteId\\":\\"(.*?)\\",\\"error\\"""").find.exists.saveAs("Asset_OrderId"))
    .body( StringBody("""
      {"action":"BusinessProcessDisplayController",
      "method":"GenericInvoke2",
      "data":["OmniChangeToQuoteWrapper","changeToQuote","{\"ContextId\":\"${AccountId}:Asset:${AssetId}\",\"timeStamp\":\"${DATE}T11:45:14.299Z\",\"userId\":\"${userid}\",\"userName\":\"${username}\",\"userProfile\":\"System Administrator\",\"userTimeZone\":-420,\"userCurrencyCode\":\"USD\",\"id\":\"${AssetId}\",\"vlcPersistentComponent\":{},\"vlcTimeTracking\":{}}","{\"preTransformBundle\":\"\",\"postTransformBundle\":\"\",\"vlcClass\":\"OmniChangeToQuoteWrapper\"}"],"type":"rpc","tid":3,"ctx":{"csrf":"${CSRFToken1}","vid":"${vid}","ns":"","ver":38}}""")).asJson)


      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


      /* ********** get CSRF Token *********** */
      .exec(http("Q_05_A2QDisconnect_CPQWP_007_MACD__getCsrf")
      .get(uri05 + "/apex/hybridcpq?id=${Asset_OrderId}")
      .headers(headers_99)
      .check(regex("""\{"name":"doGenericInvoke","len":4,"ns":"","ver":41.0,"csrf":"(.*)"\},\{"name":"doNamedCredentialCallout""").find.exists.saveAs("CSRFToken"))
      .check(regex("""vid":"(.+?)","xhr""").find.exists.saveAs("vid")))



  //.exec(session => session.set("CurrentDATE"+1, Date))  // Populate the “myToday” session variable with today’s date

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


  //.get(uri10 +"/services/data/v39.0/query/?q=SELECT Id,Name FROM Asset WHERE AccountId = '${AccountId}' LIMIT 1")
  //SELECT Id,Name FROM Asset WHERE AccountId = '001J000002OmRm9IAF' and Name like '%CPQ-WP-P0-Prod%' LIMIT 1


        /* ********** GetListOfProductsForCart *********** */
      .exec(http("Q_05_A2QDisconnect_CPQWP_009_MACD_Getlistofproductsforcart")
        .get(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}/products?pagesize=10")
        .check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfPBEntries"))
        .headers(header_1))

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        /* ********** RetrieveFilterableProducts *********** */
      .exec(http("Q_05_A2QDisconnect_CPQWP_010_MACD_RetrieveFilterableProducts")
        .get(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}/attributes")
      .check(regex(""""totalSize":1,""").find.exists)
        .headers(header_1))

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        /* ********** RetrievePromotions *********** */
        .exec(http("Q_05_A2QDisconnect_CPQWP_011_MACD_RetrievePromotions")
        .get(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}/promotions?pagesize=10")
        .check(jsonPath("$.records[0].id").find.saveAs("PromotionID"))
        .check(jsonPath("$.records[*].id").findAll.saveAs("PromotionList"))
        .headers(header_1))

     .exec( session => {
        promotionList = session("PromotionList").as[Vector[String]]
        session
      })

     .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

     /* ********** ViewProductDetails *********** */
     .feed(product_feeder)
     .exec(http("Q_05_A2QDisconnect_CPQWP_012_MACD_ViewProductDetails")
       .get(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}/products/01uJ000000FwPvlIAF?maxProdListHierarchy=5&includeAttachment=true&filters=AppliesTo__c%3AAccount_Contract&fields=Id%2CName&includeAttributes=true")
       .headers(header_1)
       .check(regex(""""totalSize":1,""").find.exists))

       .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

       /* ********** Apply Discount *********** */
          .exec(http("Q_05_A2QDisconect_CPQWP_015_MACD_ApplyDiscount")
           .post(uri05 + "/apexremote")
           .headers(headers_0)
           .check(regex(""""statusCode":200,"""").find.exists)
           .body( StringBody("""
             {"action":"CardCanvasController",
             "method":"doGenericInvoke",
             "data":["CpqAppHandler","postCartsDiscounts","{\"discountTemplateIds\":[\"a2BJ0000000VUGUMA4\"],\"cartId\":\"${Asset_OrderId}\",\"methodName\":\"postCartsDiscounts\"}","{\"vlcClass\":\"CpqAppHandler\"}"],"type":"rpc","tid":20,"ctx":{"csrf":"${CSRFToken}","vid":"${vid}","ns":"","ver":41}}""")).asJson)

             .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


        /* ********** Retrieve Discount *********** */
           .exec(http("Q_05_A2QDisconnect_CPQWP_016_MACD_RetrieveDiscount")
            .post(uri05 + "/apexremote")
            .headers(headers_0)
            .check(regex(""""statusCode":200,"""").find.exists)
             .check(regex(""""QuoteDiscountId__c\\":\{\\\"value\\":\\"(.*?)\\",\\"previousValue\\":n""").find.exists.saveAs("DeleteDiscountID"))
            .body( StringBody("""
              {"action":"CardCanvasController",
              "method":"doGenericInvoke",
              "data":["CpqAppHandler","getAllApplicableDiscounts","{\"cartId\":\"${Asset_OrderId}\",\"pagesize\":\"10\"}","{\"vlcClass\":\"CpqAppHandler\"}"],"type":"rpc","tid":35,"ctx":{"csrf":"${CSRFToken}","vid":"${vid}","ns":"","ver":41}}""")).asJson)

//QuoteDiscountId__c\":{\"value\":\"a4xJ00000018IcCIAU\",\"previo
       //{"action":"CardCanvasController","method":"doGenericInvoke","data":["CpqAppHandler","deleteCartDiscount","{\"methodName\":\"deleteCartDiscount\",\"id\":\"a4qJ00000006iyYIAQ\",\"cartId\":\"801J0000002DD0VIAW\"}","{\"vlcClass\":\"CpqAppHandler\"}"],"type":"rpc","tid":29,"ctx":{"csrf":"VmpFPSxNakF5TUMwd05TMHdNbFF3TmpvME9Eb3lNaTQzTlROYSxWR0U2YnlObkVab3Q0YWllVTE0b3B3LE1HRmpORE5q","vid":"066J00000011CJa","ns":"","ver":41}}

       .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

       /* ********** GetCartLineItems *********** */
       .exec(http("Q_05_A2QDisconnect_CPQWP_019_MACD_GetCartLineItems")
         .get(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}/items?pagesize=10&price=false&validate=false")
         .headers(header_1)
         .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1")))

         .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

         /* ********** GetCartItemsByItemId *********** */
         .exec(http("Q_05_A2QDisconnect_CPQWP_020_MACD_Getlineitemdetails")
           .get(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}/items")
           .queryParamSeq(Seq(("id", "${LineItem1}")))
           .headers(header_1)
           .check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))

         .exec(session => {
           //originalItemJson.append(session("capturedItemHierarchy").as[String])
           modifiedItemJson = new StringBuilder()
           modifiedItemJson.append("""{"items":{"records":[{"displaySequence":-1,""").append(session("capturedItemHierarchy").as[String]).append("}]}}")
           session
         })

         .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)



                 /* ********** DeleteItemFromCart********** */
                 .exec(http("Q_05_A2QDisconnect_CPQWP_029_MACD_Deleteanitemfromthecart")
                   .delete(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}/items/${LineItem1}")
                   .headers(header_1)
                   .check(regex("""INFO","message":"Successfully deleted.""").find.exists))

               .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

               /* ********** RetrieveCartSummary *********** */
               .exec(http("Q_05_A2QDisconnect_CPQWP_030_MACD_RetrieveCartSummary")
                 .get(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}?price=false&validate=false")
                 .headers(header_1)
                 .check(status.is(200)))

             .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

             /* ********** RetrieveCartItems *********** */
             .exec(http("Q_05_A2QDisconnect_CPQWP_031_MACD_RetrieveCartItems")
             .get(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}/items?pagesize=10&price=false&validate=false")
             .headers(header_1)
             .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1")))

             .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

               /* ********** CreateOrderFromQuote ********** */
                     .exec(http("Q_05_A2QDisconnect_CPQWP_032_MACD_CreateOrderFromQuote")
                     .post(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}/items/checkout")
                     .headers(header_1)
                     //.check(regex("""Account""").find.exists)
                     .body( StringBody("""{
                     "items":[
                     {"itemId":"${LineItem1}"}
                     ],
                     "hierarchy":1,
                     "lastItemId":"",
                     "pagesize":20
                     }""")).asJson
                     .check(regex("""totalSize":1,"records":\[\{"displaySequence":-1,"id":"(.*)","objectType":"Order","clonedObjectIds":"null""").find.exists.saveAs("SubmitOrderID2")))

               .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

               /* ********** SubmitOrder ********** */
               .exec(http("Q_05_A2QDisconnect_CPQWP_033_MACD_SubmitOrder")
               .post(uri10 +"/services/apexrest/v2/cpq/carts/${SubmitOrderID2}/items/checkout")
               .headers(header_1)
               .check(regex("""SUBMIT-100""").find.exists)
               .body( StringBody("""{
               "cartId": "${SubmitOrderID2}",
               "skipCheckoutValidation": true
               }""")).asJson)
               .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

          }
}
