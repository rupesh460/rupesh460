package HCPQ

import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.core.structure.ChainBuilder
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._
import io.gatling.jsonpath._
import Headers._
import scala.collection._
import java.time.format.DateTimeFormatter
import java.time.LocalDateTime


 object HCPQ_Master {

    val uri01 = Configuration.Uri01
    val uri05 = Configuration.Uri05
    val uri10 = Configuration.Uri10
    val testDuration = Integer.getInteger("testDuration", 1)
    val LineItemJSONMAP = collection.mutable.Map[String,Any]()
    val originalItemJson = new StringBuilder()
    val modifiedItemJson = new StringBuilder()
    val origItemAttrHeirarchy = new StringBuilder()
    val modItemAttrHeirarchy = new StringBuilder()
    val randomNumber = new scala.util.Random
    val randomPBEntry = new StringBuilder()
    val randomPBEntry2 = new StringBuilder()
    val randomLineItem = new StringBuilder()
    val randomOrderId = new StringBuilder()
    val recordTypeFeeder = csv("./src/test/resources/data/hcpq/HCPQ_recordtype.csv").random
    val final_formatted_date = new StringBuilder()
    
	  val scn = scenario("HCPQ_Master")
        
    /* ************ Login to https://test.salesforce.com ********** */
    .exec(http("Web_Login")
      .post(uri01 + "/")
      .headers(headers_26)
      .formParam("un", "kasi@perftest3.sbx")
      .formParam("width", "1920")
      .formParam("height", "1080")
      .formParam("hasRememberUn", "true")
      .formParam("startURL", "")
      .formParam("loginURL", "")
      .formParam("loginType", "")
      .formParam("useSecure", "true")
      .formParam("local", "")
      .formParam("lt", "standard")
      .formParam("qs", "")
      .formParam("locale", "")
      .formParam("oauth_token", "")
      .formParam("oauth_callback", "")
      .formParam("login", "")
      .formParam("serverid", "")
      .formParam("display", "page")
      .formParam("username", "kasi@perftest3.sbx")
      .formParam("pw", "Odsdskjds425")
      .formParam("Login", "Log In to Sandbox")
      .formParam("rememberUn", "on"))
              
    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


  /* ********** Create a new Account (Billing/Group/Consumer) *********** */
  /* Account Recordtype is taken from the feeder file recordtype.csv  */    

  .exec(http("GetCONFToken")
      .get("/setup/ui/recordtypeselect.jsp?ent=Account&retURL=%2F001%2Fo&save_new_url=%2F001%2Fe%3FretURL%3D%252F001%252Fo")
      .check(regex("""id="_CONFIRMATIONTOKEN" value="(.*?)"""").find.exists.saveAs("CONF_Token"))
      .headers(headers_0))

  .feed(recordTypeFeeder)
  .exec(http("CreateAccount")
      .post(uri10 + "/001/e")
      .headers(headers_130)
      .formParam("RecordType", "${RecordType}")
      .formParam("_CONFIRMATIONTOKEN", "${CONF_Token}")
      .formParam("cancelURL", "/001/o")
      .formParam("retURL", "/001/o")
      .formParam("save_new_url", "/001/e?ent=Account&retURL=%2F001%2Fo&RecordType=${RecordType}")
      .formParam("acc2", "PSR-${RecordTypeName}-Account")
      .formParam("00Ng000000274kB", "")
      .formParam("acc3_lkid", "000000000000000")
      .formParam("acc3_lkold", "null")
      .formParam("acc3_lktp", "001")
      .formParam("acc3_lspf", "0")
      .formParam("acc3_lspfsub", "0")
      .formParam("acc3_mod", "0")
      .formParam("acc3", "")
      .formParam("00Ng000000275Zx", "")
      .formParam("acc17street", "")
      .formParam("acc10", "")
      .formParam("acc17city", "")
      .formParam("CF00Ng000000275Zs_lkid", "000000000000000")
      .formParam("CF00Ng000000275Zs_lkold", "null")
      .formParam("CF00Ng000000275Zs_lktp", "a2N")
      .formParam("CF00Ng000000275Zs_lspf", "0")
      .formParam("CF00Ng000000275Zs_lspfsub", "0")
      .formParam("CF00Ng000000275Zs_mod", "0")
      .formParam("CF00Ng000000275Zs", "")
      .formParam("acc17state", "")
      .formParam("acc17zip", "")
      .formParam("acc17country", "")
      .formParam("00Ng000000275Zu", "")
      .formParam("00Ng000000275Zk", "")
      .formParam("00Ng000000275Zj", "")
      .formParam("00Ng000000275Zf", "")
      .formParam("00Ng000000275Zl", "")
      .formParam("CF00Ng000000275Zi_lkid", "000000000000000")
      .formParam("CF00Ng000000275Zi_lkold", "null")
      .formParam("CF00Ng000000275Zi_lktp", "a3D")
      .formParam("CF00Ng000000275Zi_lspf", "0")
      .formParam("CF00Ng000000275Zi_lspfsub", "0")
      .formParam("CF00Ng000000275Zi_mod", "0")
      .formParam("CF00Ng000000275Zi", "")
      .formParam("00Ng000000275Zg", "")
      .formParam("00Ng000000275Zm", "")
      .formParam("00Ng000000275Zn", "")
      .formParam("save", "Saving...")
      .check(status.is(200))
      .check(regex("""handleRedirect\('\/(.+?)\'""").find.exists.saveAs("AccountId")))
    .pause(5)


  .exec(http("request_1")
      .get(uri10 + "/${AccountId}")
      .headers(headers_0))


  
    /* ********** Web Click Orders  *********** */
    .exec(http("Web_Click_Orders")
      .get(uri10 + "/801/o")
      .headers(headers_5)
      .check(regex("""linkToken=(.+?)&amp;""").find.exists.saveAs("linkToken1")))
      
      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
    
    /* *********** Web Click New Order ************ */
    .exec(http("Web_Click_New_Order")
      .get(uri10 + "/801/e?retURL=%2F801%2Fo")
      .headers(headers_5)
      .check(regex("""id=\"_CONFIRMATIONTOKEN\" value=\"(.+)\" \/\>\<input type=\"hidden\" name=\"cancelURL\"""").find.exists.saveAs("""CONFIRMATIONTOKEN1""")))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    /* *********** Web Click Create a new Order ************ */
    .exec(http("Web_Create_Order")
      .post(uri10 + "/801/e")
      .headers(headers_130)
      .formParam("_CONFIRMATIONTOKEN", "${CONFIRMATIONTOKEN1}")
      .formParam("cancelURL", "/801/o")
      .formParam("retURL", "/801/o")
      .formParam("save_new_url", "/801/e?retURL=%2F801%2Fo")
      .formParam("save", "Saving...")
      .formParam("accid_lkid", "${AccountId}")
      .formParam("accid_lkold", "${AccountName}")
      .formParam("accid_lktp", "001")
      .formParam("accid_lspf", "0")
      .formParam("accid_lspfsub", "0")
      .formParam("accid_mod", "1")
      .formParam("accid", "${AccountName}")
      .formParam("00Ng000000275cx", "")
      .formParam("EffectiveDate", "4/28/2017")
      .formParam("00Ng000000275dG", "")
      .formParam("Status", "Draft")
      .formParam("ShippingAddressstreet", "")
      .formParam("Type", "")
      .formParam("ShippingAddresscity", "")
      .formParam("BillingAddressstreet", "")
      .formParam("ShippingAddressstate", "")
      .formParam("BillingAddresscity", "")
      .formParam("ShippingAddresszip", "")
      .formParam("BillingAddressstate", "")
      .formParam("ShippingAddresscountry", "")
      .formParam("BillingAddresszip", "")
      .formParam("00Ng000000275d1", "Call Center")
      .formParam("BillingAddresscountry", "")
      .formParam("Description", "")
      .formParam("00Ng000000275dK", "")
      .formParam("00Ng000000275dI", "")
      .formParam("00Ng000000275dJ", "")
      .formParam("CF00Ng000000275Yz_lkid", "000000000000000")
      .formParam("CF00Ng000000275Yz_lkold", "null")
      .formParam("CF00Ng000000275Yz_lktp", "800")
      .formParam("CF00Ng000000275Yz_lspf", "0")
      .formParam("CF00Ng000000275Yz_lspfsub", "0")
      .formParam("CF00Ng000000275Yz_mod", "0")
      .formParam("CF00Ng000000275Yz", "")
      .check(status.is(200))
      .check(regex("""handleRedirect\(\'\/(.+)\'\)""").find.exists.saveAs("""OrderID""")))

    .exec(http("Order_Detail")
      .get(uri10 + "/${OrderID}")
      .headers(headers_5)
      .check(regex("""\<input\stype=\"hidden\"\sname=\"echoScontrol\"\svalue="(.+)\"\s\/\>\<input\stype""").find.exists.saveAs("""echoScontrol1"""))
      .check(regex("""\<input\stype=\"hidden\"\sname=\"echoScontrolMac\"\svalue=\"(.+)\"\s\/\>\<\/form\>""").find.exists.saveAs("""echoScontrolMac1"""))
      .check(regex("""https\:\/\/c.cs17.visual.force.com\/servlet\/servlet.Integration\?lid=(.+)\&amp;ic=1\&amp\;linkToken""").find.exists.saveAs("""lid1""")))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
  
    .exec(http("request_143")
      .post(uri05 + "/servlet/servlet.Integration?lid=${lid1}&ic=1&linkToken=${linkToken1}")
      .headers(headers_130)
      .formParam("echoScontrol", "${echoScontrol1}")
      .formParam("echoScontrolMac", "${echoScontrolMac1}"))
            
    .exec(http("request_145")
      .post(uri10 + "/visualforce/session")
      .headers(headers_145)
      .formParam("echoScontrol", "${echoScontrol1}")
      .formParam("echoScontrolMac", "${echoScontrolMac1}")
      .formParam("ic", "1")
      .formParam("lid", "${lid1}")
      .formParam("linkToken", "${linkToken1}")
      .formParam("url", "https://c.cs17.visual.force.com/servlet/servlet.Integration?lid=${lid1}&ic=1&linkToken=${linkToken1}")
      .check(regex("""id=\"sid\"\svalue=\"(.+)\"\s\/\>\<input\stype=""").find.exists.saveAs("""sid1""")))

    .exec(http("request_146")
      .post(uri05 + "/visualforce/recsession")
      .headers(headers_130)
      .formParam("cshc", "0000002Z1pY0000006Tt88")
      .formParam("echoScontrol", "${echoScontrol1}")
      .formParam("echoScontrolMac", "${echoScontrolMac1}")
      .formParam("ic", "1")
      .formParam("inst", "g")
      .formParam("lid", "${lid1}")
      .formParam("linkToken", "${linkToken1}")
      .formParam("originalRequestIsPost", "1")
      .formParam("retURL", "https://c.cs17.visual.force.com/servlet/servlet.Integration?lid=${lid1}&ic=1&linkToken=${linkToken1}")
      .formParam("sid", "{sid1}")
      .formParam("url", "https://c.cs17.visual.force.com/servlet/servlet.Integration?lid=${lid1}&ic=1&linkToken=${linkToken1}"))
            
    /* ********** Extract CSRF tokens *********** */
    .exec(http("Extract_CSRF_Tokens")
      .post(uri05 + "/servlet/servlet.Integration?lid=${lid1}&ic=1&linkToken=${linkToken1}")
      .headers(headers_145)
      .formParam("cshc", "0000002Z1pY0000006Tt88")
      .formParam("echoScontrol", "${echoScontrol1}")
      .formParam("echoScontrolMac", "${echoScontrolMac1}")
      .formParam("ic", "1")
      .formParam("inst", "g")
      .formParam("lid", "${lid1}")
      .formParam("linkToken", "${linkToken1}")
      .formParam("originalRequestIsPost", "1")
      .formParam("sid", "${sid1}")
      .formParam("url", "https://c.cs17.visual.force.com/servlet/servlet.Integration?lid=${lid1}&ic=1&linkToken=${linkToken1}")
      .check(regex("""\"getProdConfMode\",\"len\"\:0,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"getProductForAttribCheckMode\"""").find.exists.saveAs("""getProdConfMode1"""))
      .check(regex("""\"getProdAttribCheckMode\",\"len\"\:0,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"getProdConfMode\"""").find.exists.saveAs("""getProdAttribCheckMode1"""))
      .check(regex("""\"isSignitureRequired\",\"len\"\:1,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"nextProducts\"""").find.exists.saveAs("""isSignitureRequired1"""))
      .check(regex("""\"productConfSaveMode\",\"len\"\:0,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"saveProductPostConfigure\"""").find.exists.saveAs("""productConfSaveMode1"""))
      .check(regex("""\"getCpqSettings\",\"len\"\:1,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"getOrderSummaryConfig\"""").find.exists.saveAs("""getCpqSettings1"""))
      .check(regex("""\"getContextualData\",\"len\"\:1,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"getCpqSettings\"""").find.exists.saveAs("""getContextualData1"""))
      .check(regex("""\"getOrderSummaryConfig\",\"len\":2,\"ns\":\"\",\"ver\":35.0,\"csrf\":\"(.+)\"\},\{\"name\"""").find.exists.saveAs("""getOrderSummaryConfigSUMCONFCON1"""))
      .check(regex("""\"getPriceBooks\",\"len\"\:1,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"getProdAttribCheckMode\"""").find.exists.saveAs("""getPriceBooks1"""))
      .check(regex("""\"setPriceBook\",\"len\"\:2,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"updateItemQuantity\"""").find.exists.saveAs("""setPriceBook1""")))
      //.check(regex("""\"SummaryConfigController\",\"len\"\:3,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\}""").find.exists.saveAs("""SummaryConfigController"""))
      //.check(regex("""\"getOrderSummaryDetails\",\"len\"\:2,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\}""").find.exists.saveAs("""getOrderSummaryDetails"""))
           
   /* *********** Get PriceBooks ************ */ 
    .exec(http("Get_PriceBooks")
      .post("/apexremote")
      .headers(headers_160)
      .body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0160_request.txt"))
      .check(jsonPath("$..result[*].id").findAll.saveAs("ListOfPriceBooks"))
      .check(regex("""\{\"id\":\"(.+)\",\"Name\":\"Bundle Pricebook\"\}\,""").find.exists.saveAs("""BundlePriceBook"""))
      .check(regex("""\"Name\":\"mk_pricebook\"\},\{\"id\":\"(.*?)\",\"Name\":\"psr-data-generation\"\}""").find.exists.saveAs("""psrdatapricebook""")))
        
     .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    /* ********** Set PriceBook for newly created Order ********** */
    /* Using PSR-Data-PriceBook & Bundle PriceBook */
    .exec(http("SetPriceBook")
      .post("/apexremote")
      .headers(headers_160)
      .body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0178_request.txt")))


    /* ********** Get OAuth token for REST Authentication *********** */
    .exec(http("RESTGetOAuthToken")
      .post("https://test.salesforce.com/services/oauth2/token")
      .header("Content-Type", "application/x-www-form-urlencoded")
      .formParam("password", "eBAvCvrjwXZchdKsRTHaGIz4")
      .formParam("username", "kasi@pt3.sbx")
      .formParam("client_secret", "7119599995527965426")
      .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
      .formParam("grant_type", "password")
      .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
      .check(status.is(200)))

    /* ********** GetListOfProductsForCart *********** */
    .exec(http("GetListOfProductsForCart")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/products")
      .headers(header_1)) 

     /* ********** GetCartDetailsValidateFalPricingFal *********** */
    .exec(http("GetCartDetailsValidateFalPricingFal")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}")
      .queryParamSeq(Seq(("validate", "true"), ("price", "false"),("headerFieldSet","CPQV2")))
      .headers(header_1)) 

    /* ********** GetCartDetailsValidateTruPricingFal *********** */
    .exec(http("GetCartDetailsValidateTruPricingFal")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}")
      .queryParamSeq(Seq(("validate", "true"), ("price", "false"),("headerFieldSet","CPQV2")))
      .headers(header_1)) 
    
    /* ********** GetCartDetailsValidateFalPricingTru *********** */
    .exec(http("GetCartDetailsValidateFalPricingTru")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}")
      .queryParamSeq(Seq(("validate", "true"), ("price", "false"),("headerFieldSet","CPQV2")))
      .headers(header_1)) 

    /* ********** GetCartDetailsValidateTruPricingTru *********** */
    .exec(http("GetCartDetailsValidateTruPricingTru")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}")
      .queryParamSeq(Seq(("validate", "true"), ("price", "false"),("headerFieldSet","CPQV2")))
      .headers(header_1))

    /* ********** GetListofAttributesForCart  *********** */
    .exec(http("GetListofAttributesForCart")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/attributes")
      .headers(header_1)) 

    /* ********** GetListofProductsForCartH1 *********** */
    .exec(http("GetListofProductsForCartH1")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/products")
      .queryParamSeq(Seq(("query", "Business Anywhere"),("hierarchy", "1")))
      .headers(header_1)) 
    
    /* ********** GetListofProductsForCartH2 *********** */   
    .exec(http("GetListofProductsForCartH2")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/products")
      .queryParamSeq(Seq(("query", "Business Anywhere"),("hierarchy", "2")))
      .headers(header_1)) 

    /* ********** GetListofProductsForCartH3 *********** */
    .exec(http("GetListofProductsForCartH3")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/products")
      .queryParamSeq(Seq(("query", "port-in"),("hierarchy", "3")))
      .headers(header_1)) 

    /* ********** GetListofProductsForCartH2PgSiz30 *********** */
    .exec(http("GetListofProductsForCartH2PgSiz30")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/products")
      .queryParamSeq(Seq(("query", "Business Anywhere"),("hierarchy", "2"),("filters", "Anywhere"),("pagesize", "30")))
      .headers(header_1))

    /* *********** GetPriceListsForCart ********** */
    .exec(http("GetPriceListsForCart")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/pricelists")
      .check(jsonPath("$.records[0].Id").find.saveAs("PriceListId1"))
      .check(jsonPath("$.records[*].Id").findAll.saveAs("ListOfPriceLists"))
      .headers(header_1))

    /* ********** UpdatePriceListForCart *********** */
    .exec(http("UpdatePriceListForCart")
      .put(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/")
      .headers(header_1)
      .body(StringBody("""{
                    "inputFields": 
                    [
                      {
                          "PriceListId__c": "${PriceListId1}"
                        }
                      ],
                    "cartId": "${OrderID}",
                    "methodName": "updateCarts"
                }""")).asJson)     

    /* ********** GetListofProductsForCartH3PgSiz30 *********** */
    .exec(http("GetListofProductsForCartH3PgSiz30")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/products")
      .queryParamSeq(Seq(("query", "Business"),("hierarchy", "2"),("pagesize", "30")))
      .headers(header_1)
      .check(jsonPath("$.records[0].Id.value").find.saveAs("PBEntryId"))
      //.check(jsonPath("$.records[1].Id.value").find.saveAs("PBEntryId1"))
      //.check(jsonPath("$.records[2].Id.value").find.saveAs("PBEntryId2"))
      .check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfPBEntries")))

    .exec( session => {
          //println( "List Of Price Book Entires are:" )
          //println( session( "ListOfPBEntries" ).as[String] )
          val ListPBE = session("ListOfPBEntries").as[Vector[String]]
          val max = ListPBE.length - 1
          val random_index = randomNumber.nextInt(max+1)
          val random_index2 = randomNumber.nextInt(max+1)
          randomPBEntry.append(ListPBE(random_index))
          randomPBEntry2.append(ListPBE(random_index)).append(","+ListPBE(random_index2))
          session
        })
        
    /* ********** GetListofProdsAttribByPBEnrtyID *********** */
    .exec(http("GetListofProdsAttribByPBEnrtyID")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/products")
      .queryParamSeq(Seq(("Id", randomPBEntry),("includeAttachment", "true")))
      .headers(header_1)) 

    /* ********** GetListofProdsAttribByPBEnrtyIDs *********** */   
    .exec(http("GetListofProdsAttribByPBEnrtyIDs")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/products")
      .queryParamSeq(Seq(("Id", randomPBEntry2),("includeAttachment", "true")))
      .headers(header_1)) 
      
    /* ********** AddItemsToCart *********** */
    .exec(http("AddItemsToCart")
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
      .headers(header_1)
      .body( StringBody("""{
                                  "items":[{
                                  "itemId":"${PBEntryId}"
                                  }],
                                  "hierarchy":3,
                                  "lastItemId":"",
                                  "pagesize":20
                                  }""")).asJson)

    /* ********** AddItemsToCart1 *********** */
    // .exec(http("AddItemsToCart1")
    //   .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
    //   .headers(header_1)
    //   .body( StringBody("""{
    //                               "items":[{
    //                               "itemId":"${PBEntryId1}"
    //                               }],
    //                               "hierarchy":3,
    //                               "lastItemId":"",
    //                               "pagesize":20
    //                               }""")).asJson)
    
    /* ********** AddItemsToCart2 *********** */    
    // .exec(http("AddItemsToCart2")
    //   .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
    //   .headers(header_1)
    //   .body( StringBody("""{
    //                               "items":[{
    //                               "itemId":"${PBEntryId2}"
    //                               }],
    //                               "hierarchy":3,
    //                               "lastItemId":"",
    //                               "pagesize":20
    //                               }""")).asJson)                             

   /* ********** GetCartLineItems *********** */
    .exec(http("GetCartLineItems")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
      .headers(header_1)
      .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1"))
      //.check(jsonPath("$.records[1].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem2"))
      //.check(jsonPath("$.records[2].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem3"))
      .check(jsonPath("$.records[*].actions.updateitems.rest.params.items..itemId").findAll.saveAs("ListOfLineItems")))
         
    .exec( session => {
      //println( "ListOfLineItems are:" )
      //println( session( "ListOfLineItems" ).as[String] )
      val ListLineItems = session("ListOfLineItems").as[Vector[String]]
      val max = ListLineItems.length - 1
      val random_index = randomNumber.nextInt(max+1)
      val random_index2 = randomNumber.nextInt(max+1)
      randomLineItem.append(ListLineItems(random_index))
      session 
    })
   
           
   /* ********** GetCartItemsAttreachItemValidateFalsePriceFalse *********** */
   .exec(http("GetCartItemsAttreachItemValidateFalsePriceFalse")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
      .queryParamSeq(Seq(("query", "port-in"),("hierarchy", "3"),("includeAttachment", "true"),("validate", "false"),("price", "false")))
      .headers(header_1)) 

   /* ********** GetCartItemsAttreachItemValidateTruePriceTrue *********** */
    .exec(http("GetCartItemsAttreachItemValidateTruePriceTrue")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
      .queryParamSeq(Seq(("query", "port-in"),("hierarchy", "3"),("includeAttachment", "true"),("validate", "true"),("price", "true")))
      .headers(header_1))
     
   /* ********** GetCartItemsByItemIdValidateTrue *********** */
   .exec(http("GetCartItemsByItemIdValidateTrue")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
      .queryParamSeq(Seq(("id", randomLineItem),("validate", "true")))
      .headers(header_1)
      .check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))

    .exec(session => { 
      //println("---------capturedItemHierarchy----------------------")
      //println(session("capturedItemHierarchy").as[String])
      originalItemJson.append(session("capturedItemHierarchy").as[String])
      //println("originalItemJson"+originalItemJson)
      modifiedItemJson.append("""{"items":{"records":[{"displaySequence":-1,""").append(originalItemJson).append("}]}}")
      //println("modifiedItemJson"+modifiedItemJson)
      session
      })

    /* ********** GetCartItemsByItemIdValidateFalse *********** */  
    .exec(http("GetCartItemsByItemIdValidateFalse")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
      .queryParamSeq(Seq(("id", randomLineItem),("validate", "false")))
      .headers(header_1))
      
      
   /* ********** UpdateItemsInCart *********** */
   /* Updating the Quantity from default 1.00 to 3.00 */
    .exec(http("UpdateItemsInCart")
      .put(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
      .headers(header_1)
      .body(StringBody(session =>  modifiedItemJson.replaceAllLiterally(""""Quantity":{"value":1.00""",""""Quantity":{"value":3.00""").toString() )).asJson)

    /* ********** 23. GetCartItemsByItemIdValidateTrue *********** */
    /* This request is executed to get the request body for UpdateItemAttributesForLineItemInCart.
       You should be passing the randomLineItem which has configurable attributes   */
    .exec(http("GetCartItemsByItemIdValidateTrue")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
      .queryParamSeq(Seq(("id", "${LineItem1}"),("validate", "true")))
      .headers(header_1)
      .check(regex(""""displaySequence":-1,"Id":(.+?)}}]}}]}""").find.exists.saveAs("ItemAttrHierarchy")))
                                                  

      .exec(session => { 
        //println("---------ItemAttrHierarchy----------------------")
        //println(session("ItemAttrHierarchy").as[String])
        origItemAttrHeirarchy.append(session("ItemAttrHierarchy").as[String])
        println("origItemAttrHierarchy"+origItemAttrHeirarchy)
        modItemAttrHeirarchy.append("""{"items":{"records":[{"displaySequence":-1,"Id":""").append(origItemAttrHeirarchy).append("}}]}}]}}]}}")
        //println("moditemAttrHeirarchy"+modItemAttrHeirarchy)
        session
        })
      

    /* ********** 24. UpdateItemAttributesForLineItemInCart *********** */
    /*  You must be having a LineItem which has configurable attributes otherwise this request can't be done 
        Updating the uservalues with Sample test text */ 
    .exec(http("UpdateItemAttributesForLineItemInCart")
      .put(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/")
      .headers(header_1)
      .body(StringBody(session =>  modItemAttrHeirarchy.replaceAllLiterally(""""userValues":null""",""""userValues":"Sample test text"""").toString() )).asJson)


    /* ********** CloneCartLineItem ********** */
    .exec(http("CloneCartLineItem")
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/clone")
      .headers(header_1)
      .body( StringBody("""{
                              "items": [
                                          {"itemId": "${LineItem1}"}
                              ],
                              "hierarchy": 1,
                              "lastItemId": "",
                              "pagesize": 20
                           }""")).asJson)

     /* ********** DeleteItemFromCart********** */
    .exec(http("DeleteItemFromCart1")
      .delete(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/${LineItem1}")
      .headers(header_1))

    /* ********** SubmitOrder ********** */ 
    .exec(http("SubmitOrder")
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/checkout")
      .headers(header_1)
      .body( StringBody("""{
                                  "items":[
                                            {"itemId":"${LineItem1}"}
                                  ],
                                  "hierarchy":1,
                                  "lastItemId":"",
                                  "pagesize":20
                              }""")).asJson)

 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds) 
}
