package HCPQ

import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.core.structure.ChainBuilder
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._
import io.gatling.jsonpath._
import Headers._
import scala.collection._

 object HCPQ_REST {

    val uri01 = "https://test.salesforce.com"
    val uri05 = "https://c.cs17.visual.force.com"
    val uri10 = "https://cs17.salesforce.com"
    val testDuration = Integer.getInteger("testDuration", 1)
    val minWaitMs    = 2500 milliseconds
    val maxWaitMs    = 3500 milliseconds
    val LineItemJSONMAP = collection.mutable.Map[String,Any]()
    val originalItemJson = new StringBuilder()
    val modifiedItemJson = new StringBuilder()
    val origItemAttrHeirarchy = new StringBuilder()
    val modItemAttrHeirarchy = new StringBuilder()
    val randomNumber = new scala.util.Random
    val randomPBEntry = new StringBuilder()
    val randomPBEntry2 = new StringBuilder()
    val randomLineItem = new StringBuilder()
    
    val scn = scenario("HCPQ_REST")

    
    .exec(http("Login01")
      .post(uri01 + "/")
      .headers(headers_26)
      .formParam("un", "kasi@perftest3.sbx")
      .formParam("width", "1920")
      .formParam("height", "1080")
      .formParam("hasRememberUn", "true")
      .formParam("startURL", "")
      .formParam("loginURL", "")
      .formParam("loginType", "")
      .formParam("useSecure", "true")
      .formParam("local", "")
      .formParam("lt", "standard")
      .formParam("qs", "")
      .formParam("locale", "")
      .formParam("oauth_token", "")
      .formParam("oauth_callback", "")
      .formParam("login", "")
      .formParam("serverid", "")
      .formParam("display", "page")
      .formParam("username", "kasi@perftst3.sbx")
      .formParam("pw", "Osdjsdkjsdj")
      .formParam("Login", "Log In to Sandbox")
      .formParam("rememberUn", "on"))
              
    .pause(minWaitMs, maxWaitMs)
        
    /* ********** Orders Page *********** */
    .exec(http("Order_Page02")
      .get(uri10 + "/801/o")
      .headers(headers_5)
      .check(regex("""linkToken=(.+?)&amp;""").find.exists.saveAs("linkToken1")))
      
    .pause(minWaitMs, maxWaitMs)
    
    /* *********** New Order ************ */
    .exec(http("New_Order03")
      .get(uri10 + "/801/e?retURL=%2F801%2Fo")
      .headers(headers_5)
      .check(regex("""id=\"_CONFIRMATIONTOKEN\" value=\"(.+)\" \/\>\<input type=\"hidden\" name=\"cancelURL\"""").find.exists.saveAs("""CONFIRMATIONTOKEN1""")))

   
    .pause(minWaitMs, maxWaitMs)

    /* *********** Create Order ************ */
    .exec(http("Create_Order04")
      .post(uri10 + "/801/e")
      .headers(headers_130)
      .formParam("_CONFIRMATIONTOKEN", "${CONFIRMATIONTOKEN1}")
      .formParam("cancelURL", "/801/o")
      .formParam("retURL", "/801/o")
      .formParam("save_new_url", "/801/e?retURL=%2F801%2Fo")
      .formParam("save", "Saving...")
      .formParam("accid_lkid", "001g000001EwcbH")
      .formParam("accid_lkold", "AC323662")
      .formParam("accid_lktp", "001")
      .formParam("accid_lspf", "0")
      .formParam("accid_lspfsub", "0")
      .formParam("accid_mod", "1")
      .formParam("accid", "AC323662")
      .formParam("00Ng000000275cx", "")
      .formParam("EffectiveDate", "4/28/2017")
      .formParam("00Ng000000275dG", "")
      .formParam("Status", "Draft")
      .formParam("ShippingAddressstreet", "")
      .formParam("Type", "")
      .formParam("ShippingAddresscity", "")
      .formParam("BillingAddressstreet", "")
      .formParam("ShippingAddressstate", "")
      .formParam("BillingAddresscity", "")
      .formParam("ShippingAddresszip", "")
      .formParam("BillingAddressstate", "")
      .formParam("ShippingAddresscountry", "")
      .formParam("BillingAddresszip", "")
      .formParam("00Ng000000275d1", "Call Center")
      .formParam("BillingAddresscountry", "")
      .formParam("Description", "")
      .formParam("00Ng000000275dK", "")
      .formParam("00Ng000000275dI", "")
      .formParam("00Ng000000275dJ", "")
      .formParam("CF00Ng000000275Yz_lkid", "000000000000000")
      .formParam("CF00Ng000000275Yz_lkold", "null")
      .formParam("CF00Ng000000275Yz_lktp", "800")
      .formParam("CF00Ng000000275Yz_lspf", "0")
      .formParam("CF00Ng000000275Yz_lspfsub", "0")
      .formParam("CF00Ng000000275Yz_mod", "0")
      .formParam("CF00Ng000000275Yz", "")
      .check(status.is(200))
      .check(regex("""handleRedirect\(\'\/(.+)\'\)""").find.exists.saveAs("""OrderID""")))

    .exec(http("Order_Detail05")
      .get(uri10 + "/${OrderID}")
      .headers(headers_5)
      .check(regex("""\<input\stype=\"hidden\"\sname=\"echoScontrol\"\svalue="(.+)\"\s\/\>\<input\stype""").find.exists.saveAs("""echoScontrol1"""))
      .check(regex("""\<input\stype=\"hidden\"\sname=\"echoScontrolMac\"\svalue=\"(.+)\"\s\/\>\<\/form\>""").find.exists.saveAs("""echoScontrolMac1"""))
      //.check(regex("""\&amp\;linkToken=(.+)\"\stitle=\"Vlocity\sDataRaptor\sTab\"""").find.exists.saveAs("""linkToken1""")) 
      .check(regex("""https\:\/\/c.cs17.visual.force.com\/servlet\/servlet.Integration\?lid=(.+)\&amp;ic=1\&amp\;linkToken""").find.exists.saveAs("""lid1""")))

    .pause(minWaitMs, maxWaitMs)
  
    .exec(http("request_143")
      .post(uri05 + "/servlet/servlet.Integration?lid=${lid1}&ic=1&linkToken=${linkToken1}")
      .headers(headers_130)
      .formParam("echoScontrol", "${echoScontrol1}")
      .formParam("echoScontrolMac", "${echoScontrolMac1}"))
            
    .exec(http("request_145")
      .post(uri10 + "/visualforce/session")
      .headers(headers_145)
      .formParam("echoScontrol", "${echoScontrol1}")
      .formParam("echoScontrolMac", "${echoScontrolMac1}")
      .formParam("ic", "1")
      .formParam("lid", "${lid1}")
      .formParam("linkToken", "${linkToken1}")
      .formParam("url", "https://c.cs17.visual.force.com/servlet/servlet.Integration?lid=${lid1}&ic=1&linkToken=${linkToken1}")
      .check(regex("""id=\"sid\"\svalue=\"(.+)\"\s\/\>\<input\stype=""").find.exists.saveAs("""sid1""")))

    .exec(http("request_146")
      .post(uri05 + "/visualforce/recsession")
      .headers(headers_130)
      .formParam("cshc", "0000002Z1pY0000006Tt88")
      .formParam("echoScontrol", "${echoScontrol1}")
      .formParam("echoScontrolMac", "${echoScontrolMac1}")
      .formParam("ic", "1")
      .formParam("inst", "g")
      .formParam("lid", "${lid1}")
      .formParam("linkToken", "${linkToken1}")
      .formParam("originalRequestIsPost", "1")
      .formParam("retURL", "https://c.cs17.visual.force.com/servlet/servlet.Integration?lid=${lid1}&ic=1&linkToken=${linkToken1}")
      .formParam("sid", "{sid1}")
      .formParam("url", "https://c.cs17.visual.force.com/servlet/servlet.Integration?lid=${lid1}&ic=1&linkToken=${linkToken1}"))
            
    /* ********** Extract CSRF tokens *********** */
    .exec(http("Extract_CSRF_Tokens05")
      .post(uri05 + "/servlet/servlet.Integration?lid=${lid1}&ic=1&linkToken=${linkToken1}")
      .headers(headers_145)
      .formParam("cshc", "0000002Z1pY0000006Tt88")
      .formParam("echoScontrol", "${echoScontrol1}")
      .formParam("echoScontrolMac", "${echoScontrolMac1}")
      .formParam("ic", "1")
      .formParam("inst", "g")
      .formParam("lid", "${lid1}")
      .formParam("linkToken", "${linkToken1}")
      .formParam("originalRequestIsPost", "1")
      .formParam("sid", "${sid1}")
      .formParam("url", "https://c.cs17.visual.force.com/servlet/servlet.Integration?lid=${lid1}&ic=1&linkToken=${linkToken1}")
      .check(regex("""\"getProdConfMode\",\"len\"\:0,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"getProductForAttribCheckMode\"""").find.exists.saveAs("""getProdConfMode1"""))
      .check(regex("""\"getProdAttribCheckMode\",\"len\"\:0,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"getProdConfMode\"""").find.exists.saveAs("""getProdAttribCheckMode1"""))
      .check(regex("""\"isSignitureRequired\",\"len\"\:1,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"nextProducts\"""").find.exists.saveAs("""isSignitureRequired1"""))
      .check(regex("""\"productConfSaveMode\",\"len\"\:0,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"saveProductPostConfigure\"""").find.exists.saveAs("""productConfSaveMode1"""))
      .check(regex("""\"getCpqSettings\",\"len\"\:1,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"getOrderSummaryConfig\"""").find.exists.saveAs("""getCpqSettings1"""))
      .check(regex("""\"getContextualData\",\"len\"\:1,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"getCpqSettings\"""").find.exists.saveAs("""getContextualData1"""))
      .check(regex("""\"getOrderSummaryConfig\",\"len\":2,\"ns\":\"\",\"ver\":35.0,\"csrf\":\"(.+)\"\},\{\"name\"""").find.exists.saveAs("""getOrderSummaryConfigSUMCONFCON1"""))
      .check(regex("""\"getPriceBooks\",\"len\"\:1,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"getProdAttribCheckMode\"""").find.exists.saveAs("""getPriceBooks1"""))
      .check(regex("""\"setPriceBook\",\"len\"\:2,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"updateItemQuantity\"""").find.exists.saveAs("""setPriceBook1""")))
      //.check(regex("""\"SummaryConfigController\",\"len\"\:3,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\}""").find.exists.saveAs("""SummaryConfigController"""))
      //.check(regex("""\"getOrderSummaryDetails\",\"len\"\:2,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\}""").find.exists.saveAs("""getOrderSummaryDetails"""))
            
    .exec( session => {
      println( "CSRF Tokens------------------------------------------>------------------------------------------>:" )
      println( session( "getPriceBooks1" ).as[String] )
      println( session( "setPriceBook1" ).as[String] )
      session
    })
           
    /* getOrderSummaryConfigSUMCONFCON1 / getpricebooks / getContextualData / getCPQsettings / ProductConfSaveMode / issignaturerequired / getPRodAttributecheckMode / Getprodconfmode */
    .exec(http("Order_Details_Page06")
      .post("/apexremote")
      .headers(headers_160)
      .body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0160_request.txt"))
      .check(jsonPath("$..result[*].id").findAll.saveAs("ListOfPriceBooks"))
      .check(regex("""\{\"id\":\"(.+)\",\"Name\":\"psr-data-generation\"\}\,""").find.exists.saveAs("""psrdatapricebook"""))
      .check(regex("""\{\"id\":\"(.+)\",\"Name\":\"OCOM Pricebook\"\}\,""").find.exists.saveAs("""telpricebook""")))
          
    .exec( session => {
      println( "PriceBooks------------------------------------------>------------------------------------------>:" )
      println( session( "psrdatapricebook" ).as[String] )
      println( session( "telpricebook" ).as[String] )
      println( session( "ListOfPriceBooks" ).as[String] )
      session
    })
          
    .pause(minWaitMs, maxWaitMs)

    /* ********** setPriceBook ********** */ 
    .exec(http("setPriceBook10")
      .post("/apexremote")
      .headers(headers_160)
      .body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0178_request.txt")))


    /* ********** Get OAuth token for REST Authentication *********** */
    .exec(http("Get_token")
      .post("https://test.salesforce.com/services/oauth2/token")
      .header("Content-Type", "application/x-www-form-urlencoded")
      .formParam("password", "Ma425eBAvCvrjwXZchdKsRTHaGIz4")
      .formParam("username", "kasi@peftest3.sbx")
      .formParam("client_secret", "7119599995527965426")
      .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
      .formParam("grant_type", "password")
      .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
      .check(status.is(200)))

    .exec( session => {
       //println( "Value of Token_ID:"+session("Token_ID").as[String] )
       session
        })

    /* ********** 1.GetListOfProductsForCart *********** */
    .exec(http("GetListOfProductsForCart")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/products")
      .headers(header_1)) 

     /* ********** 2. GetCartDetailsValidateFalPricingFal *********** */
    .exec(http("GetCartDetailsValidateFalPricingFal")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}")
      .queryParamSeq(Seq(("validate", "true"), ("price", "false"),("headerFieldSet","CPQV2")))
      .headers(header_1)) 

    /* ********** 3. GetCartDetailsValidateTruPricingFal *********** */
    .exec(http("GetCartDetailsValidateTruPricingFal")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}")
      .queryParamSeq(Seq(("validate", "true"), ("price", "false"),("headerFieldSet","CPQV2")))
      .headers(header_1)) 
    
    /* ********** 4. GetCartDetailsValidateFalPricingTru *********** */
    .exec(http("GetCartDetailsValidateFalPricingTru")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}")
      .queryParamSeq(Seq(("validate", "true"), ("price", "false"),("headerFieldSet","CPQV2")))
      .headers(header_1)) 

    /* ********** 5. GetCartDetailsValidateTruPricingTru *********** */
    .exec(http("GetCartDetailsValidateTruPricingTru")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}")
      .queryParamSeq(Seq(("validate", "true"), ("price", "false"),("headerFieldSet","CPQV2")))
      .headers(header_1))

    /* ********** 6. GetListofAttributes  *********** */
    .exec(http("GetListofAttributes")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/attributes")
      .headers(header_1)) 

    /* ********** 7. GetListofProductsForCartH1 *********** */
    .exec(http("GetListofProductsForCartH1")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/products")
      .queryParamSeq(Seq(("query", "Business Anywhere"),("hierarchy", "1")))
      .headers(header_1)) 
    
    /* ********** 8. GetListofProductsForCartH2 *********** */   
    .exec(http("GetListofProductsForCartH2")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/products")
      .queryParamSeq(Seq(("query", "Business Anywhere"),("hierarchy", "2")))
      .headers(header_1)) 

    /* ********** 9. GetListofProductsForCartH3 *********** */
    .exec(http("GetListofProductsForCartH3")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/products")
      .queryParamSeq(Seq(("query", "port-in"),("hierarchy", "3")))
      .headers(header_1)) 

    /* ********** 10. GetListofProductsForCartH2PgSiz30 *********** */
    .exec(http("GetListofProductsForCartH2PgSiz30")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/products")
      .queryParamSeq(Seq(("query", "Business Anywhere"),("hierarchy", "2"),("filters", "Anywhere"),("pagesize", "30")))
      .headers(header_1)) 

    /* ********** 11. GetListofProductsForCartH3PgSiz30 *********** */
    .exec(http("GetListofProductsForCartH3PgSiz30")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/products")
      .queryParamSeq(Seq(("query", "Apple port-in credit"),("hierarchy", "2"),("pagesize", "30")))
      .headers(header_1)
      .check(jsonPath("$.records[0].Id.value").find.saveAs("PBEntryId"))
      .check(jsonPath("$.records[1].Id.value").find.saveAs("PBEntryId1"))
      .check(jsonPath("$.records[2].Id.value").find.saveAs("PBEntryId2"))
      .check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfPBEntries")))

    .exec( session => {
          //println( "List Of Price Book Entires are:" )
          //println( session( "ListOfPBEntries" ).as[String] )
          val ListPBE = session("ListOfPBEntries").as[Vector[String]]
          val max = ListPBE.length - 1
          val random_index = randomNumber.nextInt(max+1)
          val random_index2 = randomNumber.nextInt(max+1)
          randomPBEntry.append(ListPBE(random_index))
          randomPBEntry2.append(ListPBE(random_index)).append(","+ListPBE(random_index2))
          session
        })
        

    /* ********** 12. GetListofProdsAttribByPBEnrtyID *********** */
    .exec(http("GetListofProdsAttribByPBEnrtyID")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/products")
      .queryParamSeq(Seq(("Id", randomPBEntry),("includeAttachment", "true")))
      .headers(header_1)) 

    /* ********** 13. GetListofProdsAttribByPBEnrtyIDs *********** */   
    .exec(http("GetListofProdsAttribByPBEnrtyIDs")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/products")
      .queryParamSeq(Seq(("Id", randomPBEntry2),("includeAttachment", "true")))
      .headers(header_1)) 
      
    /* ********** 14. AddItemsToCart *********** */
    .exec(http("AddItemsToCart")
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
      .headers(header_1)
      .body( StringBody("""{
                                  "items":[{
                                  "itemId":"${PBEntryId}"
                                  }],
                                  "hierarchy":3,
                                  "lastItemId":"",
                                  "pagesize":20
                                  }""")).asJson)

    /* ********** 15. AddItemsToCart1 *********** */
    .exec(http("AddItemsToCart1")
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
      .headers(header_1)
      .body( StringBody("""{
                                  "items":[{
                                  "itemId":"${PBEntryId1}"
                                  }],
                                  "hierarchy":3,
                                  "lastItemId":"",
                                  "pagesize":20
                                  }""")).asJson)
    
    /* ********** 16. AddItemsToCart2 *********** */    
    .exec(http("AddItemsToCart2")
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
      .headers(header_1)
      .body( StringBody("""{
                                  "items":[{
                                  "itemId":"${PBEntryId2}"
                                  }],
                                  "hierarchy":3,
                                  "lastItemId":"",
                                  "pagesize":20
                                  }""")).asJson)                             

   /* ********** 17. GetCartItems *********** */
    .exec(http("GetCartItems")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
      .headers(header_1)
      .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1"))
      .check(jsonPath("$.records[1].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem2"))
      .check(jsonPath("$.records[2].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem3"))
      .check(jsonPath("$.records[*].actions.updateitems.rest.params.items..itemId").findAll.saveAs("ListOfLineItems")))
         
    .exec( session => {
      //println( "ListOfLineItems are:" )
      //println( session( "ListOfLineItems" ).as[String] )
      val ListLineItems = session("ListOfLineItems").as[Vector[String]]
      val max = ListLineItems.length - 1
      val random_index = randomNumber.nextInt(max+1)
      val random_index2 = randomNumber.nextInt(max+1)
      randomLineItem.append(ListLineItems(random_index))
      session 
    })
   
           
   /* ********** 18. GetCartItemsAttreachItemValidateFalsePriceFalse *********** */
   .exec(http("GetCartItemsAttreachItemValidateFalsePriceFalse")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
      .queryParamSeq(Seq(("query", "port-in"),("hierarchy", "3"),("includeAttachment", "true"),("validate", "false"),("price", "false")))
      .headers(header_1)) 

   /* ********** 19. GetCartItemsAttreachItemValidateTruePriceTrue *********** */
    .exec(http("GetCartItemsAttreachItemValidateTruePriceTrue")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
      .queryParamSeq(Seq(("query", "port-in"),("hierarchy", "3"),("includeAttachment", "true"),("validate", "true"),("price", "true")))
      .headers(header_1))
     
   /* ********** 20. GetCartItemsByItemIdValidateTrue *********** */
   .exec(http("GetCartItemsByItemIdValidateTrue")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
      .queryParamSeq(Seq(("id", randomLineItem),("validate", "true")))
      .headers(header_1)
      .check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))

    .exec(session => { 
      //println("---------capturedItemHierarchy----------------------")
      //println(session("capturedItemHierarchy").as[String])
      originalItemJson.append(session("capturedItemHierarchy").as[String])
      //println("originalItemJson"+originalItemJson)
      modifiedItemJson.append("""{"items":{"records":[{"displaySequence":-1,""").append(originalItemJson).append("}]}}")
      //println("modifiedItemJson"+modifiedItemJson)
      session
      })

    /* ********** 21. GetCartItemsByItemIdValidateFalse *********** */  
    .exec(http("GetCartItemsByItemIdValidateFalse")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
      .queryParamSeq(Seq(("id", randomLineItem),("validate", "false")))
      .headers(header_1))
      
      
   /* ********** 22. UpdateItemsInCart1 *********** */
    .exec(http("UpdateItemsInCart1")
      .put(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
      .headers(header_1)
      .body(StringBody(session =>  modifiedItemJson.replaceAllLiterally(""""Quantity":{"value":1.00""",""""Quantity":{"value":3.00""").toString() )).asJson)

    .repeat(5, "index") 
    {
      exec{ session =>
        println("Manju")
        session
      }
    }


    /* ********** 23. GetCartItemsByItemIdValidateTrue *********** */
    /* This request is executed to get the request body for UpdateItemAttributesForLineItemInCart.
       You should be passing the randomLineItem which has configurable attributes   */
    .exec(http("GetCartItemsByItemIdValidateTrue")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
      .queryParamSeq(Seq(("id", "${LineItem1}"),("validate", "true")))
      .headers(header_1)
      .check(regex(""""displaySequence":-1,"Id":(.+?)}}]}}]}""").find.exists.saveAs("ItemAttrHierarchy")))
                                                  

      .exec(session => { 
        //println("---------ItemAttrHierarchy----------------------")
        //println(session("ItemAttrHierarchy").as[String])
        origItemAttrHeirarchy.append(session("ItemAttrHierarchy").as[String])
        println("origItemAttrHierarchy"+origItemAttrHeirarchy)
        modItemAttrHeirarchy.append("""{"items":{"records":[{"displaySequence":-1,"Id":""").append(origItemAttrHeirarchy).append("}}]}}]}}]}}")
        //println("moditemAttrHeirarchy"+modItemAttrHeirarchy)
        session
        })
      

    /* ********** 24. UpdateItemAttributesForLineItemInCart *********** */
    /* You must be having a LineItem which has configurable attributes otherwise this request can't be done */ 
    .exec(http("UpdateItemAttributesForLineItemInCart")
      .put(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/")
      .headers(header_1)
      .body(StringBody(session =>  modItemAttrHeirarchy.replaceAllLiterally(""""userValues":null""",""""userValues":"Sample test text"""").toString() )).asJson)


    /* ********** 25. CloneItem ********** */
    .exec(http("CloneItem")
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/clone")
      .headers(header_1)
      .body( StringBody("""{
                              "items": [
                                          {"itemId": "${LineItem1}"}
                              ],
                              "hierarchy": 1,
                              "lastItemId": "",
                              "pagesize": 20
                           }""")).asJson)

     /* ********** 26. DeleteItemFromCart1********** */
    .exec(http("DeleteItemFromCart1")
      .delete(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/${LineItem1}")
      .headers(header_1))

    /* ********** 27. SubmitOrder ********** */ 
    .exec(http("SubmitOrder")
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/checkout")
      .headers(header_1)
      .body( StringBody("""{
                                  "items":[
                                            {"itemId":"${LineItem1}"}
                                  ],
                                  "hierarchy":1,
                                  "lastItemId":"",
                                  "pagesize":20
                              }""")).asJson)
}
    
