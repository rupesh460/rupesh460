package HCPQ

import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.core.structure.ChainBuilder
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._
import io.gatling.jsonpath._
import Headers._
import scala.collection._

 object HCPQ_PricingPromotions_REST {

 	val uri01 = "https://test.salesforce.com"
    val uri05 = "https://c.cs17.visual.force.com"
    val uri10 = "https://cs17.salesforce.com"
    val randomNumber = new scala.util.Random
    val randomOrderId = new StringBuilder()
   
 	val scn = scenario("HCPQ_PricingPromotions_REST")

 	.exec(http("Login01")
      .post(uri01 + "/")
      .headers(headers_26)
      .formParam("un", "kasi@perftest3.sbx")
      .formParam("width", "1920")
      .formParam("height", "1080")
      .formParam("hasRememberUn", "true")
      .formParam("startURL", "")
      .formParam("loginURL", "")
      .formParam("loginType", "")
      .formParam("useSecure", "true")
      .formParam("local", "")
      .formParam("lt", "standard")
      .formParam("qs", "")
      .formParam("locale", "")
      .formParam("oauth_token", "")
      .formParam("oauth_callback", "")
      .formParam("login", "")
      .formParam("serverid", "")
      .formParam("display", "page")
      .formParam("username", "kas@ftest3.sbx")
      .formParam("pw", "Osdjsdkj")
      .formParam("Login", "Log In to Sandbox")
      .formParam("rememberUn", "on"))

 	.exec(http("GetListOfAccounts_web")
			.get("/001/o")
			.check(regex("""class=" dataCell  "><a href="\/(.*?)">test-rest""").find.saveAs("AccountId"))
			.check(regex("""class=" dataCell  "><a href="\/(.*?)"""").findAll.exists.saveAs("ListOfAccountIds"))
			.headers(headers_0))


 	/* ********** Get OAuth token for REST Authentication *********** */
	.exec(http("Get_token")
      .post("https://test.salesforce.com/services/oauth2/token")
      .header("Content-Type", "application/x-www-form-urlencoded")
      .formParam("password", "eBAvCvrjwXZchdKsRTHaGIz4")
      .formParam("username", "kasi@perftest3.sbx")
      .formParam("client_secret", "7119599995527965426")
      .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
      .formParam("grant_type", "password")
      .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
      .check(status.is(200)))

	 /* ********** 1.GetAccountProperties *********** */ 
	.exec(http("GetAccountProperties")
			.get(uri10 +"/services/apexrest/v2/accounts/${AccountId}")
			.headers(header_1))

	/* ********** 2.GetListOfAssetsForAccount *********** */ 
	.exec(http("GetAssetsByAccount")
			.get(uri10 +"/services/apexrest/v2/accounts/${AccountId}/assets")
			.headers(header_1))

	/* ********** 4.GetContractsByAccount *********** */ 
	.exec(http("GetContractsByAccount")
			.get(uri10 +"/services/apexrest/v2/accounts/${AccountId}/contracts")
			.check(jsonPath("$.records[0].Id.value").find.saveAs("ContractId"))
			.check(jsonPath("$.records[*].Id.value").find.saveAs("ListOfContractIds"))
			.headers(header_1))

	/* ********** 3.GetListOfAssetsForContract *********** */ 
	.exec(http("GetAssetsByContract")
			.get(uri10 +"/services/apexrest/v2/contracts/${ContractId}/assets")
			.headers(header_1))

	/* ********** 5.GetListsOfValues *********** */ 
	.exec(http("GetListsOfValues")
			.get(uri10 +"/services/apexrest/v2/listsofvalues?listkeys=TimePlans,TimePolicies")
			.headers(header_1))

	/* ********** GetAssetsForAccount ********** */
	.exec(http("GetAssetsForAccount")
			.get(uri10 +"/services/apexrest/v2/accounts/${AccountId}/assets")
			.headers(header_1)
			.check(jsonPath("$.records[0].Id.value").find.saveAs("assetId1"))
      		.check(jsonPath("$.records[1].Id.value").find.saveAs("assetId2"))
      		.check(jsonPath("$.records[2].Id.value").find.saveAs("assetId3"))
			.check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfAssetIds")))

	/* ********** 6.GetPricingDetailsForAsset *********** */
	.exec(http("GetPricingDetailsForAsset")
			.get(uri10 +"/services/apexrest/v2/accounts/${AccountId}/assets/${assetId1}/pricing")
			.headers(header_1))
	

	/* ********** 7.GetPromotionDetailsForAsset *********** */ 
	.exec(http("GetPromotionDetailsForAsset")
			.get(uri10 +"/services/apexrest/v2/accounts/${AccountId}/assets/${assetId1}/promotions")
			.headers(header_1))

	.exec(http("GetListOfOrders_web")
			.get("/801/o")
			.check(regex("""class=" dataCell  "><a href="\/(.*?)"(.*?)test-rest""").find.saveAs("OrderId"))
			.check(regex("""class=" dataCell  "><a href="\/(.*?)"(.*?)test-rest""").findAll.saveAs("ListOfOrdersForAccount"))
			.headers(headers_0))

	.exec( session => {
          val ListOfOrders = session("ListOfOrdersForAccount").as[Vector[String]]
          val max = ListOfOrders.length - 1
          val random_index = randomNumber.nextInt(max+1)
          randomOrderId.append(ListOfOrders(random_index))
		session
		})


	.exec(http("GetListOfLineItemsForCart")
			.get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderId}/items")
			.headers(header_1)
			.check(jsonPath("$.records[0].Id.value").find.saveAs("LineItemId1"))
      		.check(jsonPath("$.records[1].Id.value").find.saveAs("LineItemId2"))
			.check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfLineItemIds")))

	/* ********** 8.GetPromotionDetailsForCartLineItem *********** */ 
	.exec(http("GetPromotionDetailsForCartLineItem")
			.get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderId}/items/${LineItemId1}/promotions")
			.headers(header_1))

	/* ********** 9.GetPromotionsAppliedToAccount *********** */
	.exec(http("GetPromotionsAppliedToAccount")
			.get(uri10 +"/services/apexrest/v2/accounts/${AccountId}/promotions")
			.headers(header_1))

	/* ********** 10.GetPromotionsAppliedToCart *********** */ 
	.exec(http("GetPromotionsAppliedToCart")
			.get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderId}/promotions")
			.headers(header_1))

	/* ********** 11.PricingDetailsForCartLineItem *********** */
	.exec(http("GetPricingDetailsForCartLineItem")
			.get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderId}/items/${LineItemId1}/pricing?fields=OneTimeCharge__c")
			.headers(header_1))

	/* *********** 19.CreateOrder_draft *********** */
	.exec(http("CreateOrder_draft")
			.post(uri10 +"/services/apexrest/v2/carts")
			.headers(header_1)
			.check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderId_draft"))
			.body( StringBody("""{"subaction":"createOrder",
								"inputFields":[
									{"AccountId":"001g000001hIc0F"},
									{"PriceListId__c":"a2Pg0000001MwIVEA0"},
									{"Name":"NewOrder1"},{"Status":"Draft"},
									{"EffectiveDate":"12/7/2019"}
								]}""")).asJson)


	/* ********** 12.UpdatePriceListForCart *********** */
	.exec(http("UpdatePriceListForCart")
			.put(uri10 +"/services/apexrest/v2/cpq/carts/${OrderId}/")
			.headers(header_1)
			.body(StringBody("""{
   									"inputFields": 
   									[
   										{
         									"PriceListId__c": "a2Pg0000001MwIiEAK"
         								}
         							],
   									"cartId": "801g000000CH4iwAAD",
   									"methodName": "updateCarts"
								}""")).asJson)

	/* ********** 13.CreateOpptyCart *********** */
	.exec(http("CreateOpptyCart")
			.post(uri10 +"/services/apexrest/v2/carts")
			.headers(header_1)
			.check(regex(""""Id":"(.*?)"""").find.exists.saveAs("""OpptyId"""))
			.body(StringBody("""{
   									"subaction":"createOppty",
									"inputFields":[
									{"AccountId":"001g000001hIc0F"},
									{"PriceListId__c":"a2Pg0000001MwIVEA0"},
									{"Name":"NewTestOppty1"},{"StageName":"Qualification"},
									{"Closedate":"12/7/2019"}]
								}""")).asJson)

	/* ********** 14.CreateQuoteCart *********** */
	.exec(http("CreateQuoteCart")
			.post(uri10 +"/services/apexrest/v2/carts")
			.headers(header_1)
			.check(regex(""""Id":"(.*?)"""").find.exists.saveAs("""QuoteId"""))
			.body(StringBody("""{
   									 "subaction":"createQuote",
   									 "inputFields":
   									 [
   									 	{"opportunityId":"${OpptyId}"},
   									 	{"PriceListId__c":"a2Pg0000001MwIVEA0"},	
   									 	{"Name":"NewTestQuote1"}
   									 ]
								}""")).asJson)

	/* ********** 16.GetProductsForOppty *********** */
	.exec(http("GetProductsForOpptyCart")
			.get(uri10 +"/services/apexrest/v2/cpq/carts/${OpptyId}/products")
			.headers(header_1)
			.check(jsonPath("$.records[0].Id.value").find.saveAs("PBEntryId1"))
      		.check(jsonPath("$.records[1].Id.value").find.saveAs("PBEntryId2"))
      		.check(jsonPath("$.records[2].Id.value").find.saveAs("PBEntryId3"))
			.check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfPBEntries")))

	/* ********** 17. AddItemsToOpptyCart *********** */
    .exec(http("AddItemsToOpptyCart")
			.post(uri10 +"/services/apexrest/v2/cpq/carts/${OpptyId}/items")
			.headers(header_1)
			.body( StringBody("""{
                                  "items":[{
                                  "itemId":"${PBEntryId1}"
                                  }],
                                  "hierarchy":3,
                                  "lastItemId":"",
                                  "pagesize":20
                                  }""")).asJson)
												 

	/* ************ 18.CreateQuoteCartFromOppty *********** */
	.exec(http("CreateQuoteCartFromOppty")
			.post(uri10 +"/services/apexrest/v2/cpq/carts/${OpptyId}/items/checkout")
			.headers(header_1)
			.check(regex(""""id":"(.*?)"""").find.exists.saveAs("""QuoteId"""))
			.check(regex(""""objectType":"(.*?)"""").find.exists.saveAs("""ObjectType"""))
			.body(StringBody("""{}""")).asJson)


/*
	/* ************ 19.CreateOrderFromQuote *********** */ // not working manually
	.exec(http("CreateOrderFromQuote")
			.post(uri10 +"/services/apexrest/v2/cpq/carts/${QuoteId}/items/checkout")
			.headers(header_1)
			.check(regex(""""Id":"(.*?)"""").find.exists.saveAs("""OrderId"""))
			.check(regex(""""objectType":"(.*?)"""").find.exists.saveAs("""ObjectType"""))
			.body(StringBody("""{}""")).asJson)

	/* ************ 20.AssetChangeToOrder *********** */ 
	.exec(http("AssetChangeToOrder")
			.post(uri10 +"/services/")
			.headers(header_1)
			.check(regex(""""Id":"(.*?)"""").find.exists.saveAs("""OrderId"""))
			.check(regex(""""objectType":"(.*?)"""").find.exists.saveAs("""ObjectType"""))
			.body(StringBody("""{}""")).asJson)

	/* ************ 21.AssetChangeToQuote *********** */ 
	.exec(http("AssetChangeToQuote")
			.post(uri10 +"/services/")
			.headers(header_1)
			.check(regex(""""Id":"(.*?)"""").find.exists.saveAs("""OrderId"""))
			.check(regex(""""objectType":"(.*?)"""").find.exists.saveAs("""ObjectType"""))
			.body(StringBody("""{}""")).asJson)

	
	/* ************ 22.AssetMove *********** */ 
	.exec(http("AssetMove")
			.post(uri10 +"/services/")
			.headers(header_1)
			.check(regex(""""Id":"(.*?)"""").find.exists.saveAs("""OrderId"""))
			.check(regex(""""objectType":"(.*?)"""").find.exists.saveAs("""ObjectType"""))
			.body(StringBody("""{}""")).asJson)

	/* *********** 23.DeletePromotionForLineItem ********** */
	.exec(http("DeletePromotionForLineItem")
			.delete(uri10 +"/services/apexrest/v2/carts/{cartId}/items/{itemId}/promotions/{promotionId}")
			.headers(header_1))

	/* *********** 24.RemovePromotionAppliedToCart ********** */
	.exec(http("RemovePromotionAppliedToCart")
			.get(uri10 +"/services/apexrest/v2/carts/{cartId}/promotions/{appliedPromotionId}")
			.headers(header_1))

		
	/* *********** 25.ListOfPriceListsForCustomer ********** */
	.exec(http("ListOfPriceListsForCustomer")
			.post(uri10 +"/services/apexrest/v2/customer/{customerId}/pricelists")
			.headers(header_1)
			.body(StringBody("""{}""")).asJson)

*/

 }
