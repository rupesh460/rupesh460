package HCPQ

import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.core.structure.ChainBuilder
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._
import Headers._

 object HCPQ_CreateOrderDetails {

	

    val uri01 = "https://test.salesforce.com"
    val uri05 = "https://c.cs17.visual.force.com"
    val uri10 = "https://cs17.salesforce.com"
    val testDuration = Integer.getInteger("testDuration", 1)
	val minWaitMs    = 2500 milliseconds
  	val maxWaitMs    = 3500 milliseconds

	val scn = scenario("HCPQ_CreateOrderDetails")
						
		.exec(http("Login01")
			.post(uri01 + "/")
			.headers(headers_26)
			.formParam("un", "kasi@perftest3.sbx")
			.formParam("width", "1920")
			.formParam("height", "1080")
			.formParam("hasRememberUn", "true")
			.formParam("startURL", "")
			.formParam("loginURL", "")
			.formParam("loginType", "")
			.formParam("useSecure", "true")
			.formParam("local", "")
			.formParam("lt", "standard")
			.formParam("qs", "")
			.formParam("locale", "")
			.formParam("oauth_token", "")
			.formParam("oauth_callback", "")
			.formParam("login", "")
			.formParam("serverid", "")
			.formParam("display", "page")
			.formParam("username", "kasi@perftes.sbx")
			.formParam("pw", "OPOskdnsd")
			.formParam("Login", "Log In to Sandbox")
			.formParam("rememberUn", "on"))
				
		.pause(minWaitMs, maxWaitMs)
        
		//Orders Page
		.exec(http("Order_Page02")
			.get(uri10 + "/801/o")
			.headers(headers_5)
			)
		.pause(minWaitMs, maxWaitMs)
		

		//New Order
		.exec(http("New_Order03")
			.get(uri10 + "/801/e?retURL=%2F801%2Fo")
			.headers(headers_5)
            .check(regex("""id=\"_CONFIRMATIONTOKEN\" value=\"(.+)\" \/\>\<input type=\"hidden\" name=\"cancelURL\"""").find.exists.saveAs("""CONFIRMATIONTOKEN1""")))

         .exec( session => {
				  println( "Confirmation Token------------------------------------------>------------------------------------------>:" )
				  println( session( "CONFIRMATIONTOKEN1" ).as[String] )
				  session
				})

				
		.pause(minWaitMs, maxWaitMs)
		//Create Order
		.exec(http("Create_Order04")
			.post(uri10 + "/801/e")
			.headers(headers_130)
			.formParam("_CONFIRMATIONTOKEN", "${CONFIRMATIONTOKEN1}")
			.formParam("cancelURL", "/801/o")
			.formParam("retURL", "/801/o")
			.formParam("save_new_url", "/801/e?retURL=%2F801%2Fo")
			.formParam("save", "Saving...")
			.formParam("accid_lkid", "001g000001EwcbH")
			.formParam("accid_lkold", "AC323662")
			.formParam("accid_lktp", "001")
			.formParam("accid_lspf", "0")
			.formParam("accid_lspfsub", "0")
			.formParam("accid_mod", "1")
			.formParam("accid", "AC323662")
			.formParam("00Ng000000275cx", "")
			.formParam("EffectiveDate", "4/28/2017")
			.formParam("00Ng000000275dG", "")
			.formParam("Status", "Draft")
			.formParam("ShippingAddressstreet", "")
			.formParam("Type", "")
			.formParam("ShippingAddresscity", "")
			.formParam("BillingAddressstreet", "")
			.formParam("ShippingAddressstate", "")
			.formParam("BillingAddresscity", "")
			.formParam("ShippingAddresszip", "")
			.formParam("BillingAddressstate", "")
			.formParam("ShippingAddresscountry", "")
			.formParam("BillingAddresszip", "")
			.formParam("00Ng000000275d1", "Call Center")
			.formParam("BillingAddresscountry", "")
			.formParam("Description", "")
			.formParam("00Ng000000275dK", "")
			.formParam("00Ng000000275dI", "")
			.formParam("00Ng000000275dJ", "")
			.formParam("CF00Ng000000275Yz_lkid", "000000000000000")
			.formParam("CF00Ng000000275Yz_lkold", "null")
			.formParam("CF00Ng000000275Yz_lktp", "800")
			.formParam("CF00Ng000000275Yz_lspf", "0")
			.formParam("CF00Ng000000275Yz_lspfsub", "0")
			.formParam("CF00Ng000000275Yz_mod", "0")
			.formParam("CF00Ng000000275Yz", "")
		    .check(status.is(200))
		    .check(regex("""handleRedirect\(\'\/(.+)\'\)""").find.exists.saveAs("""OrderID""")))

		.pause(minWaitMs, maxWaitMs)
		
		// Order Detail
		.exec(http("Order_Detail05")
			.get(uri10 + "/${OrderID}")
			.headers(headers_5)
            .check(regex("""\<input\stype=\"hidden\"\sname=\"echoScontrol\"\svalue="(.+)\"\s\/\>\<input\stype""").find.exists.saveAs("""echoScontrol1"""))
            .check(regex("""\<input\stype=\"hidden\"\sname=\"echoScontrolMac\"\svalue=\"(.+)\"\s\/\>\<\/form\>""").find.exists.saveAs("""echoScontrolMac1"""))
            .check(regex("""\&amp\;linkToken=(.+)\"\stitle=\"Vlocity\sDataRaptor\sTab\"""").find.exists.saveAs("""linkToken1""")) 
            .check(regex("""https\:\/\/c.cs17.visual.force.com\/servlet\/servlet.Integration\?lid=(.+)\&amp;ic=1\&amp\;linkToken""").find.exists.saveAs("""lid1""")))

		.pause(minWaitMs, maxWaitMs)
		// 
		.exec(http("request_143")
			.post(uri05 + "/servlet/servlet.Integration?lid=${lid1}&ic=1&linkToken=${linkToken1}")
			.headers(headers_130)
			.formParam("echoScontrol", "${echoScontrol1}")
			.formParam("echoScontrolMac", "${echoScontrolMac1}"))
            
        .exec(http("request_145")
			.post(uri10 + "/visualforce/session")
			.headers(headers_145)
			.formParam("echoScontrol", "${echoScontrol1}")
			.formParam("echoScontrolMac", "${echoScontrolMac1}")
			.formParam("ic", "1")
			.formParam("lid", "${lid1}")
			.formParam("linkToken", "${linkToken1}")
			.formParam("url", "https://c.cs17.visual.force.com/servlet/servlet.Integration?lid=${lid1}&ic=1&linkToken=${linkToken1}")
            .check(regex("""id=\"sid\"\svalue=\"(.+)\"\s\/\>\<input\stype=""").find.exists.saveAs("""sid1""")))

        .exec(http("request_146")
			.post(uri05 + "/visualforce/recsession")
			.headers(headers_130)
			.formParam("cshc", "0000002Z1pY0000006Tt88")
			.formParam("echoScontrol", "${echoScontrol1}")
			.formParam("echoScontrolMac", "${echoScontrolMac1}")
			.formParam("ic", "1")
			.formParam("inst", "g")
			.formParam("lid", "${lid1}")
			.formParam("linkToken", "${linkToken1}")
			.formParam("originalRequestIsPost", "1")
			.formParam("retURL", "https://c.cs17.visual.force.com/servlet/servlet.Integration?lid=${lid1}&ic=1&linkToken=${linkToken1}")
			.formParam("sid", "{sid1}")
			.formParam("url", "https://c.cs17.visual.force.com/servlet/servlet.Integration?lid=${lid1}&ic=1&linkToken=${linkToken1}"))
            
            // Extract CSRF tokens
        .exec(http("Extract_CSRF_Tokens05")
			.post(uri05 + "/servlet/servlet.Integration?lid=${lid1}&ic=1&linkToken=${linkToken1}")
			.headers(headers_145)
			.formParam("cshc", "0000002Z1pY0000006Tt88")
			.formParam("echoScontrol", "${echoScontrol1}")
			.formParam("echoScontrolMac", "${echoScontrolMac1}")
			.formParam("ic", "1")
			.formParam("inst", "g")
			.formParam("lid", "${lid1}")
			.formParam("linkToken", "${linkToken1}")
			.formParam("originalRequestIsPost", "1")
			.formParam("sid", "${sid1}")
			.formParam("url", "https://c.cs17.visual.force.com/servlet/servlet.Integration?lid=${lid1}&ic=1&linkToken=${linkToken1}")
            .check(regex("""\"addProductToCart\",\"len\"\:3,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"addProductsToCart\"""").find.exists.saveAs("""addProductToCart1"""))
            .check(regex("""\"addProductsToCart\",\"len\"\:2,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"checkCacheEnabled\"""").find.exists.saveAs("""addProductsToCart1"""))
            .check(regex("""\"checkCacheEnabled\",\"len\"\:0,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"checkPaginationMode\"""").find.exists.saveAs("""checkCacheEnabled1"""))
            .check(regex("""\"checkPaginationMode\",\"len\"\:1,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"configureProductFromCart\"""").find.exists.saveAs("""checkPaginationMode1"""))
            .check(regex("""\"configureProductFromCart\",\"len\"\:2,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"cpqCreate\"""").find.exists.saveAs("""configureProductFromCart1"""))
            .check(regex("""\"cpqCreate\",\"len\"\:1,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"deleteImplSavedLineItems\"""").find.exists.saveAs("""cpqCreate1"""))
            .check(regex("""\"deleteImplSavedLineItems\",\"len\"\:1,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"deleteProductFromCart\"""").find.exists.saveAs("""deleteImplSavedLineItems1"""))
            .check(regex("""\"deleteProductFromCart\",\"len\"\:2,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"executeQueryableMethod\"""").find.exists.saveAs("""deleteProductFromCart1"""))
            .check(regex("""\"executeQueryableMethod\",\"len\":4,\"ns\":\"\",\"ver\":31.0,\"csrf\":\"(.+)\"\}\,\{\"name\":\"getAttributes\"""").find.exists.saveAs("""executeQueryableMethod1"""))
            .check(regex("""\"getAttributes\",\"len\"\:1,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"getCartDetails\"""").find.exists.saveAs("""getAttributes1"""))
            .check(regex("""\"getCartDetails\",\"len\"\:2,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"getCartItems\"""").find.exists.saveAs("""getCartDetails1"""))
            .check(regex("""\"getCartItems\",\"len\"\:1,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"getContextProductHierarchy\"""").find.exists.saveAs("""getCartItems1"""))
            .check(regex("""\"getContextProductHierarchy\",\"len\"\:5,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"getContextualData\"""").find.exists.saveAs("""getContextProductHierarchy1"""))
            .check(regex("""\"getContextualData\",\"len\"\:1,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"getCpqSettings\"""").find.exists.saveAs("""getContextualData1"""))
            .check(regex("""\"getCpqSettings\",\"len\"\:1,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"getOrderSummaryConfig\"""").find.exists.saveAs("""getCpqSettings1"""))
            .check(regex("""\"getOrderSummaryConfig\",\"len\":2,\"ns\":\"\",\"ver\":35.0,\"csrf\":\"(.+)\"\},\{\"name\"""").find.exists.saveAs("""getOrderSummaryConfigSUMCONFCON1"""))
            .check(regex("""\"getOrderSummaryConfig\",\"len\":2,\"ns\":\"\",\"ver\"\:31.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"getOrderSummaryDetails\",\"len\":2,\"ns\":\"\",\"ver\":31.0,\"""").find.exists.saveAs("""getOrderSummaryConfig1"""))
            .check(regex("""\"getOrderSummaryDetails\",\"len\"\:2,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"getPriceBooks\"""").find.exists.saveAs("""getOrderSummaryDetails1"""))
            .check(regex("""\"getPriceBooks\",\"len\"\:1,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"getProdAttribCheckMode\"""").find.exists.saveAs("""getPriceBooks1"""))
            .check(regex("""\"getProdAttribCheckMode\",\"len\"\:0,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"getProdConfMode\"""").find.exists.saveAs("""getProdAttribCheckMode1"""))
            .check(regex("""\"getProdConfMode\",\"len\"\:0,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"getProductForAttribCheckMode\"""").find.exists.saveAs("""getProdConfMode1"""))
            .check(regex("""\"getProductForAttribCheckMode\",\"len\"\:1,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"getProductHierarchy\"""").find.exists.saveAs("""getProductForAttribCheckMode1"""))
            .check(regex("""\"getProductHierarchy\",\"len\"\:4,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"getProductsList\"""").find.exists.saveAs("""getProductHierarchy1"""))
            .check(regex("""\"getProductsList\",\"len\"\:1,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"getProducts\"""").find.exists.saveAs("""getProductsList1"""))
            .check(regex("""\"getProducts\",\"len\"\:1,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"implicitSaveProduct\"""").find.exists.saveAs("""getProducts1"""))
            .check(regex("""\"implicitSaveProduct\",\"len\"\:4,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"isSignitureRequired\"""").find.exists.saveAs("""implicitSaveProduct1"""))
            .check(regex("""\"isSignitureRequired\",\"len\"\:1,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"nextProducts\"""").find.exists.saveAs("""isSignitureRequired1"""))
            .check(regex("""\"nextProducts\",\"len\"\:5,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"previousProducts\"""").find.exists.saveAs("""nextProducts1"""))
            .check(regex("""\"previousProducts\",\"len\"\:5,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"priceHeader\"""").find.exists.saveAs("""previousProducts1"""))
            .check(regex("""\"priceHeader\",\"len\"\:1,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"priceLineItems\"""").find.exists.saveAs("""priceHeader1"""))
            .check(regex("""\"priceLineItems\",\"len\"\:2,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"productConfSaveMode\"""").find.exists.saveAs("""priceLineItems1"""))
            .check(regex("""\"productConfSaveMode\",\"len\"\:0,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"saveProductPostConfigure\"""").find.exists.saveAs("""productConfSaveMode1"""))
            .check(regex("""\"saveProductPostConfigure\",\"len\"\:3,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"searchProducts\"""").find.exists.saveAs("""saveProductPostConfigure1"""))
            .check(regex("""\"searchProducts\",\"len\"\:4,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"setPriceBook\"""").find.exists.saveAs("""searchProducts1"""))
            .check(regex("""\"setPriceBook\",\"len\"\:2,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"updateItemQuantity\"""").find.exists.saveAs("""setPriceBook1"""))
            .check(regex("""\"updateItemQuantity\",\"len\"\:3,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"updateProductAttributes\"""").find.exists.saveAs("""updateItemQuantity1"""))
            .check(regex("""\"updateProductAttributes\",\"len\"\:2,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"updateProvisioningStatusForImplSave\"""").find.exists.saveAs("""updateProductAttributes1"""))
            .check(regex("""\"updateProvisioningStatusForImplSave\",\"len\"\:2,\"ns\"\:\"\",\"ver\"\:31\.0,\"csrf\"\:\"(.+)\"\},\{\"name\":\"validateProductConfiguration\"""").find.exists.saveAs("""updateProvisioningStatusForImplSave1"""))
            .check(regex("""\"validateProductConfiguration\",\"len\":0,\"ns\":\"\",\"ver\":31.0,\"csrf\":\"(.+)\"}\],\"prm\":0\},\"SummaryConfigController\"""").find.exists.saveAs("""validateProductConfiguration1""")))
            
            .exec( session => {
				  println( "CSRF Tokens------------------------------------------>------------------------------------------>:" )
				  println( session( "addProductToCart1" ).as[String] )
				  println( session( "addProductsToCart1" ).as[String] )
				  println( session( "checkCacheEnabled1" ).as[String] )
				  println( session( "checkPaginationMode1" ).as[String] )
				  println( session( "configureProductFromCart1" ).as[String] )
				  println( session( "cpqCreate1" ).as[String] )
				  println( session( "deleteImplSavedLineItems1" ).as[String] )
				  println( session( "deleteProductFromCart1" ).as[String] )
				  println( session( "executeQueryableMethod1" ).as[String] )
				  println( session( "getAttributes1" ).as[String] )
				  println( session( "getCartDetails1" ).as[String] )
				  println( session( "getCartItems1" ).as[String] )
				  println( session( "getContextProductHierarchy1" ).as[String] )
				  println( session( "getContextualData1" ).as[String] )
				  println( session( "getCpqSettings1" ).as[String] )
				  println( session( "getOrderSummaryConfig1" ).as[String] )
				  println( session( "getOrderSummaryDetails1" ).as[String] )
				  println( session( "getPriceBooks1" ).as[String] )
				  println( session( "getProdAttribCheckMode1" ).as[String] )
				  println( session( "getProdConfMode1" ).as[String] )
				  println( session( "getProductForAttribCheckMode1" ).as[String] )
				  println( session( "getProductHierarchy1" ).as[String] )
				  println( session( "getProductsList1" ).as[String] )
				  println( session( "getProducts1" ).as[String] )
				  println( session( "implicitSaveProduct1" ).as[String] )
				  println( session( "isSignitureRequired1" ).as[String] )
				  println( session( "nextProducts1" ).as[String] )
				  println( session( "previousProducts1" ).as[String] )
				  println( session( "priceHeader1" ).as[String] )
				  println( session( "priceLineItems1" ).as[String] )
				  println( session( "productConfSaveMode1" ).as[String] )
				  println( session( "saveProductPostConfigure1" ).as[String] )
				  println( session( "searchProducts1" ).as[String] )
				  println( session( "setPriceBook1" ).as[String] )
				  println( session( "updateItemQuantity1" ).as[String] )
				  println( session( "updateProductAttributes1" ).as[String] )
				  println( session( "updateProvisioningStatusForImplSave1" ).as[String] )
				  println( session( "validateProductConfiguration1" ).as[String] )
				  println( session( "getOrderSummaryConfigSUMCONFCON1" ).as[String] )
				  session
				})
           
            // getOrderSummaryConfigSUMCONFCON1 / getpricebooks / getContextualData / getCPQsettings / ProductConfSaveMode / issignaturerequired / getPRodAttributecheckMode / Getprodconfmode
         .exec(http("Order_Details_Page06")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0160_request.txt")))
            
            
            // deleteImplSavedLineItems
         .exec(http("deleteImplSavedLineItems07")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0173_request.txt")))
            
            // getCartItems
         .exec(http("getCartItems08")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0174_request.txt")))
            
            //GetOrderSummaryConfig
         .exec(http("GetOrderSummaryConfig09")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0175_request.txt")))
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0132_response.txt"))))
		
		.pause(minWaitMs, maxWaitMs)
				
		.exec(
            // setPriceBook
			http("setPriceBook10")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0178_request.txt"))
			.resources(
            // getPriceBooks / GetContextualdata  / GetCPQsettings / productConfSaveMode / issignaturerequired / getProdAttributeCheckMode / getProdConfMode 
			http("getPriceBooks11")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0179_request.txt")),
            
            // checkPaginationMode / checkCacheEnabled / getAttributes / getProductsList / deleteImplSavedLineItems  
            http("CPQSettings_check12")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0180_request.txt"))))
		
		.pause(minWaitMs, maxWaitMs)
		
            // getProductForAttribCheckMode / getCartItems
		.exec(http("getCartItems13")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0182_request.txt")))

		.pause(minWaitMs, maxWaitMs)
		// GetOrderSummaryConfig
		.exec(http("GetOrderSummaryConfig14")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0183_request.txt")))
		
		.pause(minWaitMs, maxWaitMs)
		
		.exec(

			//.resources(
			http("LoadHybridCPQ_page15")
			.get(uri05 + "/apex/hybridcpq?id=${OrderID}")
			.headers(headers_5)
            .check(regex("""deleteCard\",\"len\"\:1,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"deleteCardById\"""").find.exists.saveAs("""deleteCard1"""))
            .check(regex("""deleteCardById\",\"len\"\:1,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"deleteLayout\"""").find.exists.saveAs("""deleteCardById1"""))
            .check(regex("""deleteLayout\",\"len\"\:1,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"deleteLayoutById\"""").find.exists.saveAs("""deleteLayout1"""))
            .check(regex("""deleteLayoutById\",\"len\"\:1,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"deleteTemplate\"""").find.exists.saveAs("""deleteLayoutById"""))
            .check(regex("""deleteTemplate\",\"len\"\:1,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"doCheckClassType\"""").find.exists.saveAs("""deleteTemplate1"""))
            .check(regex("""doCheckClassType\",\"len\"\:2,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"doGenericInvoke\"""").find.exists.saveAs("""doCheckClassType1"""))
            .check(regex("""doGenericInvoke\",\"len\"\:4,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"doNamedCredentialCallout\"""").find.exists.saveAs("""doGenericInvoke1"""))
            .check(regex("""doNamedCredentialCallout\",\"len\"\:1,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getAccountById\"""").find.exists.saveAs("""doNamedCredentialCallout1"""))
            .check(regex("""getAccountById\",\"len\"\:1,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getAccounts\"""").find.exists.saveAs("""getAccountById1"""))
            .check(regex("""getAccounts\",\"len\"\:0,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getActionDetails\"""").find.exists.saveAs("""getAccounts1"""))
            .check(regex("""getActionDetails\",\"len\"\:4,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getActions\"""").find.exists.saveAs("""getActionDetails1"""))
            .check(regex("""getActions\",\"len\"\:2,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getActionsInfo\"""").find.exists.saveAs("""getActions1"""))
            .check(regex("""getActionsInfo\",\"len\"\:0,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getActiveTemplateNames\"""").find.exists.saveAs("""getActionsInfo1"""))
            .check(regex("""getActiveTemplateNames\",\"len\"\:0,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getAllCardDefinitions\"""").find.exists.saveAs("""getActiveTemplateNames1"""))
            .check(regex("""getAllCardDefinitions\",\"len\"\:0,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getAllLayouts\"""").find.exists.saveAs("""getAllCardDefinitions1"""))
            .check(regex("""getAllLayouts\",\"len\"\:0,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getAllObjects\"""").find.exists.saveAs("""getAllLayouts1"""))
            .check(regex("""getAllObjects\",\"len\"\:0,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getCardByName\"""").find.exists.saveAs("""getAllObjects1"""))
            .check(regex("""getCardByName\",\"len\"\:1,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getCardDefinitionsForIds\"""").find.exists.saveAs("""getCardByName"""))
            .check(regex("""getCardDefinitionsForIds\",\"len\"\:1,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getCardsByNames\"""").find.exists.saveAs("""getCardDefinitionsForIds1"""))
            .check(regex("""getCardsByNames\",\"len\"\:1,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getConsoleCardsAction\"""").find.exists.saveAs("""getCardsByNames1"""))
            .check(regex("""getConsoleCardsAction\",\"len\"\:2,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getCustomLabelValue\"""").find.exists.saveAs("""getConsoleCardsAction1"""))
            .check(regex("""getCustomLabelValue\",\"len\"\:1,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getCustomLabels\"""").find.exists.saveAs("""getCustomLabelValue1"""))
            .check(regex("""getCustomLabels\",\"len\"\:2,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getCustomSettings\"""").find.exists.saveAs("""getCustomLabels1"""))
            .check(regex("""getCustomSettings\",\"len\"\:1,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getDataViaDataRaptor\"""").find.exists.saveAs("""getCustomSettings1"""))
            .check(regex("""getDataViaDataRaptor\",\"len\"\:2,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getDataViaDynamicSoql\"""").find.exists.saveAs("""getDataViaDataRaptor1"""))
            .check(regex("""getDataViaDynamicSoql\",\"len\"\:1,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getDatasourceQuery\"""").find.exists.saveAs("""getDataViaDynamicSoql1"""))
            .check(regex("""getDatasourceQuery\",\"len\"\:1,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getFieldsForObject\"""").find.exists.saveAs("""getDatasourceQuery1"""))
            .check(regex("""getFieldsForObject\",\"len\"\:1,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getLayoutByName\"""").find.exists.saveAs("""getFieldsForObject1"""))
            .check(regex("""getLayoutByName\",\"len\"\:1,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getLayout\"""").find.exists.saveAs("""getLayoutByName1"""))
            .check(regex("""getLayout\",\"len\"\:2,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getLayoutsInfo\"""").find.exists.saveAs("""getLayout1"""))
            .check(regex("""getLayoutsInfo\",\"len\"\:0,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getStaticResourcesUrl\"""").find.exists.saveAs("""getLayoutsInfo1"""))
            .check(regex("""getStaticResourcesUrl\",\"len\"\:0,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getTemplate\"""").find.exists.saveAs("""getStaticResourcesUrl1"""))
            .check(regex("""getTemplate\",\"len\"\:1,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getTemplateByName\"""").find.exists.saveAs("""getTemplate1"""))
            .check(regex("""getTemplateByName\",\"len\"\:1,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getTemplatesByNames\"""").find.exists.saveAs("""getTemplateByName1"""))
            .check(regex("""getTemplatesByNames\",\"len\"\:1,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getTemplatesInfo\"""").find.exists.saveAs("""getTemplatesByNames1"""))
            .check(regex("""getTemplatesInfo\",\"len\"\:0,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getTemplates\"""").find.exists.saveAs("""getTemplatesInfo1"""))
            .check(regex("""getTemplates\",\"len\"\:0,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"getUserProfile\"""").find.exists.saveAs("""getTemplates1"""))
            .check(regex("""getUserProfile\",\"len\"\:0,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"saveCard\"""").find.exists.saveAs("""getUserProfile1"""))
            .check(regex("""saveCard\",\"len\"\:1,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"saveLayout\"""").find.exists.saveAs("""saveCard1"""))
            .check(regex("""saveLayout\",\"len\"\:1,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"saveTemplate\"""").find.exists.saveAs("""saveLayout1"""))
            .check(regex("""saveTemplate\",\"len\"\:1,\"ns\":\"\",\"ver\":32.0,\"csrf\":\"(.+)\"\},\{\"name\":\"trackVlocityInteraction\"""").find.exists.saveAs("""saveTemplate1"""))
            .check(regex("""\{\"vf\"\:\{\"vid\"\:\"(.+)\",\"xhr\"""").find.exists.saveAs("""vid2""")))

            .exec(
            //GetactiveTemplateNames
            http("GetactiveTemplateNames16")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0191_request.txt")))
			//.check(regex("""statusCode\"\:200""").find.exists))
			
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0191_response.txt"))),
            .exec(
            //GetactionsInfo
            http("GetactionsInfo17")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0192_request.txt")))
			//.check(regex("""statusCode\"\:200""").find.exists))
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0192_response.txt"))),
           .exec(
            // GetUserProfile
            http("GetUserProfile18")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0193_request.txt")))
			//.check(regex("""statusCode\"\:200""").find.exists))
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0193_response.txt"))),
            .exec(
            //Getcustomsettings
            http("Getcustomsettings_CardFrwrk19")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0194_request.txt")))
			//.check(regex("""statusCode\"\:200""").find.exists))
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0194_response.txt"))),
            .exec(
            // Getcustomsettings
            http("Getcustomsettings_CPQConfig20")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0195_request.txt")))
			//.check(regex("""statusCode\"\:200""").find.exists))
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0195_response.txt"))),
            .exec(
            // getcustomLabels
            http("getcustomLabels21")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0196_request.txt")))
			//.check(regex("""statusCode\"\:200""").find.exists))
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0196_response.txt"))),
            .exec(
            // DoGenericInvoke - getCartItems
            http("DoGenericInvoke-getCartItems22")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0197_request.txt")))
			//.check(regex("""statusCode\"\:200""").find.exists))
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0197_response.txt"))),
            .exec(
            // DoGenericInvoke - getCarts 
            http("DoGenericInvoke-getCarts23")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0198_request.txt")))
			//.check(regex("""statusCode\"\:200""").find.exists))
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0198_response.txt"))),
            .exec(
            // DoGenericInvoke - getCartsProducts
            http("DoGenericInvoke-getCartsProducts24")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0199_request.txt")))
			//.check(regex("""statusCode\"\:200""").find.exists))
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0199_response.txt"))),
            .exec(
            // DoGenericInvoke - getCarts
            http("DoGenericInvoke-getCarts25")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0200_request.txt")))
			//.check(regex("""statusCode\"\:200""").find.exists))
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0200_response.txt"))),
            
            .exec(           
            //getcustomLabels
            http("getcustomLabels_CardFrwk26")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0203_request.txt")))
			//.check(regex("""statusCode\"\:200""").find.exists))
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0203_response.txt"))),
            .exec(
            //getcustomLabels
            http("getcustomLabels27")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0206_request.txt")))
			//.check(regex("""statusCode\"\:200""").find.exists))
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0206_response.txt"))))
		
		.pause(minWaitMs, maxWaitMs)
		
				
		// DoGenericInvoke - getCartsProducts
		.exec(http("DoGenericInvoke-getCartsProducts28")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0209_request.txt")))
			//.check(regex("""statusCode\"\:200""").find.exists)) 
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0209_response.txt"))))
		
		.pause(minWaitMs, maxWaitMs)
		// DoGenericInvoke - postCartsItems
		.exec(http("DoGenericInvoke-postCartsItems29")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0210_request.txt")))
			//.check(regex("""statusCode\"\:200""").find.exists))
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0210_response.txt"))))
		.pause(minWaitMs, maxWaitMs)
		
		.exec(
            // DoGenericInvoke - getCarts
			http("DoGenericInvoke-getCarts30")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0211_request.txt"))
			//.check(regex("""statusCode\"\:200""").find.exists)
			.resources(
            // GetLayout
			http("GetLayout31")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0212_request.txt")),
			//.check(regex("""statusCode\"\:200""").find.exists),
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0212_response.txt"))),
            
            // GetcardsByNames
            http("GetcardsByNames32")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0214_request.txt")),
			//.check(regex("""statusCode\"\:200""").find.exists),
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0214_response.txt"))),
            // getTemplate 
            http("getTemplate_itemProd33")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0215_request.txt")),
			//.check(regex("""statusCode\"\:200""").find.exists),
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0215_response.txt"))),
            // getTemplate
            http("getTemplate_ItemChild34")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0216_request.txt"))))
			//.check(regex("""statusCode\"\:200""").find.exists)))
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0216_response.txt"))))
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0211_response.txt"))))
		.pause(minWaitMs, maxWaitMs)
		
		.exec(http("TrackvLocity35")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0217_request.txt")))
			//.check(regex("""statusCode\"\:200""").find.exists))
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0217_response.txt"))))
		.pause(minWaitMs, maxWaitMs)
		.exec(
            // GetLayout
			http("GetLayout36")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0218_request.txt"))
			//.check(regex("""statusCode\"\:200""").find.exists)
			.resources(
            // GetcardsByNames
			http("GetcardsByNames37")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0219_request.txt")),
			//.check(regex("""statusCode\"\:200""").find.exists),
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0219_response.txt"))),
            //DoGenericInvoke - getCartsItemsByID
            http("DoGenericInvoke-getCartsItemsByID38")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0220_request.txt"))))
			//.check(regex("""statusCode\"\:200""").find.exists)))
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0220_response.txt"))))
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0218_response.txt"))))
		.pause(minWaitMs, maxWaitMs)
		.exec(
            // getTemplate
			http("getTemplate_cartItem39")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0221_request.txt")))
			//.check(regex("""statusCode\"\:200""").find.exists))
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0221_response.txt"))))
		.pause(minWaitMs, maxWaitMs)
				
		.exec(
            // getexpandedItems
			http("getexpandedItems40")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0223_request.txt")))
			//.check(regex("""statusCode\"\:200""").find.exists))
			
			.exec(
            // getcustomlabels
			http("getcustomLabels_CardFrwk41")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0224_request.txt")))
			//.check(regex("""statusCode\"\:200""").find.exists))
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0224_response.txt"))))
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0223_response.txt"))))
		.pause(minWaitMs, maxWaitMs)
				
		.exec(
            // PutcartsItems
			http("DoGenericInvoke_PutcartsItems42")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0226_request.txt"))
			.check(regex("""statusCode\"\:200""").find.exists))
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0226_response.txt"))))
		.pause(minWaitMs, maxWaitMs)
		// DoGenericInvoke getCarts
		.exec(http("DoGenericInvoke_getCarts43")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0227_request.txt"))
			.check(regex("""statusCode\"\:200""").find.exists))
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0227_response.txt"))))
		.pause(minWaitMs, maxWaitMs)
		.exec(
            // PutcartsItems
			http("DoGenericInvoke_PutcartsItems44")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0228_request.txt")))
			//.check(regex("""statusCode\"\:200""").find.exists))

		 .exec(
            // DoGenericInvoke getCarts
            http("DoGenericInvoke_getCarts45")
			.post("/apexremote")
			.headers(headers_160)
			.body(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0230_request.txt"))
			.check(regex("""statusCode\"\:200""").find.exists))
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0230_response.txt"))))
			//.check(bodyBytes.is(ElFileBody("./src/test/resources/bodies/hcpq/HCPQsimulation_0228_response.txt"))))		
  }
