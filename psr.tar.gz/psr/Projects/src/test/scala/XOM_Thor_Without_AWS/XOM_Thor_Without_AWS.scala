  package XOM_Thor_Without_AWS

  import scala.concurrent.duration._
  import io.gatling.core.Predef._
  import io.gatling.core.structure.ChainBuilder
  import io.gatling.http.Predef._
  import io.gatling.jdbc.Predef._
  import io.gatling.jsonpath._
  import Headers._
  import scala.collection._
  import java.time.format.DateTimeFormatter
  import java.time.LocalDateTime
  import java.time.LocalDate

  import io.gatling.core.feeder._
import java.util.Base64
import java.nio.charset.StandardCharsets
import scala.util.matching.Regex


   object XOM_Thor_Without_AWS {

      val uri01 = Configuration.Uri01
      val uri05 = Configuration.Uri05
      val uri10 = Configuration.Uri10
      val randomNumber = new scala.util.Random
      var accountName = new StringBuilder()     
      var session_ids = Vector[String]()
      var xomSubmitOrder = new StringBuilder()
      val userFeeder = csv("./src/test/resources/data/xomthor/XOM_Thor_Users.csv").random
       val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
  val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
  val password_v = (passwordByEnv.get("perf3").toString)
  val password_encoded = password_v.substring(12,(password_v.length - 2 ))
  val credentials = new String(Base64.getDecoder.decode(password_encoded))

      val productFeeder = csv("./src/test/resources/data/xomthor/XOM_Thor_Products_10lineitem.csv").random
      val accountFeeder = csv("./src/test/resources/data/xomthor/XOM_Thor_Accounts_V1.csv").circular
      
  	  val scn = scenario("XOM_Thor_Without_AWS")
      
      .feed(userFeeder)       
      .exec(http("XOM_Login")
          .post(uri01 + "/")
          .headers(headers_00)
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          .formParam("startURL", "")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          .formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "M1D2l15jFvl")
          .formParam("display", "page")
          .formParam("username", "${username}")
          .formParam("pw", "${password}")
          .formParam("Login", ""))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("RESTGetOAuthToken")
          .post("https://test.salesforce.com/services/oauth2/token")
          .header("Content-Type", "application/x-www-form-urlencoded")
          .formParam("password", "${password}")
          .formParam("username", "${username}")
          .formParam("client_secret", "7119599995527965426")
          .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
          .formParam("grant_type", "password")
          .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
          .check(status.is(200)))

      .repeat(6000)
      {
        /***************************************************** start of creating new account with Order**********************************/

         /*exec(session => session.set("AccountName",""))

        .exec( session => {
              val random_index = randomNumber.nextInt(100000)
              accountName.append("Acc-v2json25jan-"+random_index)
              session
            })

            .exec(session => session.set("AccountName",accountName))

             .exec( session => {
              accountName = new StringBuilder()
              session
            })

      // *********** CreateAccount ***********
         .exec(http("CreateAccount")
              .post(uri10 +"/services/data/v41.0/sobjects/account")
              .headers(header_1)
              .check(regex(""""id":"(.*?)"""").find.exists.saveAs("AccountId"))
              .body( StringBody("""
                {
                      "Name" : "${AccountName}",
                      "ShippingCity" : "San Francisco",
                      "RecordTypeId" : "012g00000005CoWAAU",
                      "Status__c"    : "Active"
                }""")).asJson) 

           /* *********** CreateAOrder *********** */*/
      feed(accountFeeder)
      .exec(http("Create a new order")
          .post(uri10 +"/services/apexrest/v2/carts")
          .headers(header_1)
          .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
          .body(StringBody("""{"subaction":"createOrder",
                    "inputFields":[
                      {"AccountId":"${AccountId}"},
                      {"PriceListId__c":"a2Pg0000001UvvuEAC"},
                      {"Name":"NewOrder1"},{"Status":"Draft"},
                      {"EffectiveDate":"04/23/2018"}
                    ]}""")).asJson)
     

      .exec(http("Order_Detail")
          .get(uri10 + "/${OrderID}")
          .headers(headers_05) 
          //.check(regex("""sforce.connection.sessionId = '(.+)'; }\n...[a-zA-Z0-9\s*'_,:{.(]*name: 'XOMSubmitOrder'""").find.exists.saveAs("""sfdc_session_id""")))
          .check(regex("""sforce.connection.sessionId = '(.+)';.}[a-zA-Z0-9\s{.('_,:]*name:.'XOMSubmitOrder'}""").find.exists.saveAs("""sfdc_session_id""")))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)  

      .feed(productFeeder)
      .exec(http("Add items to cart") 
          .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
          .headers(header_1)
          .check(regex(""""messages":\[\{"code":"150","severity":"INFO","message":"Successfully(......)""").find.exists.saveAs("AddStatus"))
          .body( StringBody("""{"methodName":"postCartsItems","items":[{"itemId":"${ProductId}"}],"cartId":"${OrderID}","price":true,"validate":true,"includeAttachment":false,"pagesize":10,"lastRecordId":null,"hierarchy":-1,"query":"plan"}""")).asJson)

       .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("Order Update")
          .put(uri10 + "/services/apexrest/Orders/")
          .headers(header_1)
          .check(regex("""status":"Update succeeded""").find.exists)
          .body( StringBody("""[{"orderId":"${OrderID}","state":"Activated"}]""")).asJson) 

          .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds) 

    } 

  }
