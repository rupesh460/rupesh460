package DC_ldv2_WP_AWS_Loggedin_ABO

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import Headers.header_1
import Headers.header_1


object DC_WP_AWS_ABO
{

	val uri01 = Configuration.Uri01
	val uri02 = Configuration.Uri02_AWS
	val offerFeeder = csv("./src/test/resources/data/DC_WP/ldv2_offercodes.csv").random
	val contextFeeder = csv("./src/test/resources/data/DC_WP/ldv2_contextdimensions.csv").random
	val promoFeeder = csv("./src/test/resources/data/DC_WP/ldv2_promocodes.csv").random
	val accountFeeder = csv("./src/test/resources/data/DC_WP/ldv2_accounts.csv").random
	val assetToBasket= csv("./src/test/resources/data/DC_WP/ldv2_23LI_assettobasketIds.csv").circular
	val assetToBaskets7= csv("./src/test/resources/data/DC_WP/ldv2_23LI_assettobasketIds_s7.csv").circular
	
	// Here we need to add ABO's scripts and scenario to be included in scn file

		val script6ABODisconnect = scenario("SF_DC_Loggedin_Script_6_ABO_Disconnect")

		.repeat(10000)
		{
			/* ***************************************** ASSET TO BASKET (ABO) ********************************* */
			feed(assetToBasket)
			.exec(http("s6_ABOgetLoggedinCKForAsset")
			.get(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/offers?context={"accountId":"${AccountId_Asset}"}&isloggedin=true""")
			.headers(header_1)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""contextKey":"(.+?)".""").find.exists.saveAs("LoggedinCKAsset")))

			.pause(Configuration.script6_ABODisconnect_minWaitMs milliseconds, Configuration.script6_ABODisconnect_maxWaitMs milliseconds)

			/* ********* Call to getOffers ************* */
			.exec(http("s6_ABOGetOffersByCatalogKnownUser")
			.get(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/offers?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
			.headers(header_1)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""contextKey":"(.+?)".""").find.exists.saveAs("ABOgetOffersCK")))

			.pause(Configuration.script6_ABODisconnect_minWaitMs milliseconds, Configuration.script6_ABODisconnect_maxWaitMs milliseconds)

			.feed(offerFeeder)
			.exec(http("s6_ABOGetOfferDetailsKnownUser")
			.get(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/offers/${OfferCode}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
			.headers(header_1)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""contextKey""").find.exists)
			.check(bodyString.saveAs("OfferDetailsResKnownUser")).asJson)

			.pause(Configuration.script6_ABODisconnect_minWaitMs milliseconds, Configuration.script6_ABODisconnect_maxWaitMs milliseconds)

			/* ********** ConfigureOffer  V105 *********** */
			.exec(http("s6_ABOConfigureOfferKnownUser")
			.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/offers/${OfferCode}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
			.headers(header_1)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.body(StringBody("""${OfferDetailsResKnownUser}""")).asJson
			.check(regex("""contextKey""").find.exists)
			//.body(ElFileBody("./src/test/resources/bodies/DC_WP/eCom-Prod-Bnd-15399454256600.txt")).asJson
			.check(regex(""""result":(.+?)."errorCode":"INVOKE""").find.exists.saveAs("AddWithConfigKnownUser")))

			.pause(Configuration.script6_ABODisconnect_minWaitMs milliseconds, Configuration.script6_ABODisconnect_maxWaitMs milliseconds)

			/* ********** AssetToBasket V105 *********** This should be the first call as per sheet****************/
	 
	.exec(http("s6_ABOAssetToBasketKnownUser")
	.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket?context={"accountId":"${AccountId_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
	.headers(header_1)
	.check(status.is(200))
	.check(status.not(404), status.not(500),status.not(504),status.not(503))
	.check(regex("""assetReferenceKey":"(.+?)",""").optional.saveAs("AssetRefKeyKnownUser"))
	.check(regex("""assetReferenceKey":"(.+?)",""").count.saveAs("AssetRefKeyCountKnownUser"))
	.check(regex("""cartContextKey":"(.+?)",""").find.exists.saveAs("CartContextKeyAssetToBasketKnownUser"))
	.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("ABOProdBundleContextKeyKnownUserWNC")).asJson
	.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("ABOProdLineItemKeyKnownUserWNC")).asJson
	//for 23 LI
	.check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.addChildBasketAction.rest.params.parentLineItemKey""").optional.saveAs("ABOparentLineItemKeyKnownUser")).asJson
	.check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.addChildBasketAction.rest.params.parentHierarchyPath""").optional.saveAs("ABOparentHierarchyPathKnownUser")).asJson
	.check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.addChildBasketAction.rest.params.offer""").optional.saveAs("ABOofferKnownUser")).asJson
	.check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.addChildBasketAction.rest.params.basketAction""").optional.saveAs("ABObasketActionKnownUser")).asJson
	.check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.addChildBasketAction.rest.params.bundleContextKey""").optional.saveAs("ABObundleContextKeyKnownUser")).asJson
	.body(StringBody("""{"rootAssetIds":"${RootItemId__c_Asset}","basketAction":"assetToBasket","requestDateTime":"2020-07-24T00:00:00.000z"}""")).asJson)

			.pause(Configuration.script6_ABODisconnect_minWaitMs milliseconds, Configuration.script6_ABODisconnect_maxWaitMs milliseconds)
			
			/* ********** DeleteFromBasket *********** */
			.exec(http("s6_ABODeleteFromBasketKnownUser")
			.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAssetToBasketKnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
			.headers(header_1)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.body(StringBody("""{"deleteBundleNumber":"0","basketAction":"DeleteFromBasket"}""")).asJson)

			.pause(Configuration.script6_ABODisconnect_minWaitMs milliseconds, Configuration.script6_ABODisconnect_maxWaitMs milliseconds)

			/* ********** DeleteProductAPI *********** */
			.exec(http("s6_ABODeleteProdKnownUser")
			.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAssetToBasketKnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
			.headers(header_1)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyDeleteProdKnownUser"))
			.body(StringBody("""{"bundleContextKey":"${ABOProdBundleContextKeyKnownUserWNC}","basketAction":"deleteFromBasket","itemKey":"${ABOProdLineItemKeyKnownUserWNC}"}""")).asJson)

			.pause(Configuration.script6_ABODisconnect_minWaitMs milliseconds, Configuration.script6_ABODisconnect_maxWaitMs milliseconds)

			/* ***** AddPromotion-Step1 V105 ******* */
			.feed(promoFeeder)
			.exec(http("s6_ABOAddPromotion-Step1KnownUser")
			.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAssetToBasketKnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
			.headers(header_1)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAddPromotion-Step1KnownUser"))
			.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAssetToBasketKnownUser"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("TransKeyKnownUser"))
			.check(regex("""cartContextKey(.+?)""").optional.saveAs("CreateCartKnownUser"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("TransKeyCountKnownUser"))
			.body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}"}""")).asJson)

			.pause(Configuration.script6_ABODisconnect_minWaitMs milliseconds, Configuration.script6_ABODisconnect_maxWaitMs milliseconds)

			.doIfEquals("${TransKeyCountKnownUser}", 0) {

				exec(http("s6_ABOGetBasketDetailsKnownUser")
				.get(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step1KnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
				.headers(header_1)
				.check(status.is(200))
				.check(status.not(404), status.not(500), status.not(504), status.not(503))
				.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyGetBasketDetailsKnownUser"))
				.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").find.exists.saveAs("DelProdBundleContextKeyKnownUser")).asJson
				.check(jsonPath("""$.result.records[0].promotions.records[0].actions.deletePromotionBasketAction.rest.params.offer""").optional.saveAs("DelPromoKnownUser")).asJson)

				.pause(Configuration.script6_ABODisconnect_minWaitMs milliseconds, Configuration.script6_ABODisconnect_maxWaitMs milliseconds)

				.exec(http("s6_ABOAssetToBasketCreateCartKnownUser")
				.post(uri02 + """/v3/carts?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
				.headers(header_1)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex("""orderId":"(.+?)"""").find.exists.saveAs("OrderIdKnownUser"))
				.body(StringBody("""{"cartContextKey":"${CartContextKeyAddPromotion-Step1KnownUser}","accountId": "${AccountId_Asset}","catalogCode": "DC-WP-Cat-for-LI-products"}""")).asJson)

				.pause(Configuration.script6_ABODisconnect_minWaitMs milliseconds, Configuration.script6_ABODisconnect_maxWaitMs milliseconds)
			}

			.doIfEquals("${TransKeyCountKnownUser}", 1) {

				/* ********** AddPromotion-Step2 V105 *********** */
				//feed(promoFeeder)
				exec(http("s6_ABOAddPromotion-Step2KnownUser")
				.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAssetToBasketKnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
				.headers(header_1)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyAddPromotion-Step2KnownUser"))
				.check(regex("""cartContextKey(.+?)""").find.exists.saveAs("CreateCartKnownUser"))
				.body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}","multiTransactionKey":"${TransKeyKnownUser}"}""")).asJson)

				.pause(Configuration.script6_ABODisconnect_minWaitMs milliseconds, Configuration.script6_ABODisconnect_maxWaitMs milliseconds)

				.exec(http("s6_ABOGetBasketDetailsKnownUser")
				.get(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step2KnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
				.headers(header_1)
				.check(status.is(200))
				.check(status.not(404), status.not(500), status.not(504), status.not(503))
				.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyGetBasketDetailsKnownUser"))
				.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").find.exists.saveAs("DelProdBundleContextKeyKnownUser")).asJson
				.check(jsonPath("""$.result.records[0].promotions.records[0].actions.deletePromotionBasketAction.rest.params.offer""").optional.saveAs("DelPromoKnownUser")).asJson)

				.pause(Configuration.script6_ABODisconnect_minWaitMs milliseconds, Configuration.script6_ABODisconnect_maxWaitMs milliseconds)

				.exec(http("s6_ABOAssetToBasketCreateCartKnownUser")
				.post(uri02 + """/v3/carts?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
				.headers(header_1)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex("""orderId":"(.+?)"""").find.exists.saveAs("OrderIdKnownUser"))
				.body(StringBody("""{"cartContextKey":"${CartContextKeyAddPromotion-Step2KnownUser}","accountId": "${AccountId_Asset}","catalogCode": "DC-WP-Cat-for-LI-products"}""")).asJson)

				.pause(Configuration.script6_ABODisconnect_minWaitMs milliseconds, Configuration.script6_ABODisconnect_maxWaitMs milliseconds)

			}

			.exec(flushSessionCookies)
			.exec(flushCookieJar)
			.exec(flushHttpCache)
		}
		
		/* ********************************* Add Entire Scenarion - Script7 ABO ACD - Loggedin***************************************** */
		/* ********************************* Add Entire Scenarion - Script7 ABO ACD - Loggedin***************************************** */

		val script7ABOACD = scenario("SF_DC_KnownUser_Script_7_ABO_ACD")

		.repeat(10000)
		{
			/* ***************************************** LOGGEDIN  ********************************* */
			
			/* ********* Call to get contextKey  ************* */
			feed(accountFeeder)
			.exec(http("s7_getLoggedinCK")
			.get(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/offers?context={"accountId":"${AccountId}"}&isloggedin=true""")
			.headers(header_1)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""contextKey":"(.+?)".""").find.exists.saveAs("LoggedinCK")))

			.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

			/* ********** GetOffersByCatalogKnownUser V105 *********** */
		.exec(http("s7_GetOffersByCatalogKnownUser")
		.get(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/offers?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
		.headers(header_1)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""contextKey""").find.exists)
		.check(jsonPath("$.offers[*].ProductCode").findAll.saveAs("ProductOffersListKnownUser")))

		.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)
			
			.feed(offerFeeder)
			.exec(http("s7_GetOfferDetailsKnownUser")
			.get(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/offers/${OfferCode}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
			.headers(header_1)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""contextKey""").find.exists)
			.check(bodyString.saveAs("OfferDetailsResKnownUser")).asJson)

			.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

			/* ********** ConfigureOffer  V105 *********** */
			.exec(http("s7_ConfigureOfferKnownUser")
			.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/offers/${OfferCode}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
			.headers(header_1)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.body(StringBody("""${OfferDetailsResKnownUser}""")).asJson
			.check(regex("""contextKey""").find.exists)
			//.body(ElFileBody("./src/test/resources/bodies/DC_WP/eCom-Prod-Bnd-15399454256600.txt")).asJson
			.check(regex(""""result":(.+?)."errorCode":"INVOKE""").find.exists.saveAs("AddWithConfigKnownUser")))

			.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

			/* ********** AddWithNoConfig V105 *********** */
			.exec(http("s7_AddToCartWithNoConfigKnownUser")
			.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
			.headers(header_1)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyAddToCartWithNoConfigKnownUser")).asJson
			.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("ProdBundleContextKeyKnownUserWNC")).asJson
			.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("ProdLineItemKeyKnownUserWNC")).asJson
			.body(StringBody("""{"offer":"${OfferCode}","basketAction":"AddWithNoConfig"}""")).asJson)

			.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

			/* ********** AddWithConfig V105 *********** */
			.exec(http("s7_AddToCartWithConfigKnownUser")
			.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
			.headers(header_1)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAddToCartWithConfigKnownUser"))
			.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_ATCWC")).asJson
			.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_ATCWC_Count"))
			.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("ProdBundleContextKeyKnownUser")).asJson
			.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("ProdLineItemKeyKnownUser")).asJson
			.body(StringBody("""{"basketAction":"AddAfterConfig","productConfig":${AddWithConfigKnownUser}}""")).asJson)

			.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)


			.doIfEquals("${MultiTransactionKeyLoggedin_ATCWC_Count}",1)
			{

				doWhile(session => session("MultiTransactionKeyLoggedin_ATCWC_Count").as[String].equals("1"))
				{

					exec {

						session =>
						val addAfterConfigSession_AddToCart = session("AddWithConfigKnownUser").as[String]
						val buildStringAddWithConfig_AddToCart = addAfterConfigSession_AddToCart.substring(1)
						val finalbuildStringAddWithConfig_AddToCart = session("MultiTransactionKeyLoggedin_ATCWC").as[String]

						session.set("AddWithConfigKnownUserATC_MTS", finalbuildStringAddWithConfig_AddToCart)

					}

					/* ********** AddWithConfig *********** */
					.exec(http("s7_AddToCartWithConfigKnownUser_MTS")
					.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
					.headers(header_1)
					.check(status.is(200))
					.check(regex("""cartContextKey""").optional.saveAs("cartContextKeyPollCheck"))
					.check(status.not(404), status.not(500), status.not(504), status.not(503))
					.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAddToCartWithConfigKnownUser"))
					.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_ATCWC")).asJson
					.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_ATCWC_Count"))
					.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("ProdBundleContextKeyKnownUser")).asJson
					.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("ProdLineItemKeyKnownUser")).asJson
					.body(StringBody("""{"basketAction":"AddAfterConfig","multiTransactionKey":"${AddWithConfigKnownUserATC_MTS}","productConfig":${AddWithConfigKnownUser}}""")).asJson)

					.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

				}

			}

			/* ** UpdateExistingBasket-UpdQty V105 ******* */
			.exec(http("s7_UpdateBasketQtyKnownUser")
			.put(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
			.headers(header_1)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyUpdateBasketQtyKnownUser"))
			.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_UBQ")).asJson
			.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_UBQ_Count"))
			.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("PromoBundleContextKeyKnownUser")).asJson
			.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("PromoLineItemKeyKnownUser")).asJson
			.body(StringBody("""{"bundleContextKey":"${ProdBundleContextKeyKnownUserWNC}","lineItemKey":"${ProdLineItemKeyKnownUserWNC}","basketAction":"updateBasket","Quantity":"3"}""")).asJson)

			.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

			.doIfEquals("${MultiTransactionKeyLoggedin_UBQ_Count}",1)
			{
				doWhile(session => session("MultiTransactionKeyLoggedin_UBQ_Count").as[String].equals("1"))
				{
					/* ** UpdateExistingBasket-UpdQty V105 ******* */
					exec(http("s7_UpdateBasketQtyKnownUser_MTS")
					.put(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
					.headers(header_1)
					.check(status.is(200))
					.check(status.not(404), status.not(500),status.not(504),status.not(503))
					.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyUpdateBasketQtyKnownUser"))
					.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_UBQ")).asJson
					.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_UBQ_Count"))
					.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("PromoBundleContextKeyKnownUser")).asJson
					.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("PromoLineItemKeyKnownUser")).asJson
					.body(StringBody("""{"bundleContextKey":"${ProdBundleContextKeyKnownUserWNC}","lineItemKey":"${ProdLineItemKeyKnownUserWNC}","basketAction":"updateBasket","Quantity":"3"}""")).asJson)
				
					.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

				}
			}

			/* **** UpdateExistingBasket-UpdAttrib V105 *** CHANGE THIS ###################### */
			.exec(http("s7_UpdateBasketAttribKnownUser")
			.put(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyUpdateBasketQtyKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
			.headers(header_1)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_UBA")).asJson
			.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_UBA_Count"))
			.check(regex(""""cartContextKey":"(.+?)",""").optional.saveAs("CartContextKeyUpdateBasketAttribKnownUsers"))
			.body(ElFileBody("./src/test/resources/bodies/DC_WP/DC_WP_Loggedin_UpdateBasketAttribute.txt")).asJson)

			.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

			.doIfEquals("${MultiTransactionKeyLoggedin_UBA_Count}",1)
			{
				doWhile(session => session("MultiTransactionKeyLoggedin_UBA_Count").as[String].equals("1"))
				{
					/* **** UpdateExistingBasket-UpdAttrib V105 *** CHANGE THIS ###################### */
					exec(http("s7_UpdateBasketAttribKnownUser_MTS")
					.put(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyUpdateBasketQtyKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
					.headers(header_1)
					.check(status.is(200))
					.check(status.not(404), status.not(500),status.not(504),status.not(503))
					.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_UBA")).asJson
					.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_UBA_Count"))
					.check(regex(""""cartContextKey":"(.+?)",""").optional.saveAs("CartContextKeyUpdateBasketAttribKnownUsers"))
					.body(ElFileBody("./src/test/resources/bodies/DC_WP/DC_WP_Loggedin_UpdateBasketAttribute_MTS.txt")).asJson)

					.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

				}
			}

			/* ********** DeleteFromBasket *********** */
			.exec(http("s7_DeleteFromBasketKnownUser")
			.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
			.headers(header_1)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			//.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyDeleteFromBasketKnownUser"))
			.body(StringBody("""{"deleteBundleNumber":"0","basketAction":"DeleteFromBasket"}""")).asJson)

			.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

			/* ********** DeleteProductAPI *********** */
			.exec(http("s7_DeleteProdKnownUser")
			.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
			.headers(header_1)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyDeleteProdKnownUser"))
			.body(StringBody("""{"bundleContextKey":"${ProdBundleContextKeyKnownUserWNC}","basketAction":"deleteFromBasket","itemKey":"${ProdLineItemKeyKnownUserWNC}"}""")).asJson)

			.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)


			/* ***** AddPromotion-Step1 V105 ******* */
			.feed(promoFeeder)
			.exec(http("s7_AddPromotion-Step1KnownUser")
			.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
			.headers(header_1)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAddPromotion-Step1KnownUser"))
			.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAddToCartWithNoConfigKnownUser"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("TransKeyKnownUser"))
			.check(regex("""cartContextKey(.+?)""").optional.saveAs("CreateCartKnownUser"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("TransKeyCountKnownUser"))
			.body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}"}""")).asJson)

			.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

			.doIfEquals("${TransKeyCountKnownUser}", 0) {
				/* ********** Delete Promotion Items *********** */
				exec(http("s7_DeleteFromBasketPromoKnownUser")
				.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step1KnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
				.headers(header_1)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyDeleteFromBasketPromoKnownUser"))
				.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("Del1TransKeyKnownUser"))
				.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("Del1TransKeyCountKnownUser"))
				.body(StringBody("""{"basketAction":"deleteFromBasket","offer":"${PromoOffer}","appliedAction":"Add"}""")).asJson)

				.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

				.doIfEquals("${Del1TransKeyCountKnownUser}", 1) 
				{
					doWhile(session => session("Del1TransKeyCountKnownUser").as[String].equals("1"))
					{

						exec(http("s7_DeleteFromBasketPromo_MTS_KnownUser")
						.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step1KnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
						.headers(header_1)
						.check(status.is(200))
						.check(status.not(404), status.not(500),status.not(504),status.not(503))
						.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyDeleteFromBasketPromoKnownUser"))
						.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("Del1TransKeyKnownUser"))
						.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("Del1TransKeyCountKnownUser"))
						.body(StringBody("""{"basketAction":"deleteFromBasket","offer":"${PromoOffer}","appliedAction":"Add","multiTransactionKey":"${Del1TransKeyKnownUser}"}""")).asJson)

						.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)
					}
				}

				.exec(http("s7_GetBasketDetailsKnownUser")
				.get(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step1KnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
				.headers(header_1)
				.check(status.is(200))
				.check(status.not(404), status.not(500), status.not(504), status.not(503))
				.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyGetBasketDetailsKnownUser"))
				.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").find.exists.saveAs("DelProdBundleContextKeyKnownUser")).asJson
				.check(jsonPath("""$.result.records[0].promotions.records[0].actions.deletePromotionBasketAction.rest.params.offer""").optional.saveAs("DelPromoKnownUser")).asJson)

				.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

				/* ********** CreateCart LDV2 *********** */
				.exec(http("s7_CreateCartKnownUser")
				.post(uri02 + """/v3/carts?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
				.headers(header_1)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex("""orderId":"(.+?)"""").find.exists.saveAs("OrderIdKnownUser"))
				.body(StringBody("""{"accountId": "${AccountId}","catalogCode": "DC-WP-Cat-for-LI-products","cartContextKey":"${CartContextKeyAddPromotion-Step1KnownUser}"}""")).asJson)

				.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)
			}

			.doIfEquals("${TransKeyCountKnownUser}", 1) {

				/* ********** AddPromotion-Step2 V105 *********** */
				//feed(promoFeeder)
				exec(http("s7_AddPromotion-Step2KnownUser")
				.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
				.headers(header_1)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyAddPromotion-Step2KnownUser"))
				.check(regex("""cartContextKey(.+?)""").find.exists.saveAs("CreateCartKnownUser"))
				.body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}","multiTransactionKey":"${TransKeyKnownUser}"}""")).asJson)

				.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)


				/* ********** Delete Promotion Items *********** */
				.exec(http("s7_DeleteFromBasketPromoKnownUser")
				.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step2KnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
				.headers(header_1)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyDeleteFromBasketPromoKnownUser"))
				.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("Del2TransKeyKnownUser"))
				.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("Del2TransKeyCountKnownUser"))
				.body(StringBody("""{"basketAction":"deleteFromBasket","offer":"${PromoOffer}","appliedAction":"Add"}""")).asJson)

				.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

				.doIfEquals("${Del2TransKeyCountKnownUser}", 1) 
				{
					doWhile(session => session("Del2TransKeyCountKnownUser").as[String].equals("1"))
					{

						exec(http("s7_DeleteFromBasketPromo_MTS_KnownUser")
						.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step2KnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
						.headers(header_1)
						.check(status.is(200))
						.check(status.not(404), status.not(500),status.not(504),status.not(503))
						.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyDeleteFromBasketPromoKnownUser"))
						.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("Del2TransKeyKnownUser"))
						.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("Del2TransKeyCountKnownUser"))
						.body(StringBody("""{"basketAction":"deleteFromBasket","offer":"${PromoOffer}","appliedAction":"Add","multiTransactionKey":"${Del2TransKeyKnownUser}"}""")).asJson)

						.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)
					}
				}

				.exec(http("s7_GetBasketDetailsKnownUser")
				.get(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step2KnownUser}?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
				.headers(header_1)
				.check(status.is(200))
				.check(status.not(404), status.not(500), status.not(504), status.not(503))
				.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyGetBasketDetailsKnownUser"))
				.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").find.exists.saveAs("DelProdBundleContextKeyKnownUser")).asJson
				.check(jsonPath("""$.result.records[0].promotions.records[0].actions.deletePromotionBasketAction.rest.params.offer""").optional.saveAs("DelPromoKnownUser")).asJson)

				.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

				/* ********** CreateCart LDV2 *********** */
				.exec(http("s7_CreateCartKnownUser")
				.post(uri02 + """/v3/carts?context={"accountId":"${AccountId}"}&contextKey=${LoggedinCK}&isloggedin=true""")
				.headers(header_1)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex("""orderId":"(.+?)"""").find.exists.saveAs("OrderIdKnownUser"))
				.body(StringBody("""{"accountId": "${AccountId}","catalogCode": "DC-WP-Cat-for-LI-products","cartContextKey":"${CartContextKeyAddPromotion-Step2KnownUser}"}""")).asJson)

				.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

				.exec(flushSessionCookies)
				.exec(flushCookieJar)
				.exec(flushHttpCache)

			}
			
			/* ***************************************** ASSET TO BASKET (ABO) ************************************************************************** */
			/* ***************************************** ASSET TO BASKET (ABO) ************************************************************************** */
			
			//.feed(assetToBasket)
			.feed(assetToBaskets7)
			.exec(http("s7_ABOgetLoggedinCKForAsset")
			.get(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/offers?context={"accountId":"${AccountId_Asset}"}&isloggedin=true""")
			.headers(header_1)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""contextKey":"(.+?)".""").find.exists.saveAs("LoggedinCKAsset")))

			.pause(Configuration.script7_ABOACD_minWaitMs milliseconds, Configuration.script7_ABOACD_maxWaitMs milliseconds)

			/* ********* Call to getOffers ************* */
			.exec(http("s7_ABOGetOffersByCatalogKnownUser")
			.get(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/offers?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
			.headers(header_1)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""contextKey":"(.+?)".""").find.exists.saveAs("ABOgetOffersCK")))

			.pause(Configuration.script7_ABOACD_minWaitMs milliseconds, Configuration.script7_ABOACD_maxWaitMs milliseconds)

			.feed(offerFeeder)
			.exec(http("s7_ABOGetOfferDetailsKnownUser")
			.get(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/offers/${OfferCode}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
			.headers(header_1)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""contextKey""").find.exists)
			.check(bodyString.saveAs("OfferDetailsResKnownUser")).asJson)

			.pause(Configuration.script7_ABOACD_minWaitMs milliseconds, Configuration.script7_ABOACD_maxWaitMs milliseconds)

			/* ********** ConfigureOffer  V105 *********** */
			.exec(http("s7_ABOConfigureOfferKnownUser")
			.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/offers/${OfferCode}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
			.headers(header_1)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.body(StringBody("""${OfferDetailsResKnownUser}""")).asJson
			.check(regex("""contextKey""").find.exists)
			//.body(ElFileBody("./src/test/resources/bodies/DC_WP/eCom-Prod-Bnd-15399454256600.txt")).asJson
			.check(regex(""""result":(.+?)."errorCode":"INVOKE""").find.exists.saveAs("AddWithConfigKnownUser")))

			.pause(Configuration.script7_ABOACD_minWaitMs milliseconds, Configuration.script7_ABOACD_maxWaitMs milliseconds)

			/* ********** AssetToBasket V105 *********** This should be the first call as per sheet****************/
	 
	.exec(http("s7_ABOAssetToBasketKnownUser")
	.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket?context={"accountId":"${AccountId_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
	.headers(header_1)
	.check(status.is(200))
	.check(status.not(404), status.not(500),status.not(504),status.not(503))
	.check(regex("""assetReferenceKey":"(.+?)",""").optional.saveAs("AssetRefKeyKnownUser"))
	.check(regex("""assetReferenceKey":"(.+?)",""").count.saveAs("AssetRefKeyCountKnownUser"))
	.check(regex("""cartContextKey":"(.+?)",""").find.exists.saveAs("CartContextKeyAssetToBasketKnownUser"))
	.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("ABOProdBundleContextKeyKnownUserWNC")).asJson
	.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("ABOProdLineItemKeyKnownUserWNC")).asJson
	//for 23 LI
	.check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.addChildBasketAction.rest.params.parentLineItemKey""").optional.saveAs("ABOparentLineItemKeyKnownUser")).asJson
	.check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.addChildBasketAction.rest.params.parentHierarchyPath""").optional.saveAs("ABOparentHierarchyPathKnownUser")).asJson
	.check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.addChildBasketAction.rest.params.offer""").optional.saveAs("ABOofferKnownUser")).asJson
	.check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.addChildBasketAction.rest.params.basketAction""").optional.saveAs("ABObasketActionKnownUser")).asJson
	.check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.addChildBasketAction.rest.params.bundleContextKey""").optional.saveAs("ABObundleContextKeyKnownUser")).asJson
	.body(StringBody("""{"rootAssetIds":"${RootItemId__c_Asset}","basketAction":"assetToBasket","requestDateTime":"2020-07-24T00:00:00.000z"}""")).asJson)

			.pause(Configuration.script7_ABOACD_minWaitMs milliseconds, Configuration.script7_ABOACD_maxWaitMs milliseconds)

			/* ********** AddWithNoConfig *** Changed Here for ABO Changes *********** */
		.exec(http("s7_ABOAddToCartWithNoConfigKnownUser")
		.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAssetToBasketKnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
		.headers(header_1)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAddToCartWithNoConfigKnownUser"))
		.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_ATCWNC")).asJson
		.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_ATCWNC_Count"))
		.check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("ABOProdBundleContextKeyKnownUser")).asJson
		.check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("ABOProdLineItemKeyKnownUser")).asJson
		//.body(StringBody("""{"basketAction":"AddWithNoConfig","productConfig":${AddWithConfigKnownUser}}""")).asJson)
		.body(StringBody("""{"parentLineItemKey":"${ABOparentLineItemKeyKnownUser}","parentHierarchyPath":"${ABOparentHierarchyPathKnownUser}","offer":"${ABOofferKnownUser}","basketAction":"${ABObasketActionKnownUser}","bundleContextKey":"${ABObundleContextKeyKnownUser}"}""")).asJson)
		

		/* ** UpdateExistingBasket-UpdQty V105 ******* */
		.exec(http("s7_ABOUpdateBasketQtyKnownUser")
		.put(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
		.headers(header_1)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyUpdateBasketQtyKnownUser"))
		.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_UBQ")).asJson
		.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_UBQ_Count"))
		//.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("ABOPromoBundleContextKeyKnownUser")).asJson
		//.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("ABOPromoLineItemKeyKnownUser")).asJson
		.check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("ABOPromoBundleContextKeyKnownUser")).asJson
		.check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("ABOPromoLineItemKeyKnownUser")).asJson
		.body(StringBody("""{"bundleContextKey":"${ABOProdBundleContextKeyKnownUser}","lineItemKey":"${ABOProdLineItemKeyKnownUser}","basketAction":"updateBasket","Quantity":"3"}""")).asJson)

		.pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

		.doIfEquals("${MultiTransactionKeyLoggedin_UBQ_Count}",1)
		{
			doWhile(session => session("MultiTransactionKeyLoggedin_UBQ_Count").as[String].equals("1"))
			{
				/* ** UpdateExistingBasket-UpdQty V105 ******* */
				exec(http("s7_ABOUpdateBasketQtyKnownUser_MTS")
				.put(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfigKnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
				.headers(header_1)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyUpdateBasketQtyKnownUser"))
				.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_UBQ")).asJson
				.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_UBQ_Count"))
				//.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("ABOPromoBundleContextKeyKnownUser")).asJson
		        //.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("ABOPromoLineItemKeyKnownUser")).asJson
		        .check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("ABOPromoBundleContextKeyKnownUser")).asJson
		        .check(jsonPath("""$.result.records[0].lineItems.records[0].lineItems.records[0].lineItems.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("ABOPromoLineItemKeyKnownUser")).asJson
				.body(StringBody("""{"multiTransactionKey":"MultiTransactionKeyLoggedin_UBQ","bundleContextKey":"${ABOProdLineItemKeyKnownUser}","lineItemKey":"${ABOProdLineItemKeyKnownUser}","basketAction":"updateBasket","Quantity":"3"}""")).asJson)

			}
		}
		/* **** UpdateExistingBasket-UpdAttrib V105 *** CHANGE THIS ###################### */
		.exec(http("s7_ABOUpdateBasketAttribKnownUser")
		.put(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyUpdateBasketQtyKnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
		.headers(header_1)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_UBA")).asJson
		.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_UBA_Count"))
		.check(regex(""""cartContextKey":"(.+?)",""").optional.saveAs("CartContextKeyUpdateBasketAttribKnownUsers"))
		.body(ElFileBody("./src/test/resources/bodies/DC_WP/DC_WP_Loggedin_UpdateBasketAttribute_ABO.txt")).asJson)

		.pause(Configuration.script7_ABOACD_minWaitMs milliseconds, Configuration.script7_ABOACD_maxWaitMs milliseconds)

		.doIfEquals("${MultiTransactionKeyLoggedin_UBA_Count}",1)
		{
			doWhile(session => session("MultiTransactionKeyLoggedin_UBA_Count").as[String].equals("1"))
			{
				/* **** UpdateExistingBasket-UpdAttrib V105 *** CHANGE THIS ###################### */
				exec(http("s7_ABOUpdateBasketAttribKnownUser_MTS")
				.put(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyUpdateBasketQtyKnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
				.headers(header_1)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyLoggedin_UBA")).asJson
				.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyLoggedin_UBA_Count"))
				.check(regex(""""cartContextKey":"(.+?)",""").optional.saveAs("CartContextKeyUpdateBasketAttribKnownUsers"))
				.body(ElFileBody("./src/test/resources/bodies/DC_WP/DC_WP_Loggedin_UpdateBasketAttribute_ABO_MTS.txt")).asJson)

				.pause(Configuration.script7_ABOACD_minWaitMs milliseconds, Configuration.script7_ABOACD_maxWaitMs milliseconds)

			}
		}
				/* ********** DeleteFromBasket *********** */
				.exec(http("s7_ABODeleteFromBasketKnownUser")
				.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAssetToBasketKnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
				.headers(header_1)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				//.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyDeleteFromBasketKnownUser"))
				.body(StringBody("""{"deleteBundleNumber":"0","basketAction":"DeleteFromBasket"}""")).asJson)

				.pause(Configuration.script7_ABOACD_minWaitMs milliseconds, Configuration.script7_ABOACD_maxWaitMs milliseconds)

				/* ********** DeleteProductAPI *********** */
				.exec(http("s7_ABODeleteProdKnownUser")
				.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAssetToBasketKnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
				.headers(header_1)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyDeleteProdKnownUser"))
				.body(StringBody("""{"bundleContextKey":"${ABOProdBundleContextKeyKnownUserWNC}","basketAction":"deleteFromBasket","itemKey":"${ABOProdLineItemKeyKnownUserWNC}"}""")).asJson)

				.pause(Configuration.script7_ABOACD_minWaitMs milliseconds, Configuration.script7_ABOACD_maxWaitMs milliseconds)

				/* ***** AddPromotion-Step1 V105 ******* */
				.feed(promoFeeder)
				.exec(http("s7_ABOAddPromotion-Step1KnownUser")
				.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAssetToBasketKnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
				.headers(header_1)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAddPromotion-Step1KnownUser"))
				.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAssetToBasketKnownUser"))
				.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("TransKeyKnownUser"))
				.check(regex("""cartContextKey(.+?)""").optional.saveAs("CreateCartKnownUser"))
				.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("TransKeyCountKnownUser"))
				.body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}"}""")).asJson)

				.pause(Configuration.script7_ABOACD_minWaitMs milliseconds, Configuration.script7_ABOACD_maxWaitMs milliseconds)

				.doIfEquals("${TransKeyCountKnownUser}", 0) {
			/* ********** Delete Promotion Items *********** */
			exec(http("s7_ABODeleteFromBasketPromoKnownUser")
			.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step1KnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
			.headers(header_1)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyDeleteFromBasketPromoKnownUser"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("Del1TransKeyKnownUser"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("Del1TransKeyCountKnownUser"))
			.body(StringBody("""{"basketAction":"deleteFromBasket","offer":"${PromoOffer}","appliedAction":"Add"}""")).asJson)

			.pause(Configuration.script7_ABOACD_minWaitMs milliseconds, Configuration.script7_ABOACD_maxWaitMs milliseconds)

			.doIfEquals("${Del1TransKeyCountKnownUser}", 1) 
			{
				doWhile(session => session("Del1TransKeyCountKnownUser").as[String].equals("1"))
				{

					exec(http("s7_ABODeleteFromBasketPromo_MTS_KnownUser")
					.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step1KnownUser}?ccontext={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
					.headers(header_1)
					.check(status.is(200))
					.check(status.not(404), status.not(500),status.not(504),status.not(503))
					.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyDeleteFromBasketPromoKnownUser"))
					.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("Del1TransKeyKnownUser"))
					.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("Del1TransKeyCountKnownUser"))
					.body(StringBody("""{"basketAction":"deleteFromBasket","offer":"${PromoOffer}","appliedAction":"Add","multiTransactionKey":"${Del1TransKeyKnownUser}"}""")).asJson)

					.pause(Configuration.script7_ABOACD_minWaitMs milliseconds, Configuration.script7_ABOACD_maxWaitMs milliseconds)
				}
			}

					.exec(http("s7_ABOGetBasketDetailsKnownUser")
					.get(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step1KnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
					.headers(header_1)
					.check(status.is(200))
					.check(status.not(404), status.not(500), status.not(504), status.not(503))
					.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyGetBasketDetailsKnownUser"))
					.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").find.exists.saveAs("DelProdBundleContextKeyKnownUser")).asJson
					.check(jsonPath("""$.result.records[0].promotions.records[0].actions.deletePromotionBasketAction.rest.params.offer""").optional.saveAs("DelPromoKnownUser")).asJson)

					.pause(Configuration.script7_ABOACD_minWaitMs milliseconds, Configuration.script7_ABOACD_maxWaitMs milliseconds)

					.exec(http("s7_ABOAssetToBasketCreateCartKnownUser")
					.post(uri02 + """/v3/carts?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
					.headers(header_1)
					.check(status.is(200))
					.check(status.not(404), status.not(500),status.not(504),status.not(503))
					.check(regex("""orderId":"(.+?)"""").find.exists.saveAs("OrderIdKnownUser"))
					.body(StringBody("""{"cartContextKey":"${CartContextKeyAddPromotion-Step1KnownUser}","accountId": "${AccountId_Asset}","catalogCode": "DC-WP-Cat-for-LI-products"}""")).asJson)

					.pause(Configuration.script7_ABOACD_minWaitMs milliseconds, Configuration.script7_ABOACD_maxWaitMs milliseconds)
				}

				.doIfEquals("${TransKeyCountKnownUser}", 1) {

					/* ********** AddPromotion-Step2 V105 *********** */
					//feed(promoFeeder)
					exec(http("s7_ABOAddPromotion-Step2KnownUser")
					.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAssetToBasketKnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
					.headers(header_1)
					.check(status.is(200))
					.check(status.not(404), status.not(500),status.not(504),status.not(503))
					.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyAddPromotion-Step2KnownUser"))
					.check(regex("""cartContextKey(.+?)""").find.exists.saveAs("CreateCartKnownUser"))
					.body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}","multiTransactionKey":"${TransKeyKnownUser}"}""")).asJson)

					.pause(Configuration.script7_ABOACD_minWaitMs milliseconds, Configuration.script7_ABOACD_maxWaitMs milliseconds)

			/* ********** Delete Promotion Items *********** */
			.exec(http("s7_ABODeleteFromBasketPromoKnownUser")
			.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step2KnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
			.headers(header_1)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyDeleteFromBasketPromoKnownUser"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("Del2TransKeyKnownUser"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("Del2TransKeyCountKnownUser"))
			.body(StringBody("""{"basketAction":"deleteFromBasket","offer":"${PromoOffer}","appliedAction":"Add"}""")).asJson)

			.pause(Configuration.script7_ABOACD_minWaitMs milliseconds, Configuration.script7_ABOACD_maxWaitMs milliseconds)

			.doIfEquals("${Del2TransKeyCountKnownUser}", 1) 
			{
				doWhile(session => session("Del2TransKeyCountKnownUser").as[String].equals("1"))
				{

					exec(http("s7_ABODeleteFromBasketPromo_MTS_KnownUser")
					.post(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step2KnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
					.headers(header_1)
					.check(status.is(200))
					.check(status.not(404), status.not(500),status.not(504),status.not(503))
					.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyDeleteFromBasketPromoKnownUser"))
					.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("Del2TransKeyKnownUser"))
					.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("Del2TransKeyCountKnownUser"))
					.body(StringBody("""{"basketAction":"deleteFromBasket","offer":"${PromoOffer}","appliedAction":"Add","multiTransactionKey":"${Del2TransKeyKnownUser}"}""")).asJson)

					.pause(Configuration.script7_ABOACD_minWaitMs milliseconds, Configuration.script7_ABOACD_maxWaitMs milliseconds)
				}
			}
				
					.exec(http("s7_ABOGetBasketDetailsKnownUser")
					.get(uri02 + """/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step2KnownUser}?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
					.headers(header_1)
					.check(status.is(200))
					.check(status.not(404), status.not(500), status.not(504), status.not(503))
					.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyGetBasketDetailsKnownUser"))
					.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").find.exists.saveAs("DelProdBundleContextKeyKnownUser")).asJson
					.check(jsonPath("""$.result.records[0].promotions.records[0].actions.deletePromotionBasketAction.rest.params.offer""").optional.saveAs("DelPromoKnownUser")).asJson)

					.pause(Configuration.script7_ABOACD_minWaitMs milliseconds, Configuration.script7_ABOACD_maxWaitMs milliseconds)

					.exec(http("s7_ABOAssetToBasketCreateCartKnownUser")
					.post(uri02 + """/v3/carts?context={"accountId":"${AccountId_Asset}","rootAssetIds":"${RootItemId__c_Asset}"}&contextKey=${LoggedinCKAsset}&isloggedin=true""")
					.headers(header_1)
					.check(status.is(200))
					.check(status.not(404), status.not(500),status.not(504),status.not(503))
					.check(regex("""orderId":"(.+?)"""").find.exists.saveAs("OrderIdKnownUser"))
					.body(StringBody("""{"cartContextKey":"${CartContextKeyAddPromotion-Step2KnownUser}","accountId": "${AccountId_Asset}","catalogCode": "DC-WP-Cat-for-LI-products"}""")).asJson)

					.pause(Configuration.script7_ABOACD_minWaitMs milliseconds, Configuration.script7_ABOACD_maxWaitMs milliseconds)

				}


				.exec(flushSessionCookies)
				.exec(flushCookieJar)
				.exec(flushHttpCache)
			}
		
}
