package UPC

import java.time.format.DateTimeFormatter
import scala.util.Random
import scala.concurrent.duration.DurationInt
import java.time.LocalDate

object Configuration
 {
	val BaseUrl = "https://perftestupc.my.salesforce.com"
	val Uri01 = "https://login.salesforce.com"
	val Uri04 = "https://perftestupc--vlocity-cmt.visualforce.com"
	// val Uri05 = "https://c.cs8.visual.force.com"
	// val Uri10 = "https://cs8.salesforce.com"
var ProductName = Iterator.continually(Map("productname" -> ("A00-" + Random.alphanumeric.take(5).mkString )))
var ProductCode = Iterator.continually(Map("productcode" -> ("ACode-" + Random.alphanumeric.take(5).mkString )))
var ObjectType = Iterator.continually(Map("objecttype" -> ("PerfTest-" + Random.alphanumeric.take(5).mkString )))

	val MinWaitMs = 15000
	val MaxWaitMs = 20000

	val MiniMinWaitMs = 1000
	val MiniMaxWaitMs = 3000

}
