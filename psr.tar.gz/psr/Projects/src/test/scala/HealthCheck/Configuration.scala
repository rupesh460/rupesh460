package HealthCheck

object Configuration
{
	val p3BaseUrl = "https://c.cs17.visual.force.com"
	val p3Uri10 = "https://cs17.salesforce.com"

	val p2BaseUrl = "https://c.cs8.visual.force.com"
	val p2Uri10 = "https://cs8.salesforce.com" 

	val PriceListId_perf3 = "a2Pg0000001R7Yi" // BMK-Pricelist 
	val PriceListId_perf2 = "a2rL0000000ohIE" // 

	val MinWaitMs = 5000
	val MaxWaitMs = 15000

	val MiniMinWaitMs = 2000
	val MiniMaxWaitMs = 10000	
}