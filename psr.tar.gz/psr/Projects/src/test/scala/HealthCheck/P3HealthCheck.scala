package HealthCheck

import scala.concurrent.duration._
import io.gatling.core.Predef._
import io.gatling.core.structure.ChainBuilder
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._
import io.gatling.jsonpath._
import Headers._
import scala.collection._
import java.time.format.DateTimeFormatter
import java.time.LocalDateTime
import java.time.LocalDate

object P3HealthCheck
{
	val uri10 = Configuration.p3Uri10
	var accountName = new StringBuilder()
	val randomNumber = new scala.util.Random
	var modifiedItemJson = new StringBuilder()
	val origItemAttrHeirarchy = new StringBuilder()
	val modItemAttrHeirarchy = new StringBuilder()

	val product_feeder = csv("./src/test/resources/data/healthcheck/ProductID_P3.csv").random

	val scn = scenario("Perf3_Sandbox_HealthCheck")

	.exec(session => session.set("PriceListId",Configuration.PriceListId_perf3))

	.exec(http("RESTGetOAuthToken")
		.post("https://test.salesforce.com/services/oauth2/token")
		.header("Content-Type", "application/x-www-form-urlencoded")
		.formParam("password", "Jakdssjksd")
		.formParam("username", "kasi@perftet3.sbx")
		.formParam("client_secret", "7119599995527965426")
		.formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
		.formParam("grant_type", "password")
		.check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
		.check(status.is(200)))

	.exec(session => session.set("AccountName",""))

	.exec( session => {
		val random_index = randomNumber.nextInt(100000)
		accountName.append("Acc-"+random_index)
		session
	})

	.exec(session => session.set("AccountName",accountName))

	.exec( session => {
		accountName = new StringBuilder()
		session
	})

	/* *********** CreateAccount *********** */
	.exec(http("CreateAccount")
		.post(uri10 +"/services/data/v41.0/sobjects/account")
		.headers(header_1)
		.check(regex(""""id":"(.*?)"""").find.exists.saveAs("AccountId"))
		.body( StringBody("""
		{
			"Name" : "${AccountName}",
			"ShippingCity" : "San Francisco",
			"RecordTypeId" : "012g00000005CoWAAU",
			"Status__c"    : "Active"
		}""")).asJson)

	/* *********** CreateOrder *********** */
	.exec(http("CreateNewOrder")
		.post(uri10 +"/services/apexrest/v2/carts")
		.headers(header_1)
		.check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
		.body( StringBody("""{"subaction":"createOrder",
			"inputFields":[
			{"AccountId":"${AccountId}"},
			{"PriceListId__c":"${PriceListId}"},
			{"Name":"HealthCheckOrder"},{"Status":"Draft"},
			{"EffectiveDate":"6/5/2018"}
			]}""")).asJson)

	.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

	.repeat(2)
	{

		/* ********** AddItemsToCart *********** */
		feed(product_feeder) 
		.exec(http("Add items to cart")
			.post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
			.headers(header_1)
			.body( StringBody("""{
				"items":[{
					"itemId":"${ProductID}"
				}]}""")).asJson
			.check(regex("""INFO","message":"Successfully added.""").find.exists))

		.pause(Configuration.MiniMinWaitMs milliseconds, Configuration.MiniMaxWaitMs milliseconds)
	}

	/* ********** GetCartLineItems_100LI_InCart *********** */
	.exec(http("Get list of cart line items")
		.get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
		.headers(header_1)
		.check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1"))
		.check(jsonPath("$.records[1].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem2")))

	/* ********** GetCartItemsByItemId *********** */
	.exec(http("Get line item details")
		.get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
		.queryParamSeq(Seq(("id", "${LineItem1}")))
		.headers(header_1)
		.check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))

	.exec(session => { 
		//originalItemJson.append(session("capturedItemHierarchy").as[String])
		modifiedItemJson = new StringBuilder()
		modifiedItemJson.append("""{"items":{"records":[{"displaySequence":-1,""").append(session("capturedItemHierarchy").as[String]).append("}]}}")
		session
	})

	/* ********** UpdateItemsInCart *********** */
	/* Updating the Quantity from default 1.00 to 3.00 */
	.exec(http("Update cart line item")
		.put(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
		.headers(header_1)
		.body(StringBody(session =>  modifiedItemJson.replaceAllLiterally(""""Quantity":{"value":1.00""",""""Quantity":{"value":3.00""").toString() )).asJson
		.check(regex("""INFO","message":"Successfully updated.""").find.exists))

	.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

	/* ********** DeleteItemFromCart********** */
	.exec(http("Delete an item from the cart")
		.delete(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/${LineItem2}")
		.headers(header_1)
		.check(regex("""INFO","message":"Successfully deleted.""").find.exists))

	.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

	.exec(http("Login")
		.post(uri10 + "/")
		.headers(headers_00)
		.formParam("un", "kasi@perftest3.sbx")
		.formParam("width", "1440")
		.formParam("height", "900")
		.formParam("hasRememberUn", "true")
		.formParam("startURL", "")
		.formParam("loginURL", "")
		.formParam("loginType", "")
		.formParam("useSecure", "true")
		.formParam("local", "")
		.formParam("lt", "standard")
		.formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
		.formParam("locale", "")
		.formParam("oauth_token", "")
		.formParam("oauth_callback", "")
		.formParam("login", "")
		.formParam("serverid", "")
		.formParam("QCQQ", "M1D2l15jFvl")
		.formParam("display", "page")
		.formParam("username", "kasi@perftest3.sbx")
		.formParam("pw", "asjdskdsjk25")
		.formParam("Login", ""))

	.exec(http("Order")
		.get(uri10 + "/801/o")
		.headers(headers_05))

	.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

	.exec(http("Order_Detail")
		.get(uri10 + "/${OrderID}")
		.headers(headers_05) 
		.check(regex("""_CONFIRMATIONTOKEN=(.+?)&""").findAll.exists.saveAs("""CONF_TOKENS""")))

	.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

	.exec(http("Delete Order")
		.post(uri10 + "/setup/own/deleteredirect.jsp?delID=${OrderID}&retURL=%2F801%2Fo&failRetURL=%2F${OrderID}")
		.headers(headers_05)
		.body(StringBody("""_CONFIRMATIONTOKEN=${CONF_TOKENS(1)}""")))


	.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

}
