package EPC_CPQ_BMK

object Configuration
 {
	val BaseUrl = "https://c.cs17.visual.force.com"
	val Uri01 = "https://test.salesforce.com"
	val Uri05 = "https://c.cs17.visual.force.com"
	val Uri10 = "https://cs17.salesforce.com"

	val PriceListId = "a2Pg0000001R7Yi" // BMK-Pricelist

	val Promotion3PI = "a2eg0000001n8I1AAI" // BMK-Test-Promotion-100 //BNDL-PROMOTION-100
	val Promotion5PI = "a2eg0000001n8I0AAI" // BMK-Test-Promotion-99 //BNDL-PROMOTION-101

	val UpdatePromotion = "a2eg0000001n8HzAAI" // BMK-Test-Promotion-98    //BNDL-PROMOTION-102
	val UpdatePromotionItem = "01ug000000G1xhtAAB" // Test-Prods-For-BMK-500    //Test-Prods-For-BMK-19

	val PenaltyRulePromotion = "a2eg0000001n8HyAAI" // BMK-Test-Promotion-97     //BNDL-PROMOTION-103

	val MinWaitMs = 5000
	val MaxWaitMs = 15000

	val MiniMinWaitMs = 2000
	val MiniMaxWaitMs = 10000

}