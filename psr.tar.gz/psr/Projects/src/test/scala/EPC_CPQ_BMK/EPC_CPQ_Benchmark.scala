  package EPC_CPQ_BMK

  import scala.concurrent.duration._

  import io.gatling.core.Predef._
  import io.gatling.core.structure.ChainBuilder
  import io.gatling.http.Predef._
  import io.gatling.jdbc.Predef._
  import io.gatling.jsonpath._
  import Headers._
  import scala.collection._
  import java.time.format.DateTimeFormatter
  import java.time.LocalDateTime
  import java.time.LocalDate

import io.gatling.core.feeder._
import java.util.Base64
import java.nio.charset.StandardCharsets
import scala.util.matching.Regex


  object EPC_CPQ_Benchmark {

    val uri01 = Configuration.Uri01
    val uri05 = Configuration.Uri05
    val uri10 = Configuration.Uri10
    var modifiedItemJson = new StringBuilder()
    val origItemAttrHeirarchy = new StringBuilder()
    val modItemAttrHeirarchy = new StringBuilder()
    val randomNumber = new scala.util.Random
    var randomLineItem = new StringBuilder()
    var pbeEntriesList = Vector[String]()
    var promotionList = Vector[String]()
    var lineItemsList = Vector[String]()
    var randomPBEntry = new StringBuilder()
    var accountName = new StringBuilder()
    var randomPromoId = new StringBuilder()
    var final_formatted_date = new StringBuilder()
    val userFeeder = csv("./src/test/resources/data/bmk/EPC_BMK_Users.csv").random
    val product_feeder = csv("./src/test/resources/data/bmk/EPC_BMK_ProductIds.csv").random
    val products_ids_loy = csv("./src/test/resources/data/bmk/EPC_BMK_Loyalty_ProductIds.csv").random
    

 val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
  val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
  val password_v = (passwordByEnv.get("perf3").toString)
  val password_encoded = password_v.substring(12,(password_v.length - 2 ))
  val credentials = new String(Base64.getDecoder.decode(password_encoded))


    val scn = scenario("EPC_CPQ_Benchmark")

    .exec(session => session.set("password",credentials))
    
    .exec(session => session.set("PriceListId",Configuration.PriceListId))
    .exec(session => session.set("PromotionID1",Configuration.Promotion3PI))
    .exec(session => session.set("PromotionID2",Configuration.Promotion5PI))
    .exec(session => session.set("UpdatePromotionID",Configuration.UpdatePromotion))
    .exec(session => session.set("UpdatePromotionItemID",Configuration.UpdatePromotionItem))
    .exec(session => session.set("PenaltyRulePromotionID",Configuration.PenaltyRulePromotion))
    

    .feed(userFeeder)
    .exec(http("RESTGetOAuthToken")
      .post("https://test.salesforce.com/services/oauth2/token")
      .header("Content-Type", "application/x-www-form-urlencoded")
      .formParam("password", "${password}")
      .formParam("username", "${username}")
      .formParam("client_secret", "7119599995527965426")
      .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
      .formParam("grant_type", "password")
      .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
      .check(status.is(200)))

    .exec(session => session.set("AccountName",""))

    .exec( session => {
      val random_index = randomNumber.nextInt(100000)
      accountName.append("Acc-"+random_index)
      session
    })

    .exec(session => session.set("AccountName",accountName))
    
    .exec( session => {
      accountName = new StringBuilder()
      session
    })
    
    /* *********** CreateAccount *********** */
    .exec(http("CreateAccount")
      .post(uri10 +"/services/data/v41.0/sobjects/account")
      .headers(header_1)
      .check(regex(""""id":"(.*?)"""").find.exists.saveAs("AccountId"))
      .body( StringBody("""
      {
        "Name" : "${AccountName}",
        "ShippingCity" : "San Francisco",
        "RecordTypeId" : "012g00000005CoWAAU",
        "Status__c"    : "Active"
      }""")).asJson)

    /* *********** CreateOrder *********** */
    .exec(http("Create a new order")
      .post(uri10 +"/services/apexrest/v2/carts")
      .headers(header_1)
      .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
      .body( StringBody("""{"subaction":"createOrder",
        "inputFields":[
        {"AccountId":"${AccountId}"},
        {"PriceListId__c":"${PriceListId}"},
        {"Name":"NewOrder1"},{"Status":"Draft"},
        {"EffectiveDate":"6/5/2018"}
        ]}""")).asJson)

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    /* ********** SetPriceListForCart *********** */
    .exec(http("Set PriceList for the order")
      .put(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/")
      .headers(header_1)
      .body(StringBody("""{
        "inputFields": 
        [
        {
          "PriceListId__c": "${PriceListId}"
        }
        ],
        "cartId": "${OrderID}",
        "methodName": "updateCarts"
      }""")).asJson
      .check(regex("""Id":"${OrderID}"}]}""").find.exists))

      /* ********** GetListOfProductsForCart *********** */
    .exec(http("Get list of products for cart")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/products?pagesize=10")
      .check(jsonPath("$.records[*].Id.value").find.saveAs("ListOfPBEntries"))
      .headers(header_1))


      /* ********** GetListOfPromotionsForCart *********** */ 
    .exec(http("Get list of promotions for cart")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/promotions?pagesize=10")
      .check(jsonPath("$.records[0].id").find.saveAs("PromotionID1"))
      .check(jsonPath("$.records[*].id").findAll.saveAs("PromotionList"))
      .headers(header_1))  

     .exec( session => {
      promotionList = session("PromotionList").as[Vector[String]]
      session
    })
   
   
   .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

   /* ********** AddPromotionToCart *********** */
   .exec(http("Add a promotion which has 3 promotion items")
    .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/promotions")
    .headers(header_1)
    .body( StringBody("""{
      "items": [{"itemId":"${PromotionID1}"}],
      "promotionId":"${PromotionID1}",
      "cartId":"${OrderID}",
      "methodName":"postCartsPromoItems"
    }""")).asJson
    .check(regex("""Test-Prods-For-BMK-600""").find.exists)
    .check(regex("""Test-Prods-For-BMK-601""").find.exists)
    .check(regex("""Test-Prods-For-BMK-602""").find.exists))

   /* ********** AddPromotionToCart *********** */
   .exec(http("Add a promotion which has 5 promotion items")
    .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/promotions")
    .headers(header_1)
    .body( StringBody("""{
      "items": [{"itemId":"${PromotionID2}"}],
      "promotionId":"${PromotionID2}",
      "cartId":"${OrderID}",
      "methodName":"postCartsPromoItems"
    }""")).asJson
    .check(regex("""Test-Prods-For-BMK-607""").find.exists)
    .check(regex("""Test-Prods-For-BMK-606""").find.exists)
    .check(regex("""Test-Prods-For-BMK-605""").find.exists)
    .check(regex("""Test-Prods-For-BMK-604""").find.exists)
    .check(regex("""Test-Prods-For-BMK-603""").find.exists))

   .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

   /* Adding promotion-601 to cart for Cancel promotion call */
   /* ********** AddPromotionToCart *********** */
   .exec(http("Add a promotion to cart which has penalty rule")
    .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/promotions")
    .headers(header_1)
    .body( StringBody("""{
      "items": [{"itemId":"${PenaltyRulePromotionID}"}],
      "promotionId":"${PenaltyRulePromotionID}",
      "cartId":"${OrderID}",
      "methodName":"postCartsPromoItems"
    }""")).asJson
    .check(regex("""Test-Prods-For-BMK-700""").find.exists))
   
   .repeat(7)
   {  
     
    /* ********** AddItemsToCart *********** */
    feed(product_feeder) 
    .exec(http("Add items to cart")
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
      .headers(header_1)
      .body( StringBody("""{
        "items":[{
          "itemId":"${ProductID}"
        }],
        "hierarchy":3,
        "lastItemId":"",
        "pagesize":20
      }""")).asJson
      .check(regex("""INFO","message":"Successfully added.""").find.exists))

    .pause(Configuration.MiniMinWaitMs milliseconds, Configuration.MiniMaxWaitMs milliseconds)
    
  }

  /* ********** AddItemsToCart *********** */
  .feed(product_feeder) 
  .exec(http("Add an item to cart when cart has 20 line items")
    .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
    .headers(header_1)
    .body( StringBody("""{
      "items":[{
        "itemId":"${ProductID}"
      }],
      "hierarchy":3,
      "lastItemId":"",
      "pagesize":20
    }""")).asJson
    .check(regex("""INFO","message":"Successfully added.""").find.exists))

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
  
  
  /* ********** AddItemsToCart *********** */
  .feed(products_ids_loy)
  .exec(http("Add an item to cart which has Loyalty Price")
    .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
    .headers(header_1)
    .body( StringBody("""{
      "items":[{
        "itemId":"${ProductID_Loy}"
      }],
      "hierarchy":3,
      "lastItemId":"",
      "pagesize":20
    }""")).asJson
    .check(regex("""INFO","message":"Successfully added.""").find.exists))

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  /* ********** GetCartLineItems_20LI_InCart *********** */
  .exec(http("Get list of cart line items. Cart has approximately 20 line items")
    .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items?pagesize=10&price=false&validate=false")
    .headers(header_1)
    .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1"))
    .check(jsonPath("$.records[1].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem2")))

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  /* ********** DeleteItemFromCart********** */
  .exec(http("Delete an item from the cart. Cart has 20 line items")
    .delete(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/${LineItem2}")
    .headers(header_1)
    .check(regex("""INFO","message":"Successfully deleted.""").find.exists)) 
  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  .repeat(27)
  {
    
    /* ********** AddItemsToCart *********** */
    feed(product_feeder) 
    .exec(http("Add items to cart")
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
      .headers(header_1)
      .body( StringBody("""{
        "items":[{
          "itemId":"${ProductID}"
        }],
        "hierarchy":3,
        "lastItemId":"",
        "pagesize":20
      }""")).asJson
      .check(regex("""INFO","message":"Successfully added.""").find.exists))

    .pause(Configuration.MiniMinWaitMs milliseconds, Configuration.MiniMaxWaitMs milliseconds)
    
  }

  /* ********** AddItemsToCart *********** */
  .feed(product_feeder) 
  .exec(http("Add an item to cart when cart has 100 line items")
    .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
    .headers(header_1)
    .body( StringBody("""{
      "items":[{
        "itemId":"${ProductID}"
      }],
      "hierarchy":3,
      "lastItemId":"",
      "pagesize":20
    }""")).asJson
    .check(regex("""INFO","message":"Successfully added.""").find.exists))

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  /* ********** GetCartLineItems_100LI_InCart *********** */
  .exec(http("Get list of cart line items. Cart has approximately 100 line items")
    .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items?pagesize=10&price=false&validate=false")
    .headers(header_1)
    .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1"))
    .check(jsonPath("$.records[1].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem2")))

  
  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  /* ********** DeleteItemFromCart********** */
  .exec(http("Delete an item from the cart. Cart has 100 line items")
    .delete(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/${LineItem2}")
    .headers(header_1)
    .check(regex("""INFO","message":"Successfully deleted.""").find.exists))
  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  .repeat(33)
  {
    
    /* ********** AddItemsToCart *********** */
    feed(product_feeder) 
    .exec(http("Add items to cart")
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
      .headers(header_1)
      .body( StringBody("""{
        "items":[{
          "itemId":"${ProductID}"
        }],
        "hierarchy":3,
        "lastItemId":"",
        "pagesize":20
      }""")).asJson
      .check(regex("""INFO","message":"Successfully added.""").find.exists))

    .pause(Configuration.MiniMinWaitMs milliseconds, Configuration.MiniMaxWaitMs milliseconds)
    
  }

  /* ********** AddItemsToCart *********** */
  .feed(product_feeder) 
  .exec(http("Add an item to cart when cart has 200 line items")
    .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
    .headers(header_1)
    .body( StringBody("""{
      "items":[{
        "itemId":"${ProductID}"
      }],
      "hierarchy":3,
      "lastItemId":"",
      "pagesize":20
    }""")).asJson
    .check(regex("""INFO","message":"Successfully added.""").find.exists))

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


  /* ********** GetCartLineItems_200LI_InCart *********** */
  .exec(http("Get list of cart line items. Cart has approximately 200 line items")
    .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items?pagesize=10&price=false&validate=false")
    .headers(header_1)
    .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1"))
    .check(jsonPath("$.records[1].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem2")))

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  /* ********** DeleteItemFromCart********** */
  .exec(http("Delete an item from the cart. Cart has 200 line items")
    .delete(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/${LineItem2}")
    .headers(header_1)
    .check(regex("""INFO","message":"Successfully deleted.""").find.exists)) 
  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  /* ********** GetCarts *********** */
  .exec(http("Get carts pricing")
    .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}?price=true&validate=true")
    .headers(header_1))

  /* ********** GetCartLineItems_200LI_InCart *********** */
  .exec(http("GetCartLineItems")
    .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items?pagesize=10&price=false&validate=false")
    .headers(header_1)
    .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1"))
    .check(jsonPath("$.records[1].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem2"))
    .check(jsonPath("$.records[2].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem3"))
    .check(jsonPath("$.records[3].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem4")))
  

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  /* *********** GetPromotionsAppliedToCart ********** */
  .exec(http("Get promotions applied to cart. Cart has 3 promotions")
    .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/promotions?subaction=getPromotionsAppliedToCart")
    .check(jsonPath("$.records[0].Id.value").find.exists.saveAs("AppliedPromotionId1"))
    .check(jsonPath("$.records[1].Id.value").find.exists.saveAs("AppliedPromotionId2"))
    .headers(header_1))

  /* ********** GetCartItemsByItemId *********** */
  .exec(http("Get line item details")
    .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
    .queryParamSeq(Seq(("id", "${LineItem1}")))
    .headers(header_1)
    .check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))

  .exec(session => { 
    //originalItemJson.append(session("capturedItemHierarchy").as[String])
    modifiedItemJson = new StringBuilder()
    modifiedItemJson.append("""{"items":{"records":[{"displaySequence":-1,""").append(session("capturedItemHierarchy").as[String]).append("}]}}")
    session
  })
  
  /* ********** UpdateItemsInCart *********** */
  /* Updating the Quantity from default 1.00 to 3.00 */
  .exec(http("Update cart line item")
    .put(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
    .headers(header_1)
    .body(StringBody(session =>  modifiedItemJson.replaceAllLiterally(""""Quantity":{"value":1.00""",""""Quantity":{"value":3.00""").toString() )).asJson
    .check(regex("""INFO","message":"Successfully updated.""").find.exists))
  
  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
  

  /* ********** DeleteItemFromCart********** */
  .exec(http("Delete an item from the cart")
    .delete(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/${LineItem2}")
    .headers(header_1)
    .check(regex("""INFO","message":"Successfully deleted.""").find.exists))  

  /* ********** GetPricingDetailsForCartLineItem *********** */
  .exec(http("Get pricing details for the cart line item")
    .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/${LineItem3}/pricing?fields=RecurringCharge__c")
    .headers(header_1)) 


   /* *********** DeletePromotionAppliedToCart ********** */
 .exec(http("Delete an applied promotion in the cart")
  .delete(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/promotions?id=${AppliedPromotionId1}")
  .headers(header_1)
  .check(regex("""INFO","message":"Successfully deleted.""").find.exists))

 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


 /* ********** CloneCartLineItem ********** */
 .exec(http("Clone a cart line item - Item has approximately 2-3 childs")
  .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/clone")
  .headers(header_1)
  .body( StringBody("""{
    "items": [
    {"itemId":"${LineItem3}"}
    ],
    "hierarchy": 1,
    "lastItemId": "",
    "pagesize": 20
  }""")).asJson
  .check(regex("""INFO","message":"Clone Successful.""").find.exists))

 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

 /* ********** GetPricingDetailsForCartLineItem *********** */
 .exec(http("Get pricing details for the cart line item")
  .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/${LineItem4}/pricing?fields=RecurringCharge__c")
  .headers(header_1)) 

  /* Adding Test-Prods-For-BMK-500 which is associated with BMK-Test-Promotion-98 which is of Update type */

/* ********** AddItemsToCart *********** */
.exec(http("Add an item to cart - for update promotion call")
  .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
  .headers(header_1)
  .body( StringBody("""{
    "items":[{
      "itemId":"${UpdatePromotionItemID}"
    }],
    "hierarchy":3,
    "lastItemId":"",
    "pagesize":20
  }""")).asJson
  .check(regex("""INFO","message":"Successfully added.""").find.exists))

  
  /* ********** SubmitOrder ********** */ 
.exec(http("Submit order - with approximately 210 line items")
  .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/checkout")
  .headers(header_1)
  .body( StringBody("""{
    "items":[
    {"itemId":"${LineItem1}"}
    ],
    "hierarchy":1,
    "lastItemId":"",
    "pagesize":20
  }""")).asJson)

.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

/* ********** GetAssetsForAccount ********** */
.exec(http("Get assets for the account")
  .get(uri10 +"/services/apexrest/v2/accounts/${AccountId}/assets")
  .headers(header_1)
  .check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfAssetIds")))


  /* ********** GetRequestDateDetailsForOrderItem *********** */
.exec(http("GetRequestDateDetailsForOrderItem")
  .get(uri10 +"/services/data/v39.0/query/?q=SELECT+RequestDate__c+FROM+OrderItem+WHERE+RequestDate__c+!=+null+ORDER+BY+RequestDate__c+DESC+LIMIT+10")
  .check(regex("""<RequestDate__c>(.*?)</RequestDate__c>""").findAll.exists.saveAs("RequestDatesList"))
  .headers(header_1))

.exec( session => {
  val requestDateList = session("RequestDatesList").as[List[String]]
  val maxdate = requestDateList(0)
  val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
  val dateforcurrentrun = LocalDate.parse(maxdate,formatter).plusDays(1)
  final_formatted_date.append(dateforcurrentrun)
  session
}) 

.exec( session => session.set("DATE", final_formatted_date ) )
.exec( session => {
  final_formatted_date = new StringBuilder()
  session
})

.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

//SELECT Id,Name FROM Asset WHERE AccountId = '' AND Name = ''

.exec(http("GetAssetId")
  .get(uri10 +"/services/data/v39.0/query/?q=SELECT Id,Name FROM Asset WHERE AccountId = '${AccountId}' AND Name = 'Test-Prods-For-BMK-500' LIMIT 1")
  .check(regex("<Id>(.*?)</Id>").find.saveAs("AssetId"))
  .headers(header_1))

/* ************ AssetChangeToOrder *********** */ 
.exec(http("Asset to order. One asset has been converted to order.")
  .post(uri10 +"/services/apexrest/v2/carts")
  .headers(header_1)
  .check(jsonPath("$.records[0].cartId").find.saveAs("CartId_ForUpdatePromo"))
  .body(StringBody("""{ 
    "subaction": "assetToOrder",
    "id":"${AssetId}",
    "accountId": "${AccountId}", 
    "requestDate": "${DATE}" 
  } """)).asJson)

.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)



/* ********** AddPromotionToCart *********** */ 
.exec(http("Add a promotion which is of update type")
  .post(uri10 +"/services/apexrest/v2/cpq/carts/${CartId_ForUpdatePromo}/promotions")
  .headers(header_1)
  .body( StringBody("""{
    "items": [{"itemId":"${UpdatePromotionID}"}],
    "promotionId":"${UpdatePromotionID}",
    "cartId":"${CartId_ForUpdatePromo}",
    "methodName":"postCartsPromoItems"
  }""")).asJson)

/* ********** SubmitOrder ********** */ 
.exec(http("Submit order - with single line item")
  .post(uri10 +"/services/apexrest/v2/cpq/carts/${CartId_ForUpdatePromo}/items/checkout")
  .headers(header_1)
  .body( StringBody("""{}""")).asJson)

/* ********** GetRequestDateDetailsForOrderItem *********** */
.exec(http("GetRequestDateDetailsForOrderItem")
  .get(uri10 +"/services/data/v39.0/query/?q=SELECT+RequestDate__c+FROM+OrderItem+WHERE+RequestDate__c+!=+null+ORDER+BY+RequestDate__c+DESC+LIMIT+10")
  .check(regex("""<RequestDate__c>(.*?)</RequestDate__c>""").findAll.exists.saveAs("RequestDatesList"))
  .headers(header_1))

.exec( session => {
  val requestDateList = session("RequestDatesList").as[List[String]]
  val maxdate = requestDateList(0)
  val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
  val dateforcurrentrun = LocalDate.parse(maxdate,formatter).plusDays(1)
  final_formatted_date.append(dateforcurrentrun)
  session
}) 

.exec( session => session.set("DATE", final_formatted_date ) )
.exec( session => {
  final_formatted_date = new StringBuilder()
  session
})

.exec(http("GetAssetId")
  .get(uri10 +"/services/data/v39.0/query/?q=SELECT Id,Name FROM Asset WHERE AccountId = '${AccountId}' AND Name = 'Test-Prods-For-BMK-700' LIMIT 1")
  .check(regex("<Id>(.*?)</Id>").find.saveAs("AssetId"))
  .headers(header_1))

/* ************ AssetChangeToOrder *********** */ 
.exec(http("Asset to order. One asset has been converted to order.")
  .post(uri10 +"/services/apexrest/v2/carts")
  .headers(header_1)
  .check(jsonPath("$.records[0].cartId").find.saveAs("CartId_ForPenalty"))
  .body(StringBody("""{ 
    "subaction": "assetToOrder",
    "id":"${AssetId}",
    "accountId": "${AccountId}", 
    "requestDate": "${DATE}" 
  } """)).asJson)

.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

/* *********** GetPromotionsAppliedToCart ********** */
.exec(http("Get promotions applied to cart. Cart has 3 promotions")
  .get(uri10 +"/services/apexrest/v2/cpq/carts/${CartId_ForPenalty}/promotions?subaction=getPromotionsAppliedToCart")
  .check(jsonPath("$.records[0].Id.value").find.exists.saveAs("AppliedPromotionId"))
  .headers(header_1))


/* *********** CancelPromotionWhichHasPenalty ********** */
.exec(http("Cancel a applied promotion that has penalty rule")
  .delete(uri10 +"/services/apexrest/v2/cpq/carts/${CartId_ForPenalty}/promotions?id=${AppliedPromotionId}")
  .headers(header_1)
  .check(regex("""INFO","message":"Successfully deleted.""").find.exists))

/* ********** SubmitOrder ********** */ 
.exec(http("Submit order - with single line item")
  .post(uri10 +"/services/apexrest/v2/cpq/carts/${CartId_ForPenalty}/items/checkout")
  .headers(header_1)
  .body( StringBody("""{}""")).asJson)

.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

}
