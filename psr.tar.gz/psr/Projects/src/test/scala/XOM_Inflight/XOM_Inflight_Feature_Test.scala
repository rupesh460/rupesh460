
package XOM_Inflight

  import scala.concurrent.duration._
  import io.gatling.core.Predef._
  import io.gatling.core.structure.ChainBuilder
  import io.gatling.http.Predef._
  import io.gatling.jdbc.Predef._
  import io.gatling.jsonpath._
  import Headers._
  import scala.collection._
  import java.time.format.DateTimeFormatter
  import java.time.LocalDateTime
  import java.time.LocalDate
  import io.gatling.core.feeder._
  import java.util.Base64
  import java.nio.charset.StandardCharsets
  import scala.util.matching.Regex


   object XOM_Inflight_Feature_Test {


      val uri01 = Configuration.Uri01
      val uri05 = Configuration.Uri05
      val uri10 = Configuration.Uri10
      val randomNumber = new scala.util.Random
      var accountName = new StringBuilder()
      var session_ids = Vector[String]()
     
    
      var modifiedItemJson = new StringBuilder()

      val userFeeder = csv("./src/test/resources/data/XOM_With_Inflight_Feature/XOM_Thor_Users.csv").random
       
      //val pricelistFeeder = csv("./src/test/resources/data/XOM_With_Inflight_Feature/OM_PLUS_Pricelist.csv").random   
      val pricelistEntryFeeder_SubmitSupplementalOrder = csv("./src/test/resources/data/XOM_With_Inflight_Feature/OM_PLUS_PriceListEntry_SubmitSupplementalOrder.csv").random
      val pricelistEntryFeeder_SubmitFollowOnOrder = csv("./src/test/resources/data/XOM_With_Inflight_Feature/OM_PLUS_PriceListEntry_SubmitFollowOnOrder.csv").random
      val SubmitSupplementalOrder_input = csv("./src/test/resources/data/XOM_With_Inflight_Feature/OM_PLUS_SubmitSupplementalOrder_input.csv").circular
      val SubmitFollowOnOrder_input = csv("./src/test/resources/data/XOM_With_Inflight_Feature/OM_PLUS_SubmitFollowOnOrder_input.csv").circular
      val CancelInflightOrder_input = csv("./src/test/resources/data/XOM_With_Inflight_Feature/OM_PLUS_CancelInflightOrder_input.csv").circular
      val DiscardAmendmentRequest_input = csv("./src/test/resources/data/XOM_With_Inflight_Feature/OM_PLUS_DiscardAmendmentRequest_input.csv").circular	  
      val accountFeeder_XOM_23L = csv("./src/test/resources/data/XOM_With_Inflight_Feature/OM_PLUS_Accounts_XOM_23L.csv").circular
      val accountFeeder_XOM2_23L = csv("./src/test/resources/data/XOM_With_Inflight_Feature/OM_PLUS_Accounts_XOM2_23L.csv").circular
      
      val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
      val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
      val password_v = (passwordByEnv.get("perf3").toString)
      val password_encoded = password_v.substring(12,(password_v.length - 2 ))
      val credentials = new String(Base64.getDecoder.decode(password_encoded))
    

//########################################################################################

      val SubmitSupplementalOrderScn = scenario("OM_PLUS_SubmitSupplementalOrder")

      .exec(session => session.set("password",credentials)) 

      .feed(userFeeder)
      .exec(http("001_XOM_SubmitSupplementalOrder_Login")
          .post(uri01 + "/")
          .headers(headers_00)
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          .formParam("startURL", "")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          .formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "M1D2l15jFvl")
          .formParam("display", "page")
          .formParam("username", "${username}")
          .formParam("pw", "${password}")
          .formParam("Login", ""))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("002_XOM_SubmitSupplementalOrder_RESTGetOAuthToken")
          .post("https://test.salesforce.com/services/oauth2/token")
          .header("Content-Type", "application/x-www-form-urlencoded")
          .formParam("password", "${password}")
          .formParam("username", "${username}")
          .formParam("client_secret", "7119599995527965426")
          .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
          .formParam("grant_type", "password")
          .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
          .check(status.is(200)))
      .repeat(10000)
      {

      
      feed(SubmitSupplementalOrder_input)
      .exec(http("003_XOM_SubmitSupplementalOrder_GetNewCsrfToken")
          .get(uri05 +"/apex/OmniScriptUniversalPage?trackKey=1591628967270#/OmniScriptType/CPQ/OmniScriptSubType/AmendOrder/OmniScriptLang/Multi-Language/ContextId/${OrderID}/PrefillDataRaptorBundle//true")
          .headers(headers_001)
          .check(regex("""vid":"(.+?)...xhr""").find.exists.saveAs("vid_sso"))
          .check(regex("""\{"name":"GenericInvoke2","len":4,"ns":"","ver":38.0,"csrf":"(.*)"\},\{"name":"Ge""").find.exists.saveAs("csrfToken_sso")))


    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("004_XOM_SubmitSupplementalOrder_preValidate")
        .post(uri05 +"/apexremote")
        .headers(headers_007)
        .check(regex(""""isPONR\\":false,\\"didAnyOrderItemReachPONR\\":false,\\"OrderStatus__c\\":\\"Frozen\\",\\"IsChangesAllowed__c\\":true,\\"Id\\":\\"(.*)\\"}]}""").find.exists)
        //.check(regex("""isPONR\\":false,\\"didAnyOrderItemReachPONR\\":false,\\"accountId\\":\\"(.+?)\\",\\"OrderStatus__c\\":\\"Frozen\\",\\"IsChangesAllowed__c\\":true""").find.exists)
        .body(ElFileBody("./src/test/resources/bodies/xom_inflight/preValidate.txt")))



    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("005_XOM_SubmitSupplementalOrder_createSupplementalOrder")
      .post(uri05 +"/apexremote")
      .headers(headers_007)
      .check(regex("""supplementalOrderId\\":\\"(.+?)\\"}]}""").find.exists.saveAs("supplementalOrderId"))
      //.check(regex("""supplementalOrderId\\":\\"(.+?)\\"""").find.exists.saveAs("supplementalOrderId"))
      .body(ElFileBody("./src/test/resources/bodies/xom_inflight/createSupplementalOrder.txt")))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
      
    .exec(http("006_XOM_SubmitSupplementalOrder_GetCartLineItems")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${supplementalOrderId}/items?pagesize=10&price=false&validate=false")
      .headers(header_1)
      .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.exists.saveAs("LineItem1")))

    .exec( session => {
      println( session( "LineItem1" ).as[String] )
      session
    })

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
    
    .exec(http("007_XOM_SubmitSupplementalOrder_GetLineItemDetails")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${supplementalOrderId}/items")
      .queryParamSeq(Seq(("id", "${LineItem1}")))
      .headers(header_1)
      .check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))

    .exec(session => {
      modifiedItemJson = new StringBuilder()
      modifiedItemJson.append("""{"items":{"records":[{"displaySequence":-1,""").append(session("capturedItemHierarchy").as[String]).append("}]}}")
      session
      })

     .exec(http("008_XOM_SubmitSupplementalOrder_UpdateCartLineItem")
       .put(uri10 +"/services/apexrest/v2/cpq/carts/${supplementalOrderId}/items")
       .headers(header_1)
       .body(StringBody(session =>  modifiedItemJson.replaceAllLiterally(""""Quantity":{"value":1.00""",""""Quantity":{"value":3.00""").toString() )).asJson
       .check(regex("""message":"Successfully.updated."}]""").find.exists))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("009_XOM_SubmitSupplementalOrder_SubmitOrder")
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${supplementalOrderId}/items/checkout")
      .headers(header_1)
      .check(regex("""Submission of order (.+?) was successful""").find.exists)
      //.check(regex("""Submission of order (.+?) was successful.""").find.exists)
      .body( StringBody("""{
      "cartId": "${supplementalOrderId}",
      "skipCheckoutValidation": true
      }""")).asJson)

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
  
    }

      val DiscardAmendmentRequestScn = scenario("OM_PLUS_DiscardAmendmentRequest")
      .exec(session => session.set("password",credentials)) 

      .feed(userFeeder)
      .exec(http("001_XOM_DiscardAmendmentRequest_Login")
          .post(uri01 + "/")
          .headers(headers_00)
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          .formParam("startURL", "")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          .formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "M1D2l15jFvl")
          .formParam("display", "page")
          .formParam("username", "${username}")
          .formParam("pw", "${password}")
          .formParam("Login", ""))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("002_XOM_DiscardAmendmentRequest_RESTGetOAuthToken")
          .post("https://test.salesforce.com/services/oauth2/token")
          .header("Content-Type", "application/x-www-form-urlencoded")
          .formParam("password", "${password}")
          .formParam("username", "${username}")
          .formParam("client_secret", "7119599995527965426")
          .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
          .formParam("grant_type", "password")
          .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
          .check(status.is(200)))
      .repeat(10000)
      {

      feed(DiscardAmendmentRequest_input)
      .exec(http("003_XOM_DiscardAmendmentRequest_GetNewCsrfToken")
          .get(uri05 +"/apex/OmniScriptUniversalPage?trackKey=1591628967270#/OmniScriptType/CPQ/OmniScriptSubType/AmendOrder/OmniScriptLang/Multi-Language/ContextId/${OrderID}/PrefillDataRaptorBundle//true")
          .headers(headers_001)
          .check(regex("""vid":"(.+?)...xhr""").find.exists.saveAs("vid_sso"))
          .check(regex("""\{"name":"GenericInvoke2","len":4,"ns":"","ver":38.0,"csrf":"(.*)"\},\{"name":"Ge""").find.exists.saveAs("csrfToken_sso")))


    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

//click on amend 
      .exec(http("004_XOM_DiscardAmendmentRequest_preValidate")
        .post(uri05 +"/apexremote")
        .headers(headers_007)
        //.check(regex(""""isPONR\\":false,\\"didAnyOrderItemReachPONR\\":false,\\"OrderStatus__c\\":\\"Frozen\\",\\"IsChangesAllowed__c\\":true,\\"Id\\":\\"(.*)\\"}]}""").find.exists)
        .check(regex("""isPONR\\":false,\\"didAnyOrderItemReachPONR\\":false,\\"accountId\\":\\"(.+?)\\",\\"OrderStatus__c\\":\\"Frozen\\",\\"IsChangesAllowed__c\\":true""").find.exists)
        .body(ElFileBody("./src/test/resources/bodies/xom_inflight/preValidate.txt")))



    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


    .exec(http("005_XOM_DiscardAmendmentRequest_createSupplementalOrder")
      .post(uri05 +"/apexremote")
      .headers(headers_007)
      //.check(regex("""supplementalOrderId\\":\\"(.+?)\\"}]}""").find.exists.saveAs("supplementalOrderId"))
      .check(regex("""supplementalOrderId\\":\\"(.+?)\\"""").find.exists.saveAs("supplementalOrderId"))
      .body(ElFileBody("./src/test/resources/bodies/xom_inflight/createSupplementalOrder.txt")))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("006_XOM_DiscardAmendmentRequest_GetCartLineItems")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${supplementalOrderId}/items?pagesize=10&price=false&validate=false")
      .headers(header_1)
      .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.exists.saveAs("LineItem1")))

    .exec( session => {
      println( session( "LineItem1" ).as[String] )
      session
    })

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("007_XOM_DiscardAmendmentRequest_GetLineItemDetails")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${supplementalOrderId}/items")
      .queryParamSeq(Seq(("id", "${LineItem1}")))
      .headers(header_1)
      .check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))

    .exec(session => {
      modifiedItemJson = new StringBuilder()
      modifiedItemJson.append("""{"items":{"records":[{"displaySequence":-1,""").append(session("capturedItemHierarchy").as[String]).append("}]}}")
      session
      })

     .exec(http("008_XOM_DiscardAmendmentRequest_UpdateCartLineItem")
       .put(uri10 +"/services/apexrest/v2/cpq/carts/${supplementalOrderId}/items")
       .headers(header_1)
       .body(StringBody(session =>  modifiedItemJson.replaceAllLiterally(""""Quantity":{"value":1.00""",""""Quantity":{"value":3.00""").toString() )).asJson
       .check(regex("""message":"Successfully.updated."}]""").find.exists))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
//discarding instead submit 
    .exec(http("009_XOM_DiscardAmendmentRequest_discardOrder")
      .post(uri05 +"/apexremote")
      .headers(headers_007)
      .check(regex(""""The order was discarded successfully. The previous order has now resumed fulfilment""").find.exists)
      .body(ElFileBody("./src/test/resources/bodies/xom_inflight/discardOrder.txt")))

    }

      val CancelInflightOrderScn = scenario("OM_PLUS_CancelInflightOrder")
      .exec(session => session.set("password",credentials)) 

      .feed(userFeeder)
      .exec(http("001_XOM_CancelInflightOrder_Login")
          .post(uri01 + "/")
          .headers(headers_00)
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          .formParam("startURL", "")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          .formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "M1D2l15jFvl")
          .formParam("display", "page")
          .formParam("username", "${username}")
          .formParam("pw", "${password}")
          .formParam("Login", ""))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("002_XOM_CancelInflightOrder_RESTGetOAuthToken")
          .post("https://test.salesforce.com/services/oauth2/token")
          .header("Content-Type", "application/x-www-form-urlencoded")
          .formParam("password", "${password}")
          .formParam("username", "${username}")
          .formParam("client_secret", "7119599995527965426")
          .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
          .formParam("grant_type", "password")
          .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
          .check(status.is(200)))

      .repeat(100000)
      {

      feed(CancelInflightOrder_input)
      .exec(http("003_XOM_CancelInflightOrder_GetNewCsrfToken")
          .get(uri05 +"/apex/HybridCPQ?id=${OrderID}")
          .headers(headers_001)
          .check(regex("""vid":"(.+?)...xhr""").find.exists.saveAs("vid_co"))
          .check(regex("""len":4."ns":""."ver":41.0."csrf":"(.+?)"["$&+,:;=?@#|'<>.^*()%!-}{a-z]*doNamedCredentialCallout""").find.exists.saveAs("csrfToken_co")))


    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("004_XOM_CancelInflightOrder_preValidate")
        .post(uri05 +"/apexremote")
        .headers(headers_007)
        //.check(regex("""isPONR\\":false,\\"didAnyOrderItemReachPONR\\":false,\\"OrderStatus__c\\":\\"Frozen\\",\\"IsChangesAllowed__c\\":true,\\"Id\\":\\"(.*)\\"}]}""").find.exists)
        .check(regex("""isPONR\\":false,\\"didAnyOrderItemReachPONR\\":false,\\"accountId\\":\\"(.+?)\\",\\"OrderStatus__c\\":\\"Frozen\\",\\"IsChangesAllowed__c\\":true""").find.exists)
        .body(ElFileBody("./src/test/resources/bodies/xom_inflight/preValidate_cancelorder.txt")))


    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
      .exec(http("005_XOM_CancelInflightOrder_createSupplementalOrder")
        .post(uri05 +"/apexremote")
        .headers(headers_008)
        //.check(regex("""cancelOrderId\\":\\"(.+?)\\",\\"cartId""").find.exists.saveAs("cancelOrderId"))
        .check(regex("""cancelOrderId\\":\\"(.+?)\\"""").find.exists.saveAs("cancelOrderId"))
        .body(ElFileBody("./src/test/resources/bodies/xom_inflight/createSupplementalOrder_cancelorder.txt")))

    
    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
      
/*
      .exec(http("009_XOM_CancelInflightOrder_submitCancelOrder")
        .post(uri05 +"/apexremote")
        .headers(headers_007)
        .check(regex(""""Cancellation is accepted""").find.exists)
        .body(ElFileBody("./src/test/resources/bodies/xom_inflight/submitCancelOrder.txt")))
*/

    .exec(http("006_XOM_CancelInflightOrder_SubmitOrder")
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${cancelOrderId}/items/checkout")
      .headers(header_1)
      //.check(regex("""Supplemental order is accepted""").find.exists)
      .check(regex("""Submission of order (.+?) was successful.""").find.exists)
      .body( StringBody("""{
      "cartId": "${cancelOrderId}",
      "skipCheckoutValidation": true
      }""")).asJson)

  }

      val SubmitFollowOnOrderScn = scenario("OM_PLUS_SubmitFollowOnOrder")
      .exec(session => session.set("password",credentials)) 

      .feed(userFeeder)
      .exec(http("001_XOM_SubmitFollowOnOrder_Login")
          .post(uri01 + "/")
          .headers(headers_00)
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          .formParam("startURL", "")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          .formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "M1D2l15jFvl")
          .formParam("display", "page")
          .formParam("username", "${username}")
          .formParam("pw", "${password}")
          .formParam("Login", ""))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("002_XOM_SubmitFollowOnOrder_RESTGetOAuthToken")
          .post("https://test.salesforce.com/services/oauth2/token")
          .header("Content-Type", "application/x-www-form-urlencoded")
          .formParam("password", "${password}")
          .formParam("username", "${username}")
          .formParam("client_secret", "7119599995527965426")
          .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
          .formParam("grant_type", "password")
          .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
          .check(status.is(200)))
      .repeat(10000)
      {

      feed(SubmitFollowOnOrder_input)

      .exec(http("003_XOM_SubmitFollowOnOrder_GetNewCsrfToken")
          .get(uri05 +"/apex/OmniScriptUniversalPage?trackKey=1591628967270#/OmniScriptType/CPQ/OmniScriptSubType/AmendOrder/OmniScriptLang/Multi-Language/ContextId/${OrderID}/PrefillDataRaptorBundle//true")
          .headers(headers_001)
          .check(regex("""vid":"(.+?)...xhr""").find.exists.saveAs("vid_foo"))
          .check(regex("""\{"name":"GenericInvoke2","len":4,"ns":"","ver":38.0,"csrf":"(.*)"\},\{"name":"Ge""").find.exists.saveAs("csrfToken_foo"))
          .check(regex("""BuildJSONWithPrefillV2","len":6,"ns":"","ver":38.0,"csrf":"(.*)"\},\{"name":"CompleteScript""").find.exists.saveAs("csrfToken_foo2")))

//CLick on amend
    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("004_XOM_SubmitFollowOnOrder_preValidate")
        .post(uri05 +"/apexremote")
        .headers(headers_007)
        .check(regex(""""Request was rejected. The original order (.+?) has progressed too far to be cancelled or amended. You can create a follow-on order to capture your changes""").find.exists)
        .body(ElFileBody("./src/test/resources/bodies/xom_inflight/preValidate_FollowOnOrder.txt")))

//yes click 
    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("005_XOM_SubmitFollowOnOrder_createFollowOnOrder")
        .post(uri05 +"/apexremote")
        .headers(headers_007)
        .check(regex("""followOnOrderId\\":\\"(.+?)\\"}""").find.exists.saveAs("followOnOrderId"))
        .body(ElFileBody("./src/test/resources/bodies/xom_inflight/createFollowOnOrder.txt")))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("006_XOM_SubmitFollowOnOrder_canSubmitOrder")
        .post(uri05 +"/apexremote")
        .headers(headers_007)
        .check(regex("""Order queued successfully""").find.exists)
        .body(ElFileBody("./src/test/resources/bodies/xom_inflight/canSubmitOrder.txt")))


     

}


  val NewOrderScn = scenario("OM_PLUS_NewOrder")

      .exec(session => session.set("password",credentials)) 

      .feed(userFeeder)
      .exec(http("001_XOM_NewOrder_Login")
          .post(uri01 + "/")
          .headers(headers_00)
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          .formParam("startURL", "")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          .formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "M1D2l15jFvl")
          .formParam("display", "page")
          .formParam("username", "${username}")
          .formParam("pw", "${password}")
          .formParam("Login", ""))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("002_XOM_SubmitSupplementalOrder_RESTGetOAuthToken")
          .post("https://test.salesforce.com/services/oauth2/token")
          .header("Content-Type", "application/x-www-form-urlencoded")
          .formParam("password", "${password}")
          .formParam("username", "${username}")
          .formParam("client_secret", "7119599995527965426")
          .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
          .formParam("grant_type", "password")
          .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
          .check(status.is(200)))

      .repeat(10000)
      {
         exec(session => session.set("AccountName",""))

        .exec( session => {
              val random_index = randomNumber.nextInt(100000)
              accountName.append("Acc-10-July-2020-"+random_index)
              session
            })

            .exec(session => session.set("AccountName",accountName))

             .exec( session => {
              accountName = new StringBuilder()
              session
            })


            /************ CreateAccount ************/
          .exec(http("01_OMPlus_TA_CreateAccount")
              .post(uri10 +"/services/data/v41.0/sobjects/account")
              .headers(header_1)
              .check(regex(""""id":"(.*?)"""").find.exists.saveAs("AccountId"))
              .body( StringBody("""
                {
                      "Name" : "${AccountName}",
                      "ShippingCity" : "San Francisco",
                      "RecordTypeId" : "012g00000005CoWAAU",
                      "Status__c"    : "Active"
                }""")).asJson)

           /* *********** CreateAOrder *********** */
          .exec(http("02_OMPlus_TA_Create_a_new_order")
          .post(uri10 +"/services/apexrest/v2/carts")
          .headers(header_1)
          .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
          .body(StringBody("""{"subaction":"createOrder",
                    "inputFields":[
                      {"AccountId":"${AccountId}"},
                      {"PriceListId__c":"a2Pg0000001UvvuEAC"},
                      {"Name":"NewOrder1"},{"Status":"Draft"},
                      {"EffectiveDate":"04/23/2020"}
                    ]}""")).asJson)
          
          
          .exec(http("03_OMPlus_TA_Order_Detail")
          .get(uri10 + "/${OrderID}")
          .headers(headers_05))

            .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .feed(pricelistEntryFeeder_SubmitSupplementalOrder)
      .exec(http("04_OMPlus_TA_Add_items_to_cart")
          .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
          .headers(header_1)
          .check(regex("""Successfully added.""").find.exists)
          //.check(regex("""\{"totalSize":1,"messages":\[\{"code":"150","severity":"INFO","message":"Successfully(......)""").find.exists.saveAs("AddStatus"))
          .body( StringBody("""{"methodName":"postCartsItems","items":[{"itemId":"${ProductId_suplimental}"}],"cartId":"${OrderID}","price":true,"validate":true,"includeAttachment":false,"pagesize":10,"lastRecordId":null,"hierarchy":-1,"query":"plan"}""")).asJson)

         .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

 /* ********** SubmitOrder ********** */
  .exec(http("05_OMPlus_TA_Submitorder")
    .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/checkout")
    .headers(header_1)
    .check(regex("""was successful""").find.exists)
    .body( StringBody("""{
    "cartId": "${OrderID}",
    "skipCheckoutValidation": true
    }""")).asJson)


      
      }

        val NewOrderFollowDataScn = scenario("OM_PLUS_NewOrderOrderFollowDataPrep")

      .exec(session => session.set("password",credentials)) 

      .feed(userFeeder)
      .exec(http("001_XOM_NewOrder_Login")
          .post(uri01 + "/")
          .headers(headers_00)
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          .formParam("startURL", "")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          .formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "M1D2l15jFvl")
          .formParam("display", "page")
          .formParam("username", "${username}")
          .formParam("pw", "${password}")
          .formParam("Login", ""))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("002_XOM_SubmitSupplementalOrder_RESTGetOAuthToken")
          .post("https://test.salesforce.com/services/oauth2/token")
          .header("Content-Type", "application/x-www-form-urlencoded")
          .formParam("password", "${password}")
          .formParam("username", "${username}")
          .formParam("client_secret", "7119599995527965426")
          .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
          .formParam("grant_type", "password")
          .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
          .check(status.is(200)))
      .repeat(10000)
      {
         exec(session => session.set("AccountName",""))

        .exec( session => {
              val random_index = randomNumber.nextInt(100000)
              accountName.append("Acc-10-Follow-2020-"+random_index)
              session
            })

            .exec(session => session.set("AccountName",accountName))

             .exec( session => {
              accountName = new StringBuilder()
              session
            })


            /************ CreateAccount ************/
          .exec(http("01_OMPlus_TA_CreateAccount")
              .post(uri10 +"/services/data/v41.0/sobjects/account")
              .headers(header_1)
              .check(regex(""""id":"(.*?)"""").find.exists.saveAs("AccountId"))
              .body( StringBody("""
                {
                      "Name" : "${AccountName}",
                      "ShippingCity" : "San Francisco",
                      "RecordTypeId" : "012g00000005CoWAAU",
                      "Status__c"    : "Active"
                }""")).asJson)

           /* *********** CreateAOrder *********** */
          .exec(http("02_OMPlus_TA_Create_a_new_order")
          .post(uri10 +"/services/apexrest/v2/carts")
          .headers(header_1)
          .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
          .body(StringBody("""{"subaction":"createOrder",
                    "inputFields":[
                      {"AccountId":"${AccountId}"},
                      {"PriceListId__c":"a2Pg0000001UvvuEAC"},
                      {"Name":"NewOrder1"},{"Status":"Draft"},
                      {"EffectiveDate":"04/23/2020"}
                    ]}""")).asJson)
          
          
          .exec(http("03_OMPlus_TA_Order_Detail")
          .get(uri10 + "/${OrderID}")
          .headers(headers_05))

            .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .feed(pricelistEntryFeeder_SubmitFollowOnOrder)
      .exec(http("04_OMPlus_TA_Add_items_to_cart")
          .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
          .headers(header_1)
          .check(regex("""Successfully added.""").find.exists)
          //.check(regex("""\{"totalSize":1,"messages":\[\{"code":"150","severity":"INFO","message":"Successfully(......)""").find.exists.saveAs("AddStatus"))
          .body( StringBody("""{"methodName":"postCartsItems","items":[{"itemId":"${ProductId_followon}"}],"cartId":"${OrderID}","price":true,"validate":true,"includeAttachment":false,"pagesize":10,"lastRecordId":null,"hierarchy":-1,"query":"plan"}""")).asJson)

         .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
   

 /* ********** SubmitOrder ********** */
  .exec(http("05_OMPlus_TA_Submitorder")
    .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/checkout")
    .headers(header_1)
    .check(regex("""was successful""").find.exists)
    .body( StringBody("""{
    "cartId": "${OrderID}",
    "skipCheckoutValidation": true
    }""")).asJson)



      
      }
}
