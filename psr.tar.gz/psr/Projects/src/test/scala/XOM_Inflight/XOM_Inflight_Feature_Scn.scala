package XOM_Inflight

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._

class XOM_Inflight_Scn extends Simulation {

	val httpConf = http
		.baseUrl(Configuration.BaseUrl)
		.inferHtmlResources(BlackList(""".*\.js""", """.*\.css""", """.*\.gif""", """.*\.jpeg""", """.*\.jpg""", """.*\.ico""", """.*\.woff""", """.*\.(t|o)tf""", """.*\.png"""), WhiteList())
		.acceptHeader("*/*")
		.acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8")
		.acceptEncodingHeader("gzip, deflate, sdch")
		.acceptLanguageHeader("en-US,en;q=0.8")
		.disableCaching
		.contentTypeHeader("application/x-www-form-urlencoded; charset=UTF-8")
		.userAgentHeader("Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:41.0) Gecko/20100101 Firefox/41.0")

	

        val NoofusersSubmitOMS_23LNewOrderScn = Integer.getInteger("NoofusersXOM_23",1)
        val NoofusersSubmitOMS2_23LNewOrderScn = Integer.getInteger("NoofusersXOM1_23",1)


        val NoofusersSupplementalOrderScn = Integer.getInteger("NoofusersSupplementalOrder",1) 
        val NoofusersDiscardAmendReqScn = Integer.getInteger("NoofusersDiscardAmendReq",1)
        val NoofusersCancelInflightOrderScn = Integer.getInteger("NoofusersCancelInflightOrder",1)
        val NoofusersSubmitFollowOnOrderScn = Integer.getInteger("NoofusersSubmitFollowOnOrder",1)

        val rampUpTimeSecs = Integer.getInteger("rampUpTimeSecs", 1)
	

	val maxDurationSecs = Integer.getInteger("maxDurationSecs", 1)
	val testDuration = Integer.getInteger("testDuration",1)

	setUp(

XOM_Inflight_Feature_Test.NewOrderScn.inject(rampUsers(NoofusersSubmitOMS_23LNewOrderScn) during (rampUpTimeSecs seconds)).protocols(httpConf),
XOM_Inflight_Feature_Test.NewOrderFollowDataScn.inject(rampUsers(NoofusersSubmitOMS2_23LNewOrderScn) during (rampUpTimeSecs seconds)).protocols(httpConf),
XOM_Inflight_Feature_Test.SubmitSupplementalOrderScn.inject(rampUsers(NoofusersSupplementalOrderScn) during (rampUpTimeSecs seconds)).protocols(httpConf),
XOM_Inflight_Feature_Test.DiscardAmendmentRequestScn.inject(rampUsers(NoofusersDiscardAmendReqScn) during (rampUpTimeSecs seconds)).protocols(httpConf),
XOM_Inflight_Feature_Test.CancelInflightOrderScn.inject(rampUsers(NoofusersCancelInflightOrderScn) during (rampUpTimeSecs seconds)).protocols(httpConf),
XOM_Inflight_Feature_Test.SubmitFollowOnOrderScn.inject(rampUsers(NoofusersSubmitFollowOnOrderScn) during (rampUpTimeSecs seconds)).protocols(httpConf)).maxDuration(maxDurationSecs)  
}
