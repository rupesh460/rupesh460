package eComm_V106_Anonymous

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._
import Headers._
import Configuration._

object eComm_AWS {
  val uri01 = Configuration.Uri01
  val uri02 = Configuration.Uri02_AWS
  val userFeeder = csv("./src/test/resources/data/datagen/Perf2users.csv").random
  val offerFeeder = csv("./src/test/resources/data/eComm/offercodes.csv").random
  val contextFeeder = csv("./src/test/resources/data/eComm/contextdimensions.csv").random
  val promoFeeder = csv("./src/test/resources/data/eComm/promocodes.csv").random
  val childOfferFeeder = csv("./src/test/resources/data/eComm/childoffercodes.csv").random
  val accountFeeder = csv("./src/test/resources/data/eComm/accounts.csv").random
  val attrFeeder = csv("./src/test/resources/data/eComm/eCom-Prod-Bnd-15399454256600.csv").random
  val rootAssetFeeder = csv("./src/test/resources/data/eComm/eCom-root-asset-id.csv").random
  val updBasketJson = "./src/test/resources/bodies/eComm/eCom-Prod-Bnd-15399454256600_updatebasket.txt"

  val productViewsScn = scenario("AWS_DC_Anon_ProductViews")

    .repeat(108000) {

      /* ********* Call to get contextKey  ************* */

      feed(contextFeeder)
        .exec(http("getAnonymousCK")
          .get(uri02 + """/v3/catalogs/ECOM-CATALOG/offers?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex("""contextKey":"(.+?)".""").find.exists.saveAs("AnonymousCK")))

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* ********** GetListOfProductsForCart *********** */

        //.feed(accountFeeder)
        //.feed(ckAnonymousFeeder)
        .exec(http("GetOffersByCatalog")
          .get(uri02 + """/v3/catalogs/ECOM-CATALOG/offers?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex("""contextKey""").find.exists)
          .check(jsonPath("$.offers[*].ProductCode").findAll.saveAs("ProductOffersList")).asJson)

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        .exec(flushSessionCookies)
            .exec(flushCookieJar)
            .exec(flushHttpCache)

    }

  val addToCartScn = scenario("AWS_DC_Anon_AddToCart")

    .repeat(6000) {

      /* ********* Call to get contextKey  ************* */
      feed(contextFeeder)
        .exec(http("getAnonymousCK")
          .get(uri02 + """/v3/catalogs/ECOM-CATALOG/offers?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex("""contextKey":"(.+?)".""").find.exists.saveAs("AnonymousCK")))

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* ********** GetOfferDetails *********** */
        //.feed(accountFeeder)
        //.feed(ckAnonymousFeeder)
        .feed(offerFeeder)
        .exec(http("GetOfferDetails")
          .get(uri02 + """/v3/catalogs/ECOM-CATALOG/offers/${OfferCode}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex("""contextKey""").find.exists)
          .check(bodyString.saveAs("OfferDetailsRes")).asJson)

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* ********** ConfigureOffer *********** */
        .exec(http("ConfigureOffer")
          .post(uri02 + """/v3/catalogs/ECOM-CATALOG/offers/${OfferCode}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
          .body(StringBody("""${OfferDetailsRes}""")).asJson
          //.body(ElFileBody("./src/test/resources/bodies/eComm/eCom-Prod-Bnd-15399454256600.txt")).asJson
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          //.check(regex("""contextKey""").find.exists)
          .check(regex(""""result":(.+?)."errorCode":"INVOKE""").find.exists.saveAs("AddWithConfig")).asJson)

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* ********** AddWithNoConfig *********** */
        .exec(http("AddToCartWithNoConfig")
          .post(uri02 + """/v3/catalogs/ECOM-CATALOG/basket?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
          .headers(header_1)
          .check(status.is(200))
          .check(regex("""cartContextKey""").find.exists)
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKeyAddToCartWithNoConfig")).asJson
          .body(StringBody("""{"offer":"${OfferCode}","basketAction":"AddWithNoConfig"}""")).asJson)

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* ********** AddWithConfig *********** */
        .exec(http("AddToCartWithConfig")
          .post(uri02 + """/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyAddToCartWithNoConfig}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          //.check(regex("""contextKey""").find.exists)
          .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKeyAddToCartWithConfig"))
          .check(regex("""result":(.+?)."errorCode""").find.exists.saveAs("CreateCart"))
          .body(StringBody("""{"basketAction":"AddAfterConfig","productConfig":${AddWithConfig}}""")).asJson)

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* ********** DeleteFromBasket *********** */
        .exec(http("DeleteFromBasket")
          .post(uri02 + """/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyAddToCartWithConfig}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          //.check(regex("""contextKey""").find.exists)
          .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKeyDeleteFromBasket"))
          .body(StringBody("""{"deleteBundleNumber":"1","basketAction":"DeleteFromBasket"}""")).asJson)

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* ********** AddPromotion-Step1 *********** */
        .feed(promoFeeder)
        .exec(http("AddPromotion-Step1")
          .post(uri02 + """/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyAddToCartWithConfig}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          //.check(regex("""contextKey""").find.exists)
          .check(regex("""cartContextKey":"(.+?)"."result""").optional.saveAs("CartContextKeyAddPromotionStep1"))
          .check(regex(""""transactionKey":"(.+?)"""").optional.saveAs("TransKey"))
          .check(regex("""result":(.+?)."errorCode""").optional.saveAs("CreateCart"))
          .check(regex(""""transactionKey":"(.+?)"""").count.saveAs("TransKeyCount"))
          .body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}"}""")).asJson)

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        .doIfEquals("${TransKeyCount}", 1) {
          /* ********** AddPromotion-Step2 *********** */
          feed(promoFeeder)
            .exec(http("AddPromotion-Step2")
              .post(uri02 + """/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyAddToCartWithConfig}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
              .headers(header_1)
              .check(status.is(200))
              .check(status.not(404), status.not(500),status.not(504),status.not(503))
              //.check(regex("""contextKey""").find.exists)
              .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKeyAddPromotion-Step2"))
              .check(regex("""result":(.+?)."errorCode""").find.exists.saveAs("CreateCart"))
              .body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}","transactionKey":"${TransKey}"}""")).asJson)

            .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        }

        .exec(flushSessionCookies)
            .exec(flushCookieJar)
            .exec(flushHttpCache)
    }

  val checkOutScn = scenario("AWS_DC_Anon_CheckOut")
    
    .repeat(2000) {

      /* ********* Call to get contextKey  ************* */
      feed(contextFeeder)
        .exec(http("getAnonymousCK")
          .get(uri02 + """/v3/catalogs/ECOM-CATALOG/offers?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex("""contextKey":"(.+?)".""").find.exists.saveAs("AnonymousCK")))

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* ********** GetOfferDetails *********** */
        .feed(accountFeeder)
        //.feed(ckAnonymousFeeder)
        .feed(offerFeeder)
        .exec(http("GetOfferDetails")
          .get(uri02 + """/v3/catalogs/ECOM-CATALOG/offers/${OfferCode}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex("""contextKey""").find.exists)
          .check(bodyString.saveAs("OfferDetailsRes")).asJson)

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* ********** ConfigureOffer *********** */
        .exec(http("ConfigureOffer")
          .post(uri02 + """/v3/catalogs/ECOM-CATALOG/offers/${OfferCode}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
          .body(StringBody("""${OfferDetailsRes}""")).asJson
          //.body(ElFileBody("./src/test/resources/bodies/eComm/eCom-Prod-Bnd-15399454256600.txt")).asJson
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          //.check(regex("""contextKey""").find.exists)
          .check(regex(""""result":(.+?)."errorCode":"INVOKE""").find.exists.saveAs("AddWithConfig")).asJson)

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* ********** AddWithNoConfig *********** */
        .exec(http("AddToCartWithNoConfig")
          .post(uri02 + """/v3/catalogs/ECOM-CATALOG/basket?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          //.check(regex("""contextKey""").find.exists)
          .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKeyAddToCartWithNoConfig")).asJson
          .body(StringBody("""{"offer":"${OfferCode}","basketAction":"AddWithNoConfig"}""")).asJson)

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* ********** AddWithConfig *********** */
        .exec(http("AddToCartWithConfig")
          .post(uri02 + """/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyAddToCartWithNoConfig}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          //.check(regex("""contextKey""").find.exists)
          .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKeyAddToCartWithConfig"))
          .check(regex("""result":(.+?)."errorCode""").find.exists.saveAs("CreateCartAddToCartWithConfig"))
          .body(StringBody("""{"basketAction":"AddAfterConfig","productConfig":${AddWithConfig}}""")).asJson)

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        /* ********** AddPromotion-Step1 *********** */
        .feed(promoFeeder)
        .exec(http("AddPromotion-Step1")
          .post(uri02 + """/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyAddToCartWithConfig}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
          .headers(header_1)
          .check(status.is(200))
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          //.check(regex("""contextKey""").find.exists)
          .check(regex("""cartContextKey":"(.+?)"."result""").optional.saveAs("CartContextKeyAddPromotionStep1"))
          .check(regex(""""transactionKey":"(.+?)"""").optional.saveAs("TransKey"))
          .check(regex("""result":(.+?)."errorCode""").optional.saveAs("CreateCart"))
          .check(regex(""""transactionKey":"(.+?)"""").count.saveAs("TransKeyCount"))
          .body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}"}""")).asJson)

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        .doIfEquals("${TransKeyCount}", 1) {
          /* ********** AddPromotion-Step2 *********** */
          feed(promoFeeder)
            .exec(http("AddPromotion-Step2")
              .post(uri02 + """/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyAddToCartWithConfig}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
              .headers(header_1)
              .check(status.is(200))
              .check(status.not(404), status.not(500),status.not(504),status.not(503))
              //.check(regex("""contextKey""").find.exists)
              .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKeyAddPromotion-Step2"))
              .check(regex("""result":(.+?)."errorCode""").find.exists.saveAs("CreateCart"))
              .body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}","transactionKey":"${TransKey}"}""")).asJson)

            .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

            /* ********** CreateCart *********** */
            .feed(accountFeeder)
            .exec(http("CreateCart")
              .post(uri02 + """/v3/carts""")
              .headers(header_1)
              .check(status.is(200))
              .check(status.not(404), status.not(500),status.not(504),status.not(503))
              //.check(regex("""contextKey""").find.exists)
              .check(regex("""orderId":"(.+?)"""").find.exists.saveAs("OrderId"))
              .body(StringBody("""{"JSONResult":${CreateCartAddToCartWithConfig},"accountId": "${AccountId}","catalogCode": "ECOM-CATALOG"}""")).asJson)

            .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)
        }

        .doIfEquals("${TransKeyCount}", 0) {
          /* ********** CreateCart *********** */
          feed(accountFeeder)
            .exec(http("CreateCart")
              .post(uri02 + """/v3/carts""")
              .headers(header_1)
              .check(status.is(200))
              .check(status.not(404), status.not(500),status.not(504),status.not(503))
              //.check(regex("""contextKey""").find.exists)
              .check(regex("""orderId":"(.+?)"""").find.exists.saveAs("OrderId"))
              .body(StringBody("""{"JSONResult":${CreateCartAddToCartWithConfig},"accountId": "${AccountId}","catalogCode": "ECOM-CATALOG"}""")).asJson)

            .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)
        }
    }
  exec(flushSessionCookies)
    .exec(flushCookieJar)
    .exec(flushHttpCache)
    //.exec { session => println(session); session }

}