package eComm_V106_Anonymous

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._

class eComm_AWS_Scn extends Simulation {

  val httpConf = http
    .baseUrl(Configuration.BaseUrl_AWS)
    .inferHtmlResources(BlackList(""".*\.js""", """.*\.css""", """.*\.gif""", """.*\.jpeg""", """.*\.jpg""", """.*\.ico""", """.*\.woff""", """.*\.(t|o)tf""", """.*\.png"""), WhiteList())
    .acceptHeader("*/*")
    .acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8")
    .acceptEncodingHeader("gzip, deflate, sdch")
    .acceptLanguageHeader("en-US,en;q=0.8")
    .disableCaching
    .contentTypeHeader("application/x-www-form-urlencoded; charset=UTF-8")
    .userAgentHeader("Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:41.0) Gecko/20100101 Firefox/41.0")

  val productViewUsers = Integer.getInteger("AWS_Anon_ProductViews", 1)
  val productViewRampUp = Integer.getInteger("AWS_Anon_ProductViews_RampUp", 1)

  val addToCartUsers = Integer.getInteger("AWS_Anon_AddToCart", 1)
  val addToCartRampUp = Integer.getInteger("AWS_Anon_AddToCart_RampUp", 1)

  val checkOutUsers = Integer.getInteger("AWS_Anon_CheckOut", 1)
  val checkOutRampUp = Integer.getInteger("AWS_Anon_CheckOut_RampUp", 1)

  val maxDurationSecs = Integer.getInteger("maxDurationSecs", 1)
  val testDuration = Integer.getInteger("testDuration",1)


  setUp(
    eComm_AWS.productViewsScn.inject(rampUsers(productViewUsers) during (productViewRampUp seconds)).protocols(httpConf),
    eComm_AWS.addToCartScn.inject(rampUsers(addToCartUsers) during (addToCartRampUp seconds)).protocols(httpConf),
    eComm_AWS.checkOutScn.inject(rampUsers(checkOutUsers) during (checkOutRampUp seconds)).protocols(httpConf)).maxDuration(maxDurationSecs seconds)
}
