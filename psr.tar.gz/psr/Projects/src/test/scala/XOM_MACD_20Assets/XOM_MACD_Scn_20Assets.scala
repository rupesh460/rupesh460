package XOM_MACD_20Assets

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._

class XOM_MACD_Scn_20Assets extends Simulation {

	val httpConf = http
		.baseUrl(Configuration.BaseUrl)
		.inferHtmlResources(BlackList(""".*\.js""", """.*\.css""", """.*\.gif""", """.*\.jpeg""", """.*\.jpg""", """.*\.ico""", """.*\.woff""", """.*\.(t|o)tf""", """.*\.png"""), WhiteList(""".*\.json""", """.*\.html""", """.*\.xml"""))
		.acceptHeader("*/*")
		.acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8")
		.acceptEncodingHeader("gzip, deflate, sdch")
		.acceptLanguageHeader("en-US,en;q=0.8")
		.disableCaching
		.contentTypeHeader("application/x-www-form-urlencoded; charset=UTF-8")
		.userAgentHeader("Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:41.0) Gecko/20100101 Firefox/41.0")
	

	val NormalflowRampup = Integer.getInteger("NormalflowRampup", 1)
	val DeleteflowRampup = Integer.getInteger("DeleteflowRampup", 1)
	val UpdateflowRampup = Integer.getInteger("UpdateflowRampup", 1)
	val NormalflowUsers = Integer.getInteger("NormalflowUsers", 1)
	val DeleteflowUsers = Integer.getInteger("DeleteflowUsers", 1)
	val UpdateflowUsers = Integer.getInteger("UpdateflowUsers", 1)
	val maxDurationSecs = Integer.getInteger("maxDurationSecs", 1)
	val testDuration = Integer.getInteger("testDuration",1)


		setUp(
		XOM_MACD_Test_20Assets.Normalflow.inject(rampUsers(NormalflowUsers) during (NormalflowRampup seconds)).protocols(httpConf),
		XOM_MACD_Test_20Assets.Deleteflow.inject(rampUsers(DeleteflowUsers) during (DeleteflowRampup seconds)).protocols(httpConf),
		XOM_MACD_Test_20Assets.Updateflow.inject(rampUsers(UpdateflowUsers) during (UpdateflowRampup seconds)).protocols(httpConf)).maxDuration(maxDurationSecs)
  	
    //XOM_MACD_Test.Normalflow.inject(rampUsers(NormalflowUsers) over (NormalflowRampup seconds)).protocols(httpConf)).maxDuration(maxDurationSecs)
  	
  	}
