package FGM_Ecom

object Configuration {
	val BaseUrl = "https://c.cs17.visual.force.com"
	val Uri01 = "https://test.salesforce.com"
	val Uri05 = "https://c.cs17.visual.force.com"
	val Uri10 = "https://cs17.salesforce.com"

	val MinWaitMs = 10000
	val MaxWaitMs = 20000

	val MiniMinWaitMs = 10000
	val MiniMaxWaitMs = 20000

}