package FGM

object Configuration {
	val BaseUrl = "https://c.cs17.visual.force.com"
	val Uri01 = "https://test.salesforce.com"
	val Uri05 = "https://c.cs17.visual.force.com"
	val Uri10 = "https://cs17.salesforce.com"

	val MinWaitMs = 60000
	val MaxWaitMs = 120000

	val MiniMinWaitMs = 60000
	val MiniMaxWaitMs = 120000

}