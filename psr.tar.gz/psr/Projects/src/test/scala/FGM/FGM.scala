package FGM

import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.core.structure.ChainBuilder
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._
import io.gatling.jsonpath._
import Headers._
import scala.collection._
import java.time.format.DateTimeFormatter
import java.time.LocalDateTime


 object FGM {

    val uri01 = Configuration.Uri01
    val uri05 = Configuration.Uri05
    val uri10 = Configuration.Uri10
    var modifiedItemJson = new StringBuilder()
    val origItemAttrHeirarchy = new StringBuilder()
    val modItemAttrHeirarchy = new StringBuilder()
    val userFeeder = csv("./src/test/resources/data/fgm/FGM_TestUsers.csv").random
    val accountIdFeeder = csv("./src/test/resources/data/fgm/FGM_Accounts.csv").random
    val productFeeder = csv("./src/test/resources/data/fgm/FGM_Products.csv").random
    val promotionFeeder = csv("./src/test/resources/data/fgm/FGM_PromotionIds.csv").random
    
	 val scn = scenario("FGM")
        
   .feed(userFeeder)
   .exec(http("RESTGetOAuthToken")
    .post("https://test.salesforce.com/services/oauth2/token")
    .header("Content-Type", "application/x-www-form-urlencoded")
    .formParam("password", "${password}")
    .formParam("username", "${username}")
    .formParam("client_secret", "7119599995527965426")
    .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
    .formParam("grant_type", "password")
    .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
    .check(status.is(200)))

 .repeat(5)
 {
   /* *********** CreateOrder *********** */
   feed(accountIdFeeder)
   .exec(http("Create a new order")
    .post(uri10 +"/services/apexrest/v2/carts")
    .headers(header_1)
    .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
    .body( StringBody("""{"subaction":"createOrder",
                      "inputFields":[
                        {"AccountId":"${AccountId}"},
                        {"PriceListId__c":"a2Pg0000001R5ZjEAK"},
                        {"Name":"NewOrder1"},{"Status":"Draft"},
                        {"EffectiveDate":"9/27/2017"}
                      ]}""")).asJson)

 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  /* ********** SetPriceListForCart *********** */
  .exec(http("Set PriceList for the order")
   .put(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/")
   .headers(header_1)
   .body( StringBody("""{
                          "inputFields": 
                          [
                            {
                                "PriceListId__c": "a2Pg0000001R5ZjEAK"
                              }
                            ],
                          "cartId": "${OrderID}",
                          "methodName": "updateCarts"
                      }""")).asJson)


  /* ********** GetListOfProductsForCart *********** */
  .exec(http("Get list of products for cart with page size 20")
   .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/products")
   .check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfPBEntries"))
   .headers(header_1))

  /* ********** GetListOfPromotionsForCart *********** */ 
  .exec(http("Get list of promotions for cart with page size 20")
   .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/promotions")
   .check(jsonPath("$.records[*].id").findAll.saveAs("PromotionList"))
   .headers(header_1))  
  
  /* ********** AddItemsToCart *********** */
  .feed(productFeeder)
  .exec(http("Add items to cart1")
   .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
   .headers(header_1)
   .body( StringBody("""{
                                        "items":[{
                                        "itemId":"${ProductId}"
                                        }],
                                        "hierarchy":3,
                                        "lastItemId":"",
                                        "pagesize":20
                                        }""")).asJson)

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

   /* ********** AddItemsToCart *********** */
  .feed(productFeeder)
  .exec(http("Add items to cart2")
   .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
   .headers(header_1)
   .body( StringBody("""{
                                        "items":[{
                                        "itemId":"${ProductId}"
                                        }],
                                        "hierarchy":3,
                                        "lastItemId":"",
                                        "pagesize":20
                                        }""")).asJson)

 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
            
           
  /* ********** AddPromotionToCart *********** */
  .feed(promotionFeeder)
  .exec(http("Add a promotion to cart1")
  .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/promotions")
  .headers(header_1)
  .body( StringBody("""{
                            "items": [{"itemId":"${PromotionId}"}],
                            "promotionId":"${PromotionId}",
                            "cartId":"${OrderID}",
                            "methodName":"postCartsPromoItems"
                                        }""")).asJson)

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  /* ********** AddPromotionToCart *********** */
  .feed(promotionFeeder)
  .exec(http("Add a promotion to cart2")
  .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/promotions")
  .headers(header_1)
  .body( StringBody("""{
                            "items": [{"itemId":"${PromotionId}"}],
                            "promotionId":"${PromotionId}",
                            "cartId":"${OrderID}",
                            "methodName":"postCartsPromoItems"
                                        }""")).asJson)

 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

   /* ********** GetCarts *********** */
  .exec(http("Get carts pricing")
   .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}?price=true&validate=true")
   .headers(header_1))
   
  /* ********** GetCartLineItems *********** */
  .exec(http("Get list of cart line items")
   .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
   .headers(header_1)
   .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1"))
   .check(jsonPath("$.records[1].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem2"))
   .check(jsonPath("$.records[2].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem3"))
   .check(jsonPath("$.records[3].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem4")))

 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
          
  /* *********** GetPromotionsAppliedToCart ********** */
  .exec(http("Get promotions applied to cart")
   .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/promotions?subaction=getPromotionsAppliedToCart")
   .check(jsonPath("$.records[0].Id.value").find.exists.saveAs("AppliedPromotionId1"))
   .check(jsonPath("$.records[1].Id.value").find.exists.saveAs("AppliedPromotionId2"))
   .headers(header_1))

.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  /* ********** GetCartItemsByItemId *********** */
  .exec(http("Get line item details")
   .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
   .queryParamSeq(Seq(("id", "${LineItem1}")))
   .headers(header_1)
   .check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  .exec(session => { 
   modifiedItemJson = new StringBuilder()
   modifiedItemJson.append("""{"items":{"records":[{"displaySequence":-1,""").append(session("capturedItemHierarchy").as[String]).append("}]}}")
   session
  })
              

  /* ********** UpdateItemsInCart *********** */
  /* Updating the Quantity from default 1.00 to 3.00 */
  .exec(http("Update cart line item")
   .put(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
   .headers(header_1)
   .body(StringBody(session =>  modifiedItemJson.replaceAllLiterally(""""Quantity":{"value":1.00""",""""Quantity":{"value":3.00""").toString() )).asJson)
            

 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
        

  /* ********** DeleteItemFromCart********** */
  .exec(http("Delete an item from the cart")
  .delete(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/${LineItem3}")
  .headers(header_1))  

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
  
  /* ********** GetPricingDetailsForCartLineItem *********** */
  .exec(http("Get pricing details for the cart line item")
   .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/${LineItem2}/pricing?fields=RecurringCharge__c")
   .headers(header_1)) 

          
 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


  /* *********** DeletePromotionAppliedToCart ********** */
  .exec(http("Delete an applied promotion in the cart")
   .delete(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/promotions?id=${AppliedPromotionId1}")
   .headers(header_1))

 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  /* ********** CloneCartLineItem ********** */
  .exec(http("Clone a cart line item")
   .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/clone")
   .headers(header_1)
   .body( StringBody("""{
                                    "items": [
                                                {"itemId": "${LineItem4}"}
                                    ],
                                    "hierarchy": 1,
                                    "lastItemId": "",
                                    "pagesize": 20
                                 }""")).asJson)

 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


  /* ********** SubmitOrder ********** */ 
  .exec(http("Submit order")
   .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/checkout")
   .headers(header_1)
   .body( StringBody("""{}""")).asJson)

 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
}
}