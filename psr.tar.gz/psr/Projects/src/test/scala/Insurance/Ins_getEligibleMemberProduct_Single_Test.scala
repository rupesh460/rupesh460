package Insurance

  import scala.concurrent.duration._
  import io.gatling.core.Predef._
  import io.gatling.core.structure.ChainBuilder
  import io.gatling.http.Predef._
  import io.gatling.jdbc.Predef._
  import io.gatling.jsonpath._
  import Headers._
  import scala.collection._
  import java.time.format.DateTimeFormatter
  import java.time.LocalDateTime
  import java.time.LocalDate
  import io.gatling.core.feeder._
  import java.util.Base64
  import java.nio.charset.StandardCharsets
  import scala.util.matching.Regex


   object Ins_getEligibleMemberProduct_Single_Test {

      val uri01 = Configuration.Uri01
      val uri02 = Configuration.Uri02
      val uri03 = Configuration.Uri03
      val uri04 = Configuration.Uri04
      val uri05 = Configuration.Uri05
      val userFeeder = csv("./src/test/resources/data/Insurance/Users.csv").random
      val testDuration = Integer.getInteger("testDuration",1)
      val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
      val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
      val password_v = (passwordByEnv.get("Ins").toString)
      val password_encoded = password_v.substring(12,(password_v.length - 2 ))
      val credentials = new String(Base64.getDecoder.decode(password_encoded))
      
      
  	  val scn = scenario("Ins_getEligibleMemberProduct_Single_Test")

      .exec(session => session.set("password",credentials))
      
      .during(testDuration) {
      feed(userFeeder)        
      .exec(http("003_Ins_getEligibleMemberProduct_Single_Test_T01_Login")
          .post(uri01 + "/")
          .headers(headers_35)
     //     .formParam("pqs", "?startURL=%2Fvisualforce%2Fsession%3Furl%3Dhttps%253A%252F%252Fperf-ins-testing.lightning.force.com%252Fone%252Fone.app&ec=302")
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          // .formParam("startURL", "/visualforce/session?url=https%3A%2F%2Fperf-ins-testing.lightning.force.com%2Fone%2Fone.app")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          // .formParam("qs", "r=https%3A%2F%2Fperf-ins-testing.my.salesforce.com%2Fvisualforce%2Fsession%3Furl%3Dhttps%253A%252F%252Fperf-ins-testing.lightning.force.com%252Fone%252Fone.app")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "R6m6RfkuV7R")
          .formParam("display", "page")
          .formParam("username", "${username}")
          // .formParam("ExtraLog", "%5B%7B%22width%22:1440%7D,%7B%22height%22:900%7D,%7B%22language%22:%22en-GB%22%7D,%7B%22offset%22:-5.5%7D,%7B%22scripts%22:%5B%7B%22size%22:249,%22summary%22:%22if%20(self%20==%20top)%20%7Bdocument.documentElement.style.v%22%7D,%7B%22size%22:578,%22summary%22:%22var%20SFDCSessionVars=%7B%5C%22server%5C%22:%5C%22https:%5C%5C/%5C%5C/login.sal%22%7D,%7B%22url%22:%22https://perf-ins-testing.my.salesforce.com/jslibrary/SfdcSessionBase208.js%22%7D,%7B%22url%22:%22https://perf-ins-testing.my.salesforce.com/jslibrary/LoginHint208.js%22%7D,%7B%22size%22:26,%22summary%22:%22LoginHint.hideLoginForm();%22%7D,%7B%22size%22:36,%22summary%22:%22LoginHint.getSavedIdentities(false);%22%7D,%7B%22url%22:%22https://perf-ins-testing.my.salesforce.com/jslibrary/baselogin4.js%22%7D,%7B%22url%22:%22https://perf-ins-testing.my.salesforce.com/jslibrary/LoginMarketingSurveyResponse.js%22%7D,%7B%22url%22:%22https://perf-ins-testing.my.salesforce.com/marketing/survey/survey1/1380%22%7D,%7B%22url%22:%22https://perf-ins-testing.my.salesforce.com/marketing/survey/survey4/1380%22%7D,%7B%22size%22:517,%22summary%22:%22function%20handleLogin()%7Bdocument.login.un.value=doc%22%7D%5D%7D,%7B%22scriptCount%22:11%7D,%7B%22iframes%22:%5B%22https://c.salesforce.com/login-messages/promos.html?r=https%253A%252F%252Fperf-ins-testing.my.salesforce.com%252Fvisualforce%252Fsession%253Furl%253Dhttps%25253A%25252F%25252Fperf-ins-testing.lightning.force.com%25252Fone%25252Fone.app%22,%22https://login.salesforce.com/login/sessionserver212.html%22%5D%7D,%7B%22iframeCount%22:2%7D,%7B%22referrer%22:%22https://perf-ins-testing.my.salesforce.com/visualforce/session?url=https%253A%252F%252Fperf-ins-testing.lightning.force.com%252Fone%252Fone.app%22%7D%5D")
          // .formParam("Fingerprint", "%7B%22platform%22:%22MacIntel%22,%22window%22:%22836x1440%22,%22screen%22:%22900x1440%22,%22color%22:%2224-24%22,%22timezoneOffset%22:%22-330%22,%22canvas%22:%22-2102302436%22,%22sessionStorage%22:%22true%22,%22LocalStorage%22:%22true%22,%22indexDB%22:%22true%22,%22webSockets%22:%22true%22,%22plugins%22:%22Chrome%20PDF%20Plugin:Portable%20Document%20Format%5CnChrome%20PDF%20Viewer:%5CnNative%20Client:%5Cn%22,%22drm%22:1,%22languages%22:%5B%22en-GB%22,%22en-US%22,%22en%22%5D,%22fonts%22:%22%22,%22codecs%22:%22gIEIqgoIQqoCqH4=%22,%22mediaDevices%22:%22audioinput::default%5Cnaudioinput::c2f087d07e9625d58196c1dcdc8b4744d952e59c71f9c67f5ba00634cba94017%5Cnvideoinput::2a7fcbffc79af1068cbcd7487db6acdebd3f83a581aacd563a08b34d51595c7e%5Cnaudiooutput::default%5Cnaudiooutput::3c9bcf25320d95ed9593f8228ca811913eea05330387f4dbb5fe130b3d0565a1%5Cn%22%7D")
          .formParam("pw", "${password}")
          .formParam("Login", "Log In"))



    .exec(http("Ins_getEligibleMemberProduct_Single_Test_request_0")
      .get(uri04 + "/apex/InsuranceOmniScriptUniversal?layout=newport&id=a2Y1U000000eFobUAE&designerPreviewId=a2Y1U000000eFobUAE&previewEmbedded=true&tabKey=1572329212709&isdtp=p1&sfdcIFrameOrigin=https%3A%2F%2Fperf-ins-testing--vlocity-ins.visualforce.com&sfdcIFrameHost=web")
      .headers(headers_0)
      .check(regex("""\{"name":"GenericInvoke2","len":4,"ns":"vlocity_ins","ver":38.0,"csrf":"(.*)"\},\{"name":"GetUserInfo""").find.exists.saveAs("GenericInvoke2_csrf"))
    )
  

      .exec(http("Ins_getEligibleMemberProduct_Single")
      .post(uri04 + "/apexremote")
      .headers(headers_15)
      .body(ElFileBody("./src/test/resources/bodies/insurance/GeteligibleMember/0022_request.json"))
      .check(regex("""statusCode":200""").find.exists))
  

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


}

val onlyWhenMultiplePlansAvailable = scenario("Ins_getEligibleMemberProduct_Multiple_Test")
      
      .during(testDuration) {
      feed(userFeeder)        
      .exec(http("003_Ins_getEligibleMemberProduct_Multiple_Test_T01_Login")
          .post(uri01 + "/")
          .headers(headers_35)
     //     .formParam("pqs", "?startURL=%2Fvisualforce%2Fsession%3Furl%3Dhttps%253A%252F%252Fperf-ins-testing.lightning.force.com%252Fone%252Fone.app&ec=302")
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          // .formParam("startURL", "/visualforce/session?url=https%3A%2F%2Fperf-ins-testing.lightning.force.com%2Fone%2Fone.app")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          // .formParam("qs", "r=https%3A%2F%2Fperf-ins-testing.my.salesforce.com%2Fvisualforce%2Fsession%3Furl%3Dhttps%253A%252F%252Fperf-ins-testing.lightning.force.com%252Fone%252Fone.app")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "R6m6RfkuV7R")
          .formParam("display", "page")
          .formParam("username", "${username}")
          // .formParam("ExtraLog", "%5B%7B%22width%22:1440%7D,%7B%22height%22:900%7D,%7B%22language%22:%22en-GB%22%7D,%7B%22offset%22:-5.5%7D,%7B%22scripts%22:%5B%7B%22size%22:249,%22summary%22:%22if%20(self%20==%20top)%20%7Bdocument.documentElement.style.v%22%7D,%7B%22size%22:578,%22summary%22:%22var%20SFDCSessionVars=%7B%5C%22server%5C%22:%5C%22https:%5C%5C/%5C%5C/login.sal%22%7D,%7B%22url%22:%22https://perf-ins-testing.my.salesforce.com/jslibrary/SfdcSessionBase208.js%22%7D,%7B%22url%22:%22https://perf-ins-testing.my.salesforce.com/jslibrary/LoginHint208.js%22%7D,%7B%22size%22:26,%22summary%22:%22LoginHint.hideLoginForm();%22%7D,%7B%22size%22:36,%22summary%22:%22LoginHint.getSavedIdentities(false);%22%7D,%7B%22url%22:%22https://perf-ins-testing.my.salesforce.com/jslibrary/baselogin4.js%22%7D,%7B%22url%22:%22https://perf-ins-testing.my.salesforce.com/jslibrary/LoginMarketingSurveyResponse.js%22%7D,%7B%22url%22:%22https://perf-ins-testing.my.salesforce.com/marketing/survey/survey1/1380%22%7D,%7B%22url%22:%22https://perf-ins-testing.my.salesforce.com/marketing/survey/survey4/1380%22%7D,%7B%22size%22:517,%22summary%22:%22function%20handleLogin()%7Bdocument.login.un.value=doc%22%7D%5D%7D,%7B%22scriptCount%22:11%7D,%7B%22iframes%22:%5B%22https://c.salesforce.com/login-messages/promos.html?r=https%253A%252F%252Fperf-ins-testing.my.salesforce.com%252Fvisualforce%252Fsession%253Furl%253Dhttps%25253A%25252F%25252Fperf-ins-testing.lightning.force.com%25252Fone%25252Fone.app%22,%22https://login.salesforce.com/login/sessionserver212.html%22%5D%7D,%7B%22iframeCount%22:2%7D,%7B%22referrer%22:%22https://perf-ins-testing.my.salesforce.com/visualforce/session?url=https%253A%252F%252Fperf-ins-testing.lightning.force.com%252Fone%252Fone.app%22%7D%5D")
          // .formParam("Fingerprint", "%7B%22platform%22:%22MacIntel%22,%22window%22:%22836x1440%22,%22screen%22:%22900x1440%22,%22color%22:%2224-24%22,%22timezoneOffset%22:%22-330%22,%22canvas%22:%22-2102302436%22,%22sessionStorage%22:%22true%22,%22LocalStorage%22:%22true%22,%22indexDB%22:%22true%22,%22webSockets%22:%22true%22,%22plugins%22:%22Chrome%20PDF%20Plugin:Portable%20Document%20Format%5CnChrome%20PDF%20Viewer:%5CnNative%20Client:%5Cn%22,%22drm%22:1,%22languages%22:%5B%22en-GB%22,%22en-US%22,%22en%22%5D,%22fonts%22:%22%22,%22codecs%22:%22gIEIqgoIQqoCqH4=%22,%22mediaDevices%22:%22audioinput::default%5Cnaudioinput::c2f087d07e9625d58196c1dcdc8b4744d952e59c71f9c67f5ba00634cba94017%5Cnvideoinput::2a7fcbffc79af1068cbcd7487db6acdebd3f83a581aacd563a08b34d51595c7e%5Cnaudiooutput::default%5Cnaudiooutput::3c9bcf25320d95ed9593f8228ca811913eea05330387f4dbb5fe130b3d0565a1%5Cn%22%7D")
          .formParam("pw", "${password}")
          .formParam("Login", "Log In"))


    .exec(http("getEligibleMemberProduct_Multiple_Test_request_0")
      .get(uri04 + "/apex/InsuranceOmniScriptUniversal?layout=newport&id=a2Y1U000000eFogUAE&designerPreviewId=a2Y1U000000eFogUAE&previewEmbedded=true&tabKey=1572333307516&isdtp=p1&sfdcIFrameOrigin=https%3A%2F%2Fperf-ins-testing--vlocity-ins.visualforce.com&sfdcIFrameHost=web")
      .headers(headers_0)
      .check(regex("""\{"name":"GenericInvoke2","len":4,"ns":"vlocity_ins","ver":38.0,"csrf":"(.*)"\},\{"name":"GetUserInfo""").find.exists.saveAs("GenericInvoke2_csrf"))
    )

      .exec(http("getEligibleMemberProduct_Multiple_Test")
      .post(uri04 + "/apexremote")
      .headers(headers_17)
      .body(ElFileBody("./src/test/resources/bodies/insurance/GeteligibleMembermultiple/0022_request.json"))
     .check(regex("""statusCode":200""").find.exists))
  

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


}

}
