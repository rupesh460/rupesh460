
//THe script takes Account ID, PriceList for which order has tb created ,
//PriceList entry ID for which add to cart to be done
package Insurance

  import scala.concurrent.duration._
  import io.gatling.core.Predef._
  import io.gatling.core.structure.ChainBuilder
  import io.gatling.http.Predef._
  import io.gatling.jdbc.Predef._
  import io.gatling.jsonpath._
  import Headers._
  import scala.collection._
  import java.time.format.DateTimeFormatter
  import java.time.LocalDateTime
  import java.time.LocalDate
  import io.gatling.core.feeder._
  import java.util.Base64
  import java.nio.charset.StandardCharsets
  import scala.util.matching.Regex


   object Ins_EditPlan_Test {

      val uri01 = Configuration.Uri01
      val uri02 = Configuration.Uri02
      val uri03 = Configuration.Uri03
      val uri04 = Configuration.Uri04
      val userFeeder = csv("./src/test/resources/data/Insurance/Users.csv").random
      val testDuration = Integer.getInteger("testDuration",1)
      val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
      val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
      val password_v = (passwordByEnv.get("Ins").toString)
      val password_encoded = password_v.substring(12,(password_v.length - 2 ))
      val credentials = new String(Base64.getDecoder.decode(password_encoded))
      
      
  	  val scn = scenario("Ins_EditPlan_Test")

      .exec(session => session.set("password",credentials))
      
      .during( testDuration ) {
      feed(userFeeder)        
      .exec(http("002_EditPlan_T01_Login")
          .post(uri01 + "/")
          .headers(headers_35)
     //     .formParam("pqs", "?startURL=%2Fvisualforce%2Fsession%3Furl%3Dhttps%253A%252F%252Fperf-ins-testing.lightning.force.com%252Fone%252Fone.app&ec=302")
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          // .formParam("startURL", "/visualforce/session?url=https%3A%2F%2Fperf-ins-testing.lightning.force.com%2Fone%2Fone.app")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          // .formParam("qs", "r=https%3A%2F%2Fperf-ins-testing.my.salesforce.com%2Fvisualforce%2Fsession%3Furl%3Dhttps%253A%252F%252Fperf-ins-testing.lightning.force.com%252Fone%252Fone.app")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "R6m6RfkuV7R")
          .formParam("display", "page")
          .formParam("username", "${username}")
          // .formParam("ExtraLog", "%5B%7B%22width%22:1440%7D,%7B%22height%22:900%7D,%7B%22language%22:%22en-GB%22%7D,%7B%22offset%22:-5.5%7D,%7B%22scripts%22:%5B%7B%22size%22:249,%22summary%22:%22if%20(self%20==%20top)%20%7Bdocument.documentElement.style.v%22%7D,%7B%22size%22:578,%22summary%22:%22var%20SFDCSessionVars=%7B%5C%22server%5C%22:%5C%22https:%5C%5C/%5C%5C/login.sal%22%7D,%7B%22url%22:%22https://perf-ins-testing.my.salesforce.com/jslibrary/SfdcSessionBase208.js%22%7D,%7B%22url%22:%22https://perf-ins-testing.my.salesforce.com/jslibrary/LoginHint208.js%22%7D,%7B%22size%22:26,%22summary%22:%22LoginHint.hideLoginForm();%22%7D,%7B%22size%22:36,%22summary%22:%22LoginHint.getSavedIdentities(false);%22%7D,%7B%22url%22:%22https://perf-ins-testing.my.salesforce.com/jslibrary/baselogin4.js%22%7D,%7B%22url%22:%22https://perf-ins-testing.my.salesforce.com/jslibrary/LoginMarketingSurveyResponse.js%22%7D,%7B%22url%22:%22https://perf-ins-testing.my.salesforce.com/marketing/survey/survey1/1380%22%7D,%7B%22url%22:%22https://perf-ins-testing.my.salesforce.com/marketing/survey/survey4/1380%22%7D,%7B%22size%22:517,%22summary%22:%22function%20handleLogin()%7Bdocument.login.un.value=doc%22%7D%5D%7D,%7B%22scriptCount%22:11%7D,%7B%22iframes%22:%5B%22https://c.salesforce.com/login-messages/promos.html?r=https%253A%252F%252Fperf-ins-testing.my.salesforce.com%252Fvisualforce%252Fsession%253Furl%253Dhttps%25253A%25252F%25252Fperf-ins-testing.lightning.force.com%25252Fone%25252Fone.app%22,%22https://login.salesforce.com/login/sessionserver212.html%22%5D%7D,%7B%22iframeCount%22:2%7D,%7B%22referrer%22:%22https://perf-ins-testing.my.salesforce.com/visualforce/session?url=https%253A%252F%252Fperf-ins-testing.lightning.force.com%252Fone%252Fone.app%22%7D%5D")
          // .formParam("Fingerprint", "%7B%22platform%22:%22MacIntel%22,%22window%22:%22836x1440%22,%22screen%22:%22900x1440%22,%22color%22:%2224-24%22,%22timezoneOffset%22:%22-330%22,%22canvas%22:%22-2102302436%22,%22sessionStorage%22:%22true%22,%22LocalStorage%22:%22true%22,%22indexDB%22:%22true%22,%22webSockets%22:%22true%22,%22plugins%22:%22Chrome%20PDF%20Plugin:Portable%20Document%20Format%5CnChrome%20PDF%20Viewer:%5CnNative%20Client:%5Cn%22,%22drm%22:1,%22languages%22:%5B%22en-GB%22,%22en-US%22,%22en%22%5D,%22fonts%22:%22%22,%22codecs%22:%22gIEIqgoIQqoCqH4=%22,%22mediaDevices%22:%22audioinput::default%5Cnaudioinput::c2f087d07e9625d58196c1dcdc8b4744d952e59c71f9c67f5ba00634cba94017%5Cnvideoinput::2a7fcbffc79af1068cbcd7487db6acdebd3f83a581aacd563a08b34d51595c7e%5Cnaudiooutput::default%5Cnaudiooutput::3c9bcf25320d95ed9593f8228ca811913eea05330387f4dbb5fe130b3d0565a1%5Cn%22%7D")
          .formParam("pw", "${password}")
          .formParam("Login", "Log In"))


      .exec(http("002_EditPlan_T02_request_3")
      .get(uri03 + "/apex/vlocity_ins__InsuranceCardRules?layout=ins-quote-line-items-large-group&id=0QL1U000000I53vWAC&useCache=false&isdtp=p1&sfdcIFrameOrigin=https://perf-ins-testing.lightning.force.com&sfdcIFrameHost=web&vlocity_ins__rootLineId=0QL1U000000I53vWAC&vlocity_ins__rootProdId=01t1U000000agQAQAY")
      .headers(headers_3)
        .check(regex("""\{"name":"doGenericInvoke","len":4,"ns":"vlocity_ins","ver":41.0,"csrf":"(.*)"\},\{"name":"doNamedCredentialCallout""").find.exists.saveAs("doGenericinvoke_csrf"))
        .check(regex("""\{"name":"getCustomPermissionsForUser","len":0,"ns":"vlocity_ins","ver":41.0,"csrf":"(.*)"\},\{"name":"getCustomSettings""").find.exists.saveAs("getCustomPermissionsForUser_csrf"))
        .check(regex("""\{"name":"getCustomSettings","len":1,"ns":"vlocity_ins","ver":41.0,"csrf":"(.*)"\},\{"name":"getDataViaDataRaptor""").find.exists.saveAs("getCustomSettings_csrf"))
        .check(regex("""\{"name":"getActiveTemplateNames","len":0,"ns":"vlocity_ins","ver":41.0,"csrf":"(.*)"\},\{"name":"getAllActionsInfo""").find.exists.saveAs("getActiveTemplateNames_csrf"))
        .check(regex("""\{"name":"getUserProfile","len":0,"ns":"vlocity_ins","ver":41.0,"csrf":"(.*)"\},\{"name":"isAllTriggersOn""").find.exists.saveAs("getUserProfile_csrf"))
        .check(regex("""\{"name":"getCustomLabels","len":2,"ns":"vlocity_ins","ver":41.0,"csrf":"(.*)"\},\{"name":"getCustomPermissionsForUser""").find.exists.saveAs("getCustomLabels_csrf"))
        .check(regex("""\{"name":"getActionsInfo","len":0,"ns":"vlocity_ins","ver":41.0,"csrf":"(.*)"\},\{"name":"getActiveCardsByNames""").find.exists.saveAs("getActionsInfo_csrf"))
        .check(regex("""\{"name":"getLayout","len":2,"ns":"vlocity_ins","ver":41.0,"csrf":"(.*)"\},\{"name":"getLayoutsById""").find.exists.saveAs("getLayout_csrf"))
        .check(regex("""\{"name":"getTemplate","len":1,"ns":"vlocity_ins","ver":41.0,"csrf":"(.*)"\},\{"name":"getTemplateByName""").find.exists.saveAs("getTemplate_csrf"))
        .resources(
       http("002_EditPlan_T03_request_4")
      .get(uri02 + "?layout=ins-quote-line-items-large-group&id=0QL1U000000I53vWAC&useCache=false&isdtp=p1&sfdcIFrameOrigin=https://perf-ins-testing.lightning.force.com&sfdcIFrameHost=web&vlocity_ins__rootLineId=0QL1U000000I53vWAC&vlocity_ins__rootProdId=01t1U000000agQAQAY")
      .headers(headers_3),
      http("002_EditPlan_T04_request_5")
      .get(uri04 + "/apex/InsuranceCardRules?layout=ins-quote-line-items-large-group&useCache=false&sfdcIFrameHost=web&vlocity_ins__rootProdId=01t1U000000agQAQAY&id=0QL1U000000I53vWAC&isdtp=p1&sfdcIFrameOrigin=https%3A%2F%2Fperf-ins-testing.lightning.force.com&vlocity_ins__rootLineId=0QL1U000000I53vWAC")
      .headers(headers_3)))




// -------- getActiveTemplateNames -----
          .group("EditPlan")
            {
            exec(http("002_EditPlan_T05_getActiveTemplateNames")
            .post(uri04 + "/apexremote")
            .headers(headers_12)
            .body(ElFileBody("./src/test/resources/bodies/INS_EditPlanDesigner/EditPlanDesigner_0015_request.txt"))
            .check(regex("""statusCode":200""").find.exists))


// -------- getActionsInfo -----

            .exec(http("002_EditPlan_T06_getActionsInfo")
            .post(uri04 + "/apexremote")
            .headers(headers_12)
            .body(ElFileBody("./src/test/resources/bodies/INS_EditPlanDesigner/EditPlanDesigner_0016_request.txt"))
            .check(regex("""statusCode":200""").find.exists))


 // -------- getUserProfile -----

            .exec(http("002_EditPlan_T07_getUserProfile_1")
            .post(uri04 + "/apexremote")
            .headers(headers_12)
            .body(ElFileBody("./src/test/resources/bodies/INS_EditPlanDesigner/EditPlanDesigner_0017_request.txt"))
            .check(regex("""statusCode":200""").find.exists))           


// -------- getCustomPermissionsForUser -----

            .exec(http("002_EditPlan_T08_getCustomPermissionsForUser")
            .post(uri04 + "/apexremote")
            .headers(headers_12)
            .body(ElFileBody("./src/test/resources/bodies/INS_EditPlanDesigner/EditPlanDesigner_0018_request.txt"))
            .check(regex("""statusCode":200""").find.exists))


// -------- getCustomSettings -----

            .exec(http("002_EditPlan_T09_getCustomSettings_1")
            .post(uri04 + "/apexremote")
            .headers(headers_12)
            .body(ElFileBody("./src/test/resources/bodies/INS_EditPlanDesigner/EditPlanDesigner_0019_request.txt"))
            .check(regex("""statusCode":200""").find.exists))


// -------- getUserProfile -----

            .exec(http("002_EditPlan_T10_getUserProfile_2")
            .post(uri04 + "/apexremote")
            .headers(headers_12)
            .body(ElFileBody("./src/test/resources/bodies/INS_EditPlanDesigner/EditPlanDesigner_0020_request.txt"))
            .check(regex("""statusCode":200""").find.exists))


// -------- getCustomSettings -----

            .exec(http("002_EditPlan_T11_getCustomSettings_2")
            .post(uri04 + "/apexremote")
            .headers(headers_12)
            .body(ElFileBody("./src/test/resources/bodies/INS_EditPlanDesigner/EditPlanDesigner_0021_request.txt"))
            .check(regex("""statusCode":200""").find.exists))


// -------- getLayout -----

           .exec(http("002_EditPlan_T12_getLayout")
            .post(uri04 + "/apexremote")
            .headers(headers_12)
            .body(ElFileBody("./src/test/resources/bodies/INS_EditPlanDesigner/EditPlanDesigner_0022_request.txt"))
            .check(regex("""statusCode":200""").find.exists))


// --------  doGenericInvoke_getCustomSettings -----

            .exec(http("002_EditPlan_T13_doGenericInvoke_getCustomSettings")
            .post(uri04 + "/apexremote")
            .headers(headers_12)
            .body(ElFileBody("./src/test/resources/bodies/INS_EditPlanDesigner/EditPlanDesigner_0023_request.txt"))
            .check(regex("""statusCode":200""").find.exists))


// -------- getUserProfile -----

            .exec(http("002_EditPlan_T14_getUserProfile_3")
            .post(uri04 + "/apexremote")
            .headers(headers_12)
           .body(ElFileBody("./src/test/resources/bodies/INS_EditPlanDesigner/EditPlanDesigner_0024_request.txt"))
            .check(regex("""statusCode":200""").find.exists))


// -------- getCustomLabels -----

            .exec(http("EditPlan_T15_getCustomLabels_1")
            .post(uri04 + "/apexremote")
            .headers(headers_12)
            .body(ElFileBody("./src/test/resources/bodies/INS_EditPlanDesigner/EditPlanDesigner_0025_request.txt"))
            .check(regex("""statusCode":200""").find.exists))


// -------- getCustomLabels -----

            .exec(http("002_EditPlan_T16_getCustomLabels_2")
            .post(uri04 + "/apexremote")
            .headers(headers_12)
            .body(ElFileBody("./src/test/resources/bodies/INS_EditPlanDesigner/EditPlanDesigner_0026_request.txt"))
            .check(regex("""statusCode":200""").find.exists))


// -------- getCustomLabels -----

          .exec(http("002_EditPlan_T17_getCustomLabels_3")
            .post(uri04 + "/apexremote")
            .headers(headers_12)
            .body(ElFileBody("./src/test/resources/bodies/INS_EditPlanDesigner/EditPlanDesigner_0027_request.txt"))
            .check(regex("""statusCode":200""").find.exists))


// -------- doGenericInvoke_getQuoteLineItemDetail -----

            .exec(http("002_EditPlan_T18_doGenericInvoke_getQuoteLineItemDetail")
            .post(uri04 + "/apexremote")
            .headers(headers_12)
            .body(ElFileBody("./src/test/resources/bodies/INS_EditPlanDesigner/EditPlanDesigner_0028_request.txt"))
            .check(regex("""statusCode":200""").find.exists))


// -------- getTemplate -----

            .exec(http("002_EditPlan_T19_getTemplate")
            .post(uri04 + "/apexremote")
            .headers(headers_12)
            .body(ElFileBody("./src/test/resources/bodies/INS_EditPlanDesigner/EditPlanDesigner_0029_request.txt"))
            .check(regex("""statusCode":200""").find.exists))
  
}
    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

}
}
