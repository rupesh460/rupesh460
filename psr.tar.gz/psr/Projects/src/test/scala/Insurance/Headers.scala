package Insurance

object Headers  {

	val headers_35 = Map(
		"Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-US,en;q=0.8",
		"Cache-Control" -> "max-age=0",
		"Origin" -> "https://login.salesforce.com",
		"Upgrade-Insecure-Requests" -> "1",
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3080.0 Safari/537.36")

	val headers_0 = Map(
		"Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-GB,en-US;q=0.9,en;q=0.8",
		"Origin" -> "https://perf-ins-testing--vlocity-ins.visualforce.com",
		"Upgrade-Insecure-Requests" -> "1")

	val headers_10 = Map(
		"Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-GB,en-US;q=0.9,en;q=0.8",
		"Sec-Fetch-Mode" -> "nested-navigate",
		"Sec-Fetch-Site" -> "same-origin",
		"Upgrade-Insecure-Requests" -> "1")

	val headers_1 = Map(
		"Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-GB,en-US;q=0.9,en;q=0.8",
		"Upgrade-Insecure-Requests" -> "1")

	val headers_3 = Map(
		"Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-GB,en-US;q=0.9,en;q=0.8",
		"Upgrade-Insecure-Requests" -> "1")

	val headers_4 = Map(
		"Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-GB,en-US;q=0.9,en;q=0.8",
		"Upgrade-Insecure-Requests" -> "1")

	val headers_5 = Map(
		"Content-Type" -> "application/x-www-form-urlencoded; charset=UTF-8",
		"Origin" -> "https://perf-ins-testing--vlocity-ins.visualforce.com")

	val headers_11 = Map(
		"Accept" -> "*/*",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-GB,en-US;q=0.9,en;q=0.8",
		"Content-Type" -> "application/x-www-form-urlencoded; charset=UTF-8",
		"Origin" -> "https://perf-ins-testing.lightning.force.com",
		"X-SFDC-Request-Id" -> "25270450000efa13b7")

	//val headers_12 = Map("Origin" -> "https://perf-ins-testing--vlocity-ins.visualforce.com")

		val headers_12 = Map(
		"Accept" -> "*/*",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-GB,en-US;q=0.9,en;q=0.8",
		"Content-Type" -> "application/json",
		"Origin" -> "https://perf-ins-testing--vlocity-ins.visualforce.com",
		"X-Requested-With" -> "XMLHttpRequest",
		"X-User-Agent" -> "Visualforce-Remoting")


		val headers_20 = Map(
		"Accept" -> "*/*",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-GB,en-US;q=0.9,en;q=0.8",
		"Content-Type" -> "application/json",
		"Origin" -> "https://perf-ins-testing--vlocity-ins.visualforce.com",
		"Sec-Fetch-Mode" -> "cors",
		"Sec-Fetch-Site" -> "same-origin",
		"X-Requested-With" -> "XMLHttpRequest",
		"X-User-Agent" -> "Visualforce-Remoting")



val headers_16 = Map(
		"Content-Type" -> "application/json",
		"Origin" -> "https://perf-ins-testing--vlocity-ins.visualforce.com",
		"Sec-Fetch-Mode" -> "cors",
		"X-Requested-With" -> "XMLHttpRequest",
		"X-User-Agent" -> "Visualforce-Remoting")


	val headers_15 = Map(
		"Accept" -> "*/*",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-GB,en-US;q=0.9,en;q=0.8",
		"Content-Type" -> "application/json",
		"Origin" -> "https://perf-ins-testing--vlocity-ins.visualforce.com",
		"X-Requested-With" -> "XMLHttpRequest",
		"X-User-Agent" -> "Visualforce-Remoting")

	val headers_19 = Map(
		"Origin" -> "https://perf-ins-testing--vlocity-ins.visualforce.com",
		"Sec-Fetch-Mode" -> "cors",
		"Sec-Fetch-Site" -> "same-origin",
		"X-Requested-With" -> "XMLHttpRequest",
		"X-User-Agent" -> "Visualforce-Remoting")

	val headers_17 = Map(
		"Accept" -> "*/*",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-GB,en-US;q=0.9,en;q=0.8",
		"Content-Type" -> "application/json",
		"Origin" -> "https://perf-ins-testing--vlocity-ins.visualforce.com",
		"Sec-Fetch-Mode" -> "cors",
		"Sec-Fetch-Site" -> "same-origin",
		"X-Requested-With" -> "XMLHttpRequest",
		"X-User-Agent" -> "Visualforce-Remoting")

	val headers_37 = Map(
		"Content-Type" -> "application/x-www-form-urlencoded; charset=UTF-8",
		"Origin" -> "https://perf-ins-testing--vlocity-ins.visualforce.com",
		"Sec-Fetch-Mode" -> "cors")


	val headers_30 = Map("Origin" -> "https://perf-ins-testing--vlocity-ins.visualforce.com")

	val headers_333 = Map(
        "Content-Type" -> "application/x-www-form-urlencoded; charset=UTF-8",
        "Origin" -> "https://perf-ins-testing--vlocity-ins.visualforce.com",
        "Sec-Fetch-Mode" -> "cors",
        "Sec-Fetch-Site" -> "same-origin")

    val headers_334 = Map(
        "Origin" -> "https://perf-ins-testing--vlocity-ins.visualforce.com",
        "Sec-Fetch-Mode" -> "cors",
        "Accept" -> "/",
        "Accept-Encoding" -> "gzip, deflate, br",
        "Accept-Language" -> "en-GB,en-US;q=0.9,en;q=0.8",
        "Content-Type" -> "application/json",
        "Sec-Fetch-Site" -> "same-origin",
        "X-Requested-With" -> "XMLHttpRequest",
        "X-User-Agent" -> "Visualforce-Remoting")

    val headers_350 = Map(
		"Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-US,en;q=0.8",
		"Cache-Control" -> "max-age=0",
		"Origin" -> "https://login.salesforce.com",
		"Upgrade-Insecure-Requests" -> "1",
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3080.0 Safari/537.36")

	// val headers_0 = Map(
	// 	"Origin" -> "https://perf-ins-testing--vlocity-ins.visualforce.com",
	// 	"Sec-Fetch-Mode" -> "cors",
	// 	"Sec-Fetch-Site" -> "same-origin",
	// 	"X-Requested-With" -> "XMLHttpRequest",
	// 	"X-User-Agent" -> "Visualforce-Remoting")

		// val headers_4 = Map(
		// "Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
		// "Accept-Encoding" -> "gzip, deflate, br",
		// "Accept-Language" -> "en-GB,en-US;q=0.9,en;q=0.8",
		// "Upgrade-Insecure-Requests" -> "1")

	val headers_401 = Map(
		"Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-GB,en-US;q=0.9,en;q=0.8",
		"Sec-Fetch-Mode" -> "nested-navigate",
		"Sec-Fetch-Site" -> "same-origin",
		"Upgrade-Insecure-Requests" -> "1")

		val headers_701 = Map(
		"Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-GB,en-US;q=0.9,en;q=0.8",
		"Sec-Fetch-Mode" -> "nested-navigate",
		"Sec-Fetch-Site" -> "same-origin",
		"Upgrade-Insecure-Requests" -> "1",
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36")

		val headers_001 = Map(
		"Accept" -> "*/*",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-GB,en-US;q=0.9,en;q=0.8",
		"Content-Type" -> "application/json",
		"Origin" -> "https://perf-ins-testing--vlocity-ins.visualforce.com",
		"Sec-Fetch-Mode" -> "cors",
		"Sec-Fetch-Site" -> "same-origin",
		"X-Requested-With" -> "XMLHttpRequest",
		"X-User-Agent" -> "Visualforce-Remoting")

	val headers_713 = Map(
		"Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-GB,en-US;q=0.9,en;q=0.8",
		"Sec-Fetch-Dest" -> "document",
		"Sec-Fetch-Mode" -> "navigate",
		"Sec-Fetch-Site" -> "none",
		"Sec-Fetch-User" -> "?1",
		"Upgrade-Insecure-Requests" -> "1")

		val headers_714 = Map(
		"Accept" -> "*/*",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-GB,en-US;q=0.9,en;q=0.8",
		"Content-Type" -> "application/x-www-form-urlencoded; charset=UTF-8",
		"Origin" -> "https://perf-ins-testing.lightning.force.com",
		"Sec-Fetch-Dest" -> "empty",
		"Sec-Fetch-Mode" -> "cors",
		"Sec-Fetch-Site" -> "same-origin",
		"X-SFDC-Request-Id" -> "161439500001c0541f")


	val headers_301 = Map("Origin" -> "https://perf-ins-testing--vlocity-ins.visualforce.com")

}