package Insurance

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._

class Insurance_Scn extends Simulation {

	val httpConf = http
		.baseUrl(Configuration.BaseUrl)
		.inferHtmlResources(BlackList(""".*\.js""", """.*\.css""", """.*\.gif""", """.*\.jpeg""", """.*\.jpg""", """.*\.ico""", """.*\.woff""", """.*\.(t|o)tf""", """.*\.png"""), WhiteList())
		.acceptHeader("*/*")
		.acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8")
		.acceptEncodingHeader("gzip, deflate, sdch")
		.acceptLanguageHeader("en-US,en;q=0.8")
		.disableCaching
		.contentTypeHeader("application/x-www-form-urlencoded; charset=UTF-8")
		.userAgentHeader("Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:41.0) Gecko/20100101 Firefox/41.0")

	val rampUpTimeSecs = Integer.getInteger("rampUpTimeSecs", 1)
	val Noofusers = Integer.getInteger("Noofusers", 1)
	val maxDurationSecs = Integer.getInteger("maxDurationSecs", 1)
	val UpdateflowRampup = Integer.getInteger("UpdateflowRampup", 1)
	

	setUp(

		
// Ins_CoverageTab_Test.scn.inject(rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_EditPlan_Test.scn.inject(nothingFor(3700 second) , rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_PlanSelection_Test.scn.inject(nothingFor(7400 second) , rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_WithoutTaxGetRatedProducts_Test.scn.inject(nothingFor(11100 second) , rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_WithTaxGetRatedProducts_Test.scn.inject(nothingFor(14800 second) , rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// ////Ins_WithTaxCreateQuote_Test.scn.inject(nothingFor(18500 second) , rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_WithoutTaxCreateQuote_Test.scn.inject(nothingFor(18500 second) , rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_WithTaxReprice_Test.scn.inject(nothingFor(22200 second) , rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_WithoutTaxReprice_Test.scn.inject(nothingFor(25900 second) , rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_StandardMatrix_Test.scn.inject(nothingFor(29600 second) , rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_GroupMatrix_Test.scn.inject(nothingFor(33300 second) , rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_RowVersionMatrix_Test.scn.inject(nothingFor(37000 second) , rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_RowVersionSearch_Test.scn.inject(nothingFor(40700 second) , rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_GetMemberEnroll_Test.scn.inject(nothingFor(44400 second) , rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_EnrollMember_Test.scn.inject(nothingFor(48100 second) , rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_ModifyEnroll_Test.scn.inject(nothingFor(51800 second) , rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_ModifyEnroll_Plan_Test.scn.inject(nothingFor(55500 second) , rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_getEligibleMemberProduct_Single_Test.onlyWhenSinglePlansAvailable.inject(nothingFor(59200 second) , rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_getEligibleMemberProduct_Single_Test.onlyWhenMultiplePlansAvailable.inject(nothingFor(62900 second) , rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf))
// .maxDuration(maxDurationSecs)

                   // setUp(scn.inject(rampUsers(1000) over (20 minutes))).maxDuration(10 minutes)


// Ins_CoverageTab_Test.scn.inject(rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_EditPlan_Test.scn.inject(nothingFor(1300 second) , rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_PlanSelection_Test.scn.inject(nothingFor(2600 second) , rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_WithoutTaxGetRatedProducts_Test.scn.inject(nothingFor(3900 second) , rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_WithoutTaxReprice_Test.scn.inject(nothingFor(5200 second) , rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf))
// .maxDuration(maxDurationSecs)





// Ins_CoverageTab_Test.scn.inject(rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_EditPlan_Test.scn.inject(rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_PlanSelection_Test.scn.inject(rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_WithoutTaxGetRatedProducts_Test.scn.inject(rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_WithTaxGetRatedProducts_Test.scn.inject(rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_WithTaxCreateQuote_Test.scn.inject(rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_WithoutTaxCreateQuote_Test.scn.inject(rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_WithTaxReprice_Test.scn.inject(rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_WithoutTaxReprice_Test.scn.inject(rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_StandardMatrix_Test.scn.inject(rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_GroupMatrix_Test.scn.inject(rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_RowVersionMatrix_Test.scn.inject(rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_RowVersionSearch_Test.scn.inject(rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_GetMemberEnroll_Test.scn.inject(rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_EnrollMember_Test.scn.inject(rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_ModifyEnroll_Test.scn.inject(rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_ModifyEnroll_Plan_Test.scn.inject(rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_getEligibleMemberProduct_Single_Test.scn.inject(rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
// Ins_getEligibleMemberProduct_Multiple_Test.scn.inject(rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
//   Ins_Lwc_Add_BringModal_Test.scn.inject(rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf))
// .maxDuration(maxDurationSecs)



Ins_CoverageTab_Test.scn.inject(rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
Ins_EditPlan_Test.scn.inject(nothingFor(3700 second) , rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
Ins_StandardMatrix_Test.scn.inject(nothingFor(7400 second) , rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
Ins_GroupMatrix_Test.scn.inject(nothingFor(11100 second) , rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf),
Ins_RowVersionMatrix_Test.scn.inject(nothingFor(14800 second) , rampUsers(Noofusers) during (UpdateflowRampup seconds)).protocols(httpConf))
.maxDuration(maxDurationSecs)

  }
