package Insurance


object Configuration
 {
	val BaseUrl = "https://perf-ins-testing.lightning.force.com"
	val Uri01 = "https://login.salesforce.com"
	val Uri02 = "https://perf-ins-testing.my.salesforce.com/apex/vlocity_ins__InsuranceCardRules"
	val Uri03 = "https://perf-ins-testing.lightning.force.com"
	val Uri04 = "https://perf-ins-testing--vlocity-ins.visualforce.com"
	val Uri05 = "https://perf-ins-testing--c.visualforce.com"
	val Uri06 = "https://perf-ins-testing.my.salesforce.com/apex/vlocity_ins__InsuranceCoverages"
	

	val MinWaitMs = 15000
	val MaxWaitMs = 20000

	val MiniMinWaitMs = 1000
	val MiniMaxWaitMs = 3000

}
