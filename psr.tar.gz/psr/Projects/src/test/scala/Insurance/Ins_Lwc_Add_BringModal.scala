
//THe script takes Account ID, PriceList for which order has tb created ,
//PriceList entry ID for which add to cart to be done
package Insurance

  import scala.concurrent.duration._
  import io.gatling.core.Predef._
  import io.gatling.core.structure.ChainBuilder
  import io.gatling.http.Predef._
  import io.gatling.jdbc.Predef._
  import io.gatling.jsonpath._
  import Headers._
  import scala.collection._
  import java.time.format.DateTimeFormatter
  import java.time.LocalDateTime
  import java.time.LocalDate
  import io.gatling.core.feeder._
  import java.util.Base64
  import java.nio.charset.StandardCharsets
  import scala.util.matching.Regex


   object Ins_Lwc_Add_BringModal_Test {

      val uri01 = Configuration.Uri01
  //    val uri02 = Configuration.Uri02
      val uri03 = Configuration.Uri03
   //   val uri04 = Configuration.Uri04
  //    val uri05 = Configuration.Uri05
      val userFeeder = csv("./src/test/resources/data/Insurance/Users.csv").random
    //  val userFeeder1 = csv("./src/test/resources/data/Insurance/GroupMatrixInputs.csv").random
      val testDuration = Integer.getInteger("testDuration",1)
       val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
      val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
      val password_v = (passwordByEnv.get("Ins").toString)
     val password_encoded = password_v.substring(12,(password_v.length - 2 ))
     val credentials = new String(Base64.getDecoder.decode(password_encoded))
      
      
  	  val scn = scenario("Ins_Lwc_Add_BringModal_Test")

      .exec(session => session.set("password",credentials))
      
      .during( testDuration ) {
      feed(userFeeder)        
      .exec(http("Login")
          .post(uri01 + "/")
          .headers(headers_350)
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "R6m6RfkuV7R")
          .formParam("display", "page")
          .formParam("username", "${username}")
          .formParam("pw", "${password}")
          .formParam("Login", "Log In"))


    //.feed(userFeeder1)
    .exec(http("request_0")
      .get(uri03 + "/lightning/r/Quote/0Q01U000000MC0hSAG/view")
      .headers(headers_713)
    .check(regex("""token":"(.*)","initializers""").find.exists.saveAs("Addtoken_csrf"))
    )
  
           //  .exec(http("GroupMatrix2k10v")
           //  .post(uri04 + "/apexremote")
           //  .headers(headers_001)
           // .body(ElFileBody("./src/test/resources/bodies/insurance/GroupMatrix_0000_request.txt"))
           //  .check(regex("""statusCode":200""").find.exists))

  // ${GenericInvoke2_csrf}

.exec(http("Add_BringuUpModal")
      .post(uri03 + "/aura?r=28&aura.ApexAction.execute=1")
      .headers(headers_714)
      .formParam("message", """{"actions":[{"id":"927;a","descriptor":"aura://ApexActionController/ACTION$execute","callingDescriptor":"UNKNOWN","params":{"namespace":"vlocity_ins","classname":"LWCDatasource","method":"handleData","params":{"dataSourceMap":"{\"type\":\"apexremote\",\"value\":{\"className\":\"InsProductService\",\"methodName\":\"getInsuredItemSpec\",\"inputMap\":\"{\\\"productId\\\":\\\"01t1U000002GD1rQAG\\\",\\\"childProductId\\\":\\\"01t1U000002GD1hQAG\\\"}\",\"optionsMap\":\"{}\"}}"},"cacheable":false,"isContinuation":false}}]}""")
      .formParam("aura.context", """{"mode":"PROD","fwuid":"kHqYrsGCjDhXliyGcYtIfA","app":"one:one","loaded":{"APPLICATION@markup://one:one":"Kyn0wehQw3SSPh5ILpOmkg"},"dn":[],"globals":{"density":"VIEW_ONE","srcdoc":true,"appContextId":"06m1U000001UwNJQA0"},"uad":true}""")
      .formParam("aura.pageURI", "/lightning/r/Quote/0Q01U000000MC0hSAG/view")
      .formParam("aura.token", "${Addtoken_csrf}"))



    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


}
}
