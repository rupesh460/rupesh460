package DC_ldv2_WP_SF_Anonymous

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import Headers.header_0
import Headers.header_1
import io.gatling.core.feeder._
import java.util.Base64
import java.nio.charset.StandardCharsets
import scala.util.matching.Regex


object DC_WP_Anonymous_SF 
{
	val uri01 = Configuration.Uri01
	val uri02 = Configuration.Uri02
	val offerFeeder = csv("./src/test/resources/data/DC_WP/ldv2_offercodes.csv").random
	val contextFeeder = csv("./src/test/resources/data/DC_WP/ldv2_contextdimensions.csv").random
	val promoFeeder = csv("./src/test/resources/data/DC_WP/ldv2_promocodes.csv").random
	val accountFeeder = csv("./src/test/resources/data/DC_WP/ldv2_accounts.csv").random
	//val assetToBasket= csv("./src/test/resources/data/DC_WP/ldv2_3LI_Asset_Details_25Rows.csv").random
	
	val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
       val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
       val password_v = (passwordByEnv.get("perf3").toString)
       val password_encoded = password_v.substring(12,(password_v.length - 2 ))
       val credentials = new String(Base64.getDecoder.decode(password_encoded))

	val loginScn = scenario("SF_DC_Anon_Login")
	
	.exec(session => session.set("password",credentials))

	/* ********* Get OAuth Token for Perf2 ************* */
	.exec(http("RESTGetOAuthToken")
	.post("https://test.salesforce.com/services/oauth2/token")
	.header("Content-Type", "application/x-www-form-urlencoded")
	.formParam("password", "${password}")
	.formParam("username", "ldvtesting2@vlocity.com")
	.formParam("client_secret", "4F1DE5B4EC987DC9138A68A1D1567ECA1DCC9583A88B3130B95D2742ADB473EA")
	.formParam("client_id", "3MVG9_7ddP9KqTzfqPTQdMvr5pwHfDxPcU4QZMHvJTbg1TlFT_Nx8_2aS.NWDGESp83ZDu7NTPhr8X3kVxfq3")
	.formParam("grant_type", "password")
	.check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
	.check(status.is(200)))

	.repeat(10000) {

		pause(Configuration.loginminWaitMs milliseconds, Configuration.loginmaxWaitMs milliseconds)

	}

	/* **************************************************************************************** 
	Script #1 Browsing
	**************************************************************************************** */

	val script1Browsing = scenario("SF_DC_Anon_Script_1_Browsing")
	
	.exec(session => session.set("password",credentials))

	/* ********* Get OAuth Token for Perf2 ************* */
	.exec(http("RESTGetOAuthToken")
	.post("https://test.salesforce.com/services/oauth2/token")
	.header("Content-Type", "application/x-www-form-urlencoded")
	.formParam("password", "${password}")
	.formParam("username", "ldvtesting2@vlocity.com")
	.formParam("client_secret", "4F1DE5B4EC987DC9138A68A1D1567ECA1DCC9583A88B3130B95D2742ADB473EA")
	.formParam("client_id", "3MVG9_7ddP9KqTzfqPTQdMvr5pwHfDxPcU4QZMHvJTbg1TlFT_Nx8_2aS.NWDGESp83ZDu7NTPhr8X3kVxfq3")
	.formParam("grant_type", "password")
	.check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
	.check(status.is(200)))

	.pause(Configuration.script1_Browsing_minWaitMs milliseconds, Configuration.script1_Browsing_maxWaitMs milliseconds)

	.repeat(10000) {

		/* ********* Call to get contextKey  ************* */
		feed(contextFeeder)
		.exec(http("s1_getAnonymousCK")
		.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""contextKey":"(.+?)".""").find.exists.saveAs("AnonymousCK")))

		.pause(Configuration.script1_Browsing_minWaitMs milliseconds, Configuration.script1_Browsing_maxWaitMs milliseconds)

		/* ********** GetListOfProductsForCart *********** */
		.exec(http("s1_GetOffersByCatalog")
		.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""contextKey""").find.exists)
		.check(jsonPath("$.offers[*].ProductCode").findAll.saveAs("ProductOffersList")).asJson)

		.pause(Configuration.script1_Browsing_minWaitMs milliseconds, Configuration.script1_Browsing_maxWaitMs milliseconds)

		/* ********** GetOfferDetails *********** */
		.feed(offerFeeder)
		.exec(http("s1_GetOfferDetails")
		.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers/${OfferCode}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""contextKey""").find.exists)
		.check(bodyString.saveAs("OfferDetailsRes")).asJson)

		.pause(Configuration.script1_Browsing_minWaitMs milliseconds, Configuration.script1_Browsing_maxWaitMs milliseconds)

		/* ********** ConfigureOffer *********** */
		.exec(http("s1_ConfigureOffer")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers/${OfferCode}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
		.body(StringBody("""${OfferDetailsRes}""")).asJson
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""contextKey""").find.exists)
		//.body(ElFileBody("./src/test/resources/bodies/DC_WP/eCom-Prod-Bnd-15399454256600.txt")).asJson
		.headers(header_0)
		.check(regex(""""result":(.+?)."errorCode":"INVOKE""").find.exists.saveAs("AddWithConfig")).asJson)

		.pause(Configuration.script1_Browsing_minWaitMs milliseconds, Configuration.script1_Browsing_maxWaitMs milliseconds)

		.exec(flushSessionCookies)
		.exec(flushCookieJar)
		.exec(flushHttpCache)

	}

	/* **************************************************************************************** 
	Script #2  (Basket Operation)
	**************************************************************************************** */

	val script2BasketOperation = scenario("SF_DC_Anon_Script_2_Basket_Operation")
	
	.exec(session => session.set("password",credentials))

	/* ********* Get OAuth Token for Perf2 ************* */
	.exec(http("RESTGetOAuthToken")
	.post("https://test.salesforce.com/services/oauth2/token")
	.header("Content-Type", "application/x-www-form-urlencoded")
	.formParam("password", "${password}")
	.formParam("username", "ldvtesting2@vlocity.com")
	.formParam("client_secret", "4F1DE5B4EC987DC9138A68A1D1567ECA1DCC9583A88B3130B95D2742ADB473EA")
	.formParam("client_id", "3MVG9_7ddP9KqTzfqPTQdMvr5pwHfDxPcU4QZMHvJTbg1TlFT_Nx8_2aS.NWDGESp83ZDu7NTPhr8X3kVxfq3")
	.formParam("grant_type", "password")
	.check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
	.check(status.is(200)))

	.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

	.repeat(10000) {

		/* ********* Call to get contextKey  ************* */
		feed(contextFeeder)
		.exec(http("s2_getAnonymousCK")
		.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""contextKey":"(.+?)".""").find.exists.saveAs("AnonymousCK")))

		.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

		/* ********** GetListOfProductsForCart *********** */
		.exec(http("s2_GetOffersByCatalog")
		.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""contextKey""").find.exists)
		.check(jsonPath("$.offers[*].ProductCode").findAll.saveAs("ProductOffersList")).asJson)

		.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

		/* ********** GetOfferDetails *********** */
		.feed(offerFeeder)
		.exec(http("s2_GetOfferDetails")
		.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers/${OfferCode}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""contextKey""").find.exists)
		.check(bodyString.saveAs("OfferDetailsRes")).asJson)

		.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

		/* ********** ConfigureOffer *********** */
		.exec(http("s2_ConfigureOffer")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers/${OfferCode}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
		.headers(header_0)
		.body(StringBody("""${OfferDetailsRes}""")).asJson
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""contextKey""").find.exists)
		.check(regex(""""result":(.+?)."errorCode":"INVOKE""").find.exists.saveAs("AddWithConfig")).asJson)

		.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

		/* ********** AddWithNoConfig *********** */
		.exec(http("s2_AddToCartWithNoConfig")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
		.headers(header_0)
		.check(status.is(200))
		.check(regex("""cartContextKey""").find.exists)
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyAddToCartWithNoConfig")).asJson
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("ProdBundleContextKeyWNC")).asJson
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("ProdLineItemKeyWNC")).asJson
		.body(StringBody("""{"offer":"${OfferCode}","basketAction":"AddWithNoConfig"}""")).asJson)

		.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

		/* ********** AddWithConfig *********** */
		.exec(http("s2_AddToCartWithConfig")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfig}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAddToCartWithConfig"))
		.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyAnonymous_ATCWC")).asJson
		.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyAnonymous_ATCWC_Count"))
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("ProdBundleContextKey")).asJson
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("ProdLineItemKey")).asJson
		.body(StringBody("""{"basketAction":"AddAfterConfig","productConfig":${AddWithConfig}}""")).asJson)

		.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)


		.doIfEquals("${MultiTransactionKeyAnonymous_ATCWC_Count}",1)
		{

			doWhile(session => session("MultiTransactionKeyAnonymous_ATCWC_Count").as[String].equals("1"))
			{
				exec {

					session =>
					val addAfterConfigSession_AddToCart = session("AddWithConfig").as[String]
					val buildStringAddWithConfig_AddToCart = addAfterConfigSession_AddToCart.substring(1)
					/*val finalbuildStringAddWithConfig_AddToCart = """{"multiTransactionKey":"""" + session("MultiTransactionKeyAnonymous_ATCWC").as[String] + """",""" */
					val finalbuildStringAddWithConfig_AddToCart = session("MultiTransactionKeyAnonymous_ATCWC").as[String]
					/* session.set("AddWithConfigATC_MTS", finalbuildStringAddWithConfig_AddToCart + buildStringAddWithConfig_AddToCart) */
					session.set("AddWithConfigATC_MTS", finalbuildStringAddWithConfig_AddToCart)

				}

				/* ********** AddWithConfig *********** */
				.exec(http("s2_AddToCartWithConfig_MTS")
				.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfig}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
				.headers(header_0)
				.check(status.is(200))
				.check(regex("""cartContextKey""").optional.saveAs("cartContextKeyPollCheck"))
				.check(status.not(404), status.not(500), status.not(504), status.not(503))
				.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAddToCartWithConfig"))
				.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyAnonymous_ATCWC")).asJson
				.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyAnonymous_ATCWC_Count"))
				.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("ProdBundleContextKey")).asJson
				.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("ProdLineItemKey")).asJson
				.body(StringBody("""{"basketAction":"AddAfterConfig","multiTransactionKey":"${AddWithConfigATC_MTS}","productConfig":${AddWithConfig}}""")).asJson)

				.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

			}

		}

		/* *** UpdateExistingBasket-UpdQty V105 ******* */
		.exec(http("s2_UpdateBasketQty")
		.put(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfig}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyUpdateBasketQty"))
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("PromoBundleContextKey")).asJson
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("PromoLineItemKey")).asJson
		.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyAnonymous_UBQ")).asJson
		.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyAnonymous_UBQ_Count"))
		.body(StringBody("""{"bundleContextKey":"${ProdBundleContextKeyWNC}","lineItemKey":"${ProdLineItemKeyWNC}","basketAction":"updateBasket","Quantity":"3"}""")).asJson)

		.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

		.doIfEquals("${MultiTransactionKeyAnonymous_UBQ_Count}",1)
		{

			doWhile(session => session("MultiTransactionKeyAnonymous_UBQ_Count").as[String].equals("1"))
			{

				/* *** UpdateExistingBasket-UpdQty V105 ******* */
				exec(http("s2_UpdateBasketQty_MTS")
				.put(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfig}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
				.headers(header_0)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyUpdateBasketQty"))
				.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("PromoBundleContextKey")).asJson
				.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("PromoLineItemKey")).asJson
				.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyAnonymous_UBQ")).asJson
				.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyAnonymous_UBQ_Count"))
				.body(StringBody("""{"bundleContextKey":"${ProdBundleContextKeyWNC}","lineItemKey":"${ProdLineItemKeyWNC}","multiTransactionKey":"${MultiTransactionKeyAnonymous_UBQ}","basketAction":"updateBasket","Quantity":"3"}""")).asJson)

				.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

			}

		}

		/* **** UpdateExistingBasket-UpdAttrib V105 *** */
		.exec(http("s2_UpdateBasketAttrib")
		.put(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyUpdateBasketQty}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex(""""cartContextKey":"(.+?)",""").optional.saveAs("CartContextKeyUpdateBasketAttrib"))
		.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyAnonymous_UBA")).asJson
		.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyAnonymous_UBA_Count"))
		.body(ElFileBody("./src/test/resources/bodies/DC_WP/DC_WP_Anonymous_UpdateBasketAttribute.txt")).asJson)

		.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

		.doIfEquals("${MultiTransactionKeyAnonymous_UBA_Count}",1)
		{

			doWhile(session => session("MultiTransactionKeyAnonymous_UBA_Count").as[String].equals("1"))
			{

				/* **** UpdateExistingBasket-UpdAttrib V105 *** */
				exec(http("s2_UpdateBasketAttrib_MTS")
				.put(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyUpdateBasketQty}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
				.headers(header_0)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex(""""cartContextKey":"(.+?)",""").optional.saveAs("CartContextKeyUpdateBasketAttrib"))
				.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyAnonymous_UBA")).asJson
				.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyAnonymous_UBA_Count"))
				.body(ElFileBody("./src/test/resources/bodies/DC_WP/DC_WP_Anonymous_UpdateBasketAttribute_MTS.txt")).asJson)

				.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

			}

		}

		/* ********** DeleteFromBasket *********** */
		.exec(http("s2_DeleteFromBasket")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfig}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		//.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyDeleteFromBasket"))
		.body(StringBody("""{"deleteBundleNumber":"0","basketAction":"DeleteFromBasket"}""")).asJson)

		.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

		/* ********** DeleteProductAPI *********** */
		.exec(http("s2_DeleteProd")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfig}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyDeleteProd"))
		.body(StringBody("""{"bundleContextKey":"${ProdBundleContextKeyWNC}","basketAction":"deleteFromBasket","itemKey":"${ProdLineItemKeyWNC}"}""")).asJson)

		.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

		/* ********** AddPromotion-Step1 *********** */
		.feed(promoFeeder)
		.exec(http("""s2_AddPromotion-Step1""")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfig}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAddPromotionStep1"))
		.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAddToCartWithNoConfig"))
		.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("TransKey"))
		.check(regex("""cartContextKey(.+?)""").optional.saveAs("CreateCart"))
		.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("TransKeyCount"))
		.body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}"}""")).asJson)

		.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

		.doIfEquals("${TransKeyCount}", 0) {
			/* ********** Delete Promotion Items *********** */
			exec(http("s2_DeleteFromBasketPromo")
			.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotionStep1}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
			.headers(header_0)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyDeleteFromBasketPromo"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("Del1TransKey"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("Del1TransKeyCount"))
			.body(StringBody("""{"basketAction":"deleteFromBasket","offer":"${PromoOffer}","appliedAction":"Add"}""")).asJson)

			.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

			.doIfEquals("${Del1TransKeyCount}", 1) 
			{
				doWhile(session => session("Del1TransKeyCount").as[String].equals("1"))
				{

					exec(http("s2_DeleteFromBasketPromo_MTS")
					.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotionStep1}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
					.headers(header_0)
					.check(status.is(200))
					.check(status.not(404), status.not(500),status.not(504),status.not(503))
					.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyDeleteFromBasketPromo"))
					.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("Del1TransKey"))
					.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("Del1TransKeyCount"))
					.body(StringBody("""{"basketAction":"deleteFromBasket","offer":"${PromoOffer}","appliedAction":"Add","multiTransactionKey":"${Del1TransKey}"}""")).asJson)

					.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)
				}
			}

			.exec(http("s2_GetBasketDetails")
			.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotionStep1}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
			.headers(header_0)
			.check(status.is(200))
			.check(status.not(404), status.not(500), status.not(504), status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyGetBasketDetails"))
			.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").find.exists.saveAs("DelProdBundleContextKey")).asJson
			.check(jsonPath("""$.result.records[0].promotions.records[0].actions.deletePromotionBasketAction.rest.params.offer""").optional.saveAs("DelPromo")).asJson)

			.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

		}

		.doIfEquals("${TransKeyCount}", 1) {
			/* ********** AddPromotion-Step2 *********** */
			//feed(promoFeeder)
			exec(http("s2_AddPromotion-Step2")
			.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfig}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
			.headers(header_0)
			.check(status.is(200))
			.check(regex("""cartContextKey""").find.exists)
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyAddPromotion-Step2"))
			.check(regex("""cartContextKey(.+?)""").find.exists.saveAs("CreateCart"))
			.body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}","multiTransactionKey":"${TransKey}"}""")).asJson)

			.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

			/* ********** Delete Promotion Items *********** */
			.exec(http("s2_DeleteFromBasketPromo")
			.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step2}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
			.headers(header_0)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyDeleteFromBasketPromo"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("Del2TransKey"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("Del2TransKeyCount"))
			.body(StringBody("""{"basketAction":"deleteFromBasket","offer":"${PromoOffer}","appliedAction":"Add"}""")).asJson)

			.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

			.doIfEquals("${Del2TransKeyCount}", 1) 
			{
				doWhile(session => session("Del2TransKeyCount").as[String].equals("1"))
				{

					exec(http("s2_DeleteFromBasketPromo_MTS")
					.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step2}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
					.headers(header_0)
					.check(status.is(200))
					.check(status.not(404), status.not(500),status.not(504),status.not(503))
					.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyDeleteFromBasketPromo"))
					.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("Del2TransKey"))
					.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("Del2TransKeyCount"))
					.body(StringBody("""{"basketAction":"deleteFromBasket","offer":"${PromoOffer}","appliedAction":"Add","multiTransactionKey":"${Del2TransKey}"}""")).asJson)

					.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)
				}
			}

			.exec(http("s2_GetBasketDetails")
			.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step2}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
			.headers(header_0)
			.check(status.is(200))
			.check(status.not(404), status.not(500), status.not(504), status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyGetBasketDetails"))
			.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").find.exists.saveAs("DelProdBundleContextKey")).asJson
			.check(jsonPath("""$.result.records[0].promotions.records[0].actions.deletePromotionBasketAction.rest.params.offer""").optional.saveAs("DelPromo")).asJson)

			.pause(Configuration.script2_BasketOperation_minWaitMs milliseconds, Configuration.script2_BasketOperation_maxWaitMs milliseconds)

		}
		.exec(flushSessionCookies)
		.exec(flushCookieJar)
		.exec(flushHttpCache)
	}


	val script3OrderCreation = scenario("SF_DC_Anon_Script_3_Order_Creation")
	
	.exec(session => session.set("password",credentials))

	/* ********* Get OAuth Token for Perf2 ************* */
	.exec(http("RESTGetOAuthToken")
	.post("https://test.salesforce.com/services/oauth2/token")
	.header("Content-Type", "application/x-www-form-urlencoded")
	.formParam("password", "${password}")
	.formParam("username", "ldvtesting2@vlocity.com")
	.formParam("client_secret", "4F1DE5B4EC987DC9138A68A1D1567ECA1DCC9583A88B3130B95D2742ADB473EA")
	.formParam("client_id", "3MVG9_7ddP9KqTzfqPTQdMvr5pwHfDxPcU4QZMHvJTbg1TlFT_Nx8_2aS.NWDGESp83ZDu7NTPhr8X3kVxfq3")
	.formParam("grant_type", "password")
	.check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
	.check(status.is(200)))

	.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

	.repeat(10000) {

		/* ********* Call to get contextKey  ************* */
		feed(contextFeeder)
		.exec(http("s3_getAnonymousCK")
		.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""contextKey":"(.+?)".""").find.exists.saveAs("AnonymousCK")))

		.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

		/* ********** GetListOfProductsForCart *********** */
		.exec(http("s3_GetOffersByCatalog")
		.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""contextKey""").find.exists)
		.check(jsonPath("$.offers[*].ProductCode").findAll.saveAs("ProductOffersList")).asJson)

		.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

		/* ********** GetOfferDetails *********** */
		.feed(offerFeeder)
		.exec(http("s3_GetOfferDetails")
		.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers/${OfferCode}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""contextKey""").find.exists)
		.check(bodyString.saveAs("OfferDetailsRes")).asJson)

		.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

		/* ********** ConfigureOffer *********** */
		.exec(http("s3_ConfigureOffer")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/offers/${OfferCode}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
		.headers(header_0)
		.body(StringBody("""${OfferDetailsRes}""")).asJson
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""contextKey""").find.exists)
		.check(regex(""""result":(.+?)."errorCode":"INVOKE""").find.exists.saveAs("AddWithConfig")).asJson)

		.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

		/* ********** AddWithNoConfig *********** */
		.exec(http("s3_AddToCartWithNoConfig")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
		.headers(header_0)
		.check(status.is(200))
		.check(regex("""cartContextKey""").find.exists)
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyAddToCartWithNoConfig")).asJson
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("ProdBundleContextKeyWNC")).asJson
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("ProdLineItemKeyWNC")).asJson
		.body(StringBody("""{"offer":"${OfferCode}","basketAction":"AddWithNoConfig"}""")).asJson)

		.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

		/* ********** AddWithConfig *********** */
		.exec(http("s3_AddToCartWithConfig")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfig}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAddToCartWithConfig"))
		.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyAnonymous_ATCWC")).asJson
		.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyAnonymous_ATCWC_Count"))
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("ProdBundleContextKey")).asJson
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("ProdLineItemKey")).asJson
		.body(StringBody("""{"basketAction":"AddAfterConfig","productConfig":${AddWithConfig}}""")).asJson)

		.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)


		.doIfEquals("${MultiTransactionKeyAnonymous_ATCWC_Count}",1)
		{

			doWhile(session => session("MultiTransactionKeyAnonymous_ATCWC_Count").as[String].equals("1"))
			{
				exec {

					session =>
					val addAfterConfigSession_AddToCart = session("AddWithConfig").as[String]
					val buildStringAddWithConfig_AddToCart = addAfterConfigSession_AddToCart.substring(1)
					/*val finalbuildStringAddWithConfig_AddToCart = """{"multiTransactionKey":"""" + session("MultiTransactionKeyAnonymous_ATCWC").as[String] + """",""" */
					val finalbuildStringAddWithConfig_AddToCart = session("MultiTransactionKeyAnonymous_ATCWC").as[String]
					/* session.set("AddWithConfigATC_MTS", finalbuildStringAddWithConfig_AddToCart + buildStringAddWithConfig_AddToCart) */
					session.set("AddWithConfigATC_MTS", finalbuildStringAddWithConfig_AddToCart)

				}

				/* ********** AddWithConfig *********** */
				.exec(http("s3_AddToCartWithConfig_MTS")
				.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfig}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
				.headers(header_0)
				.check(status.is(200))
				.check(regex("""cartContextKey""").optional.saveAs("cartContextKeyPollCheck"))
				.check(status.not(404), status.not(500), status.not(504), status.not(503))
				.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAddToCartWithConfig"))
				.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyAnonymous_ATCWC")).asJson
				.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyAnonymous_ATCWC_Count"))
				.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("ProdBundleContextKey")).asJson
				.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("ProdLineItemKey")).asJson
				.body(StringBody("""{"basketAction":"AddAfterConfig","multiTransactionKey":"${AddWithConfigATC_MTS}","productConfig":${AddWithConfig}}""")).asJson)

				.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

			}

		}

		.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

		/* *** UpdateExistingBasket-UpdQty V105 ******* */
		.exec(http("s3_UpdateBasketQty")
		.put(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfig}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyUpdateBasketQty"))
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("PromoBundleContextKey")).asJson
		.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("PromoLineItemKey")).asJson
		.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyAnonymous_UBQ")).asJson
		.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyAnonymous_UBQ_Count"))
		.body(StringBody("""{"bundleContextKey":"${ProdBundleContextKeyWNC}","lineItemKey":"${ProdLineItemKeyWNC}","basketAction":"updateBasket","Quantity":"3"}""")).asJson)

		.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

		.doIfEquals("${MultiTransactionKeyAnonymous_UBQ_Count}",1)
		{

			doWhile(session => session("MultiTransactionKeyAnonymous_UBQ_Count").as[String].equals("1"))
			{

				/* *** UpdateExistingBasket-UpdQty V105 ******* */
				exec(http("s3_UpdateBasketQty_MTS")
				.put(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfig}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
				.headers(header_0)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyUpdateBasketQty"))
				.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").optional.saveAs("PromoBundleContextKey")).asJson
				.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.lineItemKey""").optional.saveAs("PromoLineItemKey")).asJson
				.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyAnonymous_UBQ")).asJson
				.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyAnonymous_UBQ_Count"))
				.body(StringBody("""{"bundleContextKey":"${ProdBundleContextKeyWNC}","lineItemKey":"${ProdLineItemKeyWNC}","multiTransactionKey":"${MultiTransactionKeyAnonymous_UBQ}","basketAction":"updateBasket","Quantity":"3"}""")).asJson)

				.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

			}

		}

		.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

		/* **** UpdateExistingBasket-UpdAttrib V105 *** */
		.exec(http("s3_UpdateBasketAttrib")
		.put(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyUpdateBasketQty}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex(""""cartContextKey":"(.+?)",""").optional.saveAs("CartContextKeyUpdateBasketAttrib"))
		.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyAnonymous_UBA")).asJson
		.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyAnonymous_UBA_Count"))
		.body(ElFileBody("./src/test/resources/bodies/DC_WP/DC_WP_Anonymous_UpdateBasketAttribute.txt")).asJson)

		.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

		.doIfEquals("${MultiTransactionKeyAnonymous_UBA_Count}",1)
		{

			doWhile(session => session("MultiTransactionKeyAnonymous_UBA_Count").as[String].equals("1"))
			{

				/* **** UpdateExistingBasket-UpdAttrib V105 *** */
				exec(http("s3_UpdateBasketAttrib_MTS")
				.put(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyUpdateBasketQty}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
				.headers(header_0)
				.check(status.is(200))
				.check(status.not(404), status.not(500),status.not(504),status.not(503))
				.check(regex(""""cartContextKey":"(.+?)",""").optional.saveAs("CartContextKeyUpdateBasketAttrib"))
				.check(regex("""multiTransactionKey":"(.+?)","method""").optional.saveAs("MultiTransactionKeyAnonymous_UBA")).asJson
				.check(regex("""multiTransactionKey":"(.+?)","method""").count.saveAs("MultiTransactionKeyAnonymous_UBA_Count"))
				.body(ElFileBody("./src/test/resources/bodies/DC_WP/DC_WP_Anonymous_UpdateBasketAttribute_MTS.txt")).asJson)

				.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

			}

		}

		/* ********** DeleteFromBasket *********** */
		.exec(http("s3_DeleteFromBasket")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfig}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		//.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyDeleteFromBasket"))
		.body(StringBody("""{"deleteBundleNumber":"0","basketAction":"DeleteFromBasket"}""")).asJson)

		.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

		/* ********** DeleteProductAPI *********** */
		.exec(http("s3_DeleteProd")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfig}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyDeleteProd"))
		.body(StringBody("""{"bundleContextKey":"${ProdBundleContextKeyWNC}","basketAction":"deleteFromBasket","itemKey":"${ProdLineItemKeyWNC}"}""")).asJson)

		.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

		/* ********** AddPromotion-Step1 *********** */
		.feed(promoFeeder)
		.exec(http("""s3_AddPromotion-Step1""")
		.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfig}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
		.headers(header_0)
		.check(status.is(200))
		.check(status.not(404), status.not(500),status.not(504),status.not(503))
		.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAddPromotionStep1"))
		.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyAddToCartWithNoConfig"))
		.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("TransKey"))
		.check(regex("""cartContextKey(.+?)""").optional.saveAs("CreateCart"))
		.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("TransKeyCount"))
		.body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}"}""")).asJson)

		.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

		.doIfEquals("${TransKeyCount}", 0) {
			/* ********** Delete Promotion Items *********** */
			exec(http("s3_DeleteFromBasketPromo")
			.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotionStep1}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
			.headers(header_0)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyDeleteFromBasketPromo"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("Del1TransKey"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("Del1TransKeyCount"))
			.body(StringBody("""{"basketAction":"deleteFromBasket","offer":"${PromoOffer}","appliedAction":"Add"}""")).asJson)

			.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

			.doIfEquals("${Del1TransKeyCount}", 1) 
			{
				doWhile(session => session("Del1TransKeyCount").as[String].equals("1"))
				{

					exec(http("s3_DeleteFromBasketPromo_MTS")
					.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotionStep1}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
					.headers(header_0)
					.check(status.is(200))
					.check(status.not(404), status.not(500),status.not(504),status.not(503))
					.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyDeleteFromBasketPromo"))
					.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("Del1TransKey"))
					.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("Del1TransKeyCount"))
					.body(StringBody("""{"basketAction":"deleteFromBasket","offer":"${PromoOffer}","appliedAction":"Add","multiTransactionKey":"${Del1TransKey}"}""")).asJson)

					.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)
				}
			}

			.exec(http("s3_GetBasketDetails")
			.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotionStep1}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
			.headers(header_0)
			.check(status.is(200))
			.check(status.not(404), status.not(500), status.not(504), status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyGetBasketDetails"))
			.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").find.exists.saveAs("DelProdBundleContextKey")).asJson
			.check(jsonPath("""$.result.records[0].promotions.records[0].actions.deletePromotionBasketAction.rest.params.offer""").optional.saveAs("DelPromo")).asJson)

			.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

			/* ********** CreateCart *********** */
			.feed(accountFeeder)
			.exec(http("s3_CreateCart")
			.post(uri02 + """/services/apexrest/v3/carts?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
			.headers(header_0)
			.check(status.is(200))
			.check(regex("""orderNumber""").find.exists)
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""orderId":"(.+?)"""").find.exists.saveAs("OrderId"))
			.body(StringBody("""{"accountId": "${AccountId}","catalogCode": "DC-WP-Cat-for-LI-products","cartContextKey":"${CartContextKeyAddPromotionStep1}"}""")).asJson)

			.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)


		}

		.doIfEquals("${TransKeyCount}", 1) {
			/* ********** AddPromotion-Step2 *********** */
			//feed(promoFeeder)
			exec(http("s3_AddPromotion-Step2")
			.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddToCartWithNoConfig}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
			.headers(header_0)
			.check(status.is(200))
			.check(regex("""cartContextKey""").find.exists)
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyAddPromotion-Step2"))
			.check(regex("""cartContextKey(.+?)""").find.exists.saveAs("CreateCart"))
			.body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}","multiTransactionKey":"${TransKey}"}""")).asJson)

			.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

			/* ********** Delete Promotion Items *********** */
			.exec(http("s3_DeleteFromBasketPromo")
			.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step2}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
			.headers(header_0)
			.check(status.is(200))
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyDeleteFromBasketPromo"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("Del2TransKey"))
			.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("Del2TransKeyCount"))
			.body(StringBody("""{"basketAction":"deleteFromBasket","offer":"${PromoOffer}","appliedAction":"Add"}""")).asJson)

			.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

			.doIfEquals("${Del2TransKeyCount}", 1) 
			{
				doWhile(session => session("Del2TransKeyCount").as[String].equals("1"))
				{

					exec(http("s3_DeleteFromBasketPromo_MTS")
					.post(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step2}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
					.headers(header_0)
					.check(status.is(200))
					.check(status.not(404), status.not(500),status.not(504),status.not(503))
					.check(regex("""cartContextKey":"(.+?)","""").optional.saveAs("CartContextKeyDeleteFromBasketPromo"))
					.check(regex(""""multiTransactionKey":"(.+?)","method""").optional.saveAs("Del2TransKey"))
					.check(regex(""""multiTransactionKey":"(.+?)","method""").count.saveAs("Del2TransKeyCount"))
					.body(StringBody("""{"basketAction":"deleteFromBasket","offer":"${PromoOffer}","appliedAction":"Add","multiTransactionKey":"${Del2TransKey}"}""")).asJson)

					.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)
				}
			}
			.exec(http("s3_GetBasketDetails")
			.get(uri02 + """/services/apexrest/v3/catalogs/DC-WP-Cat-for-LI-products/basket/${CartContextKeyAddPromotion-Step2}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
			.headers(header_0)
			.check(status.is(200))
			.check(status.not(404), status.not(500), status.not(504), status.not(503))
			.check(regex("""cartContextKey":"(.+?)","""").find.exists.saveAs("CartContextKeyGetBasketDetails"))
			.check(jsonPath("""$.result.records[0].actions.updateBasketAction.rest.params.bundleContextKey""").find.exists.saveAs("DelProdBundleContextKey")).asJson
			.check(jsonPath("""$.result.records[0].promotions.records[0].actions.deletePromotionBasketAction.rest.params.offer""").optional.saveAs("DelPromo")).asJson)

			.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)

			/* ********** CreateCart *********** */
			.feed(accountFeeder)
			.exec(http("s3_CreateCart")
			.post(uri02 + """/services/apexrest/v3/carts?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
			.headers(header_0)
			.check(status.is(200))
			.check(regex("""orderNumber""").find.exists)
			.check(status.not(404), status.not(500),status.not(504),status.not(503))
			.check(regex("""orderId":"(.+?)"""").find.exists.saveAs("OrderId"))
			.body(StringBody("""{"accountId": "${AccountId}","catalogCode": "DC-WP-Cat-for-LI-products","cartContextKey":"${CartContextKeyAddPromotion-Step2}"}""")).asJson)

			.pause(Configuration.script3_OrderCreation_minWaitMs milliseconds, Configuration.script3_OrderCreation_maxWaitMs milliseconds)


		}
	}

	.exec(flushSessionCookies)
	.exec(flushCookieJar)
	.exec(flushHttpCache)
}
