package DC_ldv2_WP_SF_Anonymous

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._
import io.gatling.core.protocol.Protocol
import io.gatling.core.structure.ChainBuilder

class DC_WP_Anonymous_SF_scn extends Simulation{

	val httpConf = http
	.baseUrl(Configuration.BaseUrl)
	.inferHtmlResources(BlackList(""".*\.js""", """.*\.css""", """.*\.gif""", """.*\.jpeg""", """.*\.jpg""", """.*\.ico""", """.*\.woff""", """.*\.(t|o)tf""", """.*\.png"""), WhiteList())
	.acceptHeader("*/*")
	.acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8")
	.acceptEncodingHeader("gzip, deflate, sdch")
	.acceptLanguageHeader("en-US,en;q=0.8")
	.disableCaching
	.contentTypeHeader("application/x-www-form-urlencoded; charset=UTF-8")
	.userAgentHeader("Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:41.0) Gecko/20100101 Firefox/41.0")

	/*val loginUsers = Integer.getInteger("SF_DC_Anon_Login_Users", 1)
	val loginRampUp = Integer.getInteger("SF_DC_Anon_Login_RampUp", 1)

	val script1BrowsingUsers = Integer.getInteger("SF_DC_Anon_script1Browsing_Users", 1)
	val script1BrowsingRampUp = Integer.getInteger("SF_DC_Anon_script1Browsing_RampUp", 1)

	val script2BasketOperationUsers = Integer.getInteger("SF_DC_Anon_script2BasketOperation_Users", 1)
	val script2BasketOperationRampUp = Integer.getInteger("SF_DC_Anon_script2BasketOperation_RampUp", 1)

	val script3OrderCreationUsers = Integer.getInteger("SF_DC_Anon_script3OrderCreation_Users", 1)
	val script3OrderCreationRampUp = Integer.getInteger("SF_DC_Anon_script3OrderCreation_RampUp", 1)*/

	val maxDurationSecs = Integer.getInteger("maxDurationSecs", 1)
	val testDuration = Integer.getInteger("testDuration",1)

	val s1_incrementConcurrentUsersInTest=Integer.getInteger("s1_incrementConcurrentUsersInTest", 1)
	val s1_howManyTimesToIncrement=Integer.getInteger("s1_howManyTimesToIncrement", 1)
	val s1_eachLevelLastingInTest=Integer.getInteger("s1_eachLevelLastingInTest", 1)
	val s1_separatedByRampsLasting=Integer.getInteger("s1_separatedByRampsLasting", 1)
	val s1_startingFromHowManyUsers=Integer.getInteger("s1_startingFromHowManyUsers", 1)

	val s2_incrementConcurrentUsersInTest=Integer.getInteger("s2_incrementConcurrentUsersInTest", 1)
	val s2_howManyTimesToIncrement=Integer.getInteger("s2_howManyTimesToIncrement", 1)
	val s2_eachLevelLastingInTest=Integer.getInteger("s2_eachLevelLastingInTest", 1)
	val s2_separatedByRampsLasting=Integer.getInteger("s2_separatedByRampsLasting", 1)
	val s2_startingFromHowManyUsers=Integer.getInteger("s2_startingFromHowManyUsers", 1)

	val s3_incrementConcurrentUsersInTest=Integer.getInteger("s3_incrementConcurrentUsersInTest", 1)
	val s3_howManyTimesToIncrement=Integer.getInteger("s3_howManyTimesToIncrement", 1)
	val s3_eachLevelLastingInTest=Integer.getInteger("s3_eachLevelLastingInTest", 1)
	val s3_separatedByRampsLasting=Integer.getInteger("s3_separatedByRampsLasting", 1)
	val s3_startingFromHowManyUsers=Integer.getInteger("s3_startingFromHowManyUsers", 1)


	setUp(
		/*DC_WP_Anonymous_SF.loginScn.inject(rampUsers(loginUsers) during (loginRampUp seconds)).protocols(httpConf),DC_WP_Anonymous_SF.script1Browsing.inject(rampUsers(script1BrowsingUsers) during (script1BrowsingRampUp seconds)).protocols(httpConf),DC_WP_Anonymous_SF.script2BasketOperation.inject(rampUsers(script2BasketOperationUsers) during (script2BasketOperationRampUp seconds)).protocols(httpConf),DC_WP_Anonymous_SF.script3OrderCreation.inject(rampUsers(script3OrderCreationUsers) during (script3OrderCreationRampUp seconds)).protocols(httpConf)).maxDuration(maxDurationSecs seconds)*/
		
//Script1 Browsing - 260 Users Script2 Basket operation - 70 Users Script3 Order - 20 Users //90  3 3600 225 90

		DC_WP_Anonymous_SF.script1Browsing.inject(incrementConcurrentUsers(s1_incrementConcurrentUsersInTest).times(s1_howManyTimesToIncrement).eachLevelLasting(s1_eachLevelLastingInTest seconds).separatedByRampsLasting(s1_separatedByRampsLasting seconds).startingFrom(s1_startingFromHowManyUsers)).protocols(httpConf),

		DC_WP_Anonymous_SF.script2BasketOperation.inject(incrementConcurrentUsers(s2_incrementConcurrentUsersInTest).times(s2_howManyTimesToIncrement).eachLevelLasting(s2_eachLevelLastingInTest seconds).separatedByRampsLasting(s2_separatedByRampsLasting seconds).startingFrom(s2_startingFromHowManyUsers)).protocols(httpConf),

		DC_WP_Anonymous_SF.script3OrderCreation.inject(incrementConcurrentUsers(s3_incrementConcurrentUsersInTest).times(s3_howManyTimesToIncrement).eachLevelLasting(s3_eachLevelLastingInTest seconds).separatedByRampsLasting(s3_separatedByRampsLasting seconds).startingFrom(s3_startingFromHowManyUsers)).protocols(httpConf)).maxDuration(maxDurationSecs seconds)

	}