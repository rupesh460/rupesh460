package XOM_NewOrder_AWS

object Configuration
 {
	val BaseUrl = "https://c.cs17.visual.force.com"
	val Uri01 = "https://316ajx90qe.execute-api.us-east-2.amazonaws.com"
	
	val MinWaitMs = Integer.getInteger("MinWaitMs", 1)
	val MaxWaitMs = Integer.getInteger("MaxWaitMs", 1)

}