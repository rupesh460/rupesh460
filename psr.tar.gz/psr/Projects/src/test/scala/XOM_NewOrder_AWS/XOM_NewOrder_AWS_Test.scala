package XOM_NewOrder_AWS

import RequestSigner._
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import Headers._
import scala.collection._

import java.util.UUID.randomUUID
import util.Random.nextInt
import scala.util.Random
import java.io.File
import java.io.PrintWriter
import java.io.FileOutputStream
//import java.lang.String
// import scala.util.matching.Regex
// import scala.concurrent.duration._


import com.amazonaws.auth.{BasicAWSCredentials, BasicSessionCredentials}



object XOM_NewOrder_AWS_Test {


  val uri01 = Configuration.Uri01
  var BatchId = new StringBuilder()
  var OrderId = new StringBuilder()
  var AccountId = new StringBuilder()
  var AccountName = new StringBuilder()
  var OrderNumberS = new StringBuilder()
  var OrderItemId1 = new StringBuilder()
  var OrderItemId2 = new StringBuilder()
  var OrderItemId3 = new StringBuilder()
  var OrderItemId4 = new StringBuilder()
  var OrderItemId5 = new StringBuilder()
  var OrderItemId6 = new StringBuilder()
  var OrderItemId7 = new StringBuilder()
  var OrderItemId8 = new StringBuilder()
  var OrderItemId9 = new StringBuilder()
  var OrderItemId10 = new StringBuilder()
  var AssetReferenceId1 = new StringBuilder()
  var AssetReferenceId2 = new StringBuilder()
  var AssetReferenceId3 = new StringBuilder()
  var AssetReferenceId4 = new StringBuilder()
  var AssetReferenceId5 = new StringBuilder()
  var AssetReferenceId6 = new StringBuilder()
  var AssetReferenceId7 = new StringBuilder()
  var AssetReferenceId8 = new StringBuilder()
  var AssetReferenceId9 = new StringBuilder()
  var AssetReferenceId10 = new StringBuilder()

  var SignatureDetails = new StringBuilder()
  var AmazonTimeDetails = new StringBuilder()

  val rnd = new Random()

  val scn = scenario("XOM_NewOrder_AWS")

    .repeat(8000000) {

      /** *************************************************** start of creating new account with Order **********************************/

      exec(session => session.set("batchId", ""))
        .exec(session => session.set("orderId", ""))
        .exec(session => session.set("accountId", ""))
        .exec(session => session.set("accountName", ""))
        .exec(session => session.set("OrderNumber", ""))
        .exec(session => session.set("orderItemId1", ""))
        .exec(session => session.set("assetReferenceId1", ""))
        .exec(session => session.set("orderItemId2", ""))
        .exec(session => session.set("assetReferenceId2", ""))
        .exec(session => session.set("orderItemId3", ""))
        .exec(session => session.set("assetReferenceId3", ""))
        .exec(session => session.set("orderItemId4", ""))
        .exec(session => session.set("assetReferenceId4", ""))
        .exec(session => session.set("orderItemId5", ""))
        .exec(session => session.set("assetReferenceId5", ""))
        .exec(session => session.set("orderItemId6", ""))
        .exec(session => session.set("assetReferenceId6", ""))
        .exec(session => session.set("orderItemId7", ""))
        .exec(session => session.set("assetReferenceId7", ""))
        .exec(session => session.set("orderItemId8", ""))
        .exec(session => session.set("assetReferenceId8", ""))
        .exec(session => session.set("orderItemId9", ""))
        .exec(session => session.set("assetReferenceId9", ""))
        .exec(session => session.set("orderItemId10", ""))
        .exec(session => session.set("assetReferenceId10", ""))
        .exec(session => session.set("signatureDetails", ""))
        .exec(session => session.set("amazonTimeDetails", ""))


        .exec(session => {
          BatchId.append(randomUUID().toString)
          OrderId.append("801g" + f"${rnd.nextInt(999999)}%06d" + rnd.alphanumeric.take(5).mkString)
          AccountId.append("001g" + f"${rnd.nextInt(9999999)}%07d" + rnd.alphanumeric.filter(_.isLetter).take(4).mkString)
          AccountName.append("Acc-aws-" + rnd.alphanumeric.filter(_.isLetter).take(2).mkString + rnd.nextInt(999))
          OrderNumberS.append(f"${rnd.nextInt(99999999)}%08d")
          OrderItemId1.append("802g" + f"${rnd.nextInt(999999)}%06d" + rnd.alphanumeric.filter(_.isLetter).take(5).mkString)
          OrderItemId2.append("802g" + f"${rnd.nextInt(999999)}%06d" + rnd.alphanumeric.filter(_.isLetter).take(5).mkString)
          OrderItemId3.append("802g" + f"${rnd.nextInt(999999)}%06d" + rnd.alphanumeric.filter(_.isLetter).take(5).mkString)
          OrderItemId4.append("802g" + f"${rnd.nextInt(999999)}%06d" + rnd.alphanumeric.filter(_.isLetter).take(5).mkString)
          OrderItemId5.append("802g" + f"${rnd.nextInt(999999)}%06d" + rnd.alphanumeric.filter(_.isLetter).take(5).mkString)
          OrderItemId6.append("802g" + f"${rnd.nextInt(999999)}%06d" + rnd.alphanumeric.filter(_.isLetter).take(5).mkString)
          OrderItemId7.append("802g" + f"${rnd.nextInt(999999)}%06d" + rnd.alphanumeric.filter(_.isLetter).take(5).mkString)
          OrderItemId8.append("802g" + f"${rnd.nextInt(999999)}%06d" + rnd.alphanumeric.filter(_.isLetter).take(5).mkString)
          OrderItemId9.append("802g" + f"${rnd.nextInt(999999)}%06d" + rnd.alphanumeric.filter(_.isLetter).take(5).mkString)
          OrderItemId10.append("802g" + f"${rnd.nextInt(999999)}%06d" + rnd.alphanumeric.filter(_.isLetter).take(5).mkString)
          AssetReferenceId1.append(randomUUID().toString)
          AssetReferenceId2.append(randomUUID().toString)
          AssetReferenceId3.append(randomUUID().toString)
          AssetReferenceId4.append(randomUUID().toString)
          AssetReferenceId5.append(randomUUID().toString)
          AssetReferenceId6.append(randomUUID().toString)
          AssetReferenceId7.append(randomUUID().toString)
          AssetReferenceId8.append(randomUUID().toString)
          AssetReferenceId9.append(randomUUID().toString)
          AssetReferenceId10.append(randomUUID().toString)


          val requestBuildBody =
            s"""{
    "batchId": "${BatchId}",
    "batchFinalChunk": true,
    "orders": [
        {
            "orderId": "${OrderId}",
            "accountId": "${AccountId}",
            "accountName": "${AccountName}",
            "fields": {
                "OrderNumber": "${OrderNumberS}",
                "Status": "Draft",
                "JeopardySafetyIntervalUnit__c": "Seconds"
            },
            "orderAppliedPromotions": [],
            "orderPricing": [],
            "orderItems": [
                {
                    "orderItemId": "${OrderItemId1}",
                    "lineNumber": "0001.0007.0001",
                    "serviceAccountId": "${AccountId}",
                    "serviceAccountName": "${AccountName}",
                    "billingAccountId": "${AccountId}",
                    "billingAccountName": "${AccountName}",
                    "assetReferenceId": "${AssetReferenceId1}",
                    "sourceAssetId": "",
                    "action": "Add",
                    "subAction": "",
                    "specifiedBy": {
                        "specificationId": "01tg0000007W5kb",
                        "specificationName": "Grupo Numeros Amigos de SMS",
                        "globalKey": "3ae9b8d1-c98f-53fa-8072-c37fbdb9bcb0"
                    },
                    "describedBy": [
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5644",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5602",
                            "value": ""
                        },
                        {
                            "characteristic": "Add",
                            "code": "ATTRIBUTE-5618",
                            "value": ""
                        },
                        {
                            "characteristic": "Access Type",
                            "code": "ATTRIBUTE-5614",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5564",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5486",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5630",
                            "value": ""
                        },
                        {
                            "characteristic": "Actual Provider",
                            "code": "ATTRIBUTE-5699",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5350",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5443",
                            "value": ""
                        }
                    ],
                    "fieldValues": [],
                    "fields": {}
                },
                {
                    "orderItemId": "${OrderItemId2}",
                    "lineNumber": "0001.0007",
                    "serviceAccountId": "${AccountId}",
                    "serviceAccountName": "${AccountName}",
                    "billingAccountId": "${AccountId}",
                    "billingAccountName": "${AccountName}",
                    "assetReferenceId": "${AssetReferenceId2}",
                    "sourceAssetId": "",
                    "action": "Add",
                    "subAction": "",
                    "specifiedBy": {
                        "specificationId": "01tg0000007W5kC",
                        "specificationName": "Numeros gratis a Personal 1 para sms contra recarga",
                        "globalKey": "f7e45f7e-9bae-793f-df12-3d42897434cf"
                    },
                    "describedBy": [
                        {
                            "characteristic": "Contact Name",
                            "code": "ATTRIBUTE-5348",
                            "value": ""
                        },
                        {
                            "characteristic": "Agent Role",
                            "code": "ATTRIBUTE-5378",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5644",
                            "value": ""
                        },
                        {
                            "characteristic": "Contact Email Address",
                            "code": "ATTRIBUTE-5704",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5602",
                            "value": ""
                        },
                        {
                            "characteristic": "Contact Name",
                            "code": "ATTRIBUTE-5600",
                            "value": ""
                        },
                        {
                            "characteristic": "Add",
                            "code": "ATTRIBUTE-5618",
                            "value": ""
                        },
                        {
                            "characteristic": "Contact Email",
                            "code": "ATTRIBUTE-5664",
                            "value": ""
                        },
                        {
                            "characteristic": "Compatible Operating System Type",
                            "code": "ATTRIBUTE-5577",
                            "value": ""
                        },
                        {
                            "characteristic": "Admin Email Address",
                            "code": "ATTRIBUTE-5534",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5486",
                            "value": ""
                        },
                        {
                            "characteristic": "Contact Name",
                            "code": "ATTRIBUTE-5442",
                            "value": ""
                        },
                        {
                            "characteristic": "Contact Name",
                            "code": "ATTRIBUTE-5391",
                            "value": ""
                        },
                        {
                            "characteristic": "Contact Name",
                            "code": "ATTRIBUTE-5566",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5630",
                            "value": ""
                        },
                        {
                            "characteristic": "Comments",
                            "code": "ATTRIBUTE-5379",
                            "value": ""
                        },
                        {
                            "characteristic": "Admin Username",
                            "code": "ATTRIBUTE-5532",
                            "value": ""
                        },
                        {
                            "characteristic": "Contact Email",
                            "code": "ATTRIBUTE-5665",
                            "value": ""
                        },
                        {
                            "characteristic": "Comments",
                            "code": "ATTRIBUTE-5528",
                            "value": ""
                        },
                        {
                            "characteristic": "Comments",
                            "code": "ATTRIBUTE-5536",
                            "value": ""
                        },
                        {
                            "characteristic": "Agreement Name",
                            "code": "ATTRIBUTE-5500",
                            "value": ""
                        },
                        {
                            "characteristic": "Comments",
                            "code": "ATTRIBUTE-5421",
                            "value": ""
                        },
                        {
                            "characteristic": "Admin Name",
                            "code": "ATTRIBUTE-5531",
                            "value": ""
                        },
                        {
                            "characteristic": "Actual Provider",
                            "code": "ATTRIBUTE-5699",
                            "value": ""
                        },
                        {
                            "characteristic": "Connectivity ID",
                            "code": "ATTRIBUTE-5578",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5350",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5443",
                            "value": ""
                        },
                        {
                            "characteristic": "Consolidated Comments",
                            "code": "ATTRIBUTE-5562",
                            "value": ""
                        },
                        {
                            "characteristic": "Access Type",
                            "code": "ATTRIBUTE-5614",
                            "value": ""
                        },
                        {
                            "characteristic": "Comments",
                            "code": "ATTRIBUTE-5671",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5564",
                            "value": ""
                        },
                        {
                            "characteristic": "Comments",
                            "code": "ATTRIBUTE-5539",
                            "value": ""
                        }
                    ],
                    "fieldValues": [],
                    "fields": {}
                },
                {
                    "orderItemId": "${OrderItemId3}",
                    "lineNumber": "0001.0006.0001",
                    "serviceAccountId": "${AccountId}",
                    "serviceAccountName": "${AccountName}",
                    "billingAccountId": "${AccountId}",
                    "billingAccountName": "${AccountName}",
                    "assetReferenceId": "${AssetReferenceId3}",
                    "sourceAssetId": "",
                    "action": "Add",
                    "subAction": "",
                    "specifiedBy": {
                        "specificationId": "01tg0000007W5kR",
                        "specificationName": "Grupo Numeros Amigos de Voz",
                        "globalKey": "f48d05cb-e88b-7606-95fb-8a8a9fe294ac"
                    },
                    "describedBy": [
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5644",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5602",
                            "value": ""
                        },
                        {
                            "characteristic": "Add",
                            "code": "ATTRIBUTE-5618",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5486",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5630",
                            "value": ""
                        },
                        {
                            "characteristic": "Actual Provider",
                            "code": "ATTRIBUTE-5699",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5350",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5443",
                            "value": ""
                        },
                        {
                            "characteristic": "Access Type",
                            "code": "ATTRIBUTE-5614",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5564",
                            "value": ""
                        }
                    ],
                    "fieldValues": [],
                    "fields": {}
                },
                {
                    "orderItemId": "${OrderItemId4}",
                    "lineNumber": "0001.0006",
                    "serviceAccountId": "${AccountId}",
                    "serviceAccountName": "${AccountName}",
                    "billingAccountId": "${AccountId}",
                    "billingAccountName": "${AccountName}",
                    "assetReferenceId": "${AssetReferenceId4}",
                    "sourceAssetId": "",
                    "action": "Add",
                    "subAction": "",
                    "specifiedBy": {
                        "specificationId": "01tg0000007nmS5",
                        "specificationName": "Numeros gratis a Personal 1 para voz contra recarga",
                        "globalKey": "36cbe5ca-2fae-8a1b-e649-30d80e672bb1"
                    },
                    "describedBy": [
                        {
                            "characteristic": "Comments",
                            "code": "ATTRIBUTE-5470",
                            "value": ""
                        },
                        {
                            "characteristic": "Connectivity ID",
                            "code": "ATTRIBUTE-5578",
                            "value": ""
                        },
                        {
                            "characteristic": "Change",
                            "code": "ATTRIBUTE-5617",
                            "value": ""
                        },
                        {
                            "characteristic": "City of Use",
                            "code": "ATTRIBUTE-5425",
                            "value": ""
                        },
                        {
                            "characteristic": "Business Public/Private",
                            "code": "ATTRIBUTE-5357",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5350",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5443",
                            "value": ""
                        },
                        {
                            "characteristic": "Access Type",
                            "code": "ATTRIBUTE-5614",
                            "value": ""
                        },
                        {
                            "characteristic": "Comments",
                            "code": "ATTRIBUTE-5671",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5564",
                            "value": ""
                        },
                        {
                            "characteristic": "Comments",
                            "code": "ATTRIBUTE-5539",
                            "value": ""
                        },
                        {
                            "characteristic": "Agent Role",
                            "code": "ATTRIBUTE-5378",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5644",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5602",
                            "value": ""
                        },
                        {
                            "characteristic": "Add",
                            "code": "ATTRIBUTE-5618",
                            "value": ""
                        },
                        {
                            "characteristic": "Chargeable Call Guardian Features",
                            "code": "ATTRIBUTE-5467",
                            "value": ""
                        },
                        {
                            "characteristic": "Compatible Operating System Type",
                            "code": "ATTRIBUTE-5577",
                            "value": ""
                        },
                        {
                            "characteristic": "Admin Email Address",
                            "code": "ATTRIBUTE-5534",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5486",
                            "value": ""
                        },
                        {
                            "characteristic": "Chargeable",
                            "code": "ATTRIBUTE-5468",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5630",
                            "value": ""
                        },
                        {
                            "characteristic": "Admin Username",
                            "code": "ATTRIBUTE-5532",
                            "value": ""
                        },
                        {
                            "characteristic": "City of Use",
                            "code": "ATTRIBUTE-5670",
                            "value": ""
                        },
                        {
                            "characteristic": "Channel Name",
                            "code": "ATTRIBUTE-5695",
                            "value": ""
                        },
                        {
                            "characteristic": "Agreement Name",
                            "code": "ATTRIBUTE-5500",
                            "value": ""
                        },
                        {
                            "characteristic": "Comments",
                            "code": "ATTRIBUTE-5421",
                            "value": ""
                        },
                        {
                            "characteristic": "Color",
                            "code": "ATTRIBUTE-5482",
                            "value": ""
                        },
                        {
                            "characteristic": "Admin Name",
                            "code": "ATTRIBUTE-5531",
                            "value": ""
                        },
                        {
                            "characteristic": "Actual Provider",
                            "code": "ATTRIBUTE-5699",
                            "value": ""
                        },
                        {
                            "characteristic": "Channel Name",
                            "code": "ATTRIBUTE-5363",
                            "value": ""
                        },
                        {
                            "characteristic": "color",
                            "code": "color",
                            "value": ""
                        },
                        {
                            "characteristic": "Color",
                            "code": "GEN_COLOR",
                            "value": ""
                        },
                        {
                            "characteristic": "Color1",
                            "code": "COLOR1",
                            "value": ""
                        }
                    ],
                    "fieldValues": [],
                    "fields": {}
                },
                {
                    "orderItemId": "${OrderItemId5}",
                    "lineNumber": "0001.0005",
                    "serviceAccountId": "${AccountId}",
                    "serviceAccountName": "${AccountName}",
                    "billingAccountId": "${AccountId}",
                    "billingAccountName": "${AccountName}",
                    "assetReferenceId": "${AssetReferenceId5}",
                    "sourceAssetId": "",
                    "action": "Add",
                    "subAction": "",
                    "specifiedBy": {
                        "specificationId": "01tg0000007nlvQ",
                        "specificationName": "Datos",
                        "globalKey": "f90655e9-11c2-0c04-0d7b-26e91456dbf5"
                    },
                    "describedBy": [
                        {
                            "characteristic": "Agent Role",
                            "code": "ATTRIBUTE-5378",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5644",
                            "value": ""
                        },
                        {
                            "characteristic": "Add",
                            "code": "ATTRIBUTE-5618",
                            "value": ""
                        },
                        {
                            "characteristic": "Admin Email Address",
                            "code": "ATTRIBUTE-5534",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5486",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5630",
                            "value": ""
                        },
                        {
                            "characteristic": "Admin Username",
                            "code": "ATTRIBUTE-5532",
                            "value": ""
                        },
                        {
                            "characteristic": "Admin Name",
                            "code": "ATTRIBUTE-5531",
                            "value": ""
                        },
                        {
                            "characteristic": "Actual Provider",
                            "code": "ATTRIBUTE-5699",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5350",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5443",
                            "value": ""
                        },
                        {
                            "characteristic": "Access Type",
                            "code": "ATTRIBUTE-5614",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5564",
                            "value": ""
                        }
                    ],
                    "fieldValues": [],
                    "fields": {}
                },
                {
                    "orderItemId": "${OrderItemId6}",
                    "lineNumber": "0001.0004",
                    "serviceAccountId": "${AccountId}",
                    "serviceAccountName": "${AccountName}",
                    "billingAccountId": "${AccountId}",
                    "billingAccountName": "${AccountName}",
                    "assetReferenceId": "${AssetReferenceId6}",
                    "sourceAssetId": "",
                    "action": "Add",
                    "subAction": "",
                    "specifiedBy": {
                        "specificationId": "01tg0000007nlvW",
                        "specificationName": "MMS",
                        "globalKey": "3a28aaf8-3f85-2b10-b904-424728e17434"
                    },
                    "describedBy": [
                        {
                            "characteristic": "ATTR-1",
                            "code": "ATTR-1",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5644",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5602",
                            "value": ""
                        },
                        {
                            "characteristic": "Add",
                            "code": "ATTRIBUTE-5618",
                            "value": ""
                        },
                        {
                            "characteristic": "Alternate Number to be Delivered",
                            "code": "ATTRIBUTE-5461",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5486",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5630",
                            "value": ""
                        },
                        {
                            "characteristic": "Actual Provider",
                            "code": "ATTRIBUTE-5699",
                            "value": ""
                        },
                        {
                            "characteristic": "APN",
                            "code": "ATTRIBUTE-5386",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5350",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5443",
                            "value": ""
                        },
                        {
                            "characteristic": "Access Type",
                            "code": "ATTRIBUTE-5614",
                            "value": ""
                        },
                        {
                            "characteristic": "Additional Access Information for Technician",
                            "code": "ATTRIBUTE-5564",
                            "value": ""
                        }
                    ],
                    "fieldValues": [],
                    "fields": {}
                },
                {
                    "orderItemId": "${OrderItemId7}",
                    "lineNumber": "0001.0003",
                    "serviceAccountId": "${AccountId}",
                    "serviceAccountName": "${AccountName}",
                    "billingAccountId": "${AccountId}",
                    "billingAccountName": "${AccountName}",
                    "assetReferenceId": "${AssetReferenceId7}",
                    "sourceAssetId": "",
                    "action": "Add",
                    "subAction": "",
                    "specifiedBy": {
                        "specificationId": "01tg0000007nlvh",
                        "specificationName": "SMS Entrante",
                        "globalKey": "3568dbc3-0ffc-e9b3-e8c5-8c3950d81daf"
                    },
                    "describedBy": [
                        {
                            "characteristic": "Billing Telephone Number",
                            "code": "ATTRIBUTE-5541",
                            "value": ""
                        },
                        {
                            "characteristic": "Booking ID",
                            "code": "ATTRIBUTE-5643",
                            "value": ""
                        },
                        {
                            "characteristic": "Booking ID",
                            "code": "ATTRIBUTE-5565",
                            "value": ""
                        },
                        {
                            "characteristic": "BAN",
                            "code": "ATTRIBUTE-5707",
                            "value": ""
                        },
                        {
                            "characteristic": "Billing Telephone Number",
                            "code": "ATTRIBUTE-5505",
                            "value": ""
                        },
                        {
                            "characteristic": "Booking ID",
                            "code": "ATTRIBUTE-5395",
                            "value": ""
                        },
                        {
                            "characteristic": "Booking ID",
                            "code": "ATTRIBUTE-5626",
                            "value": ""
                        },
                        {
                            "characteristic": "Billing Telephone Number",
                            "code": "ATTRIBUTE-5538",
                            "value": ""
                        },
                        {
                            "characteristic": "Booking ID",
                            "code": "ATTRIBUTE-5598",
                            "value": ""
                        },
                        {
                            "characteristic": "Billing Telephone Number",
                            "code": "ATTRIBUTE-5612",
                            "value": ""
                        },
                        {
                            "characteristic": "Billing Telephone Number",
                            "code": "ATTRIBUTE-5529",
                            "value": ""
                        },
                        {
                            "characteristic": "Booking ID",
                            "code": "ATTRIBUTE-5487",
                            "value": ""
                        },
                        {
                            "characteristic": "Bandwidth",
                            "code": "BANDWIDTH",
                            "value": ""
                        }
                    ],
                    "fieldValues": [],
                    "fields": {}
                },
                {
                    "orderItemId": "${OrderItemId8}",
                    "lineNumber": "0001.0002",
                    "serviceAccountId": "${AccountId}",
                    "serviceAccountName": "${AccountName}",
                    "billingAccountId": "${AccountId}",
                    "billingAccountName": "${AccountName}",
                    "assetReferenceId": "${AssetReferenceId8}",
                    "sourceAssetId": "",
                    "action": "Add",
                    "subAction": "",
                    "specifiedBy": {
                        "specificationId": "01tg0000007nlvi",
                        "specificationName": "SMS Saliente",
                        "globalKey": "59faa206-2a59-c1f8-8fc8-450a7e161401"
                    },
                    "describedBy": [
                        {
                            "characteristic": "ATTR-2",
                            "code": "ATTR-2",
                            "value": ""
                        },
                        {
                            "characteristic": "ATTR-1",
                            "code": "ATTR-1",
                            "value": ""
                        },
                        {
                            "characteristic": "Attr4",
                            "code": "Attr4",
                            "value": ""
                        },
                        {
                            "characteristic": "Bandwidth",
                            "code": "BANDWIDTH",
                            "value": ""
                        },
                        {
                            "characteristic": "Billing Telephone Number",
                            "code": "ATTRIBUTE-5541",
                            "value": ""
                        },
                        {
                            "characteristic": "Booking ID",
                            "code": "ATTRIBUTE-5643",
                            "value": ""
                        },
                        {
                            "characteristic": "Booking ID",
                            "code": "ATTRIBUTE-5565",
                            "value": ""
                        },
                        {
                            "characteristic": "BAN",
                            "code": "ATTRIBUTE-5707",
                            "value": ""
                        },
                        {
                            "characteristic": "Billing Telephone Number",
                            "code": "ATTRIBUTE-5505",
                            "value": ""
                        },
                        {
                            "characteristic": "Billing Telephone Number",
                            "code": "ATTRIBUTE-5538",
                            "value": ""
                        },
                        {
                            "characteristic": "Billing Telephone Number",
                            "code": "ATTRIBUTE-5612",
                            "value": ""
                        },
                        {
                            "characteristic": "APN",
                            "code": "ATTRIBUTE-5386",
                            "value": ""
                        },
                        {
                            "characteristic": "Billing Telephone Number",
                            "code": "ATTRIBUTE-5529",
                            "value": ""
                        }
                    ],
                    "fieldValues": [],
                    "fields": {}
                },
                {
                    "orderItemId": "${OrderItemId9}",
                    "lineNumber": "0001.0001",
                    "serviceAccountId": "${AccountId}",
                    "serviceAccountName": "${AccountName}",
                    "billingAccountId": "${AccountId}",
                    "billingAccountName": "${AccountName}",
                    "assetReferenceId": "${AssetReferenceId9}",
                    "sourceAssetId": "",
                    "action": "Add",
                    "subAction": "",
                    "specifiedBy": {
                        "specificationId": "01tg0000007nlvm",
                        "specificationName": "Voz",
                        "globalKey": "2eb41b3c-738b-e486-9471-0b42557e8fbb"
                    },
                    "describedBy": [
                        {
                            "characteristic": "Contact Name",
                            "code": "ATTRIBUTE-5348",
                            "value": ""
                        },
                        {
                            "characteristic": "Contact Email Address",
                            "code": "ATTRIBUTE-5704",
                            "value": ""
                        },
                        {
                            "characteristic": "Contact Name",
                            "code": "ATTRIBUTE-5600",
                            "value": ""
                        },
                        {
                            "characteristic": "Contact Email",
                            "code": "ATTRIBUTE-5664",
                            "value": ""
                        },
                        {
                            "characteristic": "Contact Number",
                            "code": "ATTRIBUTE-5666",
                            "value": ""
                        },
                        {
                            "characteristic": "Contact Name",
                            "code": "ATTRIBUTE-5442",
                            "value": ""
                        },
                        {
                            "characteristic": "Contact Name",
                            "code": "ATTRIBUTE-5391",
                            "value": ""
                        },
                        {
                            "characteristic": "Contact Name",
                            "code": "ATTRIBUTE-5566",
                            "value": ""
                        },
                        {
                            "characteristic": "Contact Name",
                            "code": "ATTRIBUTE-5488",
                            "value": ""
                        },
                        {
                            "characteristic": "Contact Name",
                            "code": "ATTRIBUTE-5647",
                            "value": ""
                        },
                        {
                            "characteristic": "Contact Email",
                            "code": "ATTRIBUTE-5665",
                            "value": ""
                        },
                        {
                            "characteristic": "Contact Name",
                            "code": "ATTRIBUTE-5444",
                            "value": ""
                        },
                        {
                            "characteristic": "Contact Name",
                            "code": "ATTRIBUTE-5633",
                            "value": ""
                        }
                    ],
                    "fieldValues": [],
                    "fields": {}
                },
                {
                    "orderItemId": "${OrderItemId10}",
                    "lineNumber": "0001",
                    "serviceAccountId": "${AccountId}",
                    "serviceAccountName": "${AccountName}",
                    "billingAccountId": "${AccountId}",
                    "billingAccountName": "${AccountName}",
                    "assetReferenceId": "${AssetReferenceId10}",
                    "sourceAssetId": "",
                    "action": "Add",
                    "subAction": "",
                    "specifiedBy": {
                        "specificationId": "01tg0000007ZWOX",
                        "specificationName": "Plan Prepago Nacional-10",
                        "globalKey": "6efd648e-9071-9fa7-2fd1-1fcc1831b523"
                    },
                    "describedBy": [
                        {
                            "characteristic": "ATTR-1",
                            "code": "ATTR-1",
                            "value": ""
                        },
                        {
                            "characteristic": "ATTR-2",
                            "code": "ATTR-2",
                            "value": ""
                        },
                        {
                            "characteristic": "Attr4",
                            "code": "Attr4",
                            "value": ""
                        },
                        {
                            "characteristic": "MyPicklist1",
                            "code": "MyPicklist1",
                            "value": ""
                        }
                    ],
                    "fieldValues": [],
                    "fields": {}
                }
            ]
        }
    ]
}"""

          /** ***************************************************generating AWS Signature keys **********************************/
          val AwsAccessKey = "AKIA3S5D7HYYSFYALB4N"
          val AwsSecretKey = "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"

          val signature = RequestSigner.sign(
            uriPath = "/perfta105/orderManagement/processOrder",

            method = "POST",
            //body = Some("""{ "hello": "foo" }"""),
            body = Some(requestBuildBody),


            headers = Seq(("Host", List("316ajx90qe.execute-api.us-east-2.amazonaws.com"))),
            queryParameters = Seq.empty,
            credentials = new BasicAWSCredentials(AwsAccessKey, AwsSecretKey),
            region = "us-east-2",
            service = "execute-api")


          //AWSSignature(None,20190829T083314Z,AWS4-HMAC-SHA256 Credential=AKIA3S5D7HYYSFYALB4N/20190829/us-east-2/execute-api/aws4_request, SignedHeaders=host, Signature=1be17d03c3452cd4161956d3932cc9de26e8498c6d2140ec2504a934256bad31)
          val amzStamp = (signature.toString).substring(18, 34)
          val sign = (signature.toString).substring(35, 223)
          AmazonTimeDetails.append(amzStamp).toString
          SignatureDetails.append(sign).toString


          session
        })


        .exec(session => session.set("batchId", BatchId))
        .exec(session => session.set("orderId", OrderId))
        .exec(session => session.set("accountId", AccountId))
        .exec(session => session.set("accountName", AccountName))
        .exec(session => session.set("OrderNumber", OrderNumberS))
        .exec(session => session.set("orderItemId1", OrderItemId1))
        .exec(session => session.set("assetReferenceId1", AssetReferenceId1))
        .exec(session => session.set("orderItemId2", OrderItemId2))
        .exec(session => session.set("assetReferenceId2", AssetReferenceId2))
        .exec(session => session.set("orderItemId3", OrderItemId3))
        .exec(session => session.set("assetReferenceId3", AssetReferenceId3))
        .exec(session => session.set("orderItemId4", OrderItemId4))
        .exec(session => session.set("assetReferenceId4", AssetReferenceId4))
        .exec(session => session.set("orderItemId5", OrderItemId5))
        .exec(session => session.set("assetReferenceId5", AssetReferenceId5))
        .exec(session => session.set("orderItemId6", OrderItemId6))
        .exec(session => session.set("assetReferenceId6", AssetReferenceId6))
        .exec(session => session.set("orderItemId7", OrderItemId7))
        .exec(session => session.set("assetReferenceId7", AssetReferenceId7))
        .exec(session => session.set("orderItemId8", OrderItemId8))
        .exec(session => session.set("assetReferenceId8", AssetReferenceId8))
        .exec(session => session.set("orderItemId9", OrderItemId9))
        .exec(session => session.set("assetReferenceId9", AssetReferenceId9))
        .exec(session => session.set("orderItemId10", OrderItemId10))
        .exec(session => session.set("assetReferenceId10", AssetReferenceId10))
        .exec(session => session.set("signatureDetails", SignatureDetails))
        .exec(session => session.set("amazonTimeDetails", AmazonTimeDetails))


        .exec(session => {
          BatchId = new StringBuilder()
          OrderId = new StringBuilder()
          AccountId = new StringBuilder()
          AccountName = new StringBuilder()
          OrderNumberS = new StringBuilder()
          OrderItemId1 = new StringBuilder()
          OrderItemId2 = new StringBuilder()
          OrderItemId3 = new StringBuilder()
          OrderItemId4 = new StringBuilder()
          OrderItemId5 = new StringBuilder()
          OrderItemId6 = new StringBuilder()
          OrderItemId7 = new StringBuilder()
          OrderItemId8 = new StringBuilder()
          OrderItemId9 = new StringBuilder()
          OrderItemId10 = new StringBuilder()
          AssetReferenceId1 = new StringBuilder()
          AssetReferenceId2 = new StringBuilder()
          AssetReferenceId3 = new StringBuilder()
          AssetReferenceId4 = new StringBuilder()
          AssetReferenceId5 = new StringBuilder()
          AssetReferenceId6 = new StringBuilder()
          AssetReferenceId7 = new StringBuilder()
          AssetReferenceId8 = new StringBuilder()
          AssetReferenceId9 = new StringBuilder()
          AssetReferenceId10 = new StringBuilder()
          SignatureDetails = new StringBuilder()
          AmazonTimeDetails = new StringBuilder()

          session
        })

        /** ***************************************************Submitting orders to incoming pods **********************************/
        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        .exec(http("Create_orchestration_plan_id")
          .post(uri01 + "/perfta105/orderManagement/processOrder")
          .headers(headers_01)
          .check(status.is(200), regex("""orchestrationPlanId\":\"(.+?)\"\,"""").saveAs("orchestrationPlanId"))
          .body(ElFileBody("./src/test/resources/bodies/XOM_NewOrder_AWS_Test/neworder_payload.json")).asJson)

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        .exec { session =>
          val s1 = new File(System.getProperty("user.dir") + "/orchestrationPlanId.csv")
          if (s1.exists()) {
            val writer = new PrintWriter(new FileOutputStream(new File(System.getProperty("user.dir") + "/orchestrationPlanId.csv"), true))
            writer.write(session("orchestrationPlanId").as[String].trim)
            writer.write("\n")
            writer.close()
          }
          else {
            val writer = new PrintWriter(new FileOutputStream(new File(System.getProperty("user.dir") + "/orchestrationPlanId.csv"), true))
            writer.println("ResponseID")
            writer.write(session("orchestrationPlanId").as[String].trim)
            writer.write("\n")
            writer.close()
          }
          session
        }
    }
}
