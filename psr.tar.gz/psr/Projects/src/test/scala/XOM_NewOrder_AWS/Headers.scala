package XOM_NewOrder_AWS

object Headers  {

	
val headers_01 = Map(
		"Host" -> "316ajx90qe.execute-api.us-east-2.amazonaws.com",
		"Content-Type" -> "application/json",
		//"test" -> "${signatureDetails}",
		"X-Amz-Date" -> "${amazonTimeDetails}",
		"Content-Length" -> "43693",
		//"X-Amz-Date" -> "20190828T191952Z",
		//"Authorization" -> "AWS4-HMAC-SHA256 Credential=AKIA3S5D7HYYSFYALB4N/20190828/us-east-2/execute-api/aws4_request, SignedHeaders=host, Signature=401c544cfff08bb8b27e645740c7d3f1bd4f4352bfa969cf0ad344856e43dcb9"
	"Authorization" -> "${signatureDetails}")
		
}