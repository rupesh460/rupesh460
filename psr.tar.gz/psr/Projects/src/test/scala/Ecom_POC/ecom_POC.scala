package Ecom_POC

import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.core.structure.ChainBuilder
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._
import io.gatling.jsonpath._
import Headers._
import scala.collection._
import java.time.format.DateTimeFormatter
import java.time.LocalDateTime


 object EcomPOC {

    val uri01 = Configuration.uri01
    val randomNumber = new scala.util.Random
    var ProductsList = Vector[String]()
    var randomProductEntry = new StringBuilder()
	  val userFeeder = csv("./src/test/resources/data/ecom/Ecom_Users.csv").random
    val accountFeeder = csv("./src/test/resources/data/ecom/Ecom_AccountIds.csv").circular

    val scn = scenario("Ecom_POC")
  

   .repeat(30)
   { 
    exec(http("RESTGetOAuthToken")
    .get("https://protected-meadow-59771.herokuapp.com/token")
    .header("Content-Type", "application/json; charset=utf-8")
    .check(regex("""\"access_token\":\"(.+)\"""").find.exists.saveAs("""TokenID"""))
    .check(status.is(200)))

    .exec(http("APGee_Create_Order")
    .get(uri01 +"/create_order/")
    .header("Content-Type", "application/x-www-form-urlencoded")
    .check(regex("\"orderId\":\"(.+)\"").find.exists.saveAs("OrderID"))
    .check(status.is(200)))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds) 

     
    .exec(http("APGee_Getcarts")
    .get(uri01 +"/get_carts/?access_token=${TokenID}&orderId=${OrderID}")
    .header("Content-Type", "application/x-www-form-urlencoded")
    .check(status.is(200)))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds) 

    .exec(http("APGee_GetCartsItems")
    .get(uri01 +"/get_carts_items/?access_token=${TokenID}&orderId=${OrderID}")
    .header("Content-Type", "application/x-www-form-urlencoded")
    .check(status.is(200)))


    .exec(http("APGee_Cache_Filter")
    .get(uri01 +"/product_cache_filter/?access_token=${TokenID}&attributes=FUEL_TYPE:undefined&cartId=${OrderID}")
    .header("Content-Type", "application/x-www-form-urlencoded")
    .check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfProductItemIDs"))
    .check(status.is(200)))


     .exec( session => {
                  ProductsList = session("ListOfProductItemIDs").as[Vector[String]]
                  session
      })

      .exec(session => session.set("ProductID",""))
      .exec( session => {
              val max = ProductsList.length - 1
              val random_index = randomNumber.nextInt(max+1)
              randomProductEntry.append(ProductsList(random_index))
              session
      })

      .exec(session => session.set("ProductID",randomProductEntry))
             
      .exec( session => {
            randomProductEntry = new StringBuilder()
            session
      })
                    
          
    .exec(http("APGee_Post_Cart_Items")
    .get(uri01 +"/post_carts_items?access_token=${TokenID}&itemId=${ProductID}&orderId=${OrderID}&postTransformBundle=&preTransformBundle=")
    .header("Content-Type", "application/x-www-form-urlencoded")
    .check(status.is(200)))

     
    .exec(http("APGee_Get_Carts")
    .get(uri01 +"/get_carts/?access_token=${TokenID}&itemId=${ProductID}&orderId=${OrderID}&postTransformBundle=&preTransformBundle=")
    .header("Content-Type", "application/x-www-form-urlencoded")
    
    .check(status.is(200)))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds) 

    .feed(userFeeder)
    .exec(http("login_SF_Org")
    .get("https://protected-meadow-59771.herokuapp.com/login_sf/?password=${password}&username=${username}")
    .header("Content-Type", "application/x-www-form-urlencoded")
    .check(regex("""user_access_token":"(.+?)"}""").find.exists.saveAs("UseraccessTokenID"))
    .check(status.is(200)))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .feed(accountFeeder)
    .exec(http("Create_sf_order") 
    .get("https://protected-meadow-59771.herokuapp.com/create_sf_order/?access_token=${UseraccessTokenID}&account_id=${AccountId}")
    .header("Content-Type", "application/x-www-form-urlencoded")
    .check(regex("\"user_order_id\":\"(.+)\"").find.exists.saveAs("UserOrderID"))
    .check(status.is(200)))


    .pause(Configuration.MiniMinWaitMs milliseconds, Configuration.MiniMaxWaitMs milliseconds) 

    .exec(http("APGee_Login_Post_Cart_Items")
    .get("https://protected-meadow-59771.herokuapp.com/post_carts_items?access_token=${UseraccessTokenID}&itemId=${ProductID}&orderId=${UserOrderID}&postTransformBundle=&preTransformBundle=")
    .header("Content-Type", "application/x-www-form-urlencoded")
    .check(status.is(200)))
    
    .exec(http("APGee_Login_Cache_Filter_")
    .get("https://protected-meadow-59771.herokuapp.com/product_cache_filter/?access_token=${UseraccessTokenID}&attributes=FUEL_TYPE:undefined&cartId=${UserOrderID}")
    .header("Content-Type", "application/x-www-form-urlencoded")
    .check(status.is(200)))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds) 
   
    .exec(http("APGee_Submit_Order")
    .get("https://protected-meadow-59771.herokuapp.com/checkout_order/?access_token=${UseraccessTokenID}&orderId=${UserOrderID}")
    .check(status.is(200)))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds) 
 
 }

}
