package Ecom_POC

object Configuration {
	
	val BaseUrl = "https://c.cs17.visual.force.com"
	val uri01 = "https://protected-meadow-59771.herokuapp.com"
	
	val MinWaitMs = 1500
	val MaxWaitMs = 3000

	val MiniMinWaitMs = 1500
	val MiniMaxWaitMs = 3000

}