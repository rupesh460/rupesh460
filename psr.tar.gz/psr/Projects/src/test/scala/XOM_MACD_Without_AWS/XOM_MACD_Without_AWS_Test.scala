  package XOM_MACD_Without_AWS


  import scala.concurrent.duration._
  import io.gatling.core.Predef._
  import io.gatling.core.structure.ChainBuilder
  import io.gatling.http.Predef._
  import io.gatling.jdbc.Predef._
  import io.gatling.jsonpath._
  import Headers._
  import scala.collection._
  import java.time.format.DateTimeFormatter
  import java.time.LocalDateTime
  import java.time.LocalDate

  import io.gatling.core.feeder._
import java.util.Base64
import java.nio.charset.StandardCharsets
import scala.util.matching.Regex


  object XOM_MACD_Without_AWS_Test {

    val uri01 = Configuration.Uri01
    val uri05 = Configuration.Uri05
    val uri10 = Configuration.Uri10

    //var session_ids = Vector[String]()
    var xomSubmitOrder = new StringBuilder()
    var modifiedItemJson = new StringBuilder()
    val timestamp = LocalDate.now()
    var final_formatted_date1 = new StringBuilder()
    var final_formatted_date2 = new StringBuilder()
    var final_formatted_date3 = new StringBuilder()
    var assetlist_update = new StringBuilder()
    var assetlist_delete = new StringBuilder()
    var assetlist_add = new StringBuilder()
    /*val randomNumber = new scala.util.Random
    var offset = new StringBuilder()
    var OFFSET = new StringBuilder()
    var DATE_add  = new StringBuilder()
    var DATE_update  = new StringBuilder()
    var DATE_delete  = new StringBuilder()
    var assetlist_id_add = new StringBuilder()
    var assetlist_id_delete = new StringBuilder()
    var assetlist_id_update = new StringBuilder()*/


    val userFeeder = csv("./src/test/resources/data/xom_macd_without_aws/XOM_Users.csv").random
    val productFeeder = csv("./src/test/resources/data/xom_macd_without_aws/XOM_MACD_Products.csv").random
    val accountFeeder = csv("./src/test/resources/data/xom_macd_without_aws/XOM_Accounts.csv").random
    val assetFeeder = csv("./src/test/resources/data/xom_macd_without_aws/XOM_Assets_add_50k.csv").circular
    val assetFeeder_update = csv("./src/test/resources/data/xom_macd_without_aws/XOM_Assets_update_50k.csv").circular
    val assetFeeder_delete = csv("./src/test/resources/data/xom_macd_without_aws/XOM_Assets_delete_50k.csv").circular
    val productFeederdelete = csv("./src/test/resources/data/xom_macd_without_aws/XOM_Products.csv").random
    val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
  val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
  val password_v = (passwordByEnv.get("perf3").toString)
  val password_encoded = password_v.substring(12,(password_v.length - 2 ))
  val credentials = new String(Base64.getDecoder.decode(password_encoded))


    val Normalflow = scenario("XOM_MACD_Without_AWS_Normalflow")
    //.exec(session => session.set("PriceListId",Configuration.PriceListId))
    .exec(session => session.set("password",credentials))

  
    .feed(userFeeder)        
    .exec(http("XOM_Login")
      .post(uri01 + "/")
      .headers(headers_00)
      .formParam("un", "${username}")
      .formParam("width", "1440")
      .formParam("height", "900")
      .formParam("hasRememberUn", "true")
      .formParam("startURL", "")
      .formParam("loginURL", "")
      .formParam("loginType", "")
      .formParam("useSecure", "true")
      .formParam("local", "")
      .formParam("lt", "standard")
      .formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
      .formParam("locale", "")
      .formParam("oauth_token", "")
      .formParam("oauth_callback", "")
      .formParam("login", "")
      .formParam("serverid", "")
      .formParam("QCQQ", "M1D2l15jFvl")
      .formParam("display", "page")
      .formParam("username", "${username}")
      .formParam("pw", "${password}")
      .formParam("Login", ""))

    //.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("RESTGetOAuthToken")
      .post("https://test.salesforce.com/services/oauth2/token")
      .header("Content-Type", "application/x-www-form-urlencoded")
      .formParam("password", "${password}")
      .formParam("username", "${username}")
      .formParam("client_secret", "7119599995527965426")
      .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
      .formParam("grant_type", "password")
      .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
      .check(status.is(200)))

    //.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .repeat(800)
    {

      feed(assetFeeder)
      /*.exec(http("addToCart_Getassetid")
          .get(uri10 +"/services/data/v39.0/query/?q=SELECT+AccountId,Id,Name,RootItemId__c+FROM+Asset+WHERE+Name+=+'Plan+Prepago+Nacional'+AND+Action__c+!=+'Disconnect'+AND+CreatedDate+>=+2018-12-19T08:52:36.000Z+LIMIT+1")
          .headers(header_1)
          .check(regex("""<Id>(.+?)<\/Id>""").find.exists.saveAs("AssetId"))      
          .check(regex("""<RootItemId__c>(.+?)<\/RootItemId__c>""").find.exists.saveAs("Rootitemid")))*/
          .exec(http("addToCart_Click on Change Order")
            .get(uri05 +"/apex/MACDFdo?id=${AssetId_add}")
            .headers(headers_145)
            .check(regex("""GenericInvoke2","len":4,"ns":"","ver":32.0,"csrf":"(.+?)"}""").find.exists.saveAs("csrfToken"))
            .check(regex("""vid":"(.+?)","xhr""").find.exists.saveAs("vid")))

          .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


          /*.exec(http("addToCart_RequestDateSize")
            .get(uri10 +"/services/data/v43.0/query/?q=SELECT+RequestDate__c+FROM+OrderItem+WHERE+AssetId__c+=+'${AssetId_add}'+Order+By+RequestDate__c+DESC+NULLS+LAST+Limit+1")
            .check(regex("""<totalSize>(.*?)<.totalSize>""").find.exists.saveAs("date_size_add"))
            .headers(header_1))

          //.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


          .doIfEqualsOrElse("${date_size_add}", "0") 
          {
            exec(session => session.set("DATE_add",""))
            .exec(session => session.set("DATE_add",timestamp))
          } 
          {
            // executed if the session value stored in "actualValue" is not equal to "expectedValue"
            exec(session => session.set("RequestDatesList1",""))
            .exec(http("addToCart_GetlatestRequestDate")
              .get(uri10 +"/services/data/v43.0/query/?q=SELECT+RequestDate__c+FROM+OrderItem+WHERE+AssetId__c+=+'${AssetId_add}'+Order+By+RequestDate__c+DESC+NULLS+LAST+Limit+1")
              .check(regex("""<RequestDate__c>(.*?)<.RequestDate__c>""").find.exists.saveAs("RequestDatesList1"))
              .headers(header_1))
            //.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

            .exec( session => {
              val requestDateList = session("RequestDatesList1").as[String]
              val maxdate = requestDateList
              val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
              val dateforcurrentrun = LocalDate.parse(maxdate,formatter).plusDays(1)
              final_formatted_date1.append(dateforcurrentrun)
              session
            })

            .exec(session => session.set("DATE_add",""))
            .exec( session => session.set("DATE_add", final_formatted_date1 ) )
            .exec( session => {
              final_formatted_date1 = new StringBuilder()

              session
            })
          } */


          /*.exec(http("addToCart_getrootitemid")
            .get(uri10 +"/services/data/v43.0/query/?q=SELECT+RootItemId__c+FROM+Asset+WHERE+Id+=+'${AssetId_add}'")
            .check(regex("""<RootItemId__c>(.+?)<\/RootItemId__c>""").find.exists.saveAs("Rootitemid_add"))
            .headers(header_1))

          .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)*/

          /*.exec(http("addToCart_getassetidlist")
            .get(uri10 +"/services/data/v39.0/query/?q=Select+Id+from+Asset+where+RootItemId__c+=+'${Rootitemid_add}'+and+Action__c+!=+'Disconnect'")
            .check(regex("""<Id>(.+?)<\/Id>""").findAll.saveAs("Assetlistids_add"))
            .headers(header_1))

          .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


         .exec( session => session.set("assetlist_id_add", "") )
         .exec { session =>  
            val Assetlistids_add = session("Assetlistids_add").as[List[String]]
            assetlist_add.append(Assetlistids_add.mkString("""\",\""""))
            //print(assetlist_add)

            session
          }
          
          .exec( session => session.set("assetlist_id_add", assetlist_add) )
          .exec( session => {
           // assetlist_add = new StringBuilder()
           assetlist_add = new StringBuilder()
           session
         })*/

          .exec(http("addToCart_Create a new MACD order")
            .post(uri05 +"/apexremote")
            .headers(headers_01)
            .check(regex("""fdoId.":."(.+?).",."error""").find.exists.saveAs("CartId_ForAdding"))
            .body(ElFileBody("./src/test/resources/bodies/xom_macd/createmacdorder_add.txt")))

          .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


          .exec(http("addToCart_OrderlineitemCount")
            .get(uri10 +"/services/data/v39.0/query/?q=SELECT+count()+FROM+OrderItem+WHERE+OrderId+=+'${CartId_ForAdding}'")
            .check(regex("""<totalSize>20<\/totalSize> || <totalSize>21<\/totalSize>""").optional.saveAs("lineitemsizesize"))
            .headers(header_1))

          .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

          .exec(http("addToCart_Order_Detail")
            .get(uri10 + "/${CartId_ForAdding}")
            .headers(headers_05) 
            .check(regex("""sforce.connection.sessionId = '(.+)';.}[a-zA-Z0-9\s{.('_,:]*name:.'XOMSubmitOrder'}""").find.exists.saveAs("""sfdc_session_id""")))

          .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds) 

          /* ********** SetPriceListForCart *********** */
          .exec(http("addToCart_Set_PriceList")
            .put(uri10 +"/services/apexrest/v2/cpq/carts/${CartId_ForAdding}/")
            .headers(header_1)
            .body(StringBody("""{
              "inputFields": 
              [
              {
                "PriceListId__c": "a2Pg0000001UvvuEAC"
              }
              ],
              "cartId": "${CartId_ForAdding}",
              "methodName": "updateCarts"
            }""")).asJson)

          .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


          .feed(productFeeder)
          .exec(http("addToCart_Add items to cart") 
            .post(uri10 +"/services/apexrest/v2/cpq/carts/${CartId_ForAdding}/items")
            .headers(header_1)
            .check(regex("""messages":\[\{"code":"150","severity":"INFO","message":"Successfully(......)""").find.exists.saveAs("AddStatus"))
            .body( StringBody("""{"methodName":"postCartsItems","items":[{"itemId":"${ProductId}"}],"cartId":"${CartId_ForAdding}","price":true,"validate":true,"includeAttachment":false,"pagesize":10,"lastRecordId":null,"hierarchy":-1,"query":"plan"}""")).asJson)

          .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)  

          .exec(http("Updateflow_OrderUpdate")
          .put(uri10 + "/services/apexrest/Orders/")
          .headers(header_1)
          .check(regex("""status":"Update succeeded""").find.exists)
          .body( StringBody("""[{"orderId":"${CartId_ForDelete}","state":"Activated"}]""")).asJson)
          

          .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
        }

        val Deleteflow = scenario("XOM_MACD_Without_AWS_Deleteflow")
        .exec(session => session.set("password",credentials))

        //.exec(session => session.set("PriceListId",Configuration.PriceListId))

        .feed(userFeeder)        
        .exec(http("XOM_Login")
          .post(uri01 + "/")
          .headers(headers_00)
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          .formParam("startURL", "")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          .formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "M1D2l15jFvl")
          .formParam("display", "page")
          .formParam("username", "${username}")
          .formParam("pw", "${password}")
          .formParam("Login", ""))

        //.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)



        .exec(http("RESTGetOAuthToken")
          .post("https://test.salesforce.com/services/oauth2/token")
          .header("Content-Type", "application/x-www-form-urlencoded")
          .formParam("password", "${password}")
          .formParam("username", "${username}")
          .formParam("client_secret", "7119599995527965426")
          .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
          .formParam("grant_type", "password")
          .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
          .check(status.is(200)))
        //.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


        .repeat(800)
        {
          feed(assetFeeder_delete)
          /*exec(session => session.set("OFFSET",""))
          .exec( session => {
            val random_index = randomNumber.nextInt(999)
            offset.append(random_index)
            session
          })

          .exec(session => session.set("OFFSET",offset))

          .exec( session => {
            offset = new StringBuilder()
            session
          })



          .exec(http("Deleteflow_Getassetid")
            .get(uri10 +"/services/data/v39.0/query/?q=SELECT+AccountId,Id,Name,RootItemId__c+FROM+Asset+WHERE+Name+=+'Plan+Prepago+Nacional'+AND+Action__c+=+'Add'+AND+CreatedDate+>=+2019-01-18T09:25:25.000Z+AND+CreatedDate+<=+2019-01-18T10:32:03.000Z+LIMIT+1+OFFSET+${OFFSET}")
            .headers(header_1)
            .check(regex("""<Id>(.+?)<\/Id>""").find.exists.saveAs("AssetId_delete"))
            .check(regex("""<AccountId>(.+?)<\/AccountId>""").find.exists.saveAs("AccountId"))    
            .check(regex("""<RootItemId__c>(.+?)<\/RootItemId__c>""").find.exists.saveAs("Rootitemid_delete")))
          .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)*/


          .exec(http("Deleteflow_Click on Change Order")
            .get(uri05 +"/apex/MACDFdo?id=${AssetId_delete}")
            .headers(headers_145)
            .check(regex("""GenericInvoke2","len":4,"ns":"","ver":32.0,"csrf":"(.+?)"}""").find.exists.saveAs("csrfToken"))
            .check(regex("""vid":"(.+?)","xhr""").find.exists.saveAs("vid")))
          .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


          /*.exec(http("Deleteflow_RequestDateSize")
            .get(uri10 +"/services/data/v43.0/query/?q=SELECT+RequestDate__c+FROM+OrderItem+WHERE+AssetId__c+=+'${AssetId_delete}'+Order+By+RequestDate__c+DESC+NULLS+LAST+Limit+1")
            .check(regex("""<totalSize>(.*?)<.totalSize>""").find.exists.saveAs("date_size_delete"))
            .headers(header_1))

          //.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)




          .doIfEqualsOrElse("${date_size_delete}", "0") 
          {

            exec(session => session.set("DATE_delete",""))
            .exec(session => session.set("DATE_delete",timestamp))
          } 
          {
            // executed if the session value stored in "actualValue" is not equal to "expectedValue"
            exec(session => session.set("RequestDatesList2",""))
            .exec(http("Deleteflow_GetlatestRequestDate")
              .get(uri10 +"/services/data/v43.0/query/?q=SELECT+RequestDate__c+FROM+OrderItem+WHERE+AssetId__c+=+'${AssetId_delete}'+Order+By+RequestDate__c+DESC+NULLS+LAST+Limit+1")
              .check(regex("""<RequestDate__c>(.*?)<.RequestDate__c>""").find.exists.saveAs("RequestDatesList2"))
              .headers(header_1))

            //.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

            .exec( session => {
              val requestDateList = session("RequestDatesList2").as[String]
              val maxdate = requestDateList
              val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
              val dateforcurrentrun = LocalDate.parse(maxdate,formatter).plusDays(1)
              final_formatted_date2.append(dateforcurrentrun)
              session
            }) 

            .exec(session => session.set("DATE_delete",""))
            .exec( session => session.set("DATE_delete", final_formatted_date2 ) )
            .exec( session => {
              final_formatted_date2 = new StringBuilder()
              session
            })
          }

*/
          /*.exec(http("Deleteflow_getrootitemid")
            .get(uri10 +"/services/data/v43.0/query/?q=SELECT+RootItemId__c+FROM+Asset+WHERE+Id+=+'${AssetId_delete}'")
            .check(regex("""<RootItemId__c>(.+?)<\/RootItemId__c>""").find.exists.saveAs("Rootitemid_delete"))
            .headers(header_1))
          .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)*/

          /*.exec(session => session.set("Assetlistids_delete",""))
          .exec(http("Deleteflow_getassetidlist")
            .get(uri10 +"/services/data/v39.0/query/?q=Select+Id+from+Asset+where+RootItemId__c+=+'${Rootitemid_delete}'+and+Action__c+!=+'Disconnect'")
            .check(regex("""<Id>(.+?)<\/Id>""").findAll.saveAs("Assetlistids_delete"))
            .headers(header_1))
          //.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


          .exec( session => session.set("assetlist_id_delete", "") )
          .exec { session =>  
            val Assetlistids_delete = session("Assetlistids_delete").as[List[String]]
            assetlist_delete.append(Assetlistids_delete.mkString("""\",\""""))
            //print(assetlist_delete)
      session
    }

    
    .exec( session => session.set("assetlist_id_delete", assetlist_delete) )
    .exec( session => {
      assetlist_delete = new StringBuilder()
      session
    })*/

    .exec(http("Deleteflow_Create a new MACD order")
      .post(uri05 +"/apexremote")
      .headers(headers_01)
      .check(regex("""fdoId.":."(.+?).",."error""").find.exists.saveAs("CartId_ForDelete"))
      .body(ElFileBody("./src/test/resources/bodies/xom_macd/createmacdorder_delete.txt")))
    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("Deleteflow_OrderlineitemCount")
      .get(uri10 +"/services/data/v39.0/query/?q=SELECT+count()+FROM+OrderItem+WHERE+OrderId+=+'${CartId_ForDelete}'")
      .check(regex("""<totalSize>20<\/totalSize>""").find.exists)
      .headers(header_1))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("Deleteflow_Get new csrf token")
      .get(uri05 +"/apex/HybridCPQ?id=${CartId_ForDelete}")
      .headers(headers_01)
      .check(regex("""vid":"(.+?)...xhr""").find.exists.saveAs("vid_del"))
      .check(regex("""len":4."ns":""."ver":41.0."csrf":"(.+?)"["$&+,:;=?@#|'<>.^*()%!-}{a-z]*doNamedCredentialCallout""").find.exists.saveAs("csrfToken_del")))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("Deleteflow_Get Parent ID")
      .post(uri05 +"/apexremote")
      .headers(headers_022)
      .check(regex("""parentId.":."(.+?).".."itemId""").find.exists.saveAs("parentid"))
      .body(ElFileBody("./src/test/resources/bodies/xom_macd/XOM_GetParentID.txt")))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("Delete Product from asset")
      .post(uri05 +"/apexremote")
      .headers(headers_022)
      .check(regex(""""message.":."Successfully.deleted""").find.exists.saveAs("deletedproduct"))
      .body(ElFileBody("./src/test/resources/bodies/xom_macd/XOM_DeleteMacD_Order.txt")))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


    .exec(http("Deleteflow_Order_Detail")
      .get(uri10 + "/${CartId_ForDelete}")
      .headers(headers_05) 
      .check(regex("""sforce.connection.sessionId = '(.+)';.}[a-zA-Z0-9\s{.('_,:]*name:.'XOMSubmitOrder'}""").find.exists.saveAs("""sfdc_session_id""")))


    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)  

    .feed(productFeederdelete)
    .exec(http("Deleteflow_Add items to cart") 
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${CartId_ForDelete}/items")
      .headers(header_1)
      .check(regex("""messages":\[\{"code":"150","severity":"INFO","message":"Successfully(......)""").find.exists.saveAs("AddStatus"))
      .body( StringBody("""{"methodName":"postCartsItems","items":[{"itemId":"${ProductId}"}],"cartId":"${CartId_ForDelete}","price":true,"validate":true,"includeAttachment":false,"pagesize":10,"lastRecordId":null,"hierarchy":-1,"query":"plan"}""")).asJson)

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)  

    
    .exec(http("Updateflow_OrderUpdate")
          .put(uri10 + "/services/apexrest/Orders/")
          .headers(header_1)
          .check(regex("""status":"Update succeeded""").find.exists)
          .body( StringBody("""[{"orderId":"${CartId_ForDelete}","state":"Activated"}]""")).asJson)  

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds) 

  }

  val Updateflow = scenario("XOM_MACD_Without_AWS_Updateflow")
  .exec(session => session.set("password",credentials))

  //.exec(session => session.set("PriceListId",Configuration.PriceListId))

  .feed(userFeeder)        
  .exec(http("XOM_Login")
    .post(uri01 + "/")
    .headers(headers_00)
    .formParam("un", "${username}")
    .formParam("width", "1440")
    .formParam("height", "900")
    .formParam("hasRememberUn", "true")
    .formParam("startURL", "")
    .formParam("loginURL", "")
    .formParam("loginType", "")
    .formParam("useSecure", "true")
    .formParam("local", "")
    .formParam("lt", "standard")
    .formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
    .formParam("locale", "")
    .formParam("oauth_token", "")
    .formParam("oauth_callback", "")
    .formParam("login", "")
    .formParam("serverid", "")
    .formParam("QCQQ", "M1D2l15jFvl")
    .formParam("display", "page")
    .formParam("username", "${username}")
    .formParam("pw", "${password}")
    .formParam("Login", ""))

  //.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)



  .exec(http("RESTGetOAuthToken")
    .post("https://test.salesforce.com/services/oauth2/token")
    .header("Content-Type", "application/x-www-form-urlencoded")
    .formParam("password", "${password}")
    .formParam("username", "${username}")
    .formParam("client_secret", "7119599995527965426")
    .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
    .formParam("grant_type", "password")
    .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
    .check(status.is(200)))

  //.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


  .repeat(800)
  {
    feed(assetFeeder_update)
    /*.exec(http("Updateflow_Getassetid")
      .get(uri10 +"/services/data/v39.0/query/?q=SELECT+AccountId,Id,Name,RootItemId__c+FROM+Asset+WHERE+Name+=+'Plan+Prepago+Nacional'+AND+Action__c+!=+'Disconnect'+AND+CreatedDate+>=+2018-12-19T08:52:36.000Z+LIMIT+1")
      .headers(header_1)
      .check(regex("""<Id>(.+?)<\/Id>""").find.exists.saveAs("AssetId_update")))    
    //.check(regex("""<RootItemId__c>(.+?)<\/RootItemId__c>""").find.exists.saveAs("Rootitemid")))
    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)*/

    .exec(http("Updateflow_Click on Change Order")
      .get(uri05 +"/apex/MACDFdo?id=${AssetId_update}")
      .headers(headers_145)
      .check(regex("""GenericInvoke2","len":4,"ns":"","ver":32.0,"csrf":"(.+?)"}""").find.exists.saveAs("csrfToken"))
      .check(regex("""vid":"(.+?)","xhr""").find.exists.saveAs("vid")))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


    /*.exec(http("Updateflow_RequestDateSize")
      .get(uri10 +"/services/data/v43.0/query/?q=SELECT+RequestDate__c+FROM+OrderItem+WHERE+AssetId__c+=+'${AssetId_update}'+Order+By+RequestDate__c+DESC+NULLS+LAST+Limit+1")
      .check(regex("""<totalSize>(.*?)<.totalSize>""").find.exists.saveAs("date_size_update"))
      .headers(header_1))
    //.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)



    .doIfEqualsOrElse("${date_size_update}", "0") 
    {

      exec(session => session.set("DATE_update",""))
      .exec(session => session.set("DATE_update",timestamp))
    } 
    {
      // executed if the session value stored in "actualValue" is not equal to "expectedValue"
      exec(session => session.set("RequestDatesList3",""))
      .exec(http("Updateflow_GetlatestRequestDate")
        .get(uri10 +"/services/data/v43.0/query/?q=SELECT+RequestDate__c+FROM+OrderItem+WHERE+AssetId__c+=+'${AssetId_update}'+Order+By+RequestDate__c+DESC+NULLS+LAST+Limit+1")
        .check(regex("""<RequestDate__c>(.*?)<.RequestDate__c>""").find.exists.saveAs("RequestDatesList3"))
        .headers(header_1))
      //.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec( session => {
        val requestDateList = session("RequestDatesList3").as[String]
        val maxdate = requestDateList
        val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
        val dateforcurrentrun = LocalDate.parse(maxdate,formatter).plusDays(1)
        final_formatted_date3.append(dateforcurrentrun)
        session
      }) 

      .exec(session => session.set("DATE_update",""))
      .exec( session => session.set("DATE_update", final_formatted_date3 ) )
      .exec( session => {
        final_formatted_date3 = new StringBuilder()
        session
      })
    }
    */

    /*.exec(http("Updateflow_getrootitemid")
      .get(uri10 +"/services/data/v43.0/query/?q=SELECT+RootItemId__c+FROM+Asset+WHERE+Id+=+'${AssetId_update}'")
      .check(regex("""<RootItemId__c>(.+?)<\/RootItemId__c>""").find.exists.saveAs("Rootitemid_update"))
      .headers(header_1))
    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)*/

    /*.exec(session => session.set("Assetlistids_update",""))
    .exec(http("Updateflow_getassetidlist")
      .get(uri10 +"/services/data/v39.0/query/?q=Select+Id+from+Asset+where+RootItemId__c+=+'${Rootitemid_update}'+and+Action__c+!=+'Disconnect'")
      .check(regex("""<Id>(.+?)<\/Id>""").findAll.saveAs("Assetlistids_update"))
      .headers(header_1))
    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


    .exec( session => session.set("assetlist_id_update", "") )
    .exec { session =>  
      val Assetlistids_update = session("Assetlistids_update").as[List[String]]
      assetlist_update.append(Assetlistids_update.mkString("""\",\""""))

        /*var Assetlistidarray_update = Assetlistids_update.toArray
        for ( i <- 0 to (Assetlistidarray_update.length - 2)) {
         assetlist_update += ("""\""""+Assetlistidarray_update(i)+"""\",""")
         
      }     
      assetlist_update = assetlist_update + ("""\""""+Assetlistidarray_update(Assetlistidarray_update.length - 1)+"""\"""")*/
      //print(assetlist_update)
      session
    }

    
    .exec( session => session.set("assetlist_id_update", assetlist_update) )
    .exec( session => {
      assetlist_update = new StringBuilder()
      session
    })*/

    .exec(http("Updateflow_Create a new MACD order")
      .post(uri05 +"/apexremote")
      .headers(headers_01)
      .check(regex("""fdoId.":."(.+?).",."error""").find.exists.saveAs("CartId_ForUpdate"))
      .body(ElFileBody("./src/test/resources/bodies/xom_macd/createmacdorder_update.txt")))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
    .exec( session => session.set("assetlist_id_update", "") )

    .exec(http("Updateflow_OrderlineitemCount")
      .get(uri10 +"/services/data/v39.0/query/?q=SELECT+count()+FROM+OrderItem+WHERE+OrderId+=+'${CartId_ForUpdate}'")
      .check(regex("""<totalSize>20<\/totalSize>""").find.exists)
      .headers(header_1))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("Updateflow_Get new csrf token")
      .get(uri05 +"/apex/HybridCPQ?id=${CartId_ForUpdate}")
      .headers(headers_01)
      .check(regex("""vid":"(.+?)...xhr""").find.exists.saveAs("vid_del"))
      .check(regex("""len":4."ns":""."ver":41.0."csrf":"(.+?)"["$&+,:;=?@#|'<>.^*()%!-}{a-z]*doNamedCredentialCallout""").find.exists.saveAs("csrfToken_del")))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    /*********** Get Cart LineItems***********/
    .exec(http("Updateflow_GetCartLineItems")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${CartId_ForUpdate}/items?pagesize=10&price=false&validate=false")
      .headers(header_1)
      .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.exists.saveAs("LineItem1")))
    //.check(jsonPath("$.records[1].actions.updateitems.rest.params.items..itemId").find.exists.saveAs("LineItem2")))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    /*********** Get LineItems Details***********/
    .exec(http("Updateflow_Get line item details")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${CartId_ForUpdate}/items")
      .queryParamSeq(Seq(("id", "${LineItem1}")))
      .headers(header_1)
      .check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(session => { 
      //originalItemJson.append(session("capturedItemHierarchy").as[String])
      modifiedItemJson = new StringBuilder()
      modifiedItemJson.append("""{"items":{"records":[{"displaySequence":-1,""").append(session("capturedItemHierarchy").as[String]).append("}]}}")
      session
    })

    /* Updating the Quantity from default 1.00 to 3.00 */
    .exec(http("Updateflow_Update cart line item")
      .put(uri10 +"/services/apexrest/v2/cpq/carts/${CartId_ForUpdate}/items")
      .headers(header_1)
      .body(StringBody(session =>  modifiedItemJson.replaceAllLiterally(""""Quantity":{"value":1.00""",""""Quantity":{"value":3.00""").toString() )).asJson
      .check(regex("""message":"Successfully.updated."}]""").find.exists))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
        .exec(http("Updateflow_Order_Detail")
          .get(uri10 + "/${CartId_ForUpdate}")
          .headers(headers_05) 
          .check(regex("""sforce.connection.sessionId = '(.+)';.}[a-zA-Z0-9\s{.('_,:]*name:.'XOMSubmitOrder'}""").find.exists.saveAs("""sfdc_session_id""")))

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)  


        
        .exec(http("Updateflow_OrderUpdate")
          .put(uri10 + "/services/apexrest/Orders/")
          .headers(header_1)
          .check(regex("""status":"Update succeeded""").find.exists)
          .body( StringBody("""[{"orderId":"${CartId_ForUpdate}","state":"Activated"}]""")).asJson)
  

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds) 

      }

    }


      
