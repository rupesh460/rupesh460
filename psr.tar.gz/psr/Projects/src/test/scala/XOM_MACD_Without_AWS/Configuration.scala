package XOM_MACD_Without_AWS


object Configuration
 {
	val BaseUrl = "https://c.cs17.visual.force.com"
	val Uri01 = "https://test.salesforce.com"
	val Uri05 = "https://c.cs17.visual.force.com"
	val Uri10 = "https://cs17.salesforce.com"


	val MinWaitMs = Integer.getInteger("MinWaitMs", 1)
	val MaxWaitMs = Integer.getInteger("MaxWaitMs", 1)
	//val MinWaitMs = 5000
	//val MaxWaitMs = 10000

	val MiniMinWaitMs = 1000
	val MiniMaxWaitMs = 3000

}
