package CPQWhitepaper_Final_10LI

import scala.concurrent.duration._
import io.gatling.core.Predef._
import io.gatling.core.structure.ChainBuilder
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._
import io.gatling.jsonpath._
import Headers._
import scala.collection._
import java.time.format.DateTimeFormatter
import java.time.LocalDateTime
import java.time.LocalDate


object CPQ_OrderFlow {

  val uri01 = Configuration.Uri01
  val uri05 = Configuration.Uri05
  val uri10 = Configuration.Uri10
  var modifiedItemJson = new StringBuilder()
  val origItemAttrHeirarchy = new StringBuilder()
  val modItemAttrHeirarchy = new StringBuilder()
  val randomNumber = new scala.util.Random
  var randomLineItem = new StringBuilder()
  var pbeEntriesList = Vector[String]()
  var promotionList = Vector[String]()
  var lineItemsList = Vector[String]()
  var randomPBEntry = new StringBuilder()
  var accountName = new StringBuilder()
  var randomPromoId = new StringBuilder()
  var final_formatted_date = new StringBuilder()
  val userFeeder = csv("./src/test/resources/data/CPQ/CPQ_Users.csv").queue
  //val product_feeder = csv("./src/test/resources/data/CPQ/ProductIds.csv").circular
  val product_feeder = csv("./src/test/resources/data/CPQ/DebugProductIds.csv").circular
  val promotion_feeder = csv("./src/test/resources/data/CPQ/PromoIds.csv").random
  //val products_ids_loy = csv("./src/test/resources/data/devorg/EPC_BMK_Loyalty_ProductIds.csv").random
  //var date = DateTimeFormatter.ofPattern(“YYYY-MM-dd”).format(java.time.LocalDate.now)
  var Date =  Configuration.date


  val cpq_Whitepaper = scenario("cpq_Whitepaper")

  .exec(session => session.set("PriceListId",Configuration.PriceListId))
  .exec(session => session.set("Pricebook2Id",Configuration.Pricebook2Id))
  .exec(session => session.set("PromotionID1",Configuration.Promotion3PI))
  .exec(session => session.set("PromotionID2",Configuration.Promotion5PI))
  .exec(session => session.set("UpdatePromotionID",Configuration.UpdatePromotion))
  .exec(session => session.set("UpdatePromotionItemID",Configuration.UpdatePromotionItem))
  .exec(session => session.set("PenaltyRulePromotionID",Configuration.PenaltyRulePromotion))


  .feed(userFeeder)
  .exec(http("LDV1_Login")
    .post(uri01 + "/")
    .headers(headers_35)
    .formParam("un", "${username}")
    .formParam("width", "1440")
    .formParam("height", "900")
    .formParam("hasRememberUn", "true")
    .formParam("startURL", "")
    .formParam("loginURL", "")
    .formParam("loginType", "")
    .formParam("useSecure", "true")
    .formParam("local", "")
    .formParam("lt", "standard")
    //.formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
    .formParam("locale", "")
    .formParam("oauth_token", "")
    .formParam("oauth_callback", "")
    .formParam("login", "")
    .formParam("serverid", "")
    .formParam("QCQQ", "M1D2l15jFvl")
    .formParam("display", "page")
    .formParam("username", "${username}")
    .formParam("pw", "${password}")
    .formParam("Login", ""))

//  .feed(userFeeder)
  .exec(http("RESTGetOAuthToken")
    .post("https://test.salesforce.com/services/oauth2/token")
    .header("Content-Type", "application/x-www-form-urlencoded")
    .formParam("password", "${password}")
    .formParam("username", "${username}")
    .formParam("client_secret", "7119599995527965426")
    .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
    .formParam("grant_type", "password")
    .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
    .check(status.is(200)))

    .repeat(1)
    {

    exec(session => session.set("AccountName",""))

    .exec( session => {
      val random_index = randomNumber.nextInt(100000)
      accountName.append("Acc-"+random_index)
      session
    })

    .exec(session => session.set("AccountName",accountName))

    .exec( session => {
      accountName = new StringBuilder()
      session
    })

    /* *********** CreateAccount *********** */
    .exec(http("001_New_CreateAccount")
      .post(uri10 +"/services/data/v44.0/sobjects/account")
      .headers(header_1)
      .check(regex(""""id":"(.*?)"""").find.exists.saveAs("AccountId"))
      .body( StringBody("""
      {
        "Name" : "CPQ${AccountName}",
        "ShippingCity" : "San Francisco",
        "Status__c": "Active"
      }""")).asJson)

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  //  "RecordTypeId" : "012J0000000F2q3IAC",


  .exec( session => {
    val maxdate = Date
    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
    val dateforcurrentrun = LocalDate.parse(maxdate,formatter).plusDays(1)
    final_formatted_date.append(dateforcurrentrun)
    session
  })

  .exec( session => session.set("DATE", final_formatted_date ) )
  .exec( session => {
    final_formatted_date = new StringBuilder()
    session
  })

  /* *********** CreateOrder *********** */
  .exec(http("002_New_Create_a_new_order")
    .post(uri10 +"/services/apexrest/v2/carts")
    .headers(header_1)
    .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
    .body( StringBody("""{"subaction":"createOrder",
      "inputFields":[
      {"AccountId":"${AccountId}"},
      {"PriceListId__c":"${PriceListId}"},
      {"Name":"Bmk-Order"},{"Status":"Draft"},
      {"EffectiveDate":"${DATE}"}
      ]}""")).asJson)

//${Date}4/24/2020

/* ********** get CSRF Token *********** */
.exec(http("003_New_getCsrf")
.get(uri05 + "/apex/hybridcpq?id=${OrderID}")
.headers(headers_99)
.check(regex("""\{"name":"doGenericInvoke","len":4,"ns":"","ver":41.0,"csrf":"(.*)"\},\{"name":"doNamedCredentialCallout""").find.exists.saveAs("CSRFToken"))
.check(regex("""vid":"(.+?)","xhr""").find.exists.saveAs("vid")))

.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
    /* ********** ViewPriceLists *********** */
  .exec(http("004_New_ViewPriceLists")
    .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/pricelists")
    //.check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfPBEntries"))
    .headers(header_1))

    /* ********** SetPriceListForCart *********** */
    .exec(http("005_New_SetPriceListfortheOrder")
      .put(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/")
      .headers(header_1)
      .body(StringBody("""{
        "inputFields":
        [
        {
          "PriceListId__c": "${PriceListId}"
        }
        ],
        "cartId": "${OrderID}",
        "methodName": "updateCarts"
      }""")).asJson
      .check(regex(""""Id":"${OrderID}"""").find.exists))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      /* ********** GetListOfProductsForCart *********** */
    .exec(http("006_New_Getlistofproductsforcart")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/products?pagesize=10")
      .check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfPBEntries"))
      .headers(header_1))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      /* ********** RetrieveFilterableProducts *********** */
    .exec(http("007_New_RetrieveFilterableProducts")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/attributes")
      .check(regex(""""totalSize":1,""").find.exists)
      .headers(header_1))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      /* ********** RetrievePromotions *********** */
      .exec(http("008_New_RetrievePromotions")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/promotions?pagesize=10")
      .check(jsonPath("$.records[0].id").find.saveAs("PromotionID"))
      .check(jsonPath("$.records[*].id").findAll.saveAs("PromotionList"))
      .headers(header_1))

   .exec( session => {
      promotionList = session("PromotionList").as[Vector[String]]
      session
    })

   .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


     .repeat(1)
     {
           /* ********** AddItemsToCart *********** */
           feed(product_feeder)
           .exec(http("09_New_Additemstocart")
             .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
             .headers(header_1)
             .body( StringBody("""{
               "items":[{
                 "itemId":"${Product24LI_ID}"
               }],
               "price":"true",
               "validate":"true",
               "pagesize":20
             }""")).asJson
             .check(regex("""productHierarchyPath":"(.*?)","name":"CPQ-WP-P0-Prod-""").find.exists.saveAs("c_productHierarchyPath"))
           .check(jsonPath("$.records[0].lineItems.records[0].actions.updateitems.rest.params.items[0]..itemId").find.saveAs("CloneLineItem")))

           .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
     }

//.check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("CloneLineItem"))
//$.records[0].lineItems.records[0].actions.updateitems.rest.params.items[0].itemId

     /* ********** ExpandParentItemtoDisplayNextLevelChildren *********** */
     .exec(http("010_New_ExpandParentItemtoDisplayNextLevelChildren")
       .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/${CloneLineItem}/expand?productHierarchyPath=${c_productHierarchyPath}")
       .headers(header_1)
       .check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))

  /*
       /* ********** ExpandParentItemtoDisplayNextLevelChildren *********** */
       .exec(http("011_New_ExpandParentItemtoDisplayNextLevelChildren_Add")
         .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/${CloneLineItem}/expand?productHierarchyPath=01tJ0000009OtGOIA0<01tJ0000008yN9XIAU")
         .headers(header_1)
         .check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))
*/
     /* ********** GetCartLineItems *********** */
     .exec(http("011_New_GetCartLineItems")
       .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items?pagesize=10&price=false&validate=false")
       .headers(header_1)
       .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1")))


//{"action":"CardCanvasController","method":"doGenericInvoke","data":["CpqAppHandler","getCartsDiscounts","{\"cartId\":\"801J0000002DD0V\",\"includeIneligible\":\"true\",\"includeProducts\":\"true\",\"localeCode\":\"en_US\",\"offsetSize\":\"0\",\"pagesize\":\"10\"}","{\"vlcClass\":\"CpqAppHandler\"}"],"type":"rpc","tid":13,"ctx":{"csrf":"VmpFPSxNakF5TUMwd05TMHdNbFF3T0Rvd05qb3dPQzR3TXpoYSx2c3hDVGpDY2hCTk45Wnp4TXFGX1NMLE1HRmpORE5q","vid":"066J00000011CJa","ns":"","ver":41}}


/*
/* ********** getcarts Discount *********** */
   .exec(http("012_New_getcartsDiscount")
    .post(uri05 + "/apexremote")
    .headers(headers_0)
    .check(regex(""""statusCode":200,"""").find.exists)
    .body( StringBody("""
      {"action":"CardCanvasController",
      "method":"doGenericInvoke",
      "data":["CpqAppHandler","getCartsDiscounts","{\"cartId\":\"${OrderID}\",\"pagesize\":\"10\"}","{\"vlcClass\":\"CpqAppHandler\"}"],"type":"rpc","tid":13,"ctx":{"csrf":"${CSRFToken}","vid":"${vid}","ns":"","ver":41}}""")).asJson)
*/

/* ********** getcarts Discount *********** */
   .exec(http("012_New_getcartsDiscount")
    .post(uri05 + "/apexremote")
    .headers(headers_0)
    .check(regex(""""statusCode":200,"""").find.exists)
    .body(ElFileBody("./src/test/resources/bodies/CPQ/23LI/GetCartsDiscount.txt")))

//.body(ElFileBody("./src/test/resources/bodies/CPQ/MACD_ADD/O_23LI_Addtocart.txt")))


/*
/* ********** CreateNew Discount *********** */
      .exec(http("013_New_CreateNewDiscount")
       .post(uri05 + "/apexremote")
       .headers(headers_0)
       .check(regex(""""statusCode":200,"""").find.exists)
       .body( StringBody("""
         {"action":"CardCanvasController",
           "method":"doGenericInvoke",
           "data":["CpqAppHandler","postCartsDiscounts","{\"methodName\":\"postCartsDiscounts\",\"cartId\":\"${OrderID}\",\"items\":{\"records\":[{\"Allocation\":{\"selectedDiscountType\":{\"value\":\"Order\",\"name\":\"Order\",\"$$hashKey\":\"object:1838\"},\"types\":[{\"value\":\"Account\",\"name\":\"Account\",\"$$hashKey\":\"object:1837\"},{\"value\":\"Order\",\"name\":\"Order\",\"$$hashKey\":\"object:1838\"},{\"value\":\"Contract\",\"name\":\"Contract\",\"$$hashKey\":\"object:1839\"}],\"label\":\"Discount Type\"},\"Category\":{\"actions\":{\"rest\":{\"params\":{},\"method\":null,\"link\":null},\"remote\":{\"params\":{\"methodName\":\"getCatalogHierarchy\",\"ContextId\":\"${OrderID}\",\"includeAllCatalogs\":true,\"cartId\":\"${OrderID}\"}},\"client\":{\"records\":[],\"params\":{\"methodName\":\"getCatalogHierarchy\",\"ContextId\":\"${OrderID}\",\"includeAllCatalogs\":true,\"cartId\":\"${OrderID}\"}}},\"categories\":[],\"value\":\"\",\"label\":\"Category\"},\"Product\":{\"actions\":{\"rest\":{\"params\":{},\"method\":null,\"link\":null},\"remote\":{\"params\":{\"methodName\":\"getCartsProducts\",\"cartId\":\"${OrderID}\"}},\"client\":{\"records\":[],\"params\":{\"methodName\":\"getCartsProducts\",\"cartId\":\"${OrderID}\"}}},\"products\":[],\"value\":\"\",\"label\":\"Product\"},\"Discount\":{\"discounts\":[{\"types\":[{\"method\":\"Percent\",\"detailType\":\"Discount\",\"value\":\"%\"},{\"method\":\"Absolute\",\"detailType\":\"Discount\",\"value\":\"$\"}],\"value\":null,\"actions\":{\"rest\":{\"params\":{},\"method\":null,\"link\":null},\"remote\":{\"params\":{\"methodName\":\"getListsOfValues\",\"listkeys\":\"TimePlans,TimePolicies\"}},\"client\":{\"records\":[],\"params\":{}}},\"selectedAdjustmentMethod\":{\"value\":\"%\"},\"chargeType\":\"Recurring\",\"selectedTimePlan\":null,\"selectedTimePolicy\":null,\"label\":\"\",\"$$hashKey\":\"object:1817\"},{\"types\":[{\"method\":\"Percent\",\"detailType\":\"Discount\",\"value\":\"%\",\"$$hashKey\":\"object:1832\"},{\"method\":\"Absolute\",\"detailType\":\"Discount\",\"value\":\"$\",\"$$hashKey\":\"object:1833\"}],\"value\":-15,\"selectedAdjustmentMethod\":{\"method\":\"Absolute\",\"detailType\":\"Discount\",\"value\":\"$\",\"$$hashKey\":\"object:1833\"},\"chargeType\":\"One-time\",\"label\":\"\",\"$$hashKey\":\"object:1816\"}],\"label\":\"Discount\",\"value\":\"\"},\"Duration unit\":{\"label\":\"Duration unit\",\"value\":\"Month\"},\"All items in cart\":{\"label\":\"All items in cart\",\"value\":true},\"End date\":{\"label\":\"End Date\",\"value\":null},\"Active period\":{\"label\":\"Active Period\",\"value\":null},\"Discount Name\":{\"label\":\"Discount Name\",\"value\":\"Custom_Discount\"},\"timePlanList\":[{\"valuekey\":\"a2SJ0000000NGsSMAW\",\"label\":\"Time Plan 1 year\"},{\"valuekey\":\"a2SJ0000000NGsJMAW\",\"label\":\"Time Plan 1 week new\"},{\"valuekey\":\"a2SJ0000000NGsKMAW\",\"label\":\"Time Plan 1 day new\"},{\"valuekey\":\"a2SJ0000000NGsLMAW\",\"label\":\"Time Plan 1 Quater2\"},{\"valuekey\":\"a2SJ0000000NGsMMAW\",\"label\":\"Time Plan 1 Quarter new\"},{\"valuekey\":\"a2SJ0000000NGsNMAW\",\"label\":\"Time Plan 2 Week\"},{\"valuekey\":\"a2SJ0000000NGsOMAW\",\"label\":\"Time Plan 1 Quater\"},{\"valuekey\":\"a2SJ0000000NGsPMAW\",\"label\":\"Time Plan 1 month new\"},{\"valuekey\":\"a2SJ0000000NGsQMAW\",\"label\":\"Time Plan 1 year new\"},{\"valuekey\":\"a2SJ0000000NGsRMAW\",\"label\":\"Time Plan 1 day\"}],\"Description\":{\"value\":\"Custom_Discount\"}}]}}","{\"vlcClass\":\"CpqAppHandler\"}"],
           "type":"rpc",
           "tid":37,
           "ctx":{"csrf":"${CSRFToken}","vid":"${vid}","ns":"","ver":41}}""")).asJson)

           .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

*/

/* ********** CreateNew Discount *********** */
      .exec(http("013_New_CreateNewDiscount")
       .post(uri05 + "/apexremote")
       .headers(headers_0)
       .check(regex(""""statusCode":200,"""").find.exists)
       .body(ElFileBody("./src/test/resources/bodies/CPQ/23LI/CreateNewDiscount.txt")))

       .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
/*
     /* ********** Apply Discount *********** */
        .exec(http("014_New_ApplyDiscount")
         .post(uri05 + "/apexremote")
         .headers(headers_0)
         .check(regex(""""statusCode":200,"""").find.exists)
         .body( StringBody("""
           {"action":"CardCanvasController",
           "method":"doGenericInvoke",
           "data":["CpqAppHandler","postCartsDiscounts","{\"discountTemplateIds\":[\"a2BJ0000000VUGUMA4\"],\"cartId\":\"${OrderID}\",\"methodName\":\"postCartsDiscounts\"}","{\"vlcClass\":\"CpqAppHandler\"}"],"type":"rpc","tid":20,"ctx":{"csrf":"${CSRFToken}","vid":"${vid}","ns":"","ver":41}}""")).asJson)

           .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
*/

/* ********** Apply Discount *********** */
   .exec(http("014_New_ApplyDiscount")
    .post(uri05 + "/apexremote")
    .headers(headers_0)
    .check(regex(""""statusCode":200,"""").find.exists)
    .body(ElFileBody("./src/test/resources/bodies/CPQ/23LI/ApplyDiscount.txt")))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
  /*
           /* ********** Retrieve Discount *********** */
              .exec(http("015_New_RetrieveDiscount")
               .post(uri05 + "/apexremote")
               .headers(headers_0)
               .check(regex(""""statusCode":200,"""").find.exists)
                .check(regex(""""OrderDiscountId__c\\":\{\\\"value\\":\\"(.*?)\\",\\"previousValue\\":n""").find.exists.saveAs("DeleteDiscountID"))
               .body( StringBody("""
                 {"action":"CardCanvasController",
                 "method":"doGenericInvoke",
                 "data":["CpqAppHandler","getAllApplicableDiscounts","{\"cartId\":\"${OrderID}\",\"pagesize\":\"10\"}","{\"vlcClass\":\"CpqAppHandler\"}"],"type":"rpc","tid":35,"ctx":{"csrf":"${CSRFToken}","vid":"${vid}","ns":"","ver":41}}""")).asJson)

                 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
*/
//{"action":"CardCanvasController","method":"doGenericInvoke","data":["CpqAppHandler","deleteCartDiscount","{\"methodName\":\"deleteCartDiscount\",\"id\":\"a4qJ00000006iyYIAQ\",\"cartId\":\"801J0000002DD0VIAW\"}","{\"vlcClass\":\"CpqAppHandler\"}"],"type":"rpc","tid":29,"ctx":{"csrf":"VmpFPSxNakF5TUMwd05TMHdNbFF3TmpvME9Eb3lNaTQzTlROYSxWR0U2YnlObkVab3Q0YWllVTE0b3B3LE1HRmpORE5q","vid":"066J00000011CJa","ns":"","ver":41}}

/* ********** Retrieve Discount *********** */
   .exec(http("015_New_RetrieveDiscount")
    .post(uri05 + "/apexremote")
    .headers(headers_0)
    .check(regex(""""statusCode":200,"""").find.exists)
     .check(regex(""""OrderDiscountId__c\\":\{\\\"value\\":\\"(.*?)\\",\\"previousValue\\":n""").find.exists.saveAs("DeleteDiscountID"))
    .body(ElFileBody("./src/test/resources/bodies/CPQ/23LI/RetrieveDiscount.txt")))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

/*
/* ********** Modify Discount *********** */
      .exec(http("016_New_ModifyDiscount")
       .post(uri05 + "/apexremote")
       .headers(headers_0)
       .check(regex(""""statusCode":200,"""").find.exists)
       .body( StringBody("""
         {"action":"CardCanvasController",
           "method":"doGenericInvoke",
           "data":["CpqAppHandler","configureDiscounts","{\"methodName\":\"configureDiscounts\",\"discountId\":\"${DeleteDiscountID}\",\"cartId\":\"${OrderID}\",\"items\":{\"records\":[{\"actions\":{\"deleteDiscount\":{\"rest\":{\"params\":{},\"method\":null,\"link\":null},\"remote\":{\"params\":{\"methodName\":\"deleteCartDiscount\",\"id\":\"${DeleteDiscountID}\",\"cartId\":\"${OrderID}\"}},\"client\":{\"params\":{}}},\"configureDiscounts\":{\"rest\":{\"params\":{},\"method\":null,\"link\":null},\"remote\":{\"params\":{\"methodName\":\"configureDiscounts\",\"discountId\":\"${DeleteDiscountID}\",\"cartId\":\"${OrderID}\"}},\"client\":{\"params\":{}}}},\"displaySequence\":-1,\"Id\":{\"value\":\"${DeleteDiscountID}\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Record ID\",\"hidden\":null,\"fieldName\":\"Id\",\"editable\":false,\"dataType\":\"ID\",\"alternateValues\":null,\"actions\":{}},\"Name\":{\"value\":\"23LI_Discount\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Name\",\"hidden\":null,\"fieldName\":\"Name\",\"editable\":true,\"dataType\":\"STRING\",\"alternateValues\":null,\"actions\":{}},\"EffectiveEndDate__c\":{\"value\":null,\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Effective End Date\",\"hidden\":null,\"fieldName\":\"EffectiveEndDate__c\",\"editable\":true,\"dataType\":\"DATETIME\",\"alternateValues\":null,\"actions\":{}},\"EffectiveStartDate__c\":{\"value\":null,\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Effective Start Date\",\"hidden\":null,\"fieldName\":\"EffectiveStartDate__c\",\"editable\":true,\"dataType\":\"DATETIME\",\"alternateValues\":null,\"actions\":{}},\"AppliesToAllItems__c\":{\"value\":true,\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Applies To All Items\",\"hidden\":null,\"fieldName\":\"AppliesToAllItems__c\",\"editable\":true,\"dataType\":\"BOOLEAN\",\"alternateValues\":null,\"actions\":{}},\"DurationUnitOfMeasure__c\":{\"value\":\"Month\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Discount Duration Unit of Measure\",\"hidden\":null,\"fieldName\":\"DurationUnitOfMeasure__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}},\"Duration__c\":{\"value\":null,\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Discount Duration\",\"hidden\":null,\"fieldName\":\"Duration__c\",\"editable\":true,\"dataType\":\"DOUBLE\",\"alternateValues\":null,\"actions\":{}},\"ReferenceNumber__c\":{\"value\":\"b789b3d4-3431-916a-1cce-eb068de4c334\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Reference Number\",\"hidden\":null,\"fieldName\":\"ReferenceNumber__c\",\"editable\":true,\"dataType\":\"STRING\",\"alternateValues\":null,\"actions\":{}},\"ApprovalStatus__c\":{\"value\":\"Approved\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"ApprovalStatus\",\"hidden\":null,\"fieldName\":\"ApprovalStatus__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}},\"Description__c\":{\"value\":\"23LI_Discount\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Description\",\"hidden\":null,\"fieldName\":\"Description__c\",\"editable\":true,\"dataType\":\"TEXTAREA\",\"alternateValues\":null,\"actions\":{}},\"DiscountType__c\":{\"value\":\"Order\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Discount Type\",\"hidden\":null,\"fieldName\":\"DiscountType__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}},\"Action__c\":{\"value\":\"New\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Action\",\"hidden\":null,\"fieldName\":\"Action__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}},\"Status__c\":{\"value\":\"Not Activated\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Status\",\"hidden\":null,\"fieldName\":\"Status__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}},\"DiscountTemplateId__c\":{\"value\":\"a2BJ0000000VUGUMA4\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Discount Template\",\"hidden\":null,\"fieldName\":\"DiscountTemplateId__c\",\"editable\":true,\"dataType\":\"REFERENCE\",\"alternateValues\":null,\"actions\":{}},\"Discount Name\":{\"label\":\"Discount Name\",\"value\":\"23LI_Discount\"},\"name\":\"23LI_Discount\",\"Allocation\":{\"label\":\"Discount Type\",\"types\":[{\"value\":\"Account\",\"name\":\"Account\"},{\"value\":\"Order\",\"name\":\"Order\"},{\"value\":\"Contract\",\"name\":\"Contract\"}],\"selectedDiscountType\":{\"value\":\"Order\",\"name\":\"Order\"}},\"All items in cart\":{\"label\":\"All items in cart\",\"value\":\"\"},\"Duration unit\":{\"label\":\"Duration unit\",\"value\":\"Month\"},\"objectName\":\"OrderDiscount__c\",\"Product\":{\"products\":[],\"label\":\"Product\"},\"Category\":{\"categories\":[],\"label\":\"Category\"},\"Status\":{\"label\":\"Status\",\"value\":\"Approved\"},\"Discount\":{\"discounts\":[{\"label\":\"one time charges\",\"chargeType\":\"One-time\",\"selectedAdjustmentMethod\":{\"value\":\"$\"},\"value\":-15,\"types\":[{\"method\":\"Percent\",\"detailType\":\"Discount\",\"value\":\"%\"},{\"method\":\"Absolute\",\"detailType\":\"Discount\",\"value\":\"$\"}],\"$$hashKey\":\"object:2086\"},{\"types\":[{\"method\":\"Percent\",\"detailType\":\"Discount\",\"value\":\"%\"},{\"method\":\"Absolute\",\"detailType\":\"Discount\",\"value\":\"$\"}],\"value\":null,\"actions\":{\"rest\":{\"params\":{},\"method\":null,\"link\":null},\"remote\":{\"params\":{\"methodName\":\"getListsOfValues\",\"listkeys\":\"TimePlans,TimePolicies\"}},\"client\":{\"records\":[],\"params\":{}}},\"selectedAdjustmentMethod\":{\"value\":\"%\"},\"chargeType\":\"Recurring\",\"selectedTimePlan\":null,\"selectedTimePolicy\":null,\"label\":\"\",\"$$hashKey\":\"object:2087\"}],\"label\":\"Discount\"},\"discountPriceAdjustments\":{\"totalSize\":1,\"records\":[{\"displaySequence\":-1,\"Id\":{\"value\":\"a4pJ0000000MArLIAW\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Record ID\",\"hidden\":null,\"fieldName\":\"Id\",\"editable\":false,\"dataType\":\"ID\",\"alternateValues\":null,\"actions\":{}},\"Name\":{\"value\":\"a2BJ0000000VUGUMA4\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Reference Number\",\"hidden\":null,\"fieldName\":\"Name\",\"editable\":true,\"dataType\":\"STRING\",\"alternateValues\":null,\"actions\":{}},\"AdjustmentValue__c\":{\"value\":-10,\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Adjustment Value\",\"hidden\":null,\"fieldName\":\"AdjustmentValue__c\",\"editable\":true,\"dataType\":\"DOUBLE\",\"alternateValues\":null,\"actions\":{}},\"Amount__c\":{\"value\":null,\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Amount\",\"hidden\":null,\"fieldName\":\"Amount__c\",\"editable\":true,\"dataType\":\"CURRENCY\",\"alternateValues\":null,\"actions\":{}},\"PricingVariableId__c\":{\"value\":\"a40J0000001TQ6LIAW\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Pricing Variable\",\"hidden\":null,\"fieldName\":\"PricingVariableId__c\",\"editable\":true,\"dataType\":\"REFERENCE\",\"alternateValues\":null,\"actions\":{}},\"TimePlanId__c\":{\"value\":null,\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Time Plan\",\"hidden\":null,\"fieldName\":\"TimePlanId__c\",\"editable\":true,\"dataType\":\"REFERENCE\",\"alternateValues\":null,\"actions\":{}},\"TimePolicyId__c\":{\"value\":null,\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Time Policy\",\"hidden\":null,\"fieldName\":\"TimePolicyId__c\",\"editable\":true,\"dataType\":\"REFERENCE\",\"alternateValues\":null,\"actions\":{}},\"OrderDiscountId__c\":{\"value\":\"${DeleteDiscountID}\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Order Discount\",\"hidden\":null,\"fieldName\":\"OrderDiscountId__c\",\"editable\":false,\"dataType\":\"REFERENCE\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.Id\":{\"value\":\"a40J0000001TQ6LIAW\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Record ID\",\"hidden\":null,\"fieldName\":\"Id\",\"editable\":false,\"dataType\":\"ID\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.Name\":{\"value\":\"One Time Std Price Adjustment Abs\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Pricing Variable Name\",\"hidden\":null,\"fieldName\":\"Name\",\"editable\":true,\"dataType\":\"STRING\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.IsActive__c\":{\"value\":true,\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Active\",\"hidden\":null,\"fieldName\":\"IsActive__c\",\"editable\":true,\"dataType\":\"BOOLEAN\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.AdjustmentMethod__c\":{\"value\":\"Absolute\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Adjustment Method\",\"hidden\":null,\"fieldName\":\"AdjustmentMethod__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.Aggregation__c\":{\"value\":\"Unit\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Aggregation\",\"hidden\":null,\"fieldName\":\"Aggregation__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.AppliesTo__c\":{\"value\":null,\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Applies To\",\"hidden\":null,\"fieldName\":\"AppliesTo__c\",\"editable\":true,\"dataType\":\"STRING\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.AppliesToVariableId__c\":{\"value\":\"a40J0000001TQ6GIAW\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Applies To Variable\",\"hidden\":null,\"fieldName\":\"AppliesToVariableId__c\",\"editable\":true,\"dataType\":\"REFERENCE\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.ChargeType__c\":{\"value\":\"Adjustment\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Charge Type\",\"hidden\":null,\"fieldName\":\"ChargeType__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.Code__c\":{\"value\":\"OT_STD_PRC_ADJ_ABS\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Code\",\"hidden\":null,\"fieldName\":\"Code__c\",\"editable\":true,\"dataType\":\"STRING\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.CurrencyType__c\":{\"value\":\"Currency\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Currency Type\",\"hidden\":null,\"fieldName\":\"CurrencyType__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.Description__c\":{\"value\":null,\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Description\",\"hidden\":null,\"fieldName\":\"Description__c\",\"editable\":true,\"dataType\":\"TEXTAREA\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.RecurringFrequency__c\":{\"value\":null,\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Frequency\",\"hidden\":null,\"fieldName\":\"RecurringFrequency__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.Scope__c\":{\"value\":\"Line\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Scope\",\"hidden\":null,\"fieldName\":\"Scope__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.SubType__c\":{\"value\":\"Standard\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Sub-Type\",\"hidden\":null,\"fieldName\":\"SubType__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.Type__c\":{\"value\":\"Price\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Type\",\"hidden\":null,\"fieldName\":\"Type__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.ValueType__c\":{\"value\":\"Pricing Element\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"ValueType\",\"hidden\":null,\"fieldName\":\"ValueType__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}}}]},\"$$hashKey\":\"object:2070\"}]}}","{\"vlcClass\":\"CpqAppHandler\"}"],
           "type":"rpc",
           "tid":37,
           "ctx":{"csrf":"${CSRFToken}","vid":"${vid}","ns":"","ver":41}}""")).asJson)

           .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

       /* ********** Delete Discount *********** */
          .exec(http("017_New_DeleteDiscount")
           .post(uri05 + "/apexremote")
           .headers(headers_0)
           .check(regex(""""statusCode":200,"""").find.exists)
           .body( StringBody("""
             {"action":"CardCanvasController",
             "method":"doGenericInvoke",
             "data":["CpqAppHandler","deleteCartDiscount","{\"methodName\":\"deleteCartDiscount\",\"id\":\"${DeleteDiscountID}\",\"cartId\":\"${OrderID}\"}","{\"vlcClass\":\"CpqAppHandler\"}"],"type":"rpc","tid":29,"ctx":{"csrf":"${CSRFToken}","vid":"${vid}","ns":"","ver":41}}""")).asJson)

*/

/* ********** Modify Discount *********** */
      .exec(http("016_New_ModifyDiscount")
       .post(uri05 + "/apexremote")
       .headers(headers_0)
       .check(regex(""""statusCode":200,"""").find.exists)
       .body(ElFileBody("./src/test/resources/bodies/CPQ/23LI/ModifyDiscount.txt")))

           .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

       /* ********** Delete Discount *********** */
          .exec(http("017_New_DeleteDiscount")
           .post(uri05 + "/apexremote")
           .headers(headers_0)
           .check(regex(""""statusCode":200,"""").find.exists)
           .body(ElFileBody("./src/test/resources/bodies/CPQ/23LI/DeleteDiscount.txt")))

     /* ********** ViewProductDetails *********** */
     .feed(product_feeder)
     .exec(http("018_New_ViewProductDetails")
       .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/products/01uJ000000FwPvlIAF?maxProdListHierarchy=5&includeAttachment=true&filters=AppliesTo__c%3AAccount_Contract&fields=Id%2CName&includeAttributes=true")
       .headers(header_1)
       .check(regex("""totalSize":1""").find.exists))

       /* ********** CloneCartLineItem ********** */
       .exec(http("019_New_Cloneacartlineitem")
        .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/clone")
        .headers(header_1)
        .body( StringBody("""{
          "items": [
          {"itemId":"${CloneLineItem}"}
          ],
          "hierarchy": 1,
          "lastItemId": "",
          "pagesize": 20
        }""")).asJson
        .check(regex("""INFO","message":"Clone Successful.""").find.exists))

       .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

       /* ********** GetCartLineItems *********** */
       .exec(http("020_New_GetCartLineItems")
         .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items?pagesize=10&price=false&validate=false")
         .headers(header_1)
         .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1")))
         //.check(jsonPath("$.records[1].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem2")))

       /* ********** GetCartItemsByItemId *********** */
       .exec(http("021_New_Getlineitemdetails")
         .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
         .queryParamSeq(Seq(("id", "${LineItem1}")))
         .headers(header_1)
         .check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))

       .exec(session => {
         //originalItemJson.append(session("capturedItemHierarchy").as[String])
         modifiedItemJson = new StringBuilder()
         modifiedItemJson.append("""{"items":{"records":[{"displaySequence":-1,""").append(session("capturedItemHierarchy").as[String]).append("}]}}")
         session
       })

      // .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

       /* ********** UpdateItemsInCart *********** */
       /* Updating the Quantity from default 1.00 to 3.00 */
       .exec(http("022_New_Updatecartlineitem")
         .put(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
         .headers(header_1)
         .body(StringBody(session =>  modifiedItemJson.replaceAllLiterally(""""Quantity":{"value":1.00""",""""Quantity":{"value":3.00""").toString() )).asJson
         .check(regex("""INFO","message":"Successfully updated.""").find.exists))

       .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


       /* ********** VIewPriceWaterfall *********** */
       .exec(http("023_New_VIewPriceWaterfall")
         .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/${LineItem1}/pricing?fields=Id%2CName")
         .headers(header_1)
        .check(regex(""""totalSize":1,"""").find.exists))

    /* ********** AddPromotionToCart *********** */
        .feed(promotion_feeder)
        .exec(http("024_New_Addapromotion")
         .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/promotions")
         .headers(header_1)
         .body( StringBody("""{
           "items": [{"itemId":"${PromoID}"}],
           "promotionId":"${PromoID}",
           "cartId":"${OrderID}",
           "methodName":"postCartsPromoItems"
         }""")).asJson
         .check(status.is(200)))

         .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

         /* ********** DeleteItemFromCart********** */
         .exec(http("025_New_Deleteanitemfromthecart")
           .delete(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/${CloneLineItem}")
           .headers(header_1)
           .check(regex("""INFO","message":"Successfully deleted.""").find.exists))

     .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

     /* *********** GetPromotionsAppliedToCart ********** */
     .exec(http("026_New_Getpromotionsappliedtocart")
       .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/promotions?subaction=getPromotionsAppliedToCart")
       .check(jsonPath("$.records[0].Id.value").find.exists.saveAs("AppliedPromotionId1"))
       .headers(header_1))

        /* *********** DeletePromotionAppliedToCart ********** */
      .exec(http("027_New_Deleteanappliedpromotioninthecart")
       .delete(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/promotions?id=${AppliedPromotionId1}")
       .headers(header_1)
       .check(regex("""INFO","message":"Successfully deleted.""").find.exists))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        /* ********** RetrieveCartSummary *********** */
        .exec(http("028_New_RetrieveCartSummary")
          .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}?price=false&validate=false")
          .headers(header_1))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    /* ********** RetrieveCartItems *********** */
    .exec(http("029_New_RetrieveCartItems")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items?pagesize=10&price=false&validate=false")
      .headers(header_1)
      .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1")))


      /* ********** SubmitOrder ********** */
      .exec(http("030_New_SubmitOrder")
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/checkout")
      .headers(header_1)
      .check(regex("""SUBMIT-100""").find.exists)
      .body( StringBody("""{
        "items":[
        {"itemId":"${LineItem1}"}
        ],
        "hierarchy":1,
        "lastItemId":"",
        "pagesize":20
      }""")).asJson)

  /* --------------------------------MACD-----------------------------------*/

  /* ********** RetrieveAccount ********** */
  .exec(http("031_MACD_RetrieveAccount")
  .get(uri10 +"/services/apexrest/v2/accounts/${AccountId}")
  .headers(header_1)
   .check(regex("""totalSize":1,""").find.exists))

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


  /* ********** RetrieveAssetsForAccount ********** */
  .exec(http("032_MACD_RetrieveAssetsForAccount")
  .get(uri10 +"/services/apexrest/v2/accounts/${AccountId}/assets")
  .headers(header_1)
  .check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfAssetIds")))

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


  /* ************ GetAssetID *********** */
  .exec(http("033_MACD_GetAssetId")
    .get(uri10 +"/services/data/v39.0/query/?q=SELECT Id,Name FROM Asset WHERE AccountId = '${AccountId}' AND Name >= 'CPQ-WP-P0-Prod-' LIMIT 1")
    .check(regex("<Id>(.*?)</Id>").find.saveAs("AssetId"))
    .headers(header_1))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

//.get(uri05 +"/apex/MACDFdo?id=${AssetId_add}")
//{"name":"GenericInvoke2","len":4,"ns":"","ver":38.0,"csrf":"VmpFPSxNakF5TUMwd05DMHlOMVF3TmpvMU16b3dNaTQxTlRKYSw0cXhCc2JqTnB4R3lKdXFCMDdqWk83LE1XRmhPVGxt"},{"name":"Ge

    /* ********** get CSRF Token *********** */
    .exec(http("034_MACD_getCsrf1")
    .get(uri05 + "/apex/MACDFdo?id=${AssetId}")
    .headers(headers_99)
    .check(regex("""\{"name":"GenericInvoke2","len":4,"ns":"","ver":38.0,"csrf":"(.*)"\},\{"name":"Ge""").find.exists.saveAs("CSRFToken1"))
    .check(regex("""vid":"(.+?)","xhr""").find.exists.saveAs("vid")))

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


    /* ********** GetRequestDateDetailsForOrderItem *********** */
  .exec(http("035_MACD_GetRequestDateDetailsForOrderItem")
    .get(uri10 +"/services/data/v39.0/query/?q=SELECT+RequestDate__c+FROM+OrderItem+WHERE+RequestDate__c+!=+null+LIMIT+10")
    .check(regex("""<RequestDate__c>(.*?)</RequestDate__c>""").findAll.exists.saveAs("RequestDatesList"))
    .headers(header_1))

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  .exec( session => {
    val maxdate = Date
    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
    val dateforcurrentrun = LocalDate.parse(maxdate,formatter).plusDays(1)
    final_formatted_date.append(dateforcurrentrun)
    session
  })

  .exec( session => session.set("DATE", final_formatted_date ) )
  .exec( session => {
    final_formatted_date = new StringBuilder()
    session
  })

  /* ************ AssetChangeToOrder *********** */
  .exec(http("036_MACD_AssettoOrder")
    .post(uri10 +"/services/apexrest/v2/carts")
    .headers(header_1)
    .check(jsonPath("$.records[0].cartId").find.saveAs("Asset_OrderId"))
    .body(StringBody("""{
      "subaction": "assetToOrder",
      "id":"${AssetId}",
      "accountId": "${AccountId}",
      "requestDate": "${DATE}"
    }""")).asJson)


  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

//totalSize":1,"
  /* ************ RetrieveAssetPriceDetails *********** */
  .exec(http("037_MACD_RetrieveAssetPriceDetails")
    .get(uri10 +"/services/apexrest/v2/assets/${AssetId}/pricing?accountId=${AccountId}")
    .check(regex(""""totalSize":1,""").find.exists)
    .headers(header_1))

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  //services/data/v39.0/query/?q=SELECT+RequestDate__c+FROM+OrderItem+WHERE+RequestDate__c+!=+null+LIMIT+10

  //services/data/v39.0/query/?q=SELECT+RequestDate__c+FROM+OrderItem+WHERE+RequestDate__c+!=+null+ORDER+BY+RequestDate__c+DESC+LIMIT+10



  //.exec(session => session.set("CurrentDATE"+1, Date))  // Populate the “myToday” session variable with today’s date

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


  //.get(uri10 +"/services/data/v39.0/query/?q=SELECT Id,Name FROM Asset WHERE AccountId = '${AccountId}' LIMIT 1")
  //SELECT Id,Name FROM Asset WHERE AccountId = '001J000002OmRm9IAF' and Name like '%CPQ-WP-P0-Prod%' LIMIT 1

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)



        /* ********** GetListOfProductsForCart *********** */
      .exec(http("038_MACD_Getlistofproductsforcart")
        .get(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}/products?pagesize=10")
        .check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfPBEntries"))
        .headers(header_1))

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        /* ********** RetrieveFilterableProducts *********** */
      .exec(http("039_MACD_RetrieveFilterableProducts")
        .get(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}/attributes")
      .check(regex(""""totalSize":1,""").find.exists)
        .headers(header_1))

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        /* ********** RetrievePromotions *********** */
        .exec(http("040_MACD_RetrievePromotions")
        .get(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}/promotions?pagesize=10")
        .check(jsonPath("$.records[0].id").find.saveAs("PromotionID"))
        .check(jsonPath("$.records[*].id").findAll.saveAs("PromotionList"))
        .headers(header_1))

     .exec( session => {
        promotionList = session("PromotionList").as[Vector[String]]
        session
      })

     .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

     /* ********** ViewProductDetails *********** */
     .feed(product_feeder)
     .exec(http("041_MACD_ViewProductDetails")
       .get(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}/products/01uJ000000FwPvlIAF?maxProdListHierarchy=5&includeAttachment=true&filters=AppliesTo__c%3AAccount_Contract&fields=Id%2CName&includeAttributes=true")
       .headers(header_1)
       .check(regex("""totalSize":1""").find.exists))

       /* ********** CreateNew Discount *********** */
             .exec(http("042_MACD_CreateNewDiscount")
              .post(uri05 + "/apexremote")
              .headers(headers_0)
              .check(regex(""""statusCode":200,"""").find.exists)
              .body(ElFileBody("./src/test/resources/bodies/CPQ/23LI/MACD_CreateNewDiscount.txt")))

              .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


            /* ********** Apply Discount *********** */
               .exec(http("043_MACD_ApplyDiscount")
                .post(uri05 + "/apexremote")
                .headers(headers_0)
                .check(regex(""""statusCode":200,"""").find.exists)
                .body(ElFileBody("./src/test/resources/bodies/CPQ/23LI/MACD_ApplyDiscount.txt")))

                  /* ********** Retrieve Discount *********** */
                     .exec(http("044_MACD_RetrieveDiscount")
                      .post(uri05 + "/apexremote")
                      .headers(headers_0)
                      .check(regex(""""statusCode":200,"""").find.exists)
                       .check(regex(""""OrderDiscountId__c\\":\{\\\"value\\":\\"(.*?)\\",\\"previousValue\\":n""").find.exists.saveAs("DeleteDiscountID"))
                      .body(ElFileBody("./src/test/resources/bodies/CPQ/23LI/MACD_RetrieveDiscount.txt")))

       //{"action":"CardCanvasController","method":"doGenericInvoke","data":["CpqAppHandler","deleteCartDiscount","{\"methodName\":\"deleteCartDiscount\",\"id\":\"a4qJ00000006iyYIAQ\",\"cartId\":\"801J0000002DD0VIAW\"}","{\"vlcClass\":\"CpqAppHandler\"}"],"type":"rpc","tid":29,"ctx":{"csrf":"VmpFPSxNakF5TUMwd05TMHdNbFF3TmpvME9Eb3lNaTQzTlROYSxWR0U2YnlObkVab3Q0YWllVTE0b3B3LE1HRmpORE5q","vid":"066J00000011CJa","ns":"","ver":41}}


       /* ********** GetCartLineItems *********** */
       .exec(http("045_MACD_GetCartLineItems")
         .get(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}/items?pagesize=10&price=false&validate=false")
         .headers(header_1)
         .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1")))
/*
       .repeat(1)
       {
             /* ********** AddItemsToCart *********** */
             feed(product_feeder)
             .exec(http("036_MACD_Additemstocart")
               .post(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}/items")
               .headers(header_1)
               .body( StringBody("""{
                 "items":[{
                   "itemId":"${Product24LI_ID}"
                 }],
                 "price":"true",
                 "validate":"true",
                 "pagesize":20
               }""")).asJson
             .check(regex("""totalSize":1""").find.exists)
             .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("AddLineItem")))

             //{"totalSize":1,"messages":[{"code":"150","severity":"INFO","message":"Successfully added."}],"actions":{"itempricesupdated":{"rest":{

           //    .check(regex("""totalSize":1""").find.exists))

             .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
       }


///Users/nvasanthakumara/gitrepo/CPQ_Whitepaper/psr/Projects/src/test/resources/bodies/CPQ/MACD_ADD/Addtocart.txt

//./src/test/resources/bodies/CPQ/MACD_ADD/Addtocart.txt

  .exec(http("request_0")
			.post("/apexremote")
			.headers(headers_0)
			.body(RawFileBody("macd_add/Macdadd/0000_request.json"))
			.resources(http("request_1")
			.post("/apexremote")
			.headers(headers_0)
			.body(RawFileBody("macd_add/Macdadd/0001_request.json"))))
		.pause(1)
*/
    .exec(http("046_MACD_Additemstocart")
          .post(uri05 +"/apexremote")
          .headers(headers_055)
          .check(regex("""Successfully added.""").find.exists)
          .body(ElFileBody("./src/test/resources/bodies/CPQ/23LI/O_23LI_Addtocart.txt")))

          /* ********** GetCartLineItems *********** */
          .exec(http("047_MACD_GetCartLineItems")
            .get(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}/items?pagesize=10&price=false&validate=false")
            .headers(header_1)
            .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1"))
            .check(jsonPath("$..records[0].lineItems.records[3].actions.updateitems.rest.params.items[0]..itemId").find.saveAs("DeleteLineItem"))
            .check(jsonPath("$..records[0].lineItems.records[1].actions.updateitems.rest.params.items[0]..itemId").find.saveAs("CloneLineItem")))

            //.records[0].lineItems.records[2].actions.updateitems.rest.params.items[0]..itemId

         /* ********** VIewPriceWaterfall *********** */
         .exec(http("048_MACD_VIewPriceWaterfall")
           .get(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}/items/${LineItem1}/pricing?fields=Id%2CName")
           .headers(header_1)
          .check(regex(""""totalSize":1,"""").find.exists))


//x.records[0].lineItems.records[10].actions.updateitems.rest.params.items[0].itemId
         /* ********** Getlineitemdetails *********** */
         .exec(http("049_MACD_Getlineitemdetails")
           .get(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}/items")
           .queryParamSeq(Seq(("id", "${LineItem1}")))
           .headers(header_1)
           .check(jsonPath("$.records[0].lineItems.records[10].actions.updateitems.rest.params.items[0]..itemId").find.saveAs("MACDCloneItem"))
           .check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))

         .exec(session => {
           //originalItemJson.append(session("capturedItemHierarchy").as[String])
           modifiedItemJson = new StringBuilder()
           modifiedItemJson.append("""{"items":{"records":[{"displaySequence":-1,""").append(session("capturedItemHierarchy").as[String]).append("}]}}")
           session
         })

         .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

         /* ********** UpdateItemsInCart *********** */
         /* Updating the Quantity from default 1.00 to 3.00 */
         .exec(http("050_MACD_Updatecartlineitem")
           .put(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}/items")
           .headers(header_1)
           .body(StringBody(session =>  modifiedItemJson.replaceAllLiterally(""""Quantity":{"value":1.00""",""""Quantity":{"value":3.00""").toString() )).asJson
           .check(regex("""INFO","message":"Successfully updated.""").find.exists))

         .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


                /* ********** Modify Discount *********** */
                      .exec(http("051_MACD_ModifyDiscount")
                       .post(uri05 + "/apexremote")
                       .headers(headers_0)
                       .check(regex(""""statusCode":200,"""").find.exists)
                       .body(ElFileBody("./src/test/resources/bodies/CPQ/23LI/MACD_ModifyDiscount.txt")))

                           .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

                       /* ********** Delete Discount *********** */
                          .exec(http("052_MACD_DeleteDiscount")
                           .post(uri05 + "/apexremote")
                           .headers(headers_0)
                           .check(regex(""""statusCode":200,"""").find.exists)
                           .body(ElFileBody("./src/test/resources/bodies/CPQ/23LI/MACD_DeleteDiscount.txt")))

         .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  ///services/apexrest/vlocity_cmt/v2/cpq/carts/801360000000oQ9/items/80236000009E2InAAK/pricing?fields=Id%2CName

  /* ********** DeleteItemFromCart********** */
  .exec(http("053_MACD_Deleteanitemfromthecart")
    .delete(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}/items/${DeleteLineItem}")
    .headers(header_1)
    .check(regex("""itempricesupdated""").find.exists))

.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


             /* ********** AddPromotionToCart *********** */
                 .feed(promotion_feeder)
                 .exec(http("054_MACD_Addapromotion")
                  .post(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}/promotions")
                  .headers(header_1)
                  .body( StringBody("""{
                    "items": [{"itemId":"${PromoID}"}],
                    "promotionId":"${PromoID}",
                    "cartId":"${Asset_OrderId}",
                    "methodName":"postCartsPromoItems"
                  }""")).asJson
                  .check(status.is(200)))

                  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


                  /* *********** GetPromotionsAppliedToCart ********** */
                  .exec(http("055_MACD_Getpromotionsappliedtocart")
                    .get(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}/promotions?subaction=getPromotionsAppliedToCart")
                    .check(jsonPath("$.records[0].Id.value").find.exists.saveAs("AppliedPromotionId1"))
                    .headers(header_1))

                 /* *********** DeletePromotionAppliedToCart ********** */
               .exec(http("056_MACD_Deleteanappliedpromotioninthecart")
                .delete(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}/promotions?id=${AppliedPromotionId1}")
                .headers(header_1)
                .check(regex("""INFO","message":"Successfully deleted.""").find.exists))

               .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

               /* ********** Adjustment by Percentage ********** */
               .exec(http("057_MACD_PriceAdjustmentByPercentage")
                .post(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}/items/${LineItem1}/pricing")
                .headers(header_1)
                .body( StringBody("""{
                     "adjustments": [
                       {
                         "AdjustmentValue": -10,
                         "AdjustmentMethod": "Absolute",
                         "DetailType": "ADJUSTMENT",
                         "PricingVariableCode": "OT_STD_PRC",
                         "Field": "OneTimeCharge__c"
                       }
                     ]
                   }""")).asJson
                .check(status.is(200)))

                /* ********** Adjustment by Code ********** */
                .exec(http("058_MACD__PriceAdjustmentByCode")
                 .post(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}/items/${LineItem1}/pricing")
                 .headers(header_1)
                 .body( StringBody("""{
                     "adjustments": [
                       {
                         "AdjustmentValue": 0,
                         "AdjustmentCode":"PE-CODE-54",
                         "AdjustmentMethod": "Absolute",
                         "DetailType": "ADJUSTMENT",
                         "PricingVariableCode": "OT_STD_PRC",
                         "Field": "OneTimeCharge__c",
                         "AdjustmentType":"Adjustment"
                       }
                     ]
                   }""")).asJson
                 .check(status.is(200)))

                 /* ********** CloneCartLineItem ********** */
                .exec(http("059_MACD_Cloneacartlineitem")
                 .post(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}/items/clone")
                 .headers(header_1)
                 .body( StringBody("""{
                 "items": [
                 {"itemId":"${MACDCloneItem}"}
                 ],
                 "hierarchy": 1,
                 "lastItemId": "",
                 "pagesize": 20
                 }""")).asJson
                 .check(regex("""INFO","message":"Clone Successful.""").find.exists))

                 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


                 /* ********** RetrieveCartSummary *********** */
                 .exec(http("060_MACD_RetrieveCartSummary")
                   .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}?price=false&validate=false")
                   .headers(header_1))

               .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

               /* ********** RetrieveCartItems *********** */
               .exec(http("061_MACD_RetrieveCartItems")
               .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items?pagesize=10&price=false&validate=false")
               .headers(header_1)
               .check(regex(""""totalSize":1""").find.exists))
              // .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("SubmitLineItem1")))

//"totalSize":1,
                 /* ********** SubmitOrder ********** */
                 .exec(http("062_MACD_SubmitOrder")
                 .post(uri10 +"/services/apexrest/v2/cpq/carts/${Asset_OrderId}/items/checkout")
                 .headers(header_1)
                 .check(regex("""SUBMIT-100""").find.exists)
                 .body( StringBody("""{
                     "cartId": "${Asset_OrderId}",
                     "skipCheckoutValidation": true
                     }""")).asJson)
                 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

}
}
