package CPQWhitepaper_Final_10LI

import scala.concurrent.duration._
import io.gatling.core.Predef._
import io.gatling.core.structure.ChainBuilder
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._
import io.gatling.jsonpath._
import Headers._
import scala.collection._
import java.time.format.DateTimeFormatter
import java.time.LocalDateTime
import java.time.LocalDate


object Q_Script1_NewCustomerQuote {

  val uri01 = Configuration.Uri01
  val uri05 = Configuration.Uri05
  val uri10 = Configuration.Uri10
  var modifiedItemJson = new StringBuilder()
  val origItemAttrHeirarchy = new StringBuilder()
  val modItemAttrHeirarchy = new StringBuilder()
  val randomNumber = new scala.util.Random
  var randomLineItem = new StringBuilder()
  var pbeEntriesList = Vector[String]()
  var promotionList = Vector[String]()
  var lineItemsList = Vector[String]()
  var randomPBEntry = new StringBuilder()
  var accountName = new StringBuilder()
  var randomPromoId = new StringBuilder()
  var final_formatted_date = new StringBuilder()
  val userFeeder = csv("./src/test/resources/data/CPQ/CPQ_Users.csv").random
  val product_feeder = csv("./src/test/resources/data/CPQ/ProductIds.csv").circular
  //val product_feeder = csv("./src/test/resources/data/CPQ/DebugProductIds.csv").circular
  val promotion_feeder = csv("./src/test/resources/data/CPQ/PromoIds.csv").random
  //val products_ids_loy = csv("./src/test/resources/data/devorg/EPC_BMK_Loyalty_ProductIds.csv").random
  //var date = DateTimeFormatter.ofPattern(“YYYY-MM-dd”).format(java.time.LocalDate.now)
  var Date =  Configuration.date


  val Q_Script1_NewCustomerQuote = scenario("Q_Script1_NewCustomerQuote")

  .exec(session => session.set("PriceListId",Configuration.PriceListId))
  .exec(session => session.set("Pricebook2Id",Configuration.Pricebook2Id))
  .exec(session => session.set("PromotionID1",Configuration.Promotion3PI))
  .exec(session => session.set("PromotionID2",Configuration.Promotion5PI))
  .exec(session => session.set("UpdatePromotionID",Configuration.UpdatePromotion))
  .exec(session => session.set("UpdatePromotionItemID",Configuration.UpdatePromotionItem))
  .exec(session => session.set("PenaltyRulePromotionID",Configuration.PenaltyRulePromotion))


  .feed(userFeeder)
  .exec(http("LDV1_Login")
    .post(uri01 + "/")
    .headers(headers_35)
    .formParam("un", "${username}")
    .formParam("width", "1440")
    .formParam("height", "900")
    .formParam("hasRememberUn", "true")
    .formParam("startURL", "")
    .formParam("loginURL", "")
    .formParam("loginType", "")
    .formParam("useSecure", "true")
    .formParam("local", "")
    .formParam("lt", "standard")
    //.formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
    .formParam("locale", "")
    .formParam("oauth_token", "")
    .formParam("oauth_callback", "")
    .formParam("login", "")
    .formParam("serverid", "")
    .formParam("QCQQ", "M1D2l15jFvl")
    .formParam("display", "page")
    .formParam("username", "${username}")
    .formParam("pw", "${password}")
    .formParam("Login", ""))


//  .feed(userFeeder)
  .exec(http("RESTGetOAuthToken")
    .post("https://test.salesforce.com/services/oauth2/token")
    .header("Content-Type", "application/x-www-form-urlencoded")
    .formParam("password", "${password}")
    .formParam("username", "${username}")
    .formParam("client_secret", "7119599995527965426")
    .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
    .formParam("grant_type", "password")
    .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
    .check(status.is(200)))

    .repeat(25)
    {

    exec(session => session.set("AccountName",""))

    .exec( session => {
      val random_index = randomNumber.nextInt(100000)
      accountName.append("Acc-"+random_index)
      session
    })

    .exec(session => session.set("AccountName",accountName))

    .exec( session => {
      accountName = new StringBuilder()
      session
    })


// Q_01_NewQuote_CPQWP_001_New_CreateAccount
// Q_02_A2QAdd_CPQWP_001_MACD_CreateAccount
// Q_03_A2QUpdate_CPQWP_001_New_CreateAccount
// Q_04_A2QMove_CPQWP_001_New_CreateAccount
// Q_05_A2QDisconnect_CPQWP_001_New_CreateAccount

    /* *********** CreateAccount *********** */
    .exec(http("Q_01_NewQuote_CPQWP_001_CreateAccount")
      .post(uri10 +"/services/data/v44.0/sobjects/account")
      .headers(header_1)
      .check(regex(""""id":"(.*?)"""").find.exists.saveAs("AccountId"))
      .body( StringBody("""
      {
        "Name" : "CPQ${AccountName}",
        "ShippingCity" : "San Francisco",
        "Status__c": "Active"
      }""")).asJson)

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  //  "RecordTypeId" : "012J0000000F2q3IAC",

      /* *********** CreateOpportunity *********** */
      .exec(http("Q_01_NewQuote_CPQWP_002_CreateOpportunity")
        .post(uri10 +"/services/apexrest/v2/carts")
        .headers(header_1)
        .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OpportunityID"))
        .body( StringBody("""{
        "subaction":"createOppty",
        "inputFields":[
      {"AccountId":"${AccountId}"},
      {"StageName":"Prospecting"},
      {"Name":"OppCPQ${AccountName}"},
      {"Type":"New Customer"},
      {"CloseDate":"2020-02-25"},
      {"NumberOfContractedMonths__c":24},
      {"Pricebook2Id":"${Pricebook2Id}"},
      {"pricebookName":"CPQWP-Pricebook"},
      {"pricelistName":"CPQWP-Pricelist"},
      {"OriginatingChannel__c":"Dealer"}
    ]}""")).asJson)

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      /* *********** CreateQuote *********** */
      .exec(http("Q_01_NewQuote_CPQWP_003_CreateQuote")
        .post(uri10 +"/services/apexrest/v2/carts")
        .headers(header_1)
        .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("QuoteID"))
        .body( StringBody("""{
            "subaction":"createQuote",
            "inputFields":[
              {"AccountId":"${AccountId}"},
              {"OpportunityId":"${OpportunityID}"},
              {"status":"Draft"},
              {"Name":"QuoCPQ${AccountName}"},
              {"Pricebook2Id":"${Pricebook2Id}"},
              {"pricebookName":"CPQWP-Pricebook"},
              {"pricelistName":"CPQWP-Pricelist"},
              {"OriginatingChannel__c":"Retail"  }
            ]}""")).asJson)

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      /* ********** get CSRF Token *********** */
      .exec(http("Q_01_NewQuote_CPQWP_004_getCsrf")
      .get(uri05 + "/apex/hybridcpq?id=${QuoteID}")
      .headers(headers_99)
      .check(regex("""\{"name":"doGenericInvoke","len":4,"ns":"","ver":41.0,"csrf":"(.*)"\},\{"name":"doNamedCredentialCallout""").find.exists.saveAs("CSRFToken"))
      .check(regex("""vid":"(.+?)","xhr""").find.exists.saveAs("vid")))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    /* ********** ViewPriceLists *********** */
  .exec(http("Q_01_NewQuote_CPQWP_005_ViewPriceLists")
    .get(uri10 +"/services/apexrest/v2/cpq/carts/${QuoteID}/pricelists")
    //.check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfPBEntries"))
    .headers(header_1))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    /* ********** SetPriceListForCart *********** */
    .exec(http("Q_01_NewQuote_CPQWP_006_SetPriceListfortheQuote")
      .put(uri10 +"/services/apexrest/v2/cpq/carts/${QuoteID}/")
      .headers(header_1)
      .body(StringBody("""{
        "inputFields":
        [
        {
          "PriceListId__c": "${PriceListId}"
        }
        ],
        "cartId": "${QuoteID}",
        "methodName": "updateCarts"
      }""")).asJson
      .check(regex(""""Id":"${QuoteID}"""").find.exists))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      /* ********** GetListOfProductsForCart *********** */
    .exec(http("Q_01_NewQuote_CPQWP_007_Getlistofproductsforcart")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${QuoteID}/products?pagesize=10")
      .check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfPBEntries"))
      .headers(header_1))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      /* ********** RetrieveFilterableProducts *********** */
    .exec(http("Q_01_NewQuote_CPQWP_008_RetrieveFilterableProducts")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${QuoteID}/attributes")
      .check(regex(""""totalSize":1,""").find.exists)
      .headers(header_1))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      /* ********** RetrievePromotions *********** */
      .exec(http("Q_01_NewQuote_CPQWP_009_RetrievePromotions")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${QuoteID}/promotions?pagesize=10")
      .check(jsonPath("$.records[0].id").find.saveAs("PromotionID"))
      .check(jsonPath("$.records[*].id").findAll.saveAs("PromotionList"))
      .headers(header_1))

   .exec( session => {
      promotionList = session("PromotionList").as[Vector[String]]
      session
    })

   .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

     .repeat(1)
     {
           /* ********** AddItemsToCart *********** */
           feed(product_feeder)
           .exec(http("Q_01_NewQuote_CPQWP_010_Additemstocart")
             .post(uri10 +"/services/apexrest/v2/cpq/carts/${QuoteID}/items")
             .headers(header_1)
             .body( StringBody("""{
               "items":[{
                 "itemId":"${Product24LI_ID}"
               }],
               "price":"true",
               "validate":"true",
               "pagesize":20
             }""")).asJson
           .check(regex("""productHierarchyPath":"(.*?)","name":"CPQ-WP-P0-Prod-""").find.exists.saveAs("c_productHierarchyPath"))
           .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("CloneLineItem")))

           //{"totalSize":1,"messages":[{"code":"150","severity":"INFO","message":"Successfully added."}],"actions":{"itempricesupdated":{"rest":{

         //    .check(regex("""totalSize":1""").find.exists))

           .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
     }



          /* ********** getcarts Discount *********** */
             .exec(http("Q_01_NewQuote_CPQWP_011_getcartsDiscount")
              .post(uri05 + "/apexremote")
              .headers(headers_0)
              .check(regex(""""statusCode":200,"""").find.exists)
              .body( StringBody("""
                {"action":"CardCanvasController",
                "method":"doGenericInvoke",
                "data":["CpqAppHandler","getCartsDiscounts","{\"cartId\":\"${QuoteID}\",\"pagesize\":\"10\"}","{\"vlcClass\":\"CpqAppHandler\"}"],"type":"rpc","tid":13,"ctx":{"csrf":"${CSRFToken}","vid":"${vid}","ns":"","ver":41}}""")).asJson)

                .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

          /* ********** CreateNew Discount *********** */
                .exec(http("Q_01_NewQuote_CPQWP_012_CreateNewDiscount")
                 .post(uri05 + "/apexremote")
                 .headers(headers_0)
                 .check(regex(""""statusCode":200,"""").find.exists)
                 .body( StringBody("""
                   {"action":"CardCanvasController",
                     "method":"doGenericInvoke",
                     "data":["CpqAppHandler","postCartsDiscounts","{\"methodName\":\"postCartsDiscounts\",\"cartId\":\"${QuoteID}\",\"items\":{\"records\":[{\"Allocation\":{\"selectedDiscountType\":{\"value\":\"Order\",\"name\":\"Order\",\"$$hashKey\":\"object:1838\"},\"types\":[{\"value\":\"Account\",\"name\":\"Account\",\"$$hashKey\":\"object:1837\"},{\"value\":\"Order\",\"name\":\"Order\",\"$$hashKey\":\"object:1838\"},{\"value\":\"Contract\",\"name\":\"Contract\",\"$$hashKey\":\"object:1839\"}],\"label\":\"Discount Type\"},\"Category\":{\"actions\":{\"rest\":{\"params\":{},\"method\":null,\"link\":null},\"remote\":{\"params\":{\"methodName\":\"getCatalogHierarchy\",\"ContextId\":\"${QuoteID}\",\"includeAllCatalogs\":true,\"cartId\":\"${QuoteID}\"}},\"client\":{\"records\":[],\"params\":{\"methodName\":\"getCatalogHierarchy\",\"ContextId\":\"${QuoteID}\",\"includeAllCatalogs\":true,\"cartId\":\"${QuoteID}\"}}},\"categories\":[],\"value\":\"\",\"label\":\"Category\"},\"Product\":{\"actions\":{\"rest\":{\"params\":{},\"method\":null,\"link\":null},\"remote\":{\"params\":{\"methodName\":\"getCartsProducts\",\"cartId\":\"${QuoteID}\"}},\"client\":{\"records\":[],\"params\":{\"methodName\":\"getCartsProducts\",\"cartId\":\"${QuoteID}\"}}},\"products\":[],\"value\":\"\",\"label\":\"Product\"},\"Discount\":{\"discounts\":[{\"types\":[{\"method\":\"Percent\",\"detailType\":\"Discount\",\"value\":\"%\"},{\"method\":\"Absolute\",\"detailType\":\"Discount\",\"value\":\"$\"}],\"value\":null,\"actions\":{\"rest\":{\"params\":{},\"method\":null,\"link\":null},\"remote\":{\"params\":{\"methodName\":\"getListsOfValues\",\"listkeys\":\"TimePlans,TimePolicies\"}},\"client\":{\"records\":[],\"params\":{}}},\"selectedAdjustmentMethod\":{\"value\":\"%\"},\"chargeType\":\"Recurring\",\"selectedTimePlan\":null,\"selectedTimePolicy\":null,\"label\":\"\",\"$$hashKey\":\"object:1817\"},{\"types\":[{\"method\":\"Percent\",\"detailType\":\"Discount\",\"value\":\"%\",\"$$hashKey\":\"object:1832\"},{\"method\":\"Absolute\",\"detailType\":\"Discount\",\"value\":\"$\",\"$$hashKey\":\"object:1833\"}],\"value\":-15,\"selectedAdjustmentMethod\":{\"method\":\"Absolute\",\"detailType\":\"Discount\",\"value\":\"$\",\"$$hashKey\":\"object:1833\"},\"chargeType\":\"One-time\",\"label\":\"\",\"$$hashKey\":\"object:1816\"}],\"label\":\"Discount\",\"value\":\"\"},\"Duration unit\":{\"label\":\"Duration unit\",\"value\":\"Month\"},\"All items in cart\":{\"label\":\"All items in cart\",\"value\":true},\"End date\":{\"label\":\"End Date\",\"value\":null},\"Active period\":{\"label\":\"Active Period\",\"value\":null},\"Discount Name\":{\"label\":\"Discount Name\",\"value\":\"Custom_Discount\"},\"timePlanList\":[{\"valuekey\":\"a2SJ0000000NGsSMAW\",\"label\":\"Time Plan 1 year\"},{\"valuekey\":\"a2SJ0000000NGsJMAW\",\"label\":\"Time Plan 1 week new\"},{\"valuekey\":\"a2SJ0000000NGsKMAW\",\"label\":\"Time Plan 1 day new\"},{\"valuekey\":\"a2SJ0000000NGsLMAW\",\"label\":\"Time Plan 1 Quater2\"},{\"valuekey\":\"a2SJ0000000NGsMMAW\",\"label\":\"Time Plan 1 Quarter new\"},{\"valuekey\":\"a2SJ0000000NGsNMAW\",\"label\":\"Time Plan 2 Week\"},{\"valuekey\":\"a2SJ0000000NGsOMAW\",\"label\":\"Time Plan 1 Quater\"},{\"valuekey\":\"a2SJ0000000NGsPMAW\",\"label\":\"Time Plan 1 month new\"},{\"valuekey\":\"a2SJ0000000NGsQMAW\",\"label\":\"Time Plan 1 year new\"},{\"valuekey\":\"a2SJ0000000NGsRMAW\",\"label\":\"Time Plan 1 day\"}],\"Description\":{\"value\":\"Custom_Discount\"}}]}}","{\"vlcClass\":\"CpqAppHandler\"}"],
                     "type":"rpc",
                     "tid":37,
                     "ctx":{"csrf":"${CSRFToken}","vid":"${vid}","ns":"","ver":41}}""")).asJson)

                     .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


               /* ********** Apply Discount *********** */
                  .exec(http("Q_01_NewQuote_CPQWP_013_ApplyDiscount")
                   .post(uri05 + "/apexremote")
                   .headers(headers_0)
                   .check(regex(""""statusCode":200,"""").find.exists)
                   .body( StringBody("""
                     {"action":"CardCanvasController",
                     "method":"doGenericInvoke",
                     "data":["CpqAppHandler","postCartsDiscounts","{\"discountTemplateIds\":[\"a2BJ0000000VUGUMA4\"],\"cartId\":\"${QuoteID}\",\"methodName\":\"postCartsDiscounts\"}","{\"vlcClass\":\"CpqAppHandler\"}"],"type":"rpc","tid":20,"ctx":{"csrf":"${CSRFToken}","vid":"${vid}","ns":"","ver":41}}""")).asJson)

                     .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

                     /* ********** Retrieve Discount *********** */
                        .exec(http("Q_01_NewQuote_CPQWP_014_RetrieveDiscount")
                         .post(uri05 + "/apexremote")
                         .headers(headers_0)
                         .check(regex(""""statusCode":200,"""").find.exists)
                          .check(regex(""""QuoteDiscountId__c\\":\{\\\"value\\":\\"(.*?)\\",\\"previousValue\\":n""").find.exists.saveAs("DeleteDiscountID"))
                         .body( StringBody("""
                           {"action":"CardCanvasController",
                           "method":"doGenericInvoke",
                           "data":["CpqAppHandler","getAllApplicableDiscounts","{\"cartId\":\"${QuoteID}\",\"pagesize\":\"10\"}","{\"vlcClass\":\"CpqAppHandler\"}"],"type":"rpc","tid":35,"ctx":{"csrf":"${CSRFToken}","vid":"${vid}","ns":"","ver":41}}""")).asJson)

//QuoteDiscountId__c\":{\"value\":\"a4xJ00000018IcCIAU\",\"previo
          //{"action":"CardCanvasController","method":"doGenericInvoke","data":["CpqAppHandler","deleteCartDiscount","{\"methodName\":\"deleteCartDiscount\",\"id\":\"a4qJ00000006iyYIAQ\",\"cartId\":\"801J0000002DD0VIAW\"}","{\"vlcClass\":\"CpqAppHandler\"}"],"type":"rpc","tid":29,"ctx":{"csrf":"VmpFPSxNakF5TUMwd05TMHdNbFF3TmpvME9Eb3lNaTQzTlROYSxWR0U2YnlObkVab3Q0YWllVTE0b3B3LE1HRmpORE5q","vid":"066J00000011CJa","ns":"","ver":41}}

          .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

          /* ********** Modify Discount *********** */
                .exec(http("Q_01_NewQuote_CPQWP_015_ModifyDiscount")
                 .post(uri05 + "/apexremote")
                 .headers(headers_0)
                 .check(regex(""""statusCode":200,"""").find.exists)
                 .body( StringBody("""
                   {"action":"CardCanvasController",
                     "method":"doGenericInvoke",
                     "data":["CpqAppHandler","configureDiscounts","{\"methodName\":\"configureDiscounts\",\"discountId\":\"${DeleteDiscountID}\",\"cartId\":\"${QuoteID}\",\"items\":{\"records\":[{\"actions\":{\"deleteDiscount\":{\"rest\":{\"params\":{},\"method\":null,\"link\":null},\"remote\":{\"params\":{\"methodName\":\"deleteCartDiscount\",\"id\":\"${DeleteDiscountID}\",\"cartId\":\"${QuoteID}\"}},\"client\":{\"params\":{}}},\"configureDiscounts\":{\"rest\":{\"params\":{},\"method\":null,\"link\":null},\"remote\":{\"params\":{\"methodName\":\"configureDiscounts\",\"discountId\":\"${DeleteDiscountID}\",\"cartId\":\"${QuoteID}\"}},\"client\":{\"params\":{}}}},\"displaySequence\":-1,\"Id\":{\"value\":\"${DeleteDiscountID}\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Record ID\",\"hidden\":null,\"fieldName\":\"Id\",\"editable\":false,\"dataType\":\"ID\",\"alternateValues\":null,\"actions\":{}},\"Name\":{\"value\":\"23LI_Discount\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Name\",\"hidden\":null,\"fieldName\":\"Name\",\"editable\":true,\"dataType\":\"STRING\",\"alternateValues\":null,\"actions\":{}},\"EffectiveEndDate__c\":{\"value\":null,\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Effective End Date\",\"hidden\":null,\"fieldName\":\"EffectiveEndDate__c\",\"editable\":true,\"dataType\":\"DATETIME\",\"alternateValues\":null,\"actions\":{}},\"EffectiveStartDate__c\":{\"value\":null,\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Effective Start Date\",\"hidden\":null,\"fieldName\":\"EffectiveStartDate__c\",\"editable\":true,\"dataType\":\"DATETIME\",\"alternateValues\":null,\"actions\":{}},\"AppliesToAllItems__c\":{\"value\":true,\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Applies To All Items\",\"hidden\":null,\"fieldName\":\"AppliesToAllItems__c\",\"editable\":true,\"dataType\":\"BOOLEAN\",\"alternateValues\":null,\"actions\":{}},\"DurationUnitOfMeasure__c\":{\"value\":\"Month\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Discount Duration Unit of Measure\",\"hidden\":null,\"fieldName\":\"DurationUnitOfMeasure__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}},\"Duration__c\":{\"value\":null,\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Discount Duration\",\"hidden\":null,\"fieldName\":\"Duration__c\",\"editable\":true,\"dataType\":\"DOUBLE\",\"alternateValues\":null,\"actions\":{}},\"ReferenceNumber__c\":{\"value\":\"b789b3d4-3431-916a-1cce-eb068de4c334\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Reference Number\",\"hidden\":null,\"fieldName\":\"ReferenceNumber__c\",\"editable\":true,\"dataType\":\"STRING\",\"alternateValues\":null,\"actions\":{}},\"ApprovalStatus__c\":{\"value\":\"Approved\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"ApprovalStatus\",\"hidden\":null,\"fieldName\":\"ApprovalStatus__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}},\"Description__c\":{\"value\":\"23LI_Discount\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Description\",\"hidden\":null,\"fieldName\":\"Description__c\",\"editable\":true,\"dataType\":\"TEXTAREA\",\"alternateValues\":null,\"actions\":{}},\"DiscountType__c\":{\"value\":\"Order\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Discount Type\",\"hidden\":null,\"fieldName\":\"DiscountType__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}},\"Action__c\":{\"value\":\"New\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Action\",\"hidden\":null,\"fieldName\":\"Action__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}},\"Status__c\":{\"value\":\"Not Activated\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Status\",\"hidden\":null,\"fieldName\":\"Status__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}},\"DiscountTemplateId__c\":{\"value\":\"a2BJ0000000VUGUMA4\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Discount Template\",\"hidden\":null,\"fieldName\":\"DiscountTemplateId__c\",\"editable\":true,\"dataType\":\"REFERENCE\",\"alternateValues\":null,\"actions\":{}},\"Discount Name\":{\"label\":\"Discount Name\",\"value\":\"23LI_Discount\"},\"name\":\"23LI_Discount\",\"Allocation\":{\"label\":\"Discount Type\",\"types\":[{\"value\":\"Account\",\"name\":\"Account\"},{\"value\":\"Order\",\"name\":\"Order\"},{\"value\":\"Contract\",\"name\":\"Contract\"}],\"selectedDiscountType\":{\"value\":\"Order\",\"name\":\"Order\"}},\"All items in cart\":{\"label\":\"All items in cart\",\"value\":\"\"},\"Duration unit\":{\"label\":\"Duration unit\",\"value\":\"Month\"},\"objectName\":\"OrderDiscount__c\",\"Product\":{\"products\":[],\"label\":\"Product\"},\"Category\":{\"categories\":[],\"label\":\"Category\"},\"Status\":{\"label\":\"Status\",\"value\":\"Approved\"},\"Discount\":{\"discounts\":[{\"label\":\"one time charges\",\"chargeType\":\"One-time\",\"selectedAdjustmentMethod\":{\"value\":\"$\"},\"value\":-15,\"types\":[{\"method\":\"Percent\",\"detailType\":\"Discount\",\"value\":\"%\"},{\"method\":\"Absolute\",\"detailType\":\"Discount\",\"value\":\"$\"}],\"$$hashKey\":\"object:2086\"},{\"types\":[{\"method\":\"Percent\",\"detailType\":\"Discount\",\"value\":\"%\"},{\"method\":\"Absolute\",\"detailType\":\"Discount\",\"value\":\"$\"}],\"value\":null,\"actions\":{\"rest\":{\"params\":{},\"method\":null,\"link\":null},\"remote\":{\"params\":{\"methodName\":\"getListsOfValues\",\"listkeys\":\"TimePlans,TimePolicies\"}},\"client\":{\"records\":[],\"params\":{}}},\"selectedAdjustmentMethod\":{\"value\":\"%\"},\"chargeType\":\"Recurring\",\"selectedTimePlan\":null,\"selectedTimePolicy\":null,\"label\":\"\",\"$$hashKey\":\"object:2087\"}],\"label\":\"Discount\"},\"discountPriceAdjustments\":{\"totalSize\":1,\"records\":[{\"displaySequence\":-1,\"Id\":{\"value\":\"a4pJ0000000MArLIAW\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Record ID\",\"hidden\":null,\"fieldName\":\"Id\",\"editable\":false,\"dataType\":\"ID\",\"alternateValues\":null,\"actions\":{}},\"Name\":{\"value\":\"a2BJ0000000VUGUMA4\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Reference Number\",\"hidden\":null,\"fieldName\":\"Name\",\"editable\":true,\"dataType\":\"STRING\",\"alternateValues\":null,\"actions\":{}},\"AdjustmentValue__c\":{\"value\":-10,\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Adjustment Value\",\"hidden\":null,\"fieldName\":\"AdjustmentValue__c\",\"editable\":true,\"dataType\":\"DOUBLE\",\"alternateValues\":null,\"actions\":{}},\"Amount__c\":{\"value\":null,\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Amount\",\"hidden\":null,\"fieldName\":\"Amount__c\",\"editable\":true,\"dataType\":\"CURRENCY\",\"alternateValues\":null,\"actions\":{}},\"PricingVariableId__c\":{\"value\":\"a40J0000001TQ6LIAW\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Pricing Variable\",\"hidden\":null,\"fieldName\":\"PricingVariableId__c\",\"editable\":true,\"dataType\":\"REFERENCE\",\"alternateValues\":null,\"actions\":{}},\"TimePlanId__c\":{\"value\":null,\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Time Plan\",\"hidden\":null,\"fieldName\":\"TimePlanId__c\",\"editable\":true,\"dataType\":\"REFERENCE\",\"alternateValues\":null,\"actions\":{}},\"TimePolicyId__c\":{\"value\":null,\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Time Policy\",\"hidden\":null,\"fieldName\":\"TimePolicyId__c\",\"editable\":true,\"dataType\":\"REFERENCE\",\"alternateValues\":null,\"actions\":{}},\"OrderDiscountId__c\":{\"value\":\"${DeleteDiscountID}\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Order Discount\",\"hidden\":null,\"fieldName\":\"OrderDiscountId__c\",\"editable\":false,\"dataType\":\"REFERENCE\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.Id\":{\"value\":\"a40J0000001TQ6LIAW\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Record ID\",\"hidden\":null,\"fieldName\":\"Id\",\"editable\":false,\"dataType\":\"ID\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.Name\":{\"value\":\"One Time Std Price Adjustment Abs\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Pricing Variable Name\",\"hidden\":null,\"fieldName\":\"Name\",\"editable\":true,\"dataType\":\"STRING\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.IsActive__c\":{\"value\":true,\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Active\",\"hidden\":null,\"fieldName\":\"IsActive__c\",\"editable\":true,\"dataType\":\"BOOLEAN\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.AdjustmentMethod__c\":{\"value\":\"Absolute\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Adjustment Method\",\"hidden\":null,\"fieldName\":\"AdjustmentMethod__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.Aggregation__c\":{\"value\":\"Unit\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Aggregation\",\"hidden\":null,\"fieldName\":\"Aggregation__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.AppliesTo__c\":{\"value\":null,\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Applies To\",\"hidden\":null,\"fieldName\":\"AppliesTo__c\",\"editable\":true,\"dataType\":\"STRING\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.AppliesToVariableId__c\":{\"value\":\"a40J0000001TQ6GIAW\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Applies To Variable\",\"hidden\":null,\"fieldName\":\"AppliesToVariableId__c\",\"editable\":true,\"dataType\":\"REFERENCE\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.ChargeType__c\":{\"value\":\"Adjustment\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Charge Type\",\"hidden\":null,\"fieldName\":\"ChargeType__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.Code__c\":{\"value\":\"OT_STD_PRC_ADJ_ABS\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Code\",\"hidden\":null,\"fieldName\":\"Code__c\",\"editable\":true,\"dataType\":\"STRING\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.CurrencyType__c\":{\"value\":\"Currency\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Currency Type\",\"hidden\":null,\"fieldName\":\"CurrencyType__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.Description__c\":{\"value\":null,\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Description\",\"hidden\":null,\"fieldName\":\"Description__c\",\"editable\":true,\"dataType\":\"TEXTAREA\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.RecurringFrequency__c\":{\"value\":null,\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Frequency\",\"hidden\":null,\"fieldName\":\"RecurringFrequency__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.Scope__c\":{\"value\":\"Line\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Scope\",\"hidden\":null,\"fieldName\":\"Scope__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.SubType__c\":{\"value\":\"Standard\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Sub-Type\",\"hidden\":null,\"fieldName\":\"SubType__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.Type__c\":{\"value\":\"Price\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"Type\",\"hidden\":null,\"fieldName\":\"Type__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}},\"pricingvariableid__r.ValueType__c\":{\"value\":\"Pricing Element\",\"previousValue\":null,\"originalValue\":null,\"messages\":[],\"label\":\"ValueType\",\"hidden\":null,\"fieldName\":\"ValueType__c\",\"editable\":true,\"dataType\":\"PICKLIST\",\"alternateValues\":null,\"actions\":{}}}]},\"$$hashKey\":\"object:2070\"}]}}","{\"vlcClass\":\"CpqAppHandler\"}"],
                     "type":"rpc",
                     "tid":37,
                     "ctx":{"csrf":"${CSRFToken}","vid":"${vid}","ns":"","ver":41}}""")).asJson)

                     .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

                 /* ********** Delete Discount *********** */
                    .exec(http("Q_01_NewQuote_CPQWP_016_DeleteDiscount")
                     .post(uri05 + "/apexremote")
                     .headers(headers_0)
                     .check(regex(""""statusCode":200,"""").find.exists)
                     .body( StringBody("""
                       {"action":"CardCanvasController",
                       "method":"doGenericInvoke",
                       "data":["CpqAppHandler","deleteCartDiscount","{\"methodName\":\"deleteCartDiscount\",\"id\":\"${DeleteDiscountID}\",\"cartId\":\"${QuoteID}\"}","{\"vlcClass\":\"CpqAppHandler\"}"],"type":"rpc","tid":29,"ctx":{"csrf":"${CSRFToken}","vid":"${vid}","ns":"","ver":41}}""")).asJson)

                      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

     /* ********** ViewProductDetails *********** */
     .feed(product_feeder)
     .exec(http("Q_01_NewQuote_CPQWP_017_ViewProductDetails")
       .get(uri10 +"/services/apexrest/v2/cpq/carts/${QuoteID}/products/01uJ000000FwPvlIAF?maxProdListHierarchy=5&includeAttachment=true&filters=AppliesTo__c%3AAccount_Contract&fields=Id%2CName&includeAttributes=true")
       .headers(header_1)
       .check(regex(""""totalSize":1,""").find.exists))

       .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

       /* ********** CloneCartLineItem ********** */
       .exec(http("Q_01_NewQuote_CPQWP_018_Cloneacartlineitem")
        .post(uri10 +"/services/apexrest/v2/cpq/carts/${QuoteID}/items/clone")
        .headers(header_1)
        .body( StringBody("""{
          "items": [
          {"itemId":"${CloneLineItem}"}
          ],
          "hierarchy": 1,
          "lastItemId": "",
          "pagesize": 20
        }""")).asJson
        .check(regex("""INFO","message":"Clone Successful.""").find.exists))

       .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)



     /* ********** GetCartLineItems *********** */
     .exec(http("Q_01_NewQuote_CPQWP_019_GetCartLineItems")
       .get(uri10 +"/services/apexrest/v2/cpq/carts/${QuoteID}/items?pagesize=10&price=false&validate=false")
       .headers(header_1)
       .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1"))
       .check(jsonPath("$.records[1].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem2")))

       .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


       /* ********** GetCartItemsByItemId *********** */
       .exec(http("Q_01_NewQuote_CPQWP_020_Getlineitemdetails")
         .get(uri10 +"/services/apexrest/v2/cpq/carts/${QuoteID}/items")
         .queryParamSeq(Seq(("id", "${LineItem1}")))
         .headers(header_1)
         .check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))

       .exec(session => {
         //originalItemJson.append(session("capturedItemHierarchy").as[String])
         modifiedItemJson = new StringBuilder()
         modifiedItemJson.append("""{"items":{"records":[{"displaySequence":-1,""").append(session("capturedItemHierarchy").as[String]).append("}]}}")
         session
       })

    //   .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

       /* ********** UpdateItemsInCart *********** */
       /* Updating the Quantity from default 1.00 to 3.00 */
       .exec(http("Q_01_NewQuote_CPQWP_021_Updatecartlineitem")
         .put(uri10 +"/services/apexrest/v2/cpq/carts/${QuoteID}/items")
         .headers(header_1)
         .body(StringBody(session =>  modifiedItemJson.replaceAllLiterally(""""Quantity":{"value":1.00""",""""Quantity":{"value":3.00""").toString() )).asJson
         .check(regex("""INFO","message":"Successfully updated.""").find.exists))

       .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


       /* ********** VIewPriceWaterfall *********** */
       .exec(http("Q_01_NewQuote_CPQWP_022_VIewPriceWaterfall")
         .get(uri10 +"/services/apexrest/v2/cpq/carts/${QuoteID}/items/${LineItem1}/pricing?fields=Id%2CName")
         .headers(header_1)
        .check(regex(""""totalSize":1,"""").find.exists))

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    /* ********** AddPromotionToCart *********** */
        .feed(promotion_feeder)
        .exec(http("Q_01_NewQuote_CPQWP_023_Addapromotion")
         .post(uri10 +"/services/apexrest/v2/cpq/carts/${QuoteID}/promotions")
         .headers(header_1)
         .body( StringBody("""{
           "items": [{"itemId":"${PromoID}"}],
           "promotionId":"${PromoID}",
           "cartId":"${QuoteID}",
           "methodName":"postCartsPromoItems"
         }""")).asJson
         .check(status.is(200)))

         .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

         /* ********** DeleteItemFromCart********** */
         .exec(http("Q_01_NewQuote_CPQWP_024_Deleteanitemfromthecart")
           .delete(uri10 +"/services/apexrest/v2/cpq/carts/${QuoteID}/items/${LineItem2}")
           .headers(header_1)
           .check(regex("""INFO","message":"Successfully deleted.""").find.exists))

     .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

     /* *********** GetPromotionsAppliedToCart ********** */
     .exec(http("Q_01_NewQuote_CPQWP_025_Getpromotionsappliedtocart")
       .get(uri10 +"/services/apexrest/v2/cpq/carts/${QuoteID}/promotions?subaction=getPromotionsAppliedToCart")
       .check(jsonPath("$.records[0].Id.value").find.exists.saveAs("AppliedPromotionId1"))
       .headers(header_1))

       .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        /* *********** DeletePromotionAppliedToCart ********** */
      .exec(http("Q_01_NewQuote_CPQWP_026_Deleteanappliedpromotioninthecart")
       .delete(uri10 +"/services/apexrest/v2/cpq/carts/${QuoteID}/promotions?id=${AppliedPromotionId1}")
       .headers(header_1)
       .check(regex("""INFO","message":"Successfully deleted.""").find.exists))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


      /* ********** ExpandParentItemtoDisplayNextLevelChildren *********** */
      .exec(http("Q_01_NewQuote_CPQWP_027_ExpandParentItemtoDisplayNextLevelChildren")
        .get(uri10 +"/services/apexrest/v2/cpq/carts/${QuoteID}/items/${LineItem1}/expand?productHierarchyPath=${c_productHierarchyPath}")
        .headers(header_1)
        .check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        /* ********** RetrieveCartSummary *********** */
        .exec(http("Q_01_NewQuote_CPQWP_028_RetrieveCartSummary")
          .get(uri10 +"/services/apexrest/v2/cpq/carts/${QuoteID}?price=false&validate=false")
          .headers(header_1)
          .check(status.is(200)))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    /* ********** RetrieveCartItems *********** */
    .exec(http("Q_01_NewQuote_CPQWP_029_RetrieveCartItems")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${QuoteID}/items?pagesize=10&price=false&validate=false")
      .headers(header_1)
      .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1")))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  /* ********** CreateOrderFromQuote ********** */
        .exec(http("Q_01_NewQuote_CPQWP_030_CreateOrderFromQuote")
        .post(uri10 +"/services/apexrest/v2/cpq/carts/${QuoteID}/items/checkout")
        .headers(header_1)
        //.check(regex("""Account""").find.exists)
        .body( StringBody("""{
        "items":[
        {"itemId":"${LineItem1}"}
        ],
        "hierarchy":1,
        "lastItemId":"",
        "pagesize":20
        }""")).asJson
        .check(regex("""totalSize":1,"records":\[\{"displaySequence":-1,"id":"(.*)","objectType":"Order","clonedObjectIds":"null""").find.exists.saveAs("SubmitOrderID1")))

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  /* ********** SubmitOrder ********** */
  .exec(http("Q_01_NewQuote_CPQWP_031_SubmitOrder")
  .post(uri10 +"/services/apexrest/v2/cpq/carts/${SubmitOrderID1}/items/checkout")
  .headers(header_1)
  .check(regex("""SUBMIT-100""").find.exists)
  .body( StringBody("""{
  "cartId": "${SubmitOrderID1}",
  "skipCheckoutValidation": true
  }""")).asJson)


  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

          }
}
