package CPQWhitepaper_Final_10LI

import java.time.format.DateTimeFormatter
import java.time.LocalDateTime
import java.time.LocalDate

object Configuration
 {

/* Perf2 Details
	val BaseUrl = "https://c.cs8.visual.force.com"
	val Uri01 = "https://test.salesforce.com"
	val Uri05 = "https://c.cs8.visual.force.com"
	val Uri10 = "https://cs8.salesforce.com"
  var date = DateTimeFormatter.ofPattern("YYYY-MM-dd").format(java.time.LocalDate.now)

	val PriceListId = "a2Pg0000001RPfpEAG"	//Pricing-Sample-PL

	val Promotion3PI = "a2eg0000001rZo9AAE" // 	PRCNG-SMPL-PROMOTION-1

  val Pricebook2Id = "01sJ0000000GVKMIA4" //CPQWP-Pricebook

	val Promotion5PI = "a341U000000ccJQQAY" //BMK-Promo-1549615894869

	val UpdatePromotion = "a341U000000ccJLQAY" // BMK-Promo-1549615893377
	val UpdatePromotionItem = "01u1U000000lc0JQAQ" // BMK-Promo-1549615893377-Prod

	val PenaltyRulePromotion = "a341U000000ccJGQAY" // BMK-Promo-1549615890400

  val MinWaitMs = 2000
  val MaxWaitMs = 3000

---->*/

    val BaseUrl = "https://c.cs10.visual.force.com"
	val Uri01 = "https://test.salesforce.com"
	val Uri05 = "https://c.cs10.visual.force.com"
	val Uri10 = "https://cs10.salesforce.com"
    var date = DateTimeFormatter.ofPattern("YYYY-MM-dd").format(java.time.LocalDate.now)

	val PriceListId = "a1yJ0000000WSsGIAW"	//CPQWP-Pricelist

  val Pricebook2Id = "01sJ0000000GVKMIA4" //CPQWP-Pricebook

	val Promotion5PI = "a2BJ0000000UhNBMA0" // 	CPQ-WP-P0-Prom-1

	val Promotion3PI = "a2BJ0000000UhOmMAK" //CPQ-WP-P0-Prom-100

	val UpdatePromotion = "a2BJ0000000UhNBMA0" // CPQ-WP-P0-Prom-1
	val UpdatePromotionItem = "a3DJ00000037Vk0MAE" // BNDL-PROMOTION-2

	val PenaltyRulePromotion = "a3DJ00000037Vk0MAE" // BNDL-PROMOTION-2

	val MinWaitMs = 2000
	val MaxWaitMs = 3000


}
