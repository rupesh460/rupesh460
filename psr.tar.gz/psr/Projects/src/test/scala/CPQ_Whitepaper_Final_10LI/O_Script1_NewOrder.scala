package CPQWhitepaper_Final_10LI

import scala.concurrent.duration._
import io.gatling.core.Predef._
import io.gatling.core.structure.ChainBuilder
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._
import io.gatling.jsonpath._
import Headers._
import scala.collection._
import java.time.format.DateTimeFormatter
import java.time.LocalDateTime
import java.time.LocalDate

import io.gatling.core.feeder._
import java.util.Base64
import java.nio.charset.StandardCharsets
import scala.util.matching.Regex


object O_Script1_NewOrder {

  val uri01 = Configuration.Uri01
  val uri05 = Configuration.Uri05
  val uri10 = Configuration.Uri10
  var modifiedItemJson = new StringBuilder()
  val origItemAttrHeirarchy = new StringBuilder()
  val modItemAttrHeirarchy = new StringBuilder()
  val randomNumber = new scala.util.Random
  var randomLineItem = new StringBuilder()
  var pbeEntriesList = Vector[String]()
  var promotionList = Vector[String]()
  var lineItemsList = Vector[String]()
  var randomPBEntry = new StringBuilder()
  var accountName = new StringBuilder()
  var randomPromoId = new StringBuilder()
  var final_formatted_date = new StringBuilder()
  val userFeeder = csv("./src/test/resources/data/CPQ/CPQ_Users.csv").random
  val product_feeder = csv("./src/test/resources/data/CPQ/ProductIds.csv").circular
  //val product_feeder = csv("./src/test/resources/data/CPQ/DebugProductIds.csv").circular
  val promotion_feeder = csv("./src/test/resources/data/CPQ/PromoIds.csv").random
  //val products_ids_loy = csv("./src/test/resources/data/devorg/EPC_BMK_Loyalty_ProductIds.csv").random
  //var date = DateTimeFormatter.ofPattern(“YYYY-MM-dd”).format(java.time.LocalDate.now)
  var Date =  Configuration.date

  val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
  val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
  val password_v = (passwordByEnv.get("perf3").toString)
  val password_encoded = password_v.substring(12,(password_v.length - 2 ))
  val credentials = new String(Base64.getDecoder.decode(password_encoded))


  val O_Script1_NewOrder = scenario("O_Script1_NewOrder")

  .exec(session => session.set("PriceListId",Configuration.PriceListId))
  .exec(session => session.set("Pricebook2Id",Configuration.Pricebook2Id))
  .exec(session => session.set("PromotionID1",Configuration.Promotion3PI))
  .exec(session => session.set("PromotionID2",Configuration.Promotion5PI))
  .exec(session => session.set("UpdatePromotionID",Configuration.UpdatePromotion))
  .exec(session => session.set("UpdatePromotionItemID",Configuration.UpdatePromotionItem))
  .exec(session => session.set("PenaltyRulePromotionID",Configuration.PenaltyRulePromotion))

.exec(session => session.set("password",credentials))

  .feed(userFeeder)
  .exec(http("LDV1_Login")
    .post(uri01 + "/")
    .headers(headers_35)
    .formParam("un", "${username}")
    .formParam("width", "1440")
    .formParam("height", "900")
    .formParam("hasRememberUn", "true")
    .formParam("startURL", "")
    .formParam("loginURL", "")
    .formParam("loginType", "")
    .formParam("useSecure", "true")
    .formParam("local", "")
    .formParam("lt", "standard")
    //.formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
    .formParam("locale", "")
    .formParam("oauth_token", "")
    .formParam("oauth_callback", "")
    .formParam("login", "")
    .formParam("serverid", "")
    .formParam("QCQQ", "M1D2l15jFvl")
    .formParam("display", "page")
    .formParam("username", "${username}")
    .formParam("pw", "${password}")
    .formParam("Login", ""))

//  .feed(userFeeder)
  .exec(http("RESTGetOAuthToken")
    .post("https://test.salesforce.com/services/oauth2/token")
    .header("Content-Type", "application/x-www-form-urlencoded")
    .formParam("password", "${password}")
    .formParam("username", "${username}")
    .formParam("client_secret", "7119599995527965426")
    .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
    .formParam("grant_type", "password")
    .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
    .check(status.is(200)))

    .repeat(10)
    {

    exec(session => session.set("AccountName",""))

    .exec( session => {
      val random_index = randomNumber.nextInt(100000)
      accountName.append("Acc-"+random_index)
      session
    })

    .exec(session => session.set("AccountName",accountName))

    .exec( session => {
      accountName = new StringBuilder()
      session
    })

    //O_01_NewOrder_CPQWP_001_New_CreateAccount

    /* *********** CreateAccount *********** */
    .exec(http("O_01_NewOrder_CPQWP_001_New_CreateAccount")
      .post(uri10 +"/services/data/v44.0/sobjects/account")
      .headers(header_1)
      .check(regex(""""id":"(.*?)"""").find.exists.saveAs("AccountId"))
      .body( StringBody("""
      {
        "Name" : "CPQ${AccountName}",
        "ShippingCity" : "San Francisco",
        "Status__c": "Active"
      }""")).asJson)

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  //  "RecordTypeId" : "012J0000000F2q3IAC",


  .exec( session => {
    val maxdate = Date
    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
    val dateforcurrentrun = LocalDate.parse(maxdate,formatter).plusDays(1)
    final_formatted_date.append(dateforcurrentrun)
    session
  })

  .exec( session => session.set("DATE", final_formatted_date ) )
  .exec( session => {
    final_formatted_date = new StringBuilder()
    session
  })

  /* *********** CreateOrder *********** */
  .exec(http("O_01_NewOrder_CPQWP_002_CreateOrder")
    .post(uri10 +"/services/apexrest/v2/carts")
    .headers(header_1)
    .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
    .body( StringBody("""{"subaction":"createOrder",
      "inputFields":[
      {"AccountId":"${AccountId}"},
      {"PriceListId__c":"${PriceListId}"},
      {"Name":"Bmk-Order"},{"Status":"Draft"},
      {"EffectiveDate":"${DATE}"}
      ]}""")).asJson)

//${Date}4/24/2020

.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

/* ********** get CSRF Token *********** */
.exec(http("O_01_NewOrder_CPQWP_003_New_getCsrf")
.get(uri05 + "/apex/hybridcpq?id=${OrderID}")
.headers(headers_99)
.check(regex("""\{"name":"doGenericInvoke","len":4,"ns":"","ver":41.0,"csrf":"(.*)"\},\{"name":"doNamedCredentialCallout""").find.exists.saveAs("CSRFToken"))
.check(regex("""vid":"(.+?)","xhr""").find.exists.saveAs("vid")))

.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
    /* ********** ViewPriceLists *********** */
  .exec(http("O_01_NewOrder_CPQWP_004_ViewPriceLists")
    .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/pricelists")
    //.check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfPBEntries"))
    .headers(header_1))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    /* ********** SetPriceListForCart *********** */
    .exec(http("O_01_NewOrder_CPQWP_005_SetPriceListfortheQuote")
      .put(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/")
      .headers(header_1)
      .body(StringBody("""{
        "inputFields":
        [
        {
          "PriceListId__c": "${PriceListId}"
        }
        ],
        "cartId": "${OrderID}",
        "methodName": "updateCarts"
      }""")).asJson
      .check(regex(""""Id":"${OrderID}"""").find.exists))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      /* ********** GetListOfProductsForCart *********** */
    .exec(http("O_01_NewOrder_CPQWP_006_Getlistofproductsforcart")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/products?pagesize=10")
      .check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfPBEntries"))
      .headers(header_1))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      /* ********** RetrieveFilterableProducts *********** */
    .exec(http("O_01_NewOrder_CPQWP_007_RetrieveFilterableProducts")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/attributes")
      .check(regex(""""totalSize":1,""").find.exists)
      .headers(header_1))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      /* ********** RetrievePromotions *********** */
      .exec(http("O_01_NewOrder_CPQWP_008_RetrievePromotions")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/promotions?pagesize=10")
      .check(jsonPath("$.records[0].id").find.saveAs("PromotionID"))
      .check(jsonPath("$.records[*].id").findAll.saveAs("PromotionList"))
      .headers(header_1))

   .exec( session => {
      promotionList = session("PromotionList").as[Vector[String]]
      session
    })

   .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


     .repeat(1)
     {
           /* ********** AddItemsToCart *********** */
           feed(product_feeder)
           .exec(http("O_01_NewOrder_CPQWP_009_Additemstocart")
             .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
             .headers(header_1)
             .body( StringBody("""{
               "items":[{
                 "itemId":"${Product24LI_ID}"
               }],
               "price":"true",
               "validate":"true",
               "pagesize":20
             }""")).asJson
           .check(regex("""productHierarchyPath":"(.*?)","name":"CPQ-WP-P0-Prod-""").find.exists.saveAs("c_productHierarchyPath"))
           .check(jsonPath("$.records[0].lineItems.records[0].actions.updateitems.rest.params.items[0]..itemId").find.saveAs("CloneLineItem")))

           //{"totalSize":1,"messages":[{"code":"150","severity":"INFO","message":"Successfully added."}],"actions":{"itempricesupdated":{"rest":{

         //    .check(regex("""totalSize":1""").find.exists))

           .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
     }


//{"action":"CardCanvasController","method":"doGenericInvoke","data":["CpqAppHandler","getCartsDiscounts","{\"cartId\":\"801J0000002DD0V\",\"includeIneligible\":\"true\",\"includeProducts\":\"true\",\"localeCode\":\"en_US\",\"offsetSize\":\"0\",\"pagesize\":\"10\"}","{\"vlcClass\":\"CpqAppHandler\"}"],"type":"rpc","tid":13,"ctx":{"csrf":"VmpFPSxNakF5TUMwd05TMHdNbFF3T0Rvd05qb3dPQzR3TXpoYSx2c3hDVGpDY2hCTk45Wnp4TXFGX1NMLE1HRmpORE5q","vid":"066J00000011CJa","ns":"","ver":41}}

/* ********** getcarts Discount *********** */
   .exec(http("O_01_NewOrder_CPQWP_010_getcartsDiscount")
    .post(uri05 + "/apexremote")
    .headers(headers_0)
    .check(regex(""""statusCode":200,"""").find.exists)
    .body( StringBody("""
      {"action":"CardCanvasController",
      "method":"doGenericInvoke",
      "data":["CpqAppHandler","getCartsDiscounts","{\"cartId\":\"${OrderID}\",\"pagesize\":\"10\"}","{\"vlcClass\":\"CpqAppHandler\"}"],"type":"rpc","tid":13,"ctx":{"csrf":"${CSRFToken}","vid":"${vid}","ns":"","ver":41}}""")).asJson)

.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

/* ********** CreateNew Discount *********** */
      .exec(http("O_01_NewOrder_CPQWP_011_CreateNewDiscount")
       .post(uri05 + "/apexremote")
       .headers(headers_0)
       .check(regex(""""statusCode":200,"""").find.exists)
       .body(ElFileBody("./src/test/resources/bodies/CPQ/10LI/CreateNewDiscount.txt")))

           .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


     /* ********** Apply Discount *********** */
        .exec(http("O_01_NewOrder_CPQWP_012_ApplyDiscount")
         .post(uri05 + "/apexremote")
         .headers(headers_0)
         .check(regex(""""statusCode":200,"""").find.exists)
         .body(ElFileBody("./src/test/resources/bodies/CPQ/10LI/ApplyDiscount.txt")))

           .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

           /* ********** Retrieve Discount *********** */
              .exec(http("O_01_NewOrder_CPQWP_013_RetrieveDiscount")
               .post(uri05 + "/apexremote")
               .headers(headers_0)
               .check(regex(""""statusCode":200,"""").find.exists)
                .check(regex(""""OrderDiscountId__c\\":\{\\\"value\\":\\"(.*?)\\",\\"previousValue\\":n""").find.exists.saveAs("DeleteDiscountID"))
                .body(ElFileBody("./src/test/resources/bodies/CPQ/10LI/RetrieveDiscount.txt")))

//{"action":"CardCanvasController","method":"doGenericInvoke","data":["CpqAppHandler","deleteCartDiscount","{\"methodName\":\"deleteCartDiscount\",\"id\":\"a4qJ00000006iyYIAQ\",\"cartId\":\"801J0000002DD0VIAW\"}","{\"vlcClass\":\"CpqAppHandler\"}"],"type":"rpc","tid":29,"ctx":{"csrf":"VmpFPSxNakF5TUMwd05TMHdNbFF3TmpvME9Eb3lNaTQzTlROYSxWR0U2YnlObkVab3Q0YWllVTE0b3B3LE1HRmpORE5q","vid":"066J00000011CJa","ns":"","ver":41}}
    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

/* ********** Modify Discount *********** */
      .exec(http("O_01_NewOrder_CPQWP_014_ModifyDiscount")
       .post(uri05 + "/apexremote")
       .headers(headers_0)
       .check(regex(""""statusCode":200,"""").find.exists)
      .body(ElFileBody("./src/test/resources/bodies/CPQ/10LI/ModifyDiscount.txt")))

           .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

       /* ********** Delete Discount *********** */
          .exec(http("O_01_NewOrder_CPQWP_015_DeleteDiscount")
           .post(uri05 + "/apexremote")
           .headers(headers_0)
           .check(regex(""""statusCode":200,"""").find.exists)
            .body(ElFileBody("./src/test/resources/bodies/CPQ/10LI/DeleteDiscount.txt")))

             .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

     /* ********** ViewProductDetails *********** */
     .feed(product_feeder)
     .exec(http("O_01_NewOrder_CPQWP_016_ViewProductDetails")
       .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/products/01uJ000000FwPvlIAF?maxProdListHierarchy=5&includeAttachment=true&filters=AppliesTo__c%3AAccount_Contract&fields=Id%2CName&includeAttributes=true")
       .headers(header_1)
       .check(regex(""""totalSize":1,""").find.exists))

       .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

       /* ********** CloneCartLineItem ********** */
       .exec(http("O_01_NewOrder_CPQWP_017_Cloneacartlineitem")
        .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/clone")
        .headers(header_1)
        .body( StringBody("""{
          "items": [
          {"itemId":"${CloneLineItem}"}
          ],
          "hierarchy": 1,
          "lastItemId": "",
          "pagesize": 20
        }""")).asJson
        .check(regex("""INFO","message":"Clone Successful.""").find.exists))

       .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

       /* ********** GetCartLineItems *********** */
       .exec(http("O_01_NewOrder_CPQWP_018_GetCartLineItems")
         .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items?pagesize=10&price=false&validate=false")
         .headers(header_1)
         .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1")))
        // .check(jsonPath("$.records[1].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem2")))

         .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

       /* ********** GetCartItemsByItemId *********** */
       .exec(http("O_01_NewOrder_CPQWP_019_Getlineitemdetails")
         .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
         .queryParamSeq(Seq(("id", "${LineItem1}")))
         .headers(header_1)
         .check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))

       .exec(session => {
         //originalItemJson.append(session("capturedItemHierarchy").as[String])
         modifiedItemJson = new StringBuilder()
         modifiedItemJson.append("""{"items":{"records":[{"displaySequence":-1,""").append(session("capturedItemHierarchy").as[String]).append("}]}}")
         session
       })

    //   .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

       /* ********** UpdateItemsInCart *********** */
       /* Updating the Quantity from default 1.00 to 3.00 */
       .exec(http("O_01_NewOrder_CPQWP_020_Updatecartlineitem")
         .put(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
         .headers(header_1)
         .body(StringBody(session =>  modifiedItemJson.replaceAllLiterally(""""Quantity":{"value":1.00""",""""Quantity":{"value":3.00""").toString() )).asJson
         .check(regex("""INFO","message":"Successfully updated.""").find.exists))

       .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


       /* ********** VIewPriceWaterfall *********** */
       .exec(http("O_01_NewOrder_CPQWP_021_ViewPriceWaterfall")
         .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/${LineItem1}/pricing?fields=Id%2CName")
         .headers(header_1)
        .check(regex(""""totalSize":1,"""").find.exists))

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    /* ********** AddPromotionToCart *********** */
        .feed(promotion_feeder)
        .exec(http("O_01_NewOrder_CPQWP_022_Addapromotion")
         .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/promotions")
         .headers(header_1)
         .body( StringBody("""{
           "items": [{"itemId":"${PromoID}"}],
           "promotionId":"${PromoID}",
           "cartId":"${OrderID}",
           "methodName":"postCartsPromoItems"
         }""")).asJson
         .check(status.is(200)))

         .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

         /* ********** DeleteItemFromCart********** */
         .exec(http("O_01_NewOrder_CPQWP_023_Deleteanitemfromthecart")
           .delete(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/${CloneLineItem}")
           .headers(header_1)
           .check(regex("""INFO","message":"Successfully deleted.""").find.exists))

     .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

     /* *********** GetPromotionsAppliedToCart ********** */
     .exec(http("O_01_NewOrder_CPQWP_024_Getpromotionsappliedtocart")
       .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/promotions?subaction=getPromotionsAppliedToCart")
       .check(jsonPath("$.records[0].Id.value").find.exists.saveAs("AppliedPromotionId1"))
       .headers(header_1))

       .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        /* *********** DeletePromotionAppliedToCart ********** */
      .exec(http("O_01_NewOrder_CPQWP_025_Deleteanappliedpromotioninthecart")
       .delete(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/promotions?id=${AppliedPromotionId1}")
       .headers(header_1)
       .check(regex("""INFO","message":"Successfully deleted.""").find.exists))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


      /* ********** ExpandParentItemtoDisplayNextLevelChildren *********** */
      .exec(http("O_01_NewOrder_CPQWP_026_ExpandParentItemtoDisplayNextLevelChildren")
        .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/${LineItem1}/expand?productHierarchyPath=${c_productHierarchyPath}")
        .headers(header_1)
        .check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        /* ********** RetrieveCartSummary *********** */
        .exec(http("O_01_NewOrder_CPQWP_027_RetrieveCartSummary")
          .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}?price=false&validate=false")
          .headers(header_1))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    /* ********** RetrieveCartItems *********** */
    .exec(http("O_01_NewOrder_CPQWP_028_RetrieveCartItems")
      .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items?pagesize=10&price=false&validate=false")
      .headers(header_1)
      .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1")))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      /* ********** SubmitOrder ********** */
      .exec(http("O_01_NewOrder_CPQWP_029_SubmitOrder")
      .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/checkout")
      .headers(header_1)
      .check(regex("""SUBMIT-100""").find.exists)
      .body( StringBody("""{
        "items":[
        {"itemId":"${LineItem1}"}
        ],
        "hierarchy":1,
        "lastItemId":"",
        "pagesize":20
      }""")).asJson)

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
}
}
