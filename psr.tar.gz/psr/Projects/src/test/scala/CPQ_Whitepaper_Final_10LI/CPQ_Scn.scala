package CPQWhitepaper_Final_10LI

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._

class CPQ_Scn extends Simulation {

	val httpConf = http
		.baseUrl(Configuration.BaseUrl)
		.inferHtmlResources(BlackList(""".*\.js""", """.*\.css""", """.*\.gif""", """.*\.jpeg""", """.*\.jpg""", """.*\.ico""", """.*\.woff""", """.*\.(t|o)tf""", """.*\.png"""), WhiteList())
		.acceptHeader("*/*")
		.acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8")
		.acceptEncodingHeader("gzip, deflate, sdch")
		.acceptLanguageHeader("en-US,en;q=0.8")
		.disableCaching
		.contentTypeHeader("application/x-www-form-urlencoded; charset=UTF-8")
		.userAgentHeader("Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:41.0) Gecko/20100101 Firefox/41.0")

	val rampUpTimeSecs = Integer.getInteger("rampUpTimeSecs", 1)
	val cpq_Whitepaper_users = Integer.getInteger("cpq_Whitepaper_users", 1)
	val D_Script0_DataCreation_users = Integer.getInteger("D_Script0_DataCreation_users", 1)
	val D_Script1_DataCreation_users = Integer.getInteger("D_Script1_DataCreation_users", 1)
	val Q_Script1_NewCustomerQuote_users = Integer.getInteger("Q_Script1_NewCustomerQuote_users", 1)
	val Q_Script2_A2QADD_users = Integer.getInteger("Q_Script2_A2QADD_users")
	val Q_Script3_A2QUpdate_users = Integer.getInteger("Q_Script3_A2QUpdate_users")
	val Q_Script4_A2QMove_users = Integer.getInteger("Q_Script4_A2QMove_users")
	val Q_Script5_A2QDisconnect_users = Integer.getInteger("Q_Script5_A2QDisconnect_users")
	val O_Script1_NewOrder_users = Integer.getInteger("O_Script1_NewOrder_users")
	val O_Script2_A2OAdd_users = Integer.getInteger("O_Script2_A2OAdd_users")
	val O_Script3_A2OUpdate_users = Integer.getInteger("O_Script3_A2OUpdate_users")
	val O_Script4_A2OMove_users = Integer.getInteger("O_Script4_A2OMove_users")
	val O_Script5_A2ODisconnect_users = Integer.getInteger("O_Script5_A2ODisconnect_users")

	val maxDurationSecs = Integer.getInteger("maxDurationSecs", 1)
	val testDuration = Integer.getInteger("testDuration",1)

	setUp(

//mvn gatling:test -X -Dgatling.simulationClass=CPQWhitepaper_Final.CPQ_Scn -DrampUpTimeSecs=8 -Dcpq_Whitepaper_users=1  -DmaxDurationSecs=1500

//mvn gatling:test -X -Dgatling.simulationClass=CPQWhitepaper_Final.CPQ_Scn -DrampUpTimeSecs=5 -DScript0_DataCreation_users=1 -DScript1_NewCustomerQuote_users=0 -DScript2_A2QADD_users=0 -DScript3_A2QUpdate_users=0 -DScript4_A2QMove_users=0 -DScript5_A2QDisconnect_users=0  -DmaxDurationSecs=1500

//mvn gatling:test -X -Dgatling.simulationClass=CPQWhitepaper_Final.CPQ_Scn -DrampUpTimeSecs=10 -DD_Script0_DataCreation_users=1 -DQ_Script1_NewCustomerQuote_users=1 -DQ_Script2_A2QADD_users=1 -DQ_Script3_A2QUpdate_users=1 -DQ_Script4_A2QMove_users=1 -DQ_Script5_A2QDisconnect_users=1 -DO_Script1_NewOrder_users=1 -DO_Script2_A2OAdd_users=1 -DO_Script3_A2OUpdate_users=1 -DO_Script4_A2OMove_users=1 -DO_Script5_A2ODisconnect_users=1 -DmaxDurationSecs=1500



		//--------CPQ Quote Scenario----------
			//	Script5_A2QDisconnect.cpq_Whitepaper.inject(rampUsers(cpq_Whitepaper_users) during (rampUpTimeSecs seconds)).protocols(httpConf)).maxDuration(maxDurationSecs)

		//		Benchmark.cpq_base_apis.inject(rampUsers(cpq_base_apis_users) during (rampUpTimeSecs seconds)).protocols(httpConf),
			//		Benchmark.cpq_diff_cart_shapes.inject(rampUsers(cpq_diff_cart_shapes_users) during (rampUpTimeSecs seconds)).protocols(httpConf)).maxDuration(maxDurationSecs)

//--------CPQOrderFLOW--------
CPQ_OrderFlow.cpq_Whitepaper.inject(rampUsers(cpq_Whitepaper_users) during (rampUpTimeSecs seconds)).protocols(httpConf)).maxDuration(maxDurationSecs)


//--------CPQQuoteFLOW--------
//CPQ_QuoteFlow1.cpq_Whitepaper.inject(rampUsers(cpq_Whitepaper_users) during (rampUpTimeSecs seconds)).protocols(httpConf)).maxDuration(maxDurationSecs)


/*
			D_Script0_DataCreation.D_Script0_DataCreation.inject(rampUsers(D_Script0_DataCreation_users) during (rampUpTimeSecs seconds)).protocols(httpConf),
			D_Script1_DataCreation.D_Script1_DataCreation.inject(rampUsers(D_Script1_DataCreation_users) during (rampUpTimeSecs seconds)).protocols(httpConf),
			Q_Script1_NewCustomerQuote.Q_Script1_NewCustomerQuote.inject(rampUsers(Q_Script1_NewCustomerQuote_users) during (rampUpTimeSecs seconds)).protocols(httpConf),
			Q_Script2_A2QADD.Q_Script2_A2QADD.inject(rampUsers(Q_Script2_A2QADD_users) during (rampUpTimeSecs seconds)).protocols(httpConf),
			Q_Script3_A2QUpdate.Q_Script3_A2QUpdate.inject(rampUsers(Q_Script3_A2QUpdate_users) during (rampUpTimeSecs seconds)).protocols(httpConf),
			Q_Script4_A2QMove.Q_Script4_A2QMove.inject(rampUsers(Q_Script4_A2QMove_users) during (rampUpTimeSecs seconds)).protocols(httpConf),
			Q_Script5_A2QDisconnect.Q_Script5_A2QDisconnect.inject(rampUsers(Q_Script5_A2QDisconnect_users) during (rampUpTimeSecs seconds)).protocols(httpConf),
			O_Script1_NewOrder.O_Script1_NewOrder.inject(rampUsers(O_Script1_NewOrder_users) during (rampUpTimeSecs seconds)).protocols(httpConf),
			O_Script2_A2OAdd.O_Script2_A2OAdd.inject(rampUsers(O_Script2_A2OAdd_users) during (rampUpTimeSecs seconds)).protocols(httpConf),
			O_Script3_A2OUpdate.O_Script3_A2OUpdate.inject(rampUsers(O_Script3_A2OUpdate_users) during (rampUpTimeSecs seconds)).protocols(httpConf),
			O_Script4_A2OMove.O_Script4_A2OMove.inject(rampUsers(O_Script4_A2OMove_users) during (rampUpTimeSecs seconds)).protocols(httpConf),
			O_Script5_A2ODisconnect.O_Script5_A2ODisconnect.inject(rampUsers(O_Script5_A2ODisconnect_users) during (rampUpTimeSecs seconds)).protocols(httpConf)).maxDuration(maxDurationSecs)

			//stepup

		//	D_Script1_DataCreation.D_Script1_DataCreation.inject(incrementConcurrentUsers(5).times(5).eachLevelLasting(100 seconds).separatedByRampsLasting(30 seconds).startingFrom(5)).protocols(httpConf)).maxDuration(maxDurationSecs)


		O_Script1_NewOrder.O_Script1_NewOrder.inject(incrementConcurrentUsers(4).times(9).eachLevelLasting(3600 seconds).separatedByRampsLasting(60 seconds).startingFrom(4)).protocols(httpConf),
		O_Script2_A2OAdd.O_Script2_A2OAdd.inject(incrementConcurrentUsers(6).times(9).eachLevelLasting(3600 seconds).separatedByRampsLasting(60 seconds).startingFrom(6)).protocols(httpConf),
		O_Script3_A2OUpdate.O_Script3_A2OUpdate.inject(incrementConcurrentUsers(8).times(9).eachLevelLasting(3600 seconds).separatedByRampsLasting(60 seconds).startingFrom(8)).protocols(httpConf),
		O_Script4_A2OMove.O_Script4_A2OMove.inject(incrementConcurrentUsers(2).times(9).eachLevelLasting(3600 seconds).separatedByRampsLasting(60 seconds).startingFrom(2)).protocols(httpConf),
		O_Script5_A2ODisconnect.O_Script5_A2ODisconnect.inject(incrementConcurrentUsers(5).times(9).eachLevelLasting(3600 seconds).separatedByRampsLasting(60 seconds).startingFrom(5)).protocols(httpConf)).maxDuration(maxDurationSecs)

		//10LI Step Up
		O_Script1_NewOrder.O_Script1_NewOrder.inject(incrementConcurrentUsers(4).times(12).eachLevelLasting(3600 seconds).separatedByRampsLasting(60 seconds).startingFrom(4)).protocols(httpConf),
		O_Script2_A2OAdd.O_Script2_A2OAdd.inject(incrementConcurrentUsers(6).times(12).eachLevelLasting(3600 seconds).separatedByRampsLasting(60 seconds).startingFrom(6)).protocols(httpConf),
		O_Script3_A2OUpdate.O_Script3_A2OUpdate.inject(incrementConcurrentUsers(8).times(12).eachLevelLasting(3600 seconds).separatedByRampsLasting(60 seconds).startingFrom(8)).protocols(httpConf),
		O_Script4_A2OMove.O_Script4_A2OMove.inject(incrementConcurrentUsers(2).times(12).eachLevelLasting(3600 seconds).separatedByRampsLasting(60 seconds).startingFrom(2)).protocols(httpConf),
		O_Script5_A2ODisconnect.O_Script5_A2ODisconnect.inject(incrementConcurrentUsers(5).times(12).eachLevelLasting(3600 seconds).separatedByRampsLasting(60 seconds).startingFrom(5)).protocols(httpConf)).maxDuration(maxDurationSecs)

*/

}
