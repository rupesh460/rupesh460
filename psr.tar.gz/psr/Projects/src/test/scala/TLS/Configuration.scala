package TLS

object Configuration
 {

	val BaseUrl = "https://perftest2-telstratest.cs8.force.com"
	
	val pageviews_min_wait_time = 1000
	val pageviews_max_wait_time = 2000

	val checkout_min_wait_time = 2000
	val checkout_max_wait_time = 5000

	val submit_min_wait_time = 4000
	val submit_max_wait_time = 8000

	val repeat_pageviews = 10
	val repeat_checkout = 10
	val repeat_submit = 10

	val MinWaitMs = 1000
	val MaxWaitMs = 2000
}