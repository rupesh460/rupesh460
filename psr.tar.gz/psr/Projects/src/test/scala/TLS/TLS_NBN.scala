  package TLS

  import scala.concurrent.duration._

  import io.gatling.core.Predef._
  import io.gatling.core.structure.ChainBuilder
  import io.gatling.http.Predef._
  import io.gatling.jdbc.Predef._
  import io.gatling.jsonpath._
  import Headers._
  import scala.collection._
  import java.time.format.DateTimeFormatter
  import java.time.LocalDateTime
  import java.time.LocalDate
  import scala.util.matching.Regex


   object TLS_NBN {


      val uri2 = "https://test.salesforce.com"
      val uri4 = "https://cs8.salesforce.com"
      var accountName = new StringBuilder()
      val randomNumber = new scala.util.Random
      val userFeeder = csv("./src/test/resources/data/tls/tls_users.csv").random
      val accountFeeder = csv("./src/test/resources/data/tls/tls_accounts.csv").random
      val timestamp: Long = System.currentTimeMillis

    /* ***************************************** PageViews & Visits Scenario - Start ****************************************** */    

            val pageviewsScn = scenario("PageViews_Visits")

            .exec((s: Session) => s.set("t",timestamp))
            
            .feed(userFeeder)
            .exec(http("Login_Community")
            .post("/scalability/s/sfsites/aura?r=7&applauncher.LoginForm.login=1")
            .headers(headers_6)
            .formParam("message", """{"actions":[{"id":"114;a","descriptor":"apex://applauncher.LoginFormController/ACTION$login","callingDescriptor":"markup://salesforceIdentity:loginForm2","params":{"username":"${username}","password":"${password}","startUrl":"/scalability/s/?t=${t}"},"version":"43.0"}]}""")
            .formParam("aura.context", """{"mode":"PROD","fwuid":"H9Yiy9uuE9726-4_PM7fkQ","app":"siteforce:loginApp2","loaded":{"APPLICATION@markup://siteforce:loginApp2":"2hkxcrdG_oFNsZmhX1Eopg"},"dn":[],"globals":{},"uad":false}""")
            .formParam("aura.pageURI", "/scalability/s/login/?startURL=%2Fscalability%2Fs%2F%3Ft%3D${t}")
            .formParam("aura.token", "undefined")
            .check(regex("""sid=(.+?)%21""").find.exists.saveAs("sid_part1"))
            .check(regex("""%21(.+?)&untethered""").find.exists.saveAs("sid_part2"))
            .check(regex("""site%3D(.+?)%""").find.exists.saveAs("siteid"))
            .check(regex("""cshc=(.+?)&""").find.exists.saveAs("cshc"))).exitHereIfFailed

            .pause(Configuration.pageviews_min_wait_time milliseconds, Configuration.pageviews_max_wait_time milliseconds) 

            .exec(http("Frontdoor")
            .get(uri4 + "/secur/frontdoor.jsp?allp=1&apv=1&cshc=${cshc}&refURL=https%3A%2F%2Fcs8.salesforce.com%2Fsecur%2Ffrontdoor.jsp&retURL=https%3A%2F%2Fcs8.salesforce.com%2Fservlet%2Fnetworks%2Fsession%2Fcreate%3Furl%3D%252Fscalability%252Fs%252F%253Ft%253D${t}%26site%3D${siteid}%26inst%3DL&sid=${sid_part1}!${sid_part2}&untethered=")
            //.check(headerRegex("Location","https(.+?)%3D").saveAs("loc_part"))
            .headers(headers_0)).exitHereIfFailed

            .exec(http("Create_sid_Apexremotes")
            .get(uri4+"/servlet/networks/session/create?url=%2Fscalability%2Fs%2F%3Ft%3D${t}&site=${siteid}&inst=L")
            .check(headerRegex("Date","Aug(.+?)GMT").saveAs("Date-rh"))
            .headers(headers_0)).exitHereIfFailed

        .repeat(Configuration.repeat_pageviews) {            
            
             exec(http("NBN_Omni_Script_Launch_PageViews_Step1")
            .get("/scalability/apex/OmniScriptUniversalPage?ContextId=&OmniScriptType=PerfRoadster&OmniScriptSubType=PerfNBNAdd&OmniScriptLang=English&scriptMode=vertical&layout=lightning&omniIframeEmbedded=true&omniCancelAction=back&tour=&isdtp=p1&sfdcIFrameOrigin=https%3A%2F%2Fperftest2-telstratest.cs8.force.com&sfdcIFrameHost=web")
            .check(regex(""""GenericInvoke2","len":4,"ns":"","ver":32.0,"csrf":"(.+?)"}""").find.exists.saveAs("GenInv2_CSRF"))
            .headers(headers_0)).exitHereIfFailed
              

            .exec(http("Ecommerce_OmniScriptToggleSwitch_PageViews_Step1")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .check(regex("""2018-03-29T17:49:00.000Z"""))
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0028_request.txt"))).exitHereIfFailed


            .feed(accountFeeder)
            .exec(http("Integration_NBN_SetupAnonymousCart_PageViews_Step1")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .check(regex("""["}{\[\\:,0-9a-zA-Z]"OrderId.":."(.+).",."SetNewOrderNumber.""").find.exists.saveAs("OrderId"))
            .check(regex("""["}{\[\\:,0-9a-zA-Z]"OrderNumber.":."(.+).",."Id""").find.exists.saveAs("OrderNumber"))
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0029_request.txt"))).exitHereIfFailed


            .exec(http("Get_Carts_Products_Offers_PageViews_Step1")
            .post("/scalability/apexremote")
            .check(regex("""Roadster Medium Offer"""))
            .headers(headers_28)
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0031_request.txt"))).exitHereIfFailed

            .exec(http("Get_Carts_Items_PageViews_Step1")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0032_request.txt"))).exitHereIfFailed


            .exec(http("Roadster_AddressQualification_PageViews_Step1")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0033_request.txt"))).exitHereIfFailed

            .pause(Configuration.pageviews_min_wait_time milliseconds, Configuration.pageviews_max_wait_time milliseconds) 

            .exec(http("Roadster_ServiceQualification_PageViews_Step2")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0035_request.txt"))).exitHereIfFailed

            .pause(Configuration.pageviews_min_wait_time milliseconds, Configuration.pageviews_max_wait_time milliseconds) 

           
            .exec(http("Add_Items_To_Cart_Bundle_PageViews_Step2")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .check(regex("""Successfully added."""))
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0045_request.txt"))).exitHereIfFailed
     
            .exec(http("Get_Carts_Items_With_Offers_PageViews_Step2")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0047_request.txt"))).exitHereIfFailed

            .exec(http("Coomunity_Landing_1_PageViews_Step3") 
            .get("/apex/Household?tour=&isdtp=p1&sfdcIFrameOrigin=https://perftest2-telstratest.cs8.force.com&nonce=5aca4619d1b686b10f3416d3310d1a80256468b5e159dee5c465b7d5ce23b004&clc=0&sfdcIFrameHost=web")
            .check(regex(""""""))).exitHereIfFailed


            .exec(http("Get_Carts_Products_Addons_PageViews_Step3")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .check(regex("""Standard Evening Speed"""))
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0048_request.txt"))).exitHereIfFailed

            .pause(Configuration.pageviews_min_wait_time milliseconds, Configuration.pageviews_max_wait_time milliseconds) 

            .exec(http("Add_Items_To_Cart_AddOn_PageViews_Step4")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .check(regex("""Successfully added."""))
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0049_request.txt"))).exitHereIfFailed

            .exec(http("Get_Carts_Items_With_Offers_Addons_PageViews_Step4")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0047_request.txt"))).exitHereIfFailed

            .pause(Configuration.pageviews_min_wait_time milliseconds, Configuration.pageviews_max_wait_time milliseconds) 

            .exec(http("Community_landing_Page_2_PageView_Step5") 
            .get("/apex/Household?tour=&isdtp=p1&sfdcIFrameOrigin=https://perftest2-telstratest.cs8.force.com&nonce=5aca4619d1b686b10f3416d3310d1a80256468b5e159dee5c465b7d5ce23b004&clc=0&sfdcIFrameHost=web")
            .check(regex(""""""))).exitHereIfFailed
        }

    /* ***************************************** PageViews & Visits Scenario - end ****************************************** */        
            
    /* ***************************************** Checkout Scenario - Start ************************************************** */

            val checkoutScn = scenario("Checkout")

            .exec((s: Session) => s.set("t",timestamp))
            
            .feed(userFeeder)
            .exec(http("Login_Community")
            .post("/scalability/s/sfsites/aura?r=7&applauncher.LoginForm.login=1")
            .headers(headers_6)
            .formParam("message", """{"actions":[{"id":"114;a","descriptor":"apex://applauncher.LoginFormController/ACTION$login","callingDescriptor":"markup://salesforceIdentity:loginForm2","params":{"username":"${username}","password":"${password}","startUrl":"/scalability/s/?t=${t}"},"version":"43.0"}]}""")
            .formParam("aura.context", """{"mode":"PROD","fwuid":"H9Yiy9uuE9726-4_PM7fkQ","app":"siteforce:loginApp2","loaded":{"APPLICATION@markup://siteforce:loginApp2":"2hkxcrdG_oFNsZmhX1Eopg"},"dn":[],"globals":{},"uad":false}""")
            .formParam("aura.pageURI", "/scalability/s/login/?startURL=%2Fscalability%2Fs%2F%3Ft%3D${t}")
            .formParam("aura.token", "undefined")
            .check(regex("""sid=(.+?)%21""").find.exists.saveAs("sid_part1"))
            .check(regex("""%21(.+?)&untethered""").find.exists.saveAs("sid_part2"))
            .check(regex("""site%3D(.+?)%""").find.exists.saveAs("siteid"))
            .check(regex("""cshc=(.+?)&""").find.exists.saveAs("cshc"))).exitHereIfFailed

            .pause(Configuration.pageviews_min_wait_time milliseconds, Configuration.pageviews_max_wait_time milliseconds)

            .exec(http("Frontdoor")
            .get(uri4 + "/secur/frontdoor.jsp?allp=1&apv=1&cshc=${cshc}&refURL=https%3A%2F%2Fcs8.salesforce.com%2Fsecur%2Ffrontdoor.jsp&retURL=https%3A%2F%2Fcs8.salesforce.com%2Fservlet%2Fnetworks%2Fsession%2Fcreate%3Furl%3D%252Fscalability%252Fs%252F%253Ft%253D${t}%26site%3D${siteid}%26inst%3DL&sid=${sid_part1}!${sid_part2}&untethered=")
            //.check(headerRegex("Location","https(.+?)%3D").saveAs("loc_part"))
            .headers(headers_0)).exitHereIfFailed

            .exec(http("Create_sid_Apexremotes")
            .get(uri4+"/servlet/networks/session/create?url=%2Fscalability%2Fs%2F%3Ft%3D${t}&site=${siteid}&inst=L")
            .check(headerRegex("Date","Aug(.+?)GMT").saveAs("Date-rh"))
            .headers(headers_0)).exitHereIfFailed

        .repeat(Configuration.repeat_checkout) {                   
            
            exec(http("NBN_Omni_Script_Launch_Checkout_Step1")
            .get("/scalability/apex/OmniScriptUniversalPage?ContextId=&OmniScriptType=PerfRoadster&OmniScriptSubType=PerfNBNAdd&OmniScriptLang=English&scriptMode=vertical&layout=lightning&omniIframeEmbedded=true&omniCancelAction=back&tour=&isdtp=p1&sfdcIFrameOrigin=https%3A%2F%2Fperftest2-telstratest.cs8.force.com&sfdcIFrameHost=web")
            .check(regex(""""GenericInvoke2","len":4,"ns":"","ver":32.0,"csrf":"(.+?)"}""").find.exists.saveAs("GenInv2_CSRF"))
            .headers(headers_0)).exitHereIfFailed
              

            .exec(http("Ecommerce_OmniScriptToggleSwitch_Checkout_Step1")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .check(regex("""2018-03-29T17:49:00.000Z"""))
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0028_request.txt"))).exitHereIfFailed


            .feed(accountFeeder)
            .exec(http("Integration_NBN_SetupAnonymousCart_Checkout_Step1")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .check(regex("""["}{\[\\:,0-9a-zA-Z]"OrderId.":."(.+).",."SetNewOrderNumber.""").find.exists.saveAs("OrderId"))
            .check(regex("""["}{\[\\:,0-9a-zA-Z]"OrderNumber.":."(.+).",."Id""").find.exists.saveAs("OrderNumber"))
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0029_request.txt"))).exitHereIfFailed


            .exec(http("Get_Carts_Products_Offers_Checkout_Step1")
            .post("/scalability/apexremote")
            .check(regex("""Roadster Medium Offer"""))
            .headers(headers_28)
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0031_request.txt"))).exitHereIfFailed

            .exec(http("Get_Carts_Items_Checkout_Step1")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0032_request.txt"))).exitHereIfFailed


            .exec(http("Roadster_AddressQualification_Checkout_Step1")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0033_request.txt"))).exitHereIfFailed

            .pause(Configuration.pageviews_min_wait_time milliseconds, Configuration.pageviews_max_wait_time milliseconds) 

            .exec(http("Roadster_ServiceQualification_Checkout_Step2")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0035_request.txt"))).exitHereIfFailed

            .pause(Configuration.pageviews_min_wait_time milliseconds, Configuration.pageviews_max_wait_time milliseconds)

           
            .exec(http("Add_Items_To_Cart_Bundle_Checkout_Step2")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .check(regex("""Successfully added."""))
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0045_request.txt"))).exitHereIfFailed
     
            .exec(http("Get_Carts_Items_With_Offers_Checkout_Step2")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0047_request.txt"))).exitHereIfFailed

            .exec(http("Coomunity_Landing_1_Checkout_Step3") 
            .get("/apex/Household?tour=&isdtp=p1&sfdcIFrameOrigin=https://perftest2-telstratest.cs8.force.com&nonce=5aca4619d1b686b10f3416d3310d1a80256468b5e159dee5c465b7d5ce23b004&clc=0&sfdcIFrameHost=web")
            .check(regex(""""""))).exitHereIfFailed


            .exec(http("Get_Carts_Products_Addons_Checkout_Step3")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .check(regex("""Standard Evening Speed"""))
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0048_request.txt"))).exitHereIfFailed

            .pause(Configuration.pageviews_min_wait_time milliseconds, Configuration.pageviews_max_wait_time milliseconds) 

            .exec(http("Add_Items_To_Cart_AddOn_Checkout_Step4")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .check(regex("""Successfully added."""))
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0049_request.txt"))).exitHereIfFailed

            .exec(http("Get_Carts_Items_With_Offers_Addons_Checkout_Step4")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0047_request.txt"))).exitHereIfFailed


            .exec(http("Community_landing_Page_2_Checkout_Step5") 
            .get("/apex/Household?tour=&isdtp=p1&sfdcIFrameOrigin=https://perftest2-telstratest.cs8.force.com&nonce=5aca4619d1b686b10f3416d3310d1a80256468b5e159dee5c465b7d5ce23b004&clc=0&sfdcIFrameHost=web")
            .check(regex(""""""))).exitHereIfFailed

            .pause(Configuration.pageviews_min_wait_time milliseconds, Configuration.pageviews_max_wait_time milliseconds)


            .exec(http("Roadster_GetAuthenticatedUser_Checkout_Step6")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0052_request.txt"))).exitHereIfFailed

            .pause(Configuration.checkout_min_wait_time milliseconds, Configuration.checkout_max_wait_time milliseconds) 

            .exec(http("Roadster_Check_Username_Checkout_Step6")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .check(regex("""BusinessProcessDisplayController"""))
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0053_request.txt"))).exitHereIfFailed

            .pause(Configuration.checkout_min_wait_time milliseconds, Configuration.checkout_max_wait_time milliseconds) 
        

            .exec(session => session.set("AccountName",""))        

            .exec( session => {
              val random_index = randomNumber.nextInt(100000)
              accountName.append("Acc-"+random_index)
              session
            })

            .exec(session => session.set("AccountName",accountName))
             
             .exec( session => {
              accountName = new StringBuilder()
              session
            })

            .exec(http("Register_TDI_User_Checkout_Step6")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .check(regex(""""""))
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0054_request.txt")))

            .pause(Configuration.checkout_min_wait_time milliseconds, Configuration.checkout_max_wait_time milliseconds) 

            .exec(http("Community_Landing_Page3_Checkout_Step7") 
            .get("/apex/Household?tour=&isdtp=p1&sfdcIFrameOrigin=https://perftest2-telstratest.cs8.force.com&nonce=5aca4619d1b686b10f3416d3310d1a80256468b5e159dee5c465b7d5ce23b004&clc=0&sfdcIFrameHost=web")
            .check(regex(""""""))).exitHereIfFailed

            .pause(Configuration.checkout_min_wait_time milliseconds, Configuration.checkout_max_wait_time milliseconds) 
            

            .exec(http("Terms_and_conditions_page_Checkout_Step8") 
            .get("/apex/Household?tour=&isdtp=p1&sfdcIFrameOrigin=https://perftest2-telstratest.cs8.force.com&nonce=5aca4619d1b686b10f3416d3310d1a80256468b5e159dee5c465b7d5ce23b004&clc=0&sfdcIFrameHost=web")
            .check(regex(""""""))).exitHereIfFailed
        }

        /* ***************************************** Checkout Scenario - end ****************************************** */


        /* ***************************************** Submit Scenario - Start ****************************************** */


            val submitScn = scenario("SubmitOrder")

            .exec((s: Session) => s.set("t",timestamp))
            
            .feed(userFeeder)
            .exec(http("Login_Community")
            .post("/scalability/s/sfsites/aura?r=7&applauncher.LoginForm.login=1")
            .headers(headers_6)
            .formParam("message", """{"actions":[{"id":"114;a","descriptor":"apex://applauncher.LoginFormController/ACTION$login","callingDescriptor":"markup://salesforceIdentity:loginForm2","params":{"username":"${username}","password":"${password}","startUrl":"/scalability/s/?t=${t}"},"version":"43.0"}]}""")
            .formParam("aura.context", """{"mode":"PROD","fwuid":"H9Yiy9uuE9726-4_PM7fkQ","app":"siteforce:loginApp2","loaded":{"APPLICATION@markup://siteforce:loginApp2":"2hkxcrdG_oFNsZmhX1Eopg"},"dn":[],"globals":{},"uad":false}""")
            .formParam("aura.pageURI", "/scalability/s/login/?startURL=%2Fscalability%2Fs%2F%3Ft%3D${t}")
            .formParam("aura.token", "undefined")
            .check(regex("""sid=(.+?)%21""").find.exists.saveAs("sid_part1"))
            .check(regex("""%21(.+?)&untethered""").find.exists.saveAs("sid_part2"))
            .check(regex("""site%3D(.+?)%""").find.exists.saveAs("siteid"))
            .check(regex("""cshc=(.+?)&""").find.exists.saveAs("cshc"))).exitHereIfFailed

            .pause(Configuration.pageviews_min_wait_time milliseconds, Configuration.pageviews_max_wait_time milliseconds) 

            .exec(http("Frontdoor")
            .get(uri4 + "/secur/frontdoor.jsp?allp=1&apv=1&cshc=${cshc}&refURL=https%3A%2F%2Fcs8.salesforce.com%2Fsecur%2Ffrontdoor.jsp&retURL=https%3A%2F%2Fcs8.salesforce.com%2Fservlet%2Fnetworks%2Fsession%2Fcreate%3Furl%3D%252Fscalability%252Fs%252F%253Ft%253D${t}%26site%3D${siteid}%26inst%3DL&sid=${sid_part1}!${sid_part2}&untethered=")
            //.check(headerRegex("Location","https(.+?)%3D").saveAs("loc_part"))
            .headers(headers_0)).exitHereIfFailed

            .exec(http("Create_sid_Apexremotes")
            .get(uri4+"/servlet/networks/session/create?url=%2Fscalability%2Fs%2F%3Ft%3D${t}&site=${siteid}&inst=L")
            .check(headerRegex("Date","Aug(.+?)GMT").saveAs("Date-rh"))
            .headers(headers_0)).exitHereIfFailed

        .repeat(Configuration.repeat_submit) {                
            
            exec(http("NBN_Omni_Script_Launch_Submit_Step1")
            .get("/scalability/apex/OmniScriptUniversalPage?ContextId=&OmniScriptType=PerfRoadster&OmniScriptSubType=PerfNBNAdd&OmniScriptLang=English&scriptMode=vertical&layout=lightning&omniIframeEmbedded=true&omniCancelAction=back&tour=&isdtp=p1&sfdcIFrameOrigin=https%3A%2F%2Fperftest2-telstratest.cs8.force.com&sfdcIFrameHost=web")
            .check(regex(""""GenericInvoke2","len":4,"ns":"","ver":32.0,"csrf":"(.+?)"}""").find.exists.saveAs("GenInv2_CSRF"))
            .headers(headers_0)).exitHereIfFailed
              

            .exec(http("Ecommerce_OmniScriptToggleSwitch_SubmitOrder_Step1")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .check(regex("""2018-03-29T17:49:00.000Z"""))
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0028_request.txt"))).exitHereIfFailed


            .feed(accountFeeder)
            .exec(http("Integration_NBN_SetupAnonymousCart_SubmitOrder_Step1")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .check(regex("""["}{\[\\:,0-9a-zA-Z]"OrderId.":."(.+).",."SetNewOrderNumber.""").find.exists.saveAs("OrderId"))
            .check(regex("""["}{\[\\:,0-9a-zA-Z]"OrderNumber.":."(.+).",."Id""").find.exists.saveAs("OrderNumber"))
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0029_request.txt"))).exitHereIfFailed


            .exec(http("Get_Carts_Products_Offers_SubmitOrder_Step1")
            .post("/scalability/apexremote")
            .check(regex("""Roadster Medium Offer"""))
            .headers(headers_28)
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0031_request.txt"))).exitHereIfFailed

            .exec(http("Get_Carts_Items_SubmitOrder_Step1")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0032_request.txt"))).exitHereIfFailed


            .exec(http("Roadster_AddressQualification_SubmitOrder_Step1")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0033_request.txt"))).exitHereIfFailed

            .pause(Configuration.pageviews_min_wait_time milliseconds, Configuration.pageviews_max_wait_time milliseconds)

            .exec(http("Roadster_ServiceQualification_SubmitOrder_Step2")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0035_request.txt"))).exitHereIfFailed

            .pause(Configuration.pageviews_min_wait_time milliseconds, Configuration.pageviews_max_wait_time milliseconds) 

           
            .exec(http("Add_Items_To_Cart_Bundle_SubmitOrder_Step2")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .check(regex("""Successfully added."""))
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0045_request.txt"))).exitHereIfFailed
     
            .exec(http("Get_Carts_Items_With_Offers_SubmitOrder_Step2")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0047_request.txt"))).exitHereIfFailed

            .exec(http("Coomunity_Landing_1_Step3") 
            .get("/apex/Household?tour=&isdtp=p1&sfdcIFrameOrigin=https://perftest2-telstratest.cs8.force.com&nonce=5aca4619d1b686b10f3416d3310d1a80256468b5e159dee5c465b7d5ce23b004&clc=0&sfdcIFrameHost=web")
            .check(regex(""""""))).exitHereIfFailed


            .exec(http("Get_Carts_Products_Addons_SubmitOrder_Step3")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .check(regex("""Standard Evening Speed"""))
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0048_request.txt"))).exitHereIfFailed

            .pause(Configuration.pageviews_min_wait_time milliseconds, Configuration.pageviews_max_wait_time milliseconds)

            .exec(http("Add_Items_To_Cart_AddOn_SubmitOrder_Step4")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .check(regex("""Successfully added."""))
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0049_request.txt"))).exitHereIfFailed

            .exec(http("Get_Carts_Items_With_Offers_Addons_SubmitOrder_Step4")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0047_request.txt"))).exitHereIfFailed


            .exec(http("Community_landing_Page_2_SubmitOrder_Step5") 
            .get("/apex/Household?tour=&isdtp=p1&sfdcIFrameOrigin=https://perftest2-telstratest.cs8.force.com&nonce=5aca4619d1b686b10f3416d3310d1a80256468b5e159dee5c465b7d5ce23b004&clc=0&sfdcIFrameHost=web")
            .check(regex(""""""))).exitHereIfFailed

            .pause(Configuration.pageviews_min_wait_time milliseconds, Configuration.pageviews_max_wait_time milliseconds)


            .exec(http("Roadster_GetAuthenticatedUser_SubmitOrder_Step6")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0052_request.txt"))).exitHereIfFailed

            .pause(Configuration.checkout_min_wait_time milliseconds, Configuration.checkout_max_wait_time milliseconds)

            .exec(http("Roadster_Check_Username_SubmitOrder_Step6")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .check(regex("""BusinessProcessDisplayController"""))
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0053_request.txt"))).exitHereIfFailed

            .pause(Configuration.checkout_min_wait_time milliseconds, Configuration.checkout_max_wait_time milliseconds) 
        

            .exec(session => session.set("AccountName",""))        

            .exec( session => {
              val random_index = randomNumber.nextInt(100000)
              accountName.append("Acc-"+random_index)
              session
            })

            .exec(session => session.set("AccountName",accountName))
             
             .exec( session => {
              accountName = new StringBuilder()
              session
            })

            .exec(http("Register_TDI_User_SubmitOrder_Step6")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .check(regex(""""""))
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0054_request.txt")))

            .pause(Configuration.checkout_min_wait_time milliseconds, Configuration.checkout_max_wait_time milliseconds) 

            .exec(http("Community_Landing_Page3_SubmitOrder_Step7") 
            .get("/apex/Household?tour=&isdtp=p1&sfdcIFrameOrigin=https://perftest2-telstratest.cs8.force.com&nonce=5aca4619d1b686b10f3416d3310d1a80256468b5e159dee5c465b7d5ce23b004&clc=0&sfdcIFrameHost=web")
            .check(regex(""""""))).exitHereIfFailed

            .pause(Configuration.checkout_min_wait_time milliseconds, Configuration.checkout_max_wait_time milliseconds)
            

            .exec(http("Terms_and_conditions_page_SubmitOrder_Step8") 
            .get("/apex/Household?tour=&isdtp=p1&sfdcIFrameOrigin=https://perftest2-telstratest.cs8.force.com&nonce=5aca4619d1b686b10f3416d3310d1a80256468b5e159dee5c465b7d5ce23b004&clc=0&sfdcIFrameHost=web")
            .check(regex(""""""))).exitHereIfFailed

            .pause(Configuration.submit_min_wait_time milliseconds, Configuration.submit_max_wait_time milliseconds) 

            .exec(http("Submit_Order_SubmitOrder_Step9")
            .post("/scalability/apexremote")
            .headers(headers_28)
            .check(regex("""id.":."(.+?)."""").find.exists.saveAs("accountId"))
            .body(ElFileBody("./src/test/resources/bodies/tls/TLS_0051_request.txt"))).exitHereIfFailed
            

            /* ***************************************** Submit Scenario - end ****************************************** */
        }
  }