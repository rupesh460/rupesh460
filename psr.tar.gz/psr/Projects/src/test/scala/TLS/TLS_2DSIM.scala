  package TLS

  import scala.concurrent.duration._

  import io.gatling.core.Predef._
  import io.gatling.core.structure.ChainBuilder
  import io.gatling.http.Predef._
  import io.gatling.jdbc.Predef._
  import io.gatling.jsonpath._
  import Headers._
  import scala.collection._
  import java.time.format.DateTimeFormatter
  import java.time.LocalDateTime
  import java.time.LocalDate


   object TLS_2DSIM {

    
      
      val userFeeder = csv("./src/test/resources/data/tls/tls_users.csv").random
      val accountFeeder = csv("./src/test/resources/data/tls/tls_accounts.csv").random
      val scn = scenario("2DSIM")


    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("Launch_2DSIM")
    .get("/apex/OmniScriptUniversalPage?ContextId=&OmniScriptType=TLS&OmniScriptSubType=New%20Prepaid%20SIM%20Card&OmniScriptLang=English&scriptMode=vertical&layout=lightning&omniIframeEmbedded=true&omniCancelAction=back&tour=&isdtp=p1&sfdcIFrameOrigin=https%3A%2F%2Fperftest2-telstratest.cs8.force.com&sfdcIFrameHost=web")
    .check(regex(""""GenericInvoke2","len":4,"ns":"","ver":32.0,"csrf":"(.+?)"}""").find.exists.saveAs("GenInv2_CSRF"))).exitHereIfFailed

    .feed(accountFeeder)
    .exec(http("Ecommerce_OmniScriptToggleSwitch")
    .post("/apexremote")
    .headers(headers_28)
    .check(regex("""2018-08-09T08:57:00.000Z"""))
    .body(ElFileBody("./src/test/resources/bodies/tlssim/tls_ecomtoggleswitch.txt"))).exitHereIfFailed

    .exec(http("Integration_RetrieveAddressSearchAPIs")
    .post("/apexremote")
    .headers(headers_28)
    .check(regex("""structuredAddressQuery"""))
    .body(ElFileBody("./src/test/resources/bodies/tlssim/tls_getaddressapi.txt"))).exitHereIfFailed

    .exec(http("Ecommerce_SetupAnonymousCart")
    .post("/apexremote")
    .headers(headers_28)
    .check(regex("""["}{\[\\:,0-9a-zA-Z]OrderId.":."(.+?)."""").find.exists.saveAs("OrderId"))
    .check(regex("""["}{\[\\:,0-9a-zA-Z]OrderNumber.":."(.+?)."""").find(0).exists.saveAs("CustomerOrderNumber"))
    .check(regex("""["}{\[\\:,0-9a-zA-Z]OrderNumber.":."(.+?)."""").find(1).exists.saveAs("OrderNumber"))
    .body(ElFileBody("./src/test/resources/bodies/tlssim/tls_setupananymouscart.txt"))).exitHereIfFailed
    
    .exec(http("Ecommerce_AddToAnonymousCart")
    .post("/apexremote")
    .headers(headers_28)
    .check(regex("""["}{\[\\:,0-9a-zA-Z]"OrderId.":."(.+).",."SetNewOrderNumber.""").find.exists.saveAs("OrderId"))
    .check(regex("""["}{\[\\:,0-9a-zA-Z]"OrderNumber.":."(.+).",."Id""").find.exists.saveAs("OrderNumber"))
    .body(ElFileBody("./src/test/resources/bodies/tlssim/tls_addtoanonymouscart.txt"))).exitHereIfFailed

    .exec(http("GetCartsItems")
    .post("/apexremote")
    .headers(headers_28)
    .check(regex("""["}{\[\\:,0-9a-zA-Z]Price Book Entry ID.",."value.":."(.+?)."},."Pricebook2Id""").findAll.saveAs("ProductIds"))
    .body(ElFileBody("./src/test/resources/bodies/tlssim/tls_getcartsitems.txt"))).exitHereIfFailed

    .exec(http("GetPriceDetails")
    .post("/apexremote")
    .headers(headers_28)
    .check(regex("""["}{\[\\:,0-9a-zA-Z]Price Book Entry ID.",."value.":."(.+?)."},."Pricebook2Id""").findAll.saveAs("ProductIds"))
    .body(ElFileBody("./src/test/resources/bodies/tlssim/tls_getpricedetails.txt"))).exitHereIfFailed
    
    .exec(http("GetCarts")
    .post("/apexremote")
    .headers(headers_28)
    .check(regex("""["}{\[\\:,0-9a-zA-Z]Price Book Entry ID.",."value.":."(.+?)."},."Pricebook2Id""").findAll.saveAs("ProductIds"))
    .body(ElFileBody("./src/test/resources/bodies/tlssim/tls_getcarts.txt"))).exitHereIfFailed

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("Get_IP_Info")
    .get("https://ipinfo.io/json")
    .headers(headers_28)).exitHereIfFailed

    .exec(http("GetPriceDetails")
    .post("/apexremote")
    .headers(headers_28)
    .check(regex("""["}{\[\\:,0-9a-zA-Z]Price Book Entry ID.",."value.":."(.+?)."},."Pricebook2Id""").findAll.saveAs("ProductIds"))
    .body(ElFileBody("./src/test/resources/bodies/tlssim/tls_getpricedetails.txt"))).exitHereIfFailed

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("Delivery_Autobook") 
    .post("/apexremote")
    .headers(headers_28)
    .check(regex(""""""))
    .body(ElFileBody("./src/test/resources/bodies/tlssim/tls_deliveryautobook.txt"))).exitHereIfFailed

    .exec(http("Privacy_Statement")
    .post("/apexremote")
    .headers(headers_28)
    .check(regex(""""""))
    .body(ElFileBody("./src/test/resources/bodies/tlssim/tls_privacystatement.txt"))).exitHereIfFailed

    .exec(http("Customer_Terms")
    .post("/apexremote")
    .headers(headers_28)
    .check(regex(""""""))
    .body(ElFileBody("./src/test/resources/bodies/tlssim/tls_customerterms.txt"))).exitHereIfFailed

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("Integration_SubmitPrepaidOrder") 
    .post("/apexremote")
    .headers(headers_28)
    .check(regex(""""""))
    .body(ElFileBody("./src/test/resources/bodies/tlssim/tls_reviewandsubmit.txt"))).exitHereIfFailed

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  }