package TLS

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._

class TLS_Scn extends Simulation {

	val httpConf = http
		.baseUrl(Configuration.BaseUrl)
		.inferHtmlResources(BlackList(""".*\.js""", """.*\.css""", """.*\.gif""", """.*\.jpeg""", """.*\.jpg""", """.*\.ico""", """.*\.woff""", """.*\.(t|o)tf""", """.*\.png"""), WhiteList())
		.acceptHeader("*/*")
		.acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8")
		.acceptEncodingHeader("gzip, deflate, sdch")
		.acceptLanguageHeader("en-US,en;q=0.8")
		//.disableCaching
		.contentTypeHeader("application/x-www-form-urlencoded; charset=UTF-8")
		.userAgentHeader("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.3")

	val pageviewsRampup = Integer.getInteger("pageviewsRampup", 1)
	val checkoutRampup = Integer.getInteger("checkoutRampup", 1)
	val submitRampup = Integer.getInteger("submitRampup", 1)
	val pageviewsUsers = Integer.getInteger("pageviewsUsers", 1)
	val checkoutUsers = Integer.getInteger("checkoutUsers", 1)
	val submitUsers = Integer.getInteger("submitUsers", 1)
	val maxDurationSecs = Integer.getInteger("maxDurationSecs", 1)
	val testDuration = Integer.getInteger("testDuration",1)


	setUp(

		TLS_NBN_Guest.pageviewsScn.inject(rampUsers(pageviewsUsers) during (pageviewsRampup seconds)).protocols(httpConf),
		TLS_NBN_Guest.checkoutScn.inject(rampUsers(checkoutUsers) during (checkoutRampup seconds)).protocols(httpConf),
		TLS_NBN_Guest.submitScn.inject(rampUsers(submitUsers) during (submitRampup seconds)).protocols(httpConf)).maxDuration(maxDurationSecs)

  }