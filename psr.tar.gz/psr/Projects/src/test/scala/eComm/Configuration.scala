package eComm


object Configuration
{
	val BaseUrl = "https://c.cs8.visual.force.com"
	val Uri01 = "https://test.salesforce.com"
	val Uri02 = "https://cs8.salesforce.com"

	val minWaitMs = 500
	val maxWaitMs = 2000

	val BaseUrl_AWS = "https://1fhjm3ncac.execute-api.us-east-2.amazonaws.com/test/dc/"
	val Uri02_AWS = "https://1fhjm3ncac.execute-api.us-east-2.amazonaws.com/test/dc/"

	val productViewMinWaitMs = Integer.getInteger("productViewMinWaitMs", 1)
	val productViewMaxWaitMs = Integer.getInteger("productViewMaxWaitMs", 1)

	val addToCartMinWaitMs = Integer.getInteger("addToCartMinWaitMs", 1)
	val addToCartMaxWaitMs = Integer.getInteger("addToCartMaxWaitMs", 1)

	val checkOutMinWaitMs = Integer.getInteger("checkOutMinWaitMs", 1)
	val checkOutMaxWaitMs = Integer.getInteger("checkOutMaxWaitMs", 1)


}