package CMT

import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.core.structure.ChainBuilder
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._
import io.gatling.jsonpath._
import Headers._
import scala.collection._
import java.time.format.DateTimeFormatter
import java.time.LocalDateTime

import io.gatling.core.feeder._
import java.util.Base64
import java.nio.charset.StandardCharsets
import scala.util.matching.Regex


 object CreateOrderSimulation {

    val uri01 = Configuration.Uri01
    val uri05 = Configuration.Uri05
    val uri10 = Configuration.Uri10
    val testDuration = Integer.getInteger("testDuration", 1)
    //val originalItemJson = new StringBuilder()
    var modifiedItemJson = new StringBuilder()
    val origItemAttrHeirarchy = new StringBuilder()
    val modItemAttrHeirarchy = new StringBuilder()
    val randomNumber = new scala.util.Random
    var randomPBEntry = new StringBuilder()
    var pbeEntriesList = Vector[String]()
    val userFeeder = csv("./src/test/resources/data/cmt/CMT100SKYTestUsers.csv").random
    val accountIdFeeder = csv("./src/test/resources/data/cmt/CMT100SKYTestAccounts.csv").random 
	

 val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
  val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
  val password_v = (passwordByEnv.get("perf3").toString)
  val password_encoded = password_v.substring(12,(password_v.length - 2 ))
  val credentials = new String(Base64.getDecoder.decode(password_encoded))

	  val scn = scenario("CreateOrderSimulation")
    
 
    .feed(userFeeder)
    .exec(http("1RESTGetOAuthToken")
      .post("https://test.salesforce.com/services/oauth2/token")
      .header("Content-Type", "application/x-www-form-urlencoded")
      .formParam("password", "${password}")
      .formParam("username", "${username}")
      .formParam("client_secret", "7119599995527965426")
      .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
      .formParam("grant_type", "password")
      .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
      .check(status.is(200)))
         
    .pause(Configuration.MiniMinWaitMs milliseconds, Configuration.MiniMaxWaitMs milliseconds)

  .repeat(3)
  {
      /* *********** CreateOrder *********** */
    feed(accountIdFeeder)
    .exec(http("1CreateOrder")
        .post(uri10 +"/services/apexrest/v2/carts")
        .headers(header_1)
        .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
        .body( StringBody("""{"subaction":"createOrder",
                  "inputFields":[
                    {"AccountId":"${AccountId}"},
                    {"PriceListId__c":"a2Pg0000001MwIPEA0"},
                    {"Name":"NewOrder1"},{"Status":"Draft"},
                    {"EffectiveDate":"9/6/2017"}
                  ]}""")).asJson)

    .pause(Configuration.MiniMinWaitMs milliseconds, Configuration.MiniMaxWaitMs milliseconds)
      /* ********** SetPriceListForCart *********** */
      .exec(http("1SetPriceListForCart")
        .put(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/")
        .headers(header_1)
        .body(StringBody("""{
                      "inputFields": 
                      [
                        {
                            "PriceListId__c": "a2Pg0000001MwIPEA0"
                          }
                        ],
                      "cartId": "${OrderID}",
                      "methodName": "updateCarts"
                  }""")).asJson)   

      /* ********** GetListOfProductsForCart *********** */
      .exec(http("1GetListOfProductsForCart")
        .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/products")
        .check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfPBEntries"))
        .headers(header_1))  

       .exec( session => {
            pbeEntriesList = session("ListOfPBEntries").as[Vector[String]]
            session
          })
     .pause(Configuration.MiniMinWaitMs milliseconds, Configuration.MiniMaxWaitMs milliseconds)
    
    .repeat(33,"counter")
    {

        exec(session => session.set("ProductID",""))
        .exec( session => {
        val max = pbeEntriesList.length - 1
        val random_index = randomNumber.nextInt(max+1)
        randomPBEntry.append(pbeEntriesList(random_index))
        //println("ProductID is ::::"+randomPBEntry)
        session
      })

      .exec(session => session.set("ProductID",randomPBEntry))
       
       .exec( session => {
        randomPBEntry = new StringBuilder()
        session
        })
    
    .pause(Configuration.MiniMinWaitMs milliseconds, Configuration.MiniMaxWaitMs milliseconds)
    
      /* ********** AddItemsToCart *********** */
      .exec(http("1AddItemsToCart1")
        .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
        .headers(header_1)
        .body( StringBody("""{
                                    "items":[{
                                    "itemId":"${ProductID}"
                                    }],
                                    "hierarchy":3,
                                    "lastItemId":"",
                                    "pagesize":20
                                    }""")).asJson)
      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
      
      
      }
      .exec(session => session.removeAll("AccountId","ProductID","ListOfPBEntries"))
      
     /* ********** GetCartLineItems *********** */
      .exec(http("1GetCartLineItems1")
        .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
        .headers(header_1)
        .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1"))
        .check(jsonPath("$.records[1].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem2"))
        .check(jsonPath("$.records[2].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem3"))
        .check(jsonPath("$.records[*].actions.updateitems.rest.params.items..itemId").findAll.saveAs("ListOfLineItems")))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
     
      .exec(session => session.removeAll("ListOfLineItems"))     
     /* ********** GetCartItemsByItemId *********** */
     .exec(http("1GetCartItemsByItemId1")
        .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
        .queryParamSeq(Seq(("id", "${LineItem1}")))
        .headers(header_1)
        .check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))

      .exec(session => { 
        //originalItemJson.append(session("capturedItemHierarchy").as[String])
        modifiedItemJson = new StringBuilder()
        //modifiedItemJson.append("""{"items":{"records":[{"displaySequence":-1,""").append(originalItemJson).append("}]}}")
        modifiedItemJson.append("""{"items":{"records":[{"displaySequence":-1,""").append(session("capturedItemHierarchy").as[String]).append("}]}}")
        session
        })
      .pause(Configuration.MiniMinWaitMs milliseconds, Configuration.MiniMaxWaitMs milliseconds)     
     
      .exec(session => session.removeAll("capturedItemHierarchy"))

     /* ********** UpdateItemsInCart *********** */
     /* Updating the Quantity from default 1.00 to 3.00 */
      .exec(http("1UpdateItemsInCart")
        .put(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
        .headers(header_1)
        .body(StringBody(session =>  modifiedItemJson.replaceAllLiterally(""""Quantity":{"value":1.00""",""""Quantity":{"value":3.00""").toString() )).asJson)

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      /* ********** DeleteItemFromCart********** */
      .exec(http("1DeleteItemFromCart")
        .delete(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/${LineItem2}")
        .headers(header_1))
      
      .pause(Configuration.MiniMinWaitMs milliseconds, Configuration.MiniMaxWaitMs milliseconds)
      
      /* ********** GetPricingDetailsForCartLineItem *********** */
      .exec(http("1GetPricingDetailsForCartLineItem")
        .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/${LineItem1}/pricing?fields=RecurringCharge__c")
        .headers(header_1))

    .exec(session => session.removeAll("LineItem1","LineItem2","LineItem3"))

     .pause(Configuration.MiniMinWaitMs milliseconds, Configuration.MiniMaxWaitMs milliseconds)

    .repeat(2,"counter")
    {

        exec(session => session.set("ProductID",""))
        .exec( session => {
        val max = pbeEntriesList.length - 1
        val random_index = randomNumber.nextInt(max+1)
        randomPBEntry.append(pbeEntriesList(random_index))
        //println("ProductID is ::::"+randomPBEntry)
        session
      })

      .exec(session => session.set("ProductID",randomPBEntry))
       
       .exec( session => {
        randomPBEntry = new StringBuilder()
        session
      })
      
      .pause(Configuration.MiniMinWaitMs milliseconds, Configuration.MiniMaxWaitMs milliseconds)
      /* ********** AddItemsToCart *********** */
      .exec(http("1AddItemsToCart2")
        .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
        .headers(header_1)
        .body( StringBody("""{
                                    "items":[{
                                    "itemId":"${ProductID}"
                                    }],
                                    "hierarchy":3,
                                    "lastItemId":"",
                                    "pagesize":20
                                    }""")).asJson)

      }
    
      .exec(session => session.removeAll("ProductID"))

      /* ********** GetCartLineItems *********** */
      .exec(http("1GetCartLineItems2")
        .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
        .headers(header_1)
        .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1"))
        .check(jsonPath("$.records[1].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem2"))
        .check(jsonPath("$.records[2].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem3"))
        .check(jsonPath("$.records[*].actions.updateitems.rest.params.items..itemId").findAll.saveAs("ListOfLineItems")))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
       
      .exec(session => session.removeAll("ListOfLineItems"))     
    /* ********** GetPricingDetailsForCartLineItem *********** */
      .exec(http("1GetPricingDetailsForCartLineItem1")
        .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/${LineItem2}/pricing?fields=RecurringCharge__c")
        .headers(header_1))   

      /* ********** 23. GetCartItemsByItemId*********** */
      .exec(http("1GetCartItemsByItemId2")
        .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
        .queryParamSeq(Seq(("id", "${LineItem1}")))
        .headers(header_1))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
      /* ********** CloneCartLineItem ********** */
      .exec(http("1CloneCartLineItem")
        .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/clone")
        .headers(header_1)
        .body( StringBody("""{
                                "items": [
                                            {"itemId": "${LineItem1}"}
                                ],
                                "hierarchy": 1,
                                "lastItemId": "",
                                "pagesize": 20
                             }""")).asJson)

     .pause(Configuration.MiniMinWaitMs milliseconds, Configuration.MiniMaxWaitMs milliseconds)
      /* ********** GetPricingDetailsForCartLineItem *********** */
      .exec(http("1GetPricingDetailsForCartLineItem2")
        .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/${LineItem2}/pricing?fields=RecurringCharge__c")
        .headers(header_1))

      .pause(Configuration.MiniMinWaitMs milliseconds, Configuration.MiniMaxWaitMs milliseconds)
    /* ********** GetCartLineItems *********** */
      .exec(http("1GetCartLineItems3")
        .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
        .headers(header_1)
        .check(jsonPath("$.records[*].actions.updateitems.rest.params.items..itemId").findAll.saveAs("ListOfLineItems")))
    
     .exec(session => session.removeAll("LineItem2","LineItem3"))      

     .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)              
     
      /* ********** SubmitOrder ********** */ 
      .exec(http("1SubmitOrder")
        .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/checkout")
        .headers(header_1)
        .body( StringBody("""{
                                    "items":[
                                              {"itemId":"${LineItem1}"}
                                    ],
                                    "hierarchy":1,
                                    "lastItemId":"",
                                    "pagesize":20
                                }""")).asJson)


   .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
   
  }
   
}
