package CMT

import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.core.structure.ChainBuilder
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._
import io.gatling.jsonpath._
import Headers._
import scala.collection._
import java.time.format.DateTimeFormatter
import java.time.LocalDateTime
import java.time.LocalDate

import io.gatling.core.feeder._
import java.util.Base64
import java.nio.charset.StandardCharsets
import scala.util.matching.Regex

 object PenaltyRulesFlow {

    val uri01 = Configuration.Uri01
    val uri05 = Configuration.Uri05
    val uri10 = Configuration.Uri10
    val randomNumber = new scala.util.Random
    val testDuration = Integer.getInteger("testDuration", 1)
    var promotionList = Vector[String]()
    var assetList = Vector[String]()
    var randomPromotion = new StringBuilder()
    var randomAsset = new StringBuilder()
    val userFeeder = csv("./src/test/resources/data/cmt/CMT100SKYTestUsers.csv").random
    val accountIdFeeder = csv("./src/test/resources/data/cmt/CMT100SKYTestAccountsPenalty.csv").random
   
    var final_formatted_date = new StringBuilder()


     val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
  val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
  val password_v = (passwordByEnv.get("perf3").toString)
  val password_encoded = password_v.substring(12,(password_v.length - 2 ))
  val credentials = new String(Base64.getDecoder.decode(password_encoded))
    

    val scn = scenario("PenaltyRulesFlow")

    .exec(session => session.set("password",credentials))

  
   .feed(userFeeder)
    .exec(http("4RESTGetOAuthToken")
      .post("https://test.salesforce.com/services/oauth2/token")
      .header("Content-Type", "application/x-www-form-urlencoded")
      .formParam("password", "${password}")
      .formParam("username", "${username}")
      .formParam("client_secret", "7119599995527965426")
      .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
      .formParam("grant_type", "password")
      .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
      .check(status.is(200)))
        
  .repeat(2)
  {   
           /* *********** CreateOrder *********** */
        feed(accountIdFeeder)
        .exec(http("4CreateOrder")
            .post(uri10 +"/services/apexrest/v2/carts")
            .headers(header_1)
            .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
            .body( StringBody("""{"subaction":"createOrder",
                      "inputFields":[
                        {"AccountId":"${AccountId}"},
                        {"PriceListId__c":"a2Pg0000001MwIiEAK"},
                        {"Name":"NewOrder1"},{"Status":"Draft"},
                        {"EffectiveDate":"9/6/2017"}
                      ]}""")).asJson)

          /* ********** SetPriceListForCart *********** */
          .exec(http("4SetPriceListForCart")
            .put(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/")
            .headers(header_1)
            .body(StringBody("""{
                          "inputFields": 
                          [
                            {
                                "PriceListId__c": "a2Pg0000001MwIiEAK" 
                              }
                            ],
                          "cartId": "${OrderID}",
                          "methodName": "updateCarts"
                      }""")).asJson)   

          /* ********** GetListOfPromotionsForCart *********** */ 
          .exec(http("4GetListOfPromotionsForCart")
            .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/promotions")
            .check(jsonPath("$.records[*].id").findAll.saveAs("PromotionList"))
            .headers(header_1))  

           .exec( session => {
                promotionList = session("PromotionList").as[Vector[String]]
                session
              })

          .exec( session => {
            val max = promotionList.length - 1
            val random_index = randomNumber.nextInt(max+1)
            randomPromotion.append(promotionList(random_index))
            //println("PromotionID is ::::"+randomPromotion)
            session
          })

          .exec(session => session.set("PromotionID",randomPromotion))

         .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
      /* ********** AddPromotionToCart *********** */ 
          .exec(http("4AddPromotionToCart")
            .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/promotions")
            .headers(header_1)
            .body( StringBody("""{
                            "items": [{"itemId":"${PromotionID}"}],
                            "promotionId":"${PromotionID}",
                            "cartId":"${OrderID}",
                            "methodName":"postCartsPromoItems"
                                        }""")).asJson)

        .exec( session => {
            randomPromotion = new StringBuilder()
            session
          })

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


        /* ********** SubmitOrder ********** */ 
          .exec(http("4SubmitOrder")
            .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/checkout")
            .headers(header_1)
            .body( StringBody("""{}""")).asJson)

          .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

          .exec(http("4GetAssetsForAccount")
            .get(uri10 +"/services/apexrest/v2/accounts/${AccountId}/assets")
            .headers(header_1)
            .check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfAssetIds")))

          .exec( session => {
                assetList = session("ListOfAssetIds").as[Vector[String]]
                session
              })

          .exec( session => {
            val max = assetList.length - 1
            val random_index = randomNumber.nextInt(max+1)
            randomAsset.append(assetList(random_index))
            println("AssetID is ::::"+randomAsset)
            session
          })

          .exec(session => session.set("AssetID",randomAsset))
          .exec( session => {
            randomAsset = new StringBuilder()
            session
          })

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

          /* ********** GetRequestDateDetailsForOrderItem *********** */
        .exec(http("4GetRequestDateDetailsForOrderItem")
            .get(uri10 +"/services/data/v39.0/query/?q=SELECT+RequestDate__c+FROM+OrderItem+WHERE+RequestDate__c+!=+null+ORDER+BY+RequestDate__c+DESC+LIMIT+10")
            .check(regex("""<RequestDate__c>(.*?)</RequestDate__c>""").findAll.exists.saveAs("RequestDatesList"))
            .headers(header_1))

        .exec( session => {
                val requestDateList = session("RequestDatesList").as[List[String]]
                val maxdate = requestDateList(0)
                val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd") //2017-09-07
                val dateforcurrentrun = LocalDate.parse(maxdate,formatter).plusDays(1)
                final_formatted_date.append(dateforcurrentrun)
                //println("Date for current run"+dateforcurrentrun)
            session
            }) 

        .exec( session => session.set("DATE", final_formatted_date ) )

        .exec( session => {
            final_formatted_date = new StringBuilder()
            session
          })

          /* ************ AssetChangeToOrder *********** */ 
        .exec(http("4AssetChangeToOrder")
            .post(uri10 +"/services/apexrest/v2/carts")
            .headers(header_1)
            .check(jsonPath("$.records[0].cartId").find.saveAs("CartId"))
            .body(StringBody("""{ 
                          "subaction": "assetToOrder",
                          "id":"${AssetID}",
                          "accountId": "${AccountId}", 
                          "requestDate": "${DATE}" 
                    } """)).asJson)

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        /* *********** GetPromotionsAppliedToCart ********** */
        .exec(http("4GetPromotionsAppliedToCart")
            .get(uri10 +"/services/apexrest/v2/cpq/carts/${CartId}/promotions?subaction=getPromotionsAppliedToCart")
            .check(jsonPath("$.records[0].Id.value").find.exists.saveAs("AppliedPromotionId"))
            .headers(header_1))
       .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      /* *********** CancelPromotionWhichHasPenalty ********** */
        .exec(http("4CancelPromotionWhichHasPenalty")
            .delete(uri10 +"/services/apexrest/v2/cpq/carts/${CartId}/promotions?id=${AppliedPromotionId}")
            .headers(header_1))

        .pause( 120000 milliseconds, 120000 milliseconds)
    }
  }
