package CMT

object Headers  {

	val headers_0 = Map(
		"Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-US,en;q=0.8,ms;q=0.6",
		"Connection" -> "keep-alive",
		"Upgrade-Insecure-Requests" -> "1",
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36")
	
  	val header_1 = Map(
  		"Accept" -> "text/javascript, text/html, application/xml, application/json, text/xml, */*",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-US,en;q=0.8",
		"Connection" -> "keep-alive",
  		"Authorization" -> "Bearer ${Token_ID}")


  	val headers_5 = Map(
		"Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-US,en;q=0.8",
		"Connection" -> "keep-alive",
		"Upgrade-Insecure-Requests" -> "1",
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3080.0 Safari/537.36")
  	
	val headers_26 = Map(
		"Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-US,en;q=0.8",
		"Cache-Control" -> "max-age=0",
		"Connection" -> "keep-alive",
		"Origin" -> "https://test.salesforce.com",
		"Upgrade-Insecure-Requests" -> "1",
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3080.0 Safari/537.36")

	val headers_29 = Map("User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3080.0 Safari/537.36")

	val headers_58 = Map(
		"Accept" -> "*/*",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-US,en;q=0.8",
		"Connection" -> "keep-alive",
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3080.0 Safari/537.36")

	val headers_65 = Map(
		"Accept" -> "text/javascript, text/html, application/xml, application/json, text/xml, */*",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-US,en;q=0.8",
		"Connection" -> "keep-alive",
		"Content-Type" -> "application/json; charset=UTF-8 application/x-www-form-urlencoded",
		"Origin" -> "https://0.umps2w1.salesforce.com",
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3080.0 Safari/537.36",
		"X-Requested-With" -> "XMLHttpRequest",
		"apiCallerSource" -> "RHS_Widget",
		"appType" -> "messenger",
		"chatMsgDeepHistoryDarkLaunchEnabled" -> "false",
		"chatMsgDeepHistoryEnabled" -> "false",
		"chatMsgHistoryEnabled" -> "true",
		"connectUrl" -> "https://cs17.salesforce.com",
		"objectId" -> "005g0000002Z1pY",
		"orgId" -> "CS17$00Dg0000006Tt88",
		"sessionId" -> "00Dg0000006Tt88!ARkAQAcIVK9.FKiVpukJ9XDr1Drj2TxK2C91JtWdhlqcHF2uVbv1smnh80NSgVOXmDWriW25D5ZC7egShMlwz1MpJBCdyhZ9",
		"umpsSessionId" -> "")

	val headers_66 = Map(
		"Accept" -> "text/javascript, text/html, application/xml, application/json, text/xml, */*",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-US,en;q=0.8",
		"Connection" -> "keep-alive",
		"Content-Type" -> "application/json; charset=UTF-8 application/x-www-form-urlencoded",
		"Origin" -> "https://0.umps2w1.salesforce.com",
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3080.0 Safari/537.36",
		"X-Requested-With" -> "XMLHttpRequest",
		"apiCallerSource" -> "RHS_Widget",
		"appType" -> "messenger",
		"connectUrl" -> "https://cs17.salesforce.com",
		"objectId" -> "005g0000002Z1pY",
		"orgId" -> "CS17$00Dg0000006Tt88",
		"sessionId" -> "00Dg0000006Tt88!ARkAQAcIVK9.FKiVpukJ9XDr1Drj2TxK2C91JtWdhlqcHF2uVbv1smnh80NSgVOXmDWriW25D5ZC7egShMlwz1MpJBCdyhZ9",
		"umpsSessionId" -> "1d5acc8612b05c03561c46858d0d95ff5aef08ac")

	val headers_67 = Map(
		"Accept" -> "text/javascript, text/html, application/xml, application/json, text/xml, */*",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-US,en;q=0.8",
		"Connection" -> "keep-alive",
		"Content-type" -> "application/x-www-form-urlencoded",
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3080.0 Safari/537.36",
		"X-Requested-With" -> "XMLHttpRequest",
		"apiCallerSource" -> "RHS_Widget",
		"appType" -> "messenger",
		"channelId" -> "CS17$00Dg0000006Tt88_005g0000002Z1pY_02_79c45a4f-c5a2-420b-8c8b-93fb596e36c2",
		"connectUrl" -> "https://cs17.salesforce.com",
		"objectId" -> "005g0000002Z1pY",
		"orgId" -> "CS17$00Dg0000006Tt88",
		"sessionId" -> "00Dg0000006Tt88!ARkAQAcIVK9.FKiVpukJ9XDr1Drj2TxK2C91JtWdhlqcHF2uVbv1smnh80NSgVOXmDWriW25D5ZC7egShMlwz1MpJBCdyhZ9",
		"umpsSessionId" -> "1d5acc8612b05c03561c46858d0d95ff5aef08ac")

	val headers_69 = Map(
		"Accept" -> "text/javascript, text/html, application/xml, application/json, text/xml, */*",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-US,en;q=0.8",
		"Connection" -> "keep-alive",
		"Content-Type" -> "application/x-www-form-urlencoded",
		"Content-type" -> "application/x-www-form-urlencoded",
		"Origin" -> "https://0.umps2w1.salesforce.com",
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3080.0 Safari/537.36",
		"X-Requested-With" -> "XMLHttpRequest",
		"apiCallerSource" -> "RHS_Widget",
		"appType" -> "messenger",
		"channelId" -> "CS17$00Dg0000006Tt88_005g0000002Z1pY_02_79c45a4f-c5a2-420b-8c8b-93fb596e36c2",
		"connectUrl" -> "https://cs17.salesforce.com",
		"objectId" -> "005g0000002Z1pY",
		"orgId" -> "CS17$00Dg0000006Tt88",
		"sessionId" -> "00Dg0000006Tt88!ARkAQAcIVK9.FKiVpukJ9XDr1Drj2TxK2C91JtWdhlqcHF2uVbv1smnh80NSgVOXmDWriW25D5ZC7egShMlwz1MpJBCdyhZ9",
		"umpsSessionId" -> "1d5acc8612b05c03561c46858d0d95ff5aef08ac")

	val headers_74 = Map(
		"Accept" -> "*/*",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-US,en;q=0.8",
		"Authorization" -> "OAuth 00Dg0000006Tt88!ARkAQAcIVK9.FKiVpukJ9XDr1Drj2TxK2C91JtWdhlqcHF2uVbv1smnh80NSgVOXmDWriW25D5ZC7egShMlwz1MpJBCdyhZ9",
		"Connection" -> "keep-alive",
		"Content-Type" -> "application/json; charset=UTF-8",
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3080.0 Safari/537.36")

	val headers_125 = Map(
		"Accept" -> "text/javascript, text/html, application/xml, application/json, text/xml, */*",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-US,en;q=0.8",
		"Connection" -> "keep-alive",
		"Content-Type" -> "application/json; charset=UTF-8 application/x-www-form-urlencoded",
		"Origin" -> "https://0.umps2w1.salesforce.com",
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3080.0 Safari/537.36",
		"X-Requested-With" -> "XMLHttpRequest",
		"apiCallerSource" -> "RHS_Widget",
		"appType" -> "messenger",
		"channelId" -> "CS17$00Dg0000006Tt88_005g0000002Z1pY_02_79c45a4f-c5a2-420b-8c8b-93fb596e36c2",
		"connectUrl" -> "https://cs17.salesforce.com",
		"objectId" -> "005g0000002Z1pY",
		"orgId" -> "CS17$00Dg0000006Tt88",
		"sessionId" -> "00Dg0000006Tt88!ARkAQAcIVK9.FKiVpukJ9XDr1Drj2TxK2C91JtWdhlqcHF2uVbv1smnh80NSgVOXmDWriW25D5ZC7egShMlwz1MpJBCdyhZ9",
		"umpsSessionId" -> "1d5acc8612b05c03561c46858d0d95ff5aef08ac")

	val headers_130 = Map(
		"Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-US,en;q=0.8",
		"Cache-Control" -> "max-age=0",
		"Connection" -> "keep-alive",
		"Origin" -> "https://cs17.salesforce.com",
		"Upgrade-Insecure-Requests" -> "1",
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3080.0 Safari/537.36")

	val headers_145 = Map(
		"Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-US,en;q=0.8",
		"Cache-Control" -> "max-age=0",
		"Connection" -> "keep-alive",
		"Origin" -> "https://c.cs17.visual.force.com",
		"Upgrade-Insecure-Requests" -> "1",
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3080.0 Safari/537.36")

	val headers_158 = Map(
		"Origin" -> "https://c.cs17.visual.force.com",
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3080.0 Safari/537.36")

	val headers_160 = Map(
		"Accept" -> "*/*",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-US,en;q=0.8",
		"Connection" -> "keep-alive",
		"Content-Type" -> "application/json",
		"Origin" -> "https://c.cs17.visual.force.com",
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3080.0 Safari/537.36",
		"X-Requested-With" -> "XMLHttpRequest",
		"X-User-Agent" -> "Visualforce-Remoting")

	val headers_184 = Map(
		"Accept" -> "text/xml",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-US,en;q=0.8",
		"Connection" -> "keep-alive",
		"Content-Type" -> "text/xml; charset=UTF-8",
		"Origin" -> "https://cs17.salesforce.com",
		"SOAPAction" -> "",
		"User-Agent" -> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3080.0 Safari/537.36")


}