package CMT

object Configuration {
	val BaseUrl = "https://c.cs17.visual.force.com"
	val Uri01 = "https://test.salesforce.com"
	val Uri05 = "https://c.cs17.visual.force.com"
 	val Uri10 = "https://cs17.salesforce.com"

 	val MinWaitMs = 5000
 	val MaxWaitMs = 8000

 	val MiniMinWaitMs = 5000
 	val MiniMaxWaitMs = 8000

}