package CMT

import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.core.structure.ChainBuilder
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._
import io.gatling.jsonpath._
import Headers._
import scala.collection._
import java.time.format.DateTimeFormatter
import java.time.LocalDateTime
import java.time.LocalDate

import io.gatling.core.feeder._
import java.util.Base64
import java.nio.charset.StandardCharsets
import scala.util.matching.Regex

 object PromotionsAndAdjustmentsUpdateType {

    val uri01 = Configuration.Uri01
    val uri05 = Configuration.Uri05
    val uri10 = Configuration.Uri10
   
    val testDuration = Integer.getInteger("testDuration", 1)
    //val originalItemJson = new StringBuilder()
    var modifiedItemJson = new StringBuilder()
    val origItemAttrHeirarchy = new StringBuilder()
    val modItemAttrHeirarchy = new StringBuilder()
    val randomNumber = new scala.util.Random
    var pbeEntriesList = Vector[String]()
    var promotionList = Vector[String]()
    var lineItemsList = Vector[String]()
    var prodNamesList = Vector[String]()
    var assetIdList = Vector[String]()
    var randomproduct = new StringBuilder()
    var randomPBEntry = new StringBuilder()
    val userFeeder = csv("./src/test/resources/data/cmt/CMT100SKYTestUsers.csv").random
    val accountIdFeeder = csv("./src/test/resources/data/cmt/CMT100SKYTestAccountsUpdatePromoAdj.csv").random
    var final_formatted_date = new StringBuilder()
    var randomAsset1 = new StringBuilder()
    var randomAsset2 = new StringBuilder()
    var randomAsset3 = new StringBuilder()

 val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
  val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
  val password_v = (passwordByEnv.get("perf3").toString)
  val password_encoded = password_v.substring(12,(password_v.length - 2 ))
  val credentials = new String(Base64.getDecoder.decode(password_encoded))

	  val scn = scenario("PromotionsAndAdjustmentsUpdateType")

    .exec(session => session.set("password",credentials))

    .feed(userFeeder)
    //.feed(passFeeder)
    .exec(http("3RESTGetOAuthToken")
      .post("https://test.salesforce.com/services/oauth2/token")
      .header("Content-Type", "application/x-www-form-urlencoded")
      .formParam("password", "${password}")
      .formParam("username", "${username}")
      .formParam("client_secret", "7119599995527965426")
      .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
      .formParam("grant_type", "password")
      .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
      .check(status.is(200)))
        
  .repeat(2)
  {  

          /* *********** CreateOrder *********** */
        feed(accountIdFeeder)
        .exec(http("3CreateOrder")
            .post(uri10 +"/services/apexrest/v2/carts")
            .headers(header_1)
            .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
            .body( StringBody("""{"subaction":"createOrder",
                      "inputFields":[
                        {"AccountId":"${AccountId}"},
                        {"PriceListId__c":"a2Pg0000001MwIREA0"},
                        {"Name":"NewOrder1"},{"Status":"Draft"},
                        {"EffectiveDate":"9/6/2017"}
                      ]}""")).asJson)

          .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
          /* ********** SetPriceListForCart *********** */
          .exec(http("3SetPriceListForCart")
            .put(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/")
            .headers(header_1)
            .body(StringBody("""{
                          "inputFields": 
                          [
                            {
                                "PriceListId__c": "a2Pg0000001MwIREA0" 
                              }
                            ],
                          "cartId": "${OrderID}",
                          "methodName": "updateCarts"
                      }""")).asJson)   

          /* ********** GetListOfProductsForCart *********** */
          .exec(http("3GetListOfProductsForCart")
            .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/products")
            .check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfPBEntries"))
            .headers(header_1))

          .exec( session => {
                pbeEntriesList = session("ListOfPBEntries").as[Vector[String]]
                session
              })

        .repeat(3,"counter")
        {

            
            exec(session => session.set("ProductID",""))
            .exec( session => {
            val max = pbeEntriesList.length - 1
            val random_index = randomNumber.nextInt(max+1)
            randomPBEntry.append(pbeEntriesList(random_index))
            //println("ProductID is ::::"+randomPBEntry)
            session
          })

          .exec(session => session.set("ProductID",randomPBEntry))
          .exec( session => {
            randomPBEntry = new StringBuilder()
            session
          })
          /* ********** AddItemsToCart *********** */
          .exec(http("3AddItemsToCart")
            .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
            .headers(header_1)
            .body( StringBody("""{
                                        "items":[{
                                        "itemId":"${ProductID}"
                                        }],
                                        "hierarchy":3,
                                        "lastItemId":"",
                                        "pagesize":20
                                        }""")).asJson)

          .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
          
        }


        /* ********** GetCartLineItems *********** */
          .exec(http("3GetCartLineItems1")
            .get(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
            .headers(header_1)
            .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1"))
            .check(jsonPath("$.records[1].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem2"))
            .check(jsonPath("$.records[2].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem3"))
            .check(jsonPath("$.records[*].actions.updateitems.rest.params.items..itemId").findAll.saveAs("LineItemsList")))

          .exec( session => {
                lineItemsList = session("LineItemsList").as[Vector[String]]
                session
              })

          .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
          /* ********** SubmitOrder ********** */ 
          .exec(http("3SubmitOrder")
            .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/checkout")
            .headers(header_1)
            .body( StringBody("""{}
                                    }""")).asJson)

          .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

       /* ********** GetAssetsForAccount ********** */
        .exec(http("3GetAssetsForAccount")
            .get(uri10 +"/services/apexrest/v2/accounts/${AccountId}/assets")
            .headers(header_1)
            .check(jsonPath("$.records[0].Id.value").find.saveAs("assetId1"))
            .check(jsonPath("$.records[1].Id.value").find.saveAs("assetId2"))
            .check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfAssetIds")))

       .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      /* ********** GetRequestDateDetailsForOrderItem *********** */
        .exec(http("3GetRequestDateDetailsForOrderItem")
            .get(uri10 +"/services/data/v39.0/query/?q=SELECT+RequestDate__c+FROM+OrderItem+WHERE+RequestDate__c+!=+null+ORDER+BY+RequestDate__c+DESC+LIMIT+10")
            .check(regex("""<RequestDate__c>(.*?)</RequestDate__c>""").findAll.exists.saveAs("RequestDatesList"))
            .headers(header_1))
        
        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        .exec( session => {
                //println("ListOfAssetIds::::")
                //println( session( "ListOfAssetIds" ).as[String] )
                assetIdList = session("ListOfAssetIds").as[Vector[String]]
                val max = assetIdList.length - 1
                val random_index1 = randomNumber.nextInt(max+1)
                val random_index2 = randomNumber.nextInt(max+1)
                val random_index3 = randomNumber.nextInt(max+1)
                randomAsset1.append(assetIdList(random_index1))
                randomAsset2.append(assetIdList(random_index2))
                randomAsset3.append(assetIdList(random_index3))
                val requestDateList = session("RequestDatesList").as[List[String]]
                val maxdate = requestDateList(0)
                val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd") //2017-09-07
                val dateforcurrentrun = LocalDate.parse(maxdate,formatter).plusDays(1)
                final_formatted_date.append(dateforcurrentrun)
                //println("Date for current run"+dateforcurrentrun)
            session
            }) 

        .exec( session => session.set("DATE", final_formatted_date ) )
        .exec( session => {
            final_formatted_date = new StringBuilder()
            session
          })
        
        .exec( session => session.set("AssetId1",  randomAsset1) )
         .exec( session => {
            randomAsset1 = new StringBuilder()
            session
          })
        
        .exec( session => session.set("AssetId2", randomAsset2 ) )
        .exec( session => {
            randomAsset2 = new StringBuilder()
            session
          })

        .exec( session => session.set("AssetId3", randomAsset3 ) )
        .exec( session => {
            randomAsset3 = new StringBuilder()
            session
          })

        /* ************ AssetChangeToOrder *********** */ 
        .exec(http("3AssetChangeToOrder")
            .post(uri10 +"/services/apexrest/v2/carts")
            .headers(header_1)
            .check(jsonPath("$.records[0].cartId").find.saveAs("CartId"))
            .body(StringBody("""{ 
                          "subaction": "assetToOrder",
                          "id":"${AssetId1},${AssetId2},${AssetId3}",
                          "accountId": "${AccountId}", 
                          "requestDate": "${DATE}" 
                    } """)).asJson)

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

          

      .exec(http("3GetCartLineItems2")
            .get(uri10 +"/services/apexrest/v2/cpq/carts/${CartId}/items")
            .headers(header_1)
            .check(jsonPath("$.records[*].PricebookEntry.Product2.Name").findAll.saveAs("LineItemsList")))

      .exec( session => {
                prodNamesList = session("LineItemsList").as[Vector[String]]
                val max = prodNamesList.length - 1
                randomproduct.append(prodNamesList(randomNumber.nextInt(max+1)))
                //println("Product Name List is ::::"+prodNamesList)
            session
            })

      .exec( session => session.set("ProductName", randomproduct ) )


      .exec( session => {
            randomproduct = new StringBuilder()
            session
            })


      .exec(http("3GetProductIdForProductName")
            .get(uri10 +"/services/data/v40.0/query/?q=SELECT Id FROM Product2 WHERE Name='${ProductName}'")
            .check(regex("""<Id>(.*?)</Id>""").find.exists.saveAs("ProductId"))
            .headers(header_1))


      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("3GetPromotionForProductFromPLE")
            .get(uri10 +"/services/data/v40.0/query/?q=SELECT PromotionId__c FROM PriceListEntry__c WHERE ProductId__c = '${ProductId}' AND Name = 'Price-List-3-Update-Promo-Adj'")
            .check(regex("""<PromotionId__c>(.*?)</PromotionId__c>""").find.exists.saveAs("PromotionId"))
            .headers(header_1))


       .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
      /* ********** AddPromotionToCart *********** */ 
          .exec(http("3AddPromotionToCart")
            .post(uri10 +"/services/apexrest/v2/cpq/carts/${CartId}/promotions")
            .headers(header_1)
            .body( StringBody("""{
                            "items": [{"itemId":"${PromotionId}"}],
                            "promotionId":"${PromotionId}",
                            "cartId":"${CartId}",
                            "methodName":"postCartsPromoItems"
                                       }""")).asJson)
         
         .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        //SubmitOrder
        /* ********** SubmitOrder ********** */ 
          .exec(http("3SubmitOrder")
            .post(uri10 +"/services/apexrest/v2/cpq/carts/${CartId}/items/checkout")
            .headers(header_1)
            .body( StringBody("""{}""")).asJson)
  }

}
