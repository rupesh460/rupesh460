  package XOM_Thor

  import scala.concurrent.duration._
  import io.gatling.core.Predef._
  import io.gatling.core.structure.ChainBuilder
  import io.gatling.http.Predef._
  import io.gatling.jdbc.Predef._
  import io.gatling.jsonpath._
  import Headers._
  import scala.collection._
  import java.time.format.DateTimeFormatter
  import java.time.LocalDateTime
  import java.time.LocalDate

import io.gatling.core.feeder._
import java.util.Base64
import java.nio.charset.StandardCharsets
import scala.util.matching.Regex


   object XOM_Thor_Test {

      val uri01 = Configuration.Uri01
      val uri05 = Configuration.Uri05
      val uri10 = Configuration.Uri10
      var session_ids = Vector[String]()
      var xomSubmitOrder = new StringBuilder()
      val randomNumber = new scala.util.Random
      var accountName = new StringBuilder()
      val productlineitem = System.getProperty("productlineitem")
      val userFeeder = csv("./src/test/resources/data/xomthor/XOM_Thor_Users.csv").circular
       val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
      val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
      val password_v = (passwordByEnv.get("perf3").toString)
      val password_encoded = password_v.substring(12,(password_v.length - 2 ))
      val credentials = new String(Base64.getDecoder.decode(password_encoded))


      val productFeeder = csv("./src/test/resources/data/xomthor/XOM_Thor_Products_"+productlineitem+"lineitem.csv").random
      //val accountFeeder = csv("./src/test/resources/data/xomthor/XOM_Thor_Accounts_2.csv").circular

  	  val scn = scenario("XOM_Thor_Test")
      .exec(session => session.set("password",credentials))

      .feed(userFeeder)
      .exec(http("XOM_Login")
          .post(uri01 + "/")
          .headers(headers_00)
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          .formParam("startURL", "")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          .formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "M1D2l15jFvl")
          .formParam("display", "page")
          .formParam("username", "${username}")
          .formParam("pw", "${password}")
          .formParam("Login", ""))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("RESTGetOAuthToken")
          .post("https://test.salesforce.com/services/oauth2/token")
          .header("Content-Type", "application/x-www-form-urlencoded")
          .formParam("password", "${password}")
          .formParam("username", "${username}")
          .formParam("client_secret", "7119599995527965426")
          .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
          .formParam("grant_type", "password")
          .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
          .check(status.is(200)))

      .repeat(1)
      {

    /***************************************************** start of creating new account with Order**********************************/

         exec(session => session.set("AccountName",""))

        .exec( session => {
              val random_index = randomNumber.nextInt(100000)
              accountName.append("Acc-10-Mar-2020-"+random_index)
              session
            })

            .exec(session => session.set("AccountName",accountName))

             .exec( session => {
              accountName = new StringBuilder()
              session
            })

      /************ CreateAccount ************/
          .exec(http("01_OMPlus_TA_CreateAccount")
              .post(uri10 +"/services/data/v41.0/sobjects/account")
              .headers(header_1)
              .check(regex(""""id":"(.*?)"""").find.exists.saveAs("AccountId"))
              .body( StringBody("""
                {
                      "Name" : "${AccountName}",
                      "ShippingCity" : "San Francisco",
                      "RecordTypeId" : "012g00000005CoWAAU",
                      "Status__c"    : "Active"
                }""")).asJson)

           /* *********** CreateAOrder *********** */
          /*.exec(http("02_OMPlus_TA_Create_a_new_order")
          .post(uri10 +"/services/apexrest/v2/carts")
          .headers(header_1)
          .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
          .body(StringBody("""{"subaction":"createOrder",
                    "inputFields":[
                      {"AccountId":"${AccountId}"},
                      {"PriceListId__c":"a2Pg0000001UvvuEAC"},
                      {"Name":"NewOrder1"},{"Status":"Draft"},
                      {"EffectiveDate":"01/02/2019"}
                    ]}""")).asJson)*/


/*****************************************************End of creating new account with Order**********************************/
      //feed(accountFeeder)
      .exec(http("02_OMPlus_TA_Create_a_new_order")
          .post(uri10 +"/services/apexrest/v2/carts")
          .headers(header_1)
          .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
          .body(StringBody("""{"subaction":"createOrder",
                    "inputFields":[
                      {"AccountId":"${AccountId}"},
                      {"PriceListId__c":"a2Pg0000001UvvuEAC"},
                      {"Name":"NewOrder1"},{"Status":"Draft"},
                      {"EffectiveDate":"04/23/2018"}
                    ]}""")).asJson)

      .exec(http("03_OMPlus_TA_Order_Detail")
          .get(uri10 + "/${OrderID}")
          .headers(headers_05))
          //.check(regex("""sforce.connection.sessionId = '(.+)'; }\n...[a-zA-Z0-9\s*'_,:{.(]*name: 'XOMSubmitOrder'""").find.exists.saveAs("""sfdc_session_id""")))
          //.check(regex("""sforce.connection.sessionId = '(.+)';.}[a-zA-Z0-9\s{.('_,:]*name:.'XOMSubmitOrder'}""").find.exists.saveAs("""sfdc_session_id""")))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .feed(productFeeder)
      .exec(http("04_OMPlus_TA_Add_items_to_cart")
          .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
          .headers(header_1)
          .check(regex("""Successfully added.""").find.exists)
          //.check(regex("""\{"totalSize":1,"messages":\[\{"code":"150","severity":"INFO","message":"Successfully(......)""").find.exists.saveAs("AddStatus"))
          .body( StringBody("""{"methodName":"postCartsItems","items":[{"itemId":"${ProductId}"}],"cartId":"${OrderID}","price":true,"validate":true,"includeAttachment":false,"pagesize":10,"lastRecordId":null,"hierarchy":-1,"query":"plan"}""")).asJson)

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

 /* ********** SubmitOrder ********** */
  .exec(http("05_OMPlus_TA_Submitorder")
    .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items/checkout")
    .headers(header_1)
    .check(regex("""SUBMIT-1001""").find.exists)
    .body( StringBody("""{
    "cartId": "${OrderID}",
    "skipCheckoutValidation": true
    }""")).asJson)


/*
      .exec(http("SubmitOrder")
          .post(uri05 + "/services/Soap/package/SimpleDecompositionController")
          .headers(headers_02)
          .check(regex("""<decomposeAndCreatePlanExResponse><result>\{&quot;planId&quot;:&quot;(.+)&quot;,""").find.exists.saveAs("PlanId"))
          .body(ElFileBody("./src/test/resources/bodies/xom/XOM_Thor_Submitorder_0001_request.txt")))
*/
    }

  }
