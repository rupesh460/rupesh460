package eComm_V105

object Headers
{
	val header_0 = Map(
  		"Accept" -> "text/javascript, text/html, application/xml, application/json, text/xml, */*",
		"Accept-Encoding" -> "gzip, deflate, br",
		"Accept-Language" -> "en-US,en;q=0.8",
		"Connection" -> "keep-alive",
  		"Authorization" -> "Bearer ${Token_ID}")
}