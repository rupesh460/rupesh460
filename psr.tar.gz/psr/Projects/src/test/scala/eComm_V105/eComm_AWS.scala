package eComm_V105

import scala.concurrent.duration._
import io.gatling.core.Predef._
import io.gatling.core.structure.ChainBuilder
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._
import io.gatling.jsonpath._
import Headers._
import scala.collection._

object eComm_AWS
{
    var userid = new StringBuilder()
    val uri02 = Configuration.Uri02_AWS
    val userFeeder = csv("./src/test/resources/data/datagen/Perf2users.csv").random
    val offerFeeder = csv("./src/test/resources/data/eComm/offercodes.csv").random
    val contextFeeder = csv("./src/test/resources/data/eComm/contextparams.csv").random
    val promoFeeder = csv("./src/test/resources/data/eComm/promocodes.csv").random
    val childOfferFeeder = csv("./src/test/resources/data/eComm/childoffercodes.csv").random
    val accountFeeder = csv("./src/test/resources/data/eComm/accounts.csv").random
    val attrFeeder = csv("./src/test/resources/data/eComm/eCom-Prod-Bnd-15399454256600.csv").random
    val randomNumber = new scala.util.Random
    

    val productViewsScn = scenario("ProductViews")


      .repeat(60000){

      /* ********** GetListOfProductsForCart *********** */
      feed(contextFeeder)
      .exec(http("GetOffersByCatalog")
        .get(uri02 +"""v3/catalogs/ECOM-CATALOG/offers?context={"accSla":"${accSla}","accStatus":"${accStatus}","accPhone":"${accPhone}"}""")
        .check(jsonPath("$.offers[*].ProductCode").findAll.saveAs("ProductOffersList"))).exitHereIfFailed

      .pause(Configuration.productViewMinWaitMs milliseconds, Configuration.productViewMaxWaitMs milliseconds) 

      /* ********** GetContainsProducts *********** */
      .feed(childOfferFeeder)
      .exec(http("GetContainsProducts")
        .get(uri02 +"""v3/catalogs/ECOM-CATALOG/offers?contains=${ChildOfferCode}&context={"accSla":"${accSla}","accStatus":"${accStatus}","accPhone":"${accPhone}"}""")
        .check(regex("""offerDetails"""))).exitHereIfFailed

      .pause(Configuration.productViewMinWaitMs milliseconds, Configuration.productViewMaxWaitMs milliseconds)  
    }

    val addToCartScn = scenario("AddToCart")

    .repeat(60000)
    {

      /* ********** GetOfferDetails *********** */
      feed(offerFeeder)
      .exec(http("GetOfferDetails")
        .get(uri02 +"v3/catalogs/ECOM-CATALOG/offers/${OfferCode}")
        .check(bodyString.saveAs("OfferDetailsRes"))).exitHereIfFailed

      .pause(Configuration.addToCartMinWaitMs milliseconds, Configuration.addToCartMaxWaitMs milliseconds)

      /* ********** ConfigureOffer *********** */
      .feed(attrFeeder)
      .exec(http("ConfigureOffer")
        .post(uri02 +"v3/catalogs/ECOM-CATALOG/offers/eCom-Prod-Bnd-15399454256600")
        //.body(StringBody("""${OfferDetailsRes}""")).asJson
        .body(RawFileBody("./src/test/resources/bodies/eComm/eCom-Prod-Bnd-15399454256600.txt")).asJson
        .check(regex(""""result":(.+?)."errorCode":"INVOKE""").find.exists.saveAs("AddWithConfig"))).exitHereIfFailed

       .pause(Configuration.addToCartMinWaitMs milliseconds, Configuration.addToCartMaxWaitMs milliseconds)

      /* ********** AddWithNoConfig *********** */
      .exec(http("AddToCartWithNoConfig")
        .post(uri02 +"v3/catalogs/ECOM-CATALOG/basket")
        .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKey1"))
        .body(StringBody("""{"offer":"${OfferCode}","basketAction":"AddWithNoConfig"}""")).asJson).exitHereIfFailed

      .pause(Configuration.addToCartMinWaitMs milliseconds, Configuration.addToCartMaxWaitMs milliseconds) 

      /* ********** AddWithConfig *********** */
      .exec(http("AddToCartWithConfig")
        .post(uri02 +"v3/catalogs/ECOM-CATALOG/basket/${CartContextKey1}")
        .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKey2"))
        .check(regex("""result":(.+?)."errorCode""").find.exists.saveAs("CreateCart"))
        .body(StringBody("""{"basketAction":"AddAfterConfig","productConfig":${AddWithConfig}}""")).asJson).exitHereIfFailed

        /* ********** DeleteFromBasket *********** */
      .exec(http("DeleteFromBasket")
        .post(uri02 +"v3/catalogs/ECOM-CATALOG/basket/${CartContextKey2}")
        .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKey3"))
        .body(StringBody("""{"deleteBundleNumber":"1","basketAction":"DeleteFromBasket"}""")).asJson).exitHereIfFailed

      .pause(Configuration.addToCartMinWaitMs milliseconds, Configuration.addToCartMaxWaitMs milliseconds)

      /* ********** AddPromotion-Step1 *********** */
      .feed(promoFeeder)
      .exec(http("AddPromotion-Step1")
        .post(uri02 +"v3/catalogs/ECOM-CATALOG/basket/${CartContextKey2}")
        .check(regex("""cartContextKey":"(.+?)"."result""").optional.saveAs("CartContextKey3"))
        .check(regex(""""transactionKey":"(.+?)"""").optional.saveAs("TransKey"))
        .check(regex("""result":(.+?)."errorCode""").optional.saveAs("CreateCart"))
        .check(regex(""""transactionKey":"(.+?)"""").count.saveAs("TransKeyCount"))
        .body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}"}""")).asJson).exitHereIfFailed

      .pause(Configuration.addToCartMinWaitMs milliseconds, Configuration.addToCartMaxWaitMs milliseconds)
      
      .doIfEqualsOrElse("${TransKeyCount}", 1) 
      {
        // executed if the session value stored in "actualValue" equals to "expectedValue"
        /* ********** AddPromotion-Step2 *********** */
        feed(promoFeeder)
        .exec(http("AddPromotion-Step2")
        .post(uri02 +"v3/catalogs/ECOM-CATALOG/basket/${CartContextKey2}")
        .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKey3"))
        .check(regex("""result":(.+?)."errorCode""").find.exists.saveAs("CreateCart1"))
        .body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}","transactionKey":"${TransKey}"}""")).asJson).exitHereIfFailed

         .pause(Configuration.addToCartMinWaitMs milliseconds, Configuration.addToCartMaxWaitMs milliseconds)
      } 
      {
        // executed if the session value stored in "actualValue" is not equal to "expectedValue"

         pause(Configuration.addToCartMinWaitMs milliseconds, Configuration.addToCartMaxWaitMs milliseconds)
      }

    }

    val checkOutScn = scenario("CheckOut")

    .repeat(60000) {

      /* ********** GetOfferDetails *********** */
      feed(offerFeeder)
      .exec(http("GetOfferDetails")
        .get(uri02 +"v3/catalogs/ECOM-CATALOG/offers/${OfferCode}")
        .check(bodyString.saveAs("OfferDetailsRes"))).exitHereIfFailed

      .pause(Configuration.checkOutMinWaitMs milliseconds, Configuration.checkOutMaxWaitMs milliseconds) 

      /* ********** ConfigureOffer *********** */
      .feed(attrFeeder)
      .exec(http("ConfigureOffer")
        .post(uri02 +"v3/catalogs/ECOM-CATALOG/offers/eCom-Prod-Bnd-15399454256600")
        .body(ElFileBody("./src/test/resources/bodies/eComm/eCom-Prod-Bnd-15399454256600.txt")).asJson
        .check(regex(""""result":(.+?)."errorCode":"INVOKE""").find.exists.saveAs("AddWithConfig"))).exitHereIfFailed

      .pause(Configuration.checkOutMinWaitMs milliseconds, Configuration.checkOutMaxWaitMs milliseconds) 

      /* ********** AddWithNoConfig *********** */
      .exec(http("AddToCartWithNoConfig")
        .post(uri02 +"v3/catalogs/ECOM-CATALOG/basket")
        .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKey1"))
        .body(StringBody("""{"offer":"${OfferCode}","basketAction":"AddWithNoConfig"}""")).asJson).exitHereIfFailed

      .pause(Configuration.checkOutMinWaitMs milliseconds, Configuration.checkOutMaxWaitMs milliseconds)  

      /* ********** AddWithConfig *********** */
      .exec(http("AddToCartWithConfig")
        .post(uri02 +"v3/catalogs/ECOM-CATALOG/basket/${CartContextKey1}")
        .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKey2"))
        .check(regex("""result":(.+?)."errorCode""").find.exists.saveAs("CreateCart"))
        .body(StringBody("""{"basketAction":"AddAfterConfig","productConfig":${AddWithConfig}}""")).asJson).exitHereIfFailed

     /* ********** AddPromotion-Step1 *********** */
      .feed(promoFeeder)
      .exec(http("AddPromotion-Step1")
        .post(uri02 +"v3/catalogs/ECOM-CATALOG/basket/${CartContextKey2}")
        .check(regex("""cartContextKey":"(.+?)"."result""").optional.saveAs("CartContextKey3"))
        .check(regex(""""transactionKey":"(.+?)"""").optional.saveAs("TransKey"))
        .check(regex("""result":(.+?)."errorCode""").optional.saveAs("CreateCart"))
        .check(regex(""""transactionKey":"(.+?)"""").count.saveAs("TransKeyCount"))
        .body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}"}""")).asJson).exitHereIfFailed

      .pause(Configuration.checkOutMinWaitMs milliseconds, Configuration.checkOutMaxWaitMs milliseconds)  
      
      .doIfEqualsOrElse("${TransKeyCount}", 1) 
      {
        // executed if the session value stored in "actualValue" equals to "expectedValue"
        /* ********** AddPromotion-Step2 *********** */
        feed(promoFeeder)
        .exec(http("AddPromotion-Step2")
        .post(uri02 +"v3/catalogs/ECOM-CATALOG/basket/${CartContextKey2}")
        .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKey3"))
        .check(regex("""result":(.+?)."errorCode""").find.exists.saveAs("CreateCart1"))
        .body(StringBody("""{"basketAction":"AddWithNoConfig","offer":"${PromoOffer}","transactionKey":"${TransKey}"}""")).asJson).exitHereIfFailed

        /* ********** CreateCart *********** */
        .feed(accountFeeder)
        .exec(http("CreateCart")
        .post(uri02 +"v3/carts")
        .check(regex("""orderId":"(.+?)"""").find.exists.saveAs("OrderId"))
        .body(StringBody("""{"JSONResult":${CreateCart1},"accountId": "${AccountId}","catalogCode": "ECOM-CATALOG"}""")).asJson).exitHereIfFailed

        .pause(Configuration.checkOutMinWaitMs milliseconds, Configuration.checkOutMaxWaitMs milliseconds) 
      } 
      {
        // executed if the session value stored in "actualValue" is not equal to "expectedValue"
        /* ********** CreateCart *********** */
        feed(accountFeeder)
        .exec(http("CreateCart")
        .post(uri02 +"v3/carts")
        .check(regex("""orderId":"(.+?)"""").find.exists.saveAs("OrderId"))
        .body(StringBody("""{"JSONResult":${CreateCart},"accountId": "${AccountId}","catalogCode": "ECOM-CATALOG"}""")).asJson).exitHereIfFailed

        .pause(Configuration.checkOutMinWaitMs milliseconds, Configuration.checkOutMaxWaitMs milliseconds) 
      }

      
    }       
}