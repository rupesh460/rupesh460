      package XOM_MACD_OneAsset

      import scala.concurrent.duration._
      import io.gatling.core.Predef._
      import io.gatling.core.structure.ChainBuilder
      import io.gatling.http.Predef._
      import io.gatling.jdbc.Predef._
      import io.gatling.jsonpath._
      import Headers._
      import scala.collection._
      import java.time.format.DateTimeFormatter
      import java.time.LocalDateTime
      import java.time.LocalDate

import io.gatling.core.feeder._
import java.util.Base64
import java.nio.charset.StandardCharsets
import scala.util.matching.Regex


      object XOM_MACD_Test_OneAsset {

        val uri01 = Configuration.Uri01
        val uri05 = Configuration.Uri05
        val uri10 = Configuration.Uri10

        //var session_ids = Vector[String]()
        var xomSubmitOrder = new StringBuilder()
        var modifiedItemJson = new StringBuilder()
        val timestamp = LocalDate.now()
        var final_formatted_date1 = new StringBuilder()
        var final_formatted_date2 = new StringBuilder()
        var final_formatted_date3 = new StringBuilder()
        var assetlist_update = new StringBuilder()
        var assetlist_delete = new StringBuilder()
        var assetlist_add = new StringBuilder()
        /*val randomNumber = new scala.util.Random
        var offset = new StringBuilder()
        var OFFSET = new StringBuilder()
        var DATE_add  = new StringBuilder()
        var DATE_update  = new StringBuilder()
        var DATE_delete  = new StringBuilder()
        var assetlist_id_add = new StringBuilder()
        var assetlist_id_delete = new StringBuilder()
        var assetlist_id_update = new StringBuilder()*/
	
 val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
  val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
  val password_v = (passwordByEnv.get("perf3").toString)
  val password_encoded = password_v.substring(12,(password_v.length - 2 ))
  val credentials = new String(Base64.getDecoder.decode(password_encoded))


        val userFeeder = csv("./src/test/resources/data/xom_macd_OneAssets/XOM_Users.csv").random
        val productFeeder = csv("./src/test/resources/data/xom_macd_OneAssets/XOM_MACD_Products.csv").random
        val accountFeeder = csv("./src/test/resources/data/xom_macd_OneAssets/XOM_Accounts.csv").random
        val assetFeeder = csv("./src/test/resources/data/xom_macd_OneAssets/XOM_Assets_add_oneasset.csv").circular
        val assetFeeder_update = csv("./src/test/resources/data/xom_macd_OneAssets/XOM_Assets_update_oneasset.csv").circular
        val assetFeeder_delete = csv("./src/test/resources/data/xom_macd_OneAssets/XOM_Assets_delete_oneasset.csv").circular
        val productFeederdelete = csv("./src/test/resources/data/xom_macd_OneAssets/XOM_Products.csv").random


        val Normalflow = scenario("XOM_MACD_Normalflow")
        //.exec(session => session.set("PriceListId",Configuration.PriceListId))
        .exec(session => session.set("password",credentials))

        .feed(userFeeder)      
        .exec(http("XOM_Login")
          .post(uri01 + "/")
          .headers(headers_00)
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          .formParam("startURL", "")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          .formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "M1D2l15jFvl")
          .formParam("display", "page")
          .formParam("username", "${username}")
          .formParam("pw", "${password}")
          .formParam("Login", ""))

        //.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        .exec(http("RESTGetOAuthToken")
          .post("https://test.salesforce.com/services/oauth2/token")
          .header("Content-Type", "application/x-www-form-urlencoded")
          .formParam("password", "${password}")
          .formParam("username", "${username}")
          .formParam("client_secret", "7119599995527965426")
          .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
          .formParam("grant_type", "password")
          .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
          .check(status.is(200)))

        //.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        .repeat(80000)
        {

          feed(assetFeeder)
              
              /***************** addToCart_Click on Change Order ***************/
              .exec(http("addToCart_Click on Change Order")
                .get(uri05 +"/apex/MACDFdo?id=${AssetId_add}")
                .headers(headers_145)
                .check(regex("""GenericInvoke2","len":4,"ns":"","ver":32.0,"csrf":"(.+?)"}""").find.exists.saveAs("csrfToken"))
                .check(regex("""vid":"(.+?)","xhr""").find.exists.saveAs("vid")))

              .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
              .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

              .exec(http("addToCart_Create a new MACD order")
                .post(uri05 +"/apexremote")
                .headers(headers_01)
                .check(regex("""fdoId.":."(.+?).",."error""").find.exists.saveAs("CartId_ForAdding"))
                .body(ElFileBody("./src/test/resources/bodies/xom_macd_OneAssets/createmacdorder_add_oneasset.txt")))

              .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


              /*.exec(http("addToCart_OrderlineitemCount")
                .get(uri10 +"/services/data/v39.0/query/?q=SELECT+count()+FROM+OrderItem+WHERE+OrderId+=+'${CartId_ForAdding}'")
                .check(regex("""<totalSize>20<\/totalSize>""").optional.saveAs("lineitemsizesize"))
                .headers(header_1))

              .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)*/

              

            
              .exec(http("addToCart_Get new csrf token")
              .get(uri05 +"/apex/HybridCPQ?id=${CartId_ForAdding}")
              .headers(headers_01)
              .check(regex("""vid":"(.+?)...xhr""").find.exists.saveAs("vid_add"))
              .check(regex("""len":4."ns":""."ver":41.0."csrf":"(.+?)"["$&+,:;=?@#|'<>.^*()%!-}{a-z]*doNamedCredentialCallout""").find.exists.saveAs("csrfToken_add")))

              .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

              .exec(http("addToCart_Get Parent ID")
              .post(uri05 +"/apexremote")
              .headers(headers_022)
              .check(regex("""parentId.":."(.+?).".."itemId""").find.exists.saveAs("parentid_add"))
              .body(ElFileBody("./src/test/resources/bodies/xom_macd_OneAssets/XOM_GetParentID_add.txt")))



              .exec(http("addToCart_Add items to cart")
              .post(uri05 +"/apexremote")
              .headers(headers_022)
              //.check(regex("""{."code.":."150.",."severity.":."INFO.",."message.":."Successfully added.."}""").find.exists)
              .body(ElFileBody("./src/test/resources/bodies/xom_macd_OneAssets/XOM_MACD_addTocart.txt")))

              .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

                .exec(http("addToCart_Order_Detail")
                .get(uri10 + "/${CartId_ForAdding}")
                .headers(headers_05) 
                .check(regex("""sforce.connection.sessionId = '(.+)';.}[a-zA-Z0-9\s{.('_,:]*name:.'XOMSubmitOrder'}""").find.exists.saveAs("""sfdc_session_id""")))

                .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

              .exec(http("addToCart_SubmitOrder")
                .post(uri05 + "/services/Soap/package/SimpleDecompositionController")
                .headers(headers_02)
                .check(regex("""<decomposeAndCreatePlanExResponse><result>\{&quot;planId&quot;:&quot;(.+)&quot;,""").find.exists.saveAs("PlanId"))
                .body(ElFileBody("./src/test/resources/bodies/xom_macd_OneAssets/submitorder_add.txt")))  

              .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
            }

            val Deleteflow = scenario("XOM_MACD_Deleteflow")
            .exec(session => session.set("password",credentials))

            //.exec(session => session.set("PriceListId",Configuration.PriceListId))

            .feed(userFeeder)        
            .exec(http("XOM_Login")
              .post(uri01 + "/")
              .headers(headers_00)
              .formParam("un", "${username}")
              .formParam("width", "1440")
              .formParam("height", "900")
              .formParam("hasRememberUn", "true")
              .formParam("startURL", "")
              .formParam("loginURL", "")
              .formParam("loginType", "")
              .formParam("useSecure", "true")
              .formParam("local", "")
              .formParam("lt", "standard")
              .formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
              .formParam("locale", "")
              .formParam("oauth_token", "")
              .formParam("oauth_callback", "")
              .formParam("login", "")
              .formParam("serverid", "")
              .formParam("QCQQ", "M1D2l15jFvl")
              .formParam("display", "page")
              .formParam("username", "${username}")
              .formParam("pw", "${password}")
              .formParam("Login", ""))

            //.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)



            .exec(http("RESTGetOAuthToken")
              .post("https://test.salesforce.com/services/oauth2/token")
              .header("Content-Type", "application/x-www-form-urlencoded")
              .formParam("password", "${password}")
              .formParam("username", "${username}")
              .formParam("client_secret", "7119599995527965426")
              .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
              .formParam("grant_type", "password")
              .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
              .check(status.is(200)))
            //.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


            .repeat(80000)
            {
              feed(assetFeeder_delete)
              .exec(http("Deleteflow_Click on Change Order")
                .get(uri05 +"/apex/MACDFdo?id=${AssetId_delete}")
                .headers(headers_145)
                .check(regex("""GenericInvoke2","len":4,"ns":"","ver":32.0,"csrf":"(.+?)"}""").find.exists.saveAs("csrfToken"))
                .check(regex("""vid":"(.+?)","xhr""").find.exists.saveAs("vid")))
              .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
              .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


        .exec(http("Deleteflow_Create a new MACD order")
          .post(uri05 +"/apexremote")
          .headers(headers_01)
          .check(regex("""fdoId.":."(.+?).",."error""").find.exists.saveAs("CartId_ForDelete"))
          .body(ElFileBody("./src/test/resources/bodies/xom_macd_OneAssets/createmacdorder_delete_oneasset.txt")))
        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        /*.exec(http("Deleteflow_OrderlineitemCount")
          .get(uri10 +"/services/data/v39.0/query/?q=SELECT+count()+FROM+OrderItem+WHERE+OrderId+=+'${CartId_ForDelete}'")
          .check(regex("""<totalSize>20<\/totalSize>""").find.exists)
          .headers(header_1))

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)*/

        .exec(http("Deleteflow_Get new csrf token")
          .get(uri05 +"/apex/HybridCPQ?id=${CartId_ForDelete}")
          .headers(headers_01)
          .check(regex("""vid":"(.+?)...xhr""").find.exists.saveAs("vid_del"))
          .check(regex("""len":4."ns":""."ver":41.0."csrf":"(.+?)"["$&+,:;=?@#|'<>.^*()%!-}{a-z]*doNamedCredentialCallout""").find.exists.saveAs("csrfToken_del")))

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        .exec(http("Deleteflow_Get Parent ID")
          .post(uri05 +"/apexremote")
          .headers(headers_022)
          .check(regex("""parentId.":."(.+?).".."itemId""").find.exists.saveAs("parentid"))
          .body(ElFileBody("./src/test/resources/bodies/xom_macd_OneAssets/XOM_GetParentID.txt")))

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        .exec(http("Delete Product from asset")
          .post(uri05 +"/apexremote")
          .headers(headers_022)
          .check(regex(""""message.":."Successfully.deleted""").find.exists.saveAs("deletedproduct"))
          .body(ElFileBody("./src/test/resources/bodies/xom_macd_OneAssets/XOM_DeleteMacD_Order.txt")))

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


        .exec(http("Deleteflow_Order_Detail")
          .get(uri10 + "/${CartId_ForDelete}")
          .headers(headers_05) 
          .check(regex("""sforce.connection.sessionId = '(.+)';.}[a-zA-Z0-9\s{.('_,:]*name:.'XOMSubmitOrder'}""").find.exists.saveAs("""sfdc_session_id""")))


        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)  

        .feed(productFeederdelete)
        .exec(http("Deleteflow_Add items to cart") 
          .post(uri10 +"/services/apexrest/v2/cpq/carts/${CartId_ForDelete}/items")
          .headers(header_1)
          .check(regex("""messages":\[\{"code":"150","severity":"INFO","message":"Successfully(......)""").find.exists.saveAs("AddStatus"))
          .body( StringBody("""{"methodName":"postCartsItems","items":[{"itemId":"${ProductId}"}],"cartId":"${CartId_ForDelete}","price":true,"validate":true,"includeAttachment":false,"pagesize":10,"lastRecordId":null,"hierarchy":-1,"query":"plan"}""")).asJson)

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)  

        .exec(http("Deleteflow_SubmitOrder")
          .post(uri05 + "/services/Soap/package/SimpleDecompositionController")
          .headers(headers_02)
          .check(regex("""<decomposeAndCreatePlanExResponse><result>\{&quot;planId&quot;:&quot;(.+)&quot;,""").find.exists.saveAs("PlanId"))
          .body(ElFileBody("./src/test/resources/bodies/xom_macd_OneAssets/submitorder_delete.txt")))  

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds) 

      }

      val Updateflow = scenario("XOM_MACD_Updateflow")
      .exec(session => session.set("password",credentials))

      //.exec(session => session.set("PriceListId",Configuration.PriceListId))

      .feed(userFeeder)        
      .exec(http("XOM_Login")
        .post(uri01 + "/")
        .headers(headers_00)
        .formParam("un", "${username}")
        .formParam("width", "1440")
        .formParam("height", "900")
        .formParam("hasRememberUn", "true")
        .formParam("startURL", "")
        .formParam("loginURL", "")
        .formParam("loginType", "")
        .formParam("useSecure", "true")
        .formParam("local", "")
        .formParam("lt", "standard")
        .formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
        .formParam("locale", "")
        .formParam("oauth_token", "")
        .formParam("oauth_callback", "")
        .formParam("login", "")
        .formParam("serverid", "")
        .formParam("QCQQ", "M1D2l15jFvl")
        .formParam("display", "page")
        .formParam("username", "${username}")
        .formParam("pw", "${password}")
        .formParam("Login", ""))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)



      .exec(http("RESTGetOAuthToken")
        .post("https://test.salesforce.com/services/oauth2/token")
        .header("Content-Type", "application/x-www-form-urlencoded")
        .formParam("password", "${password}")
        .formParam("username", "${username}")
        .formParam("client_secret", "7119599995527965426")
        .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
        .formParam("grant_type", "password")
        .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
        .check(status.is(200)))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


      .repeat(80000)
      {
        feed(assetFeeder_update)
        .exec(http("Updateflow_Click on Change Order")
          .get(uri05 +"/apex/MACDFdo?id=${AssetId_update}")
          .headers(headers_145)
          .check(regex("""GenericInvoke2","len":4,"ns":"","ver":32.0,"csrf":"(.+?)"}""").find.exists.saveAs("csrfToken"))
          .check(regex("""vid":"(.+?)","xhr""").find.exists.saveAs("vid")))

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        .exec(http("Updateflow_Create a new MACD order")
          .post(uri05 +"/apexremote")
          .headers(headers_01)
          .check(regex("""fdoId.":."(.+?).",."error""").find.exists.saveAs("CartId_ForUpdate"))
          .body(ElFileBody("./src/test/resources/bodies/xom_macd_OneAssets/createmacdorder_update_oneasset.txt")))

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        /*.exec(http("Updateflow_OrderlineitemCount")
          .get(uri10 +"/services/data/v39.0/query/?q=SELECT+count()+FROM+OrderItem+WHERE+OrderId+=+'${CartId_ForUpdate}'")
          .check(regex("""<totalSize>20<\/totalSize>""").find.exists)
          .headers(header_1))

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)*/

        .exec(http("Updateflow_Get new csrf token")
          .get(uri05 +"/apex/HybridCPQ?id=${CartId_ForUpdate}")
          .headers(headers_01)
          .check(regex("""vid":"(.+?)...xhr""").find.exists.saveAs("vid_del"))
          .check(regex("""len":4."ns":""."ver":41.0."csrf":"(.+?)"["$&+,:;=?@#|'<>.^*()%!-}{a-z]*doNamedCredentialCallout""").find.exists.saveAs("csrfToken_del")))

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        /*********** Get Cart LineItems***********/
        .exec(http("Updateflow_GetCartLineItems")
          .get(uri10 +"/services/apexrest/v2/cpq/carts/${CartId_ForUpdate}/items?pagesize=10&price=false&validate=false")
          .headers(header_1)
          .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.exists.saveAs("LineItem1")))
        //.check(jsonPath("$.records[1].actions.updateitems.rest.params.items..itemId").find.exists.saveAs("LineItem2")))

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        /*********** Get LineItems Details***********/
        .exec(http("Updateflow_Get line item details")
          .get(uri10 +"/services/apexrest/v2/cpq/carts/${CartId_ForUpdate}/items")
          .queryParamSeq(Seq(("id", "${LineItem1}")))
          .headers(header_1)
          .check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

        .exec(session => { 
          //originalItemJson.append(session("capturedItemHierarchy").as[String])
          modifiedItemJson = new StringBuilder()
          modifiedItemJson.append("""{"items":{"records":[{"displaySequence":-1,""").append(session("capturedItemHierarchy").as[String]).append("}]}}")
          session
        })

        /* Updating the Quantity from default 1.00 to 3.00 */
        .exec(http("Updateflow_Update cart line item")
          .put(uri10 +"/services/apexrest/v2/cpq/carts/${CartId_ForUpdate}/items")
          .headers(header_1)
          .body(StringBody(session =>  modifiedItemJson.replaceAllLiterally(""""Quantity":{"value":1.00""",""""Quantity":{"value":3.00""").toString() )).asJson
          .check(regex("""message":"Successfully.updated."}]""").find.exists))

        .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

            .exec(http("Updateflow_Order_Detail")
              .get(uri10 + "/${CartId_ForUpdate}")
              .headers(headers_05) 
              .check(regex("""sforce.connection.sessionId = '(.+)';.}[a-zA-Z0-9\s{.('_,:]*name:.'XOMSubmitOrder'}""").find.exists.saveAs("""sfdc_session_id""")))

            .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)  


            .exec(http("Updateflow_SubmitOrder")
              .post(uri05 + "/services/Soap/package/SimpleDecompositionController")
              .headers(headers_02)
              .check(regex("""<decomposeAndCreatePlanExResponse><result>\{&quot;planId&quot;:&quot;(.+)&quot;,""").find.exists.saveAs("PlanId"))
              .body(ElFileBody("./src/test/resources/bodies/xom_macd_OneAssets/submitorder_update.txt")))  

            .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds) 

          }

        }
