package eComm_Cart_Operations

import eComm_Cart_Operations.Headers._
import eComm_Cart_Operations.Configuration._
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._
import scala.util.Random

object eComm_SF {
  val uri01 = Configuration.Uri01
  val uri02 = Configuration.Uri02
  val userFeeder = csv("./src/test/resources/data/datagen/Perf2users.csv").random
  val offerFeeder = csv("./src/test/resources/data/eComm/offercodes.csv").random
  //val contextFeeder = csv("./src/test/resources/data/eComm/contextparams_orig.csv").random
  val contextFeeder = csv("./src/test/resources/data/eComm/contextdimensions.csv").random
  val promoFeeder = csv("./src/test/resources/data/eComm/promocodes.csv").random
  val childOfferFeeder = csv("./src/test/resources/data/eComm/childoffercodes.csv").random
  val accountFeeder = csv("./src/test/resources/data/eComm/accounts.csv").random
  val attrFeeder = csv("./src/test/resources/data/eComm/eCom-Prod-Bnd-15399454256600.csv").random
  val rootAssetFeeder = csv("./src/test/resources/data/eComm/eCom-root-asset-id.csv").random
  val updBasketJson = "./src/test/resources/bodies/eComm/eCom-Prod-Bnd-15399454256600_updatebasket.txt"
  val offerCounts = csv("./src/test/resources/data/eComm/OfferCountFile.csv").circular
  val testDuration = Integer.getInteger("testDuration", 1)


  val eCommCartOperations = scenario("ECommCartOperations")


    /* ********* Get OAuth Token for Perf2 ************* */
    .feed(userFeeder)
    .exec(http("RESTGetOAuthToken")
      .post("https://test.salesforce.com/services/oauth2/token")
      .header("Content-Type", "application/x-www-form-urlencoded")
      .formParam("password", "${password}")
      .formParam("username", "${username}")
      .formParam("client_secret", "5644903920226338215")
      .formParam("client_id", "3MVG9MHOv_bskkhR5LPzqvofeG92uGkYzDJ8QAGeB7zALujRr0TGKmehi5HFuZZU6l2GxF76.Ddpoz1NpptCX")
      .formParam("grant_type", "password")
      .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
      .check(status.is(200)))

    .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

    //.forever() {
    //.repeat(1) {
      .during(testDuration) {

        /* ********* Call to get contextKey  ************* */
        feed(contextFeeder)
          .exec(http("getAnonymousCK")
            .get(uri02 + """/services/apexrest/v3/catalogs/ECOM-CATALOG/offers?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}""")
            .headers(header_0)
            .check(status.is(200))
            .check(status.not(404), status.not(500),status.not(504),status.not(503))
            .check(regex("""contextKey":"(.+?)".""").find.exists.saveAs("AnonymousCK")))

          .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

      .feed(accountFeeder)
        .feed(offerFeeder)
        /* ********** AddWithNoConfig *********** */
        .exec(http("ATCWNC")
          .post(uri02 + """/services/apexrest/v3/catalogs/ECOM-CATALOG/basket?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
          .headers(header_0)
          .check(status.is(200))
          .check(regex("""cartContextKey""").find.exists)
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKeyAddToCartWithNoConfig")).asJson
          .body(StringBody("""{"offer":"${OfferCode}","basketAction":"AddWithNoConfig"}""")).asJson)

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

      .feed(offerFeeder)
        .exec(http("ATCWNC")
          .post(uri02 + """/services/apexrest/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyAddToCartWithNoConfig}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
          .headers(header_0)
          .check(status.is(200))
          .check(regex("""cartContextKey""").find.exists)
          .check(status.not(404), status.not(500),status.not(504),status.not(503))
          .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKeyAddToCartWithNoConfigTwo")).asJson
          .check(regex("""cartContextKey":"(.+?)"."result""").count.saveAs("CountCartContextKeyAddToCartWithNoConfigTwo"))
          .body(StringBody("""{"offer":"${OfferCode}","basketAction":"AddWithNoConfig"}""")).asJson)

        .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

        .doIfEquals("${CountCartContextKeyAddToCartWithNoConfigTwo}",1) {

          feed(offerCounts)
            .repeat("${Counts}") {

              /* ********** AddWithNoConfig *********** */
              feed(offerFeeder)
                .exec(http("ATCWNC")
                  .post(uri02 + """/services/apexrest/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyAddToCartWithNoConfigTwo}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
                  .headers(header_0)
                  .check(status.is(200))
                  .check(regex("""cartContextKey""").find.exists)
                  .check(status.not(404), status.not(500),status.not(504),status.not(503))
                  .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKeyAddToCartWithNoConfigTwo")).asJson
                  .body(StringBody("""{"offer":"${OfferCode}","basketAction":"AddWithNoConfig"}""")).asJson)

                .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)

            }
        }

        .repeat(1) {

          feed(offerFeeder)
            .exec(http("ATCWNC_${Counts}")
              .post(uri02 + """/services/apexrest/v3/catalogs/ECOM-CATALOG/basket/${CartContextKeyAddToCartWithNoConfigTwo}?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
              .headers(header_0)
              .check(status.is(200))
              .check(regex("""cartContextKey""").find.exists)
              .check(status.not(404), status.not(500),status.not(504),status.not(503))
              .check(regex("""cartContextKey":"(.+?)"."result""").find.exists.saveAs("CartContextKeyAddToCartWithNoConfigThree")).asJson
              .check(regex("""cartContextKey":"(.+?)"."result""").count.saveAs("CountCartContextKeyAddToCartWithNoConfigThree"))
              .check(regex("""result":(.+?)."errorCode""").find.exists.saveAs("CreateCart"))
              .body(StringBody("""{"offer":"${OfferCode}","basketAction":"AddWithNoConfig"}""")).asJson)

            .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)
        }

        .doIfEquals("${CountCartContextKeyAddToCartWithNoConfigThree}", 1) {
          /* ********** CreateCart *********** */
          exec(http("CreateCart_${Counts}")
            .post(uri02 + """/services/apexrest/v3/carts?context={"accStatus":"${accStatus}","accSla":"${accSla}","accPhone":"${accPhone}"}&contextKey=${AnonymousCK}""")
            .headers(header_0)
            .check(status.is(200))
            .check(regex("""orderNumber""").find.exists)
            .check(status.not(404), status.not(500),status.not(504),status.not(503))
            .check(regex("""orderId":"(.+?)"""").find.exists.saveAs("OrderId"))
            .body(StringBody("""{"JSONResult":${CreateCart},"accountId": "${AccountId}","catalogCode": "ECOM-CATALOG"}""")).asJson)

            .pause(Configuration.minWaitMs milliseconds, Configuration.maxWaitMs milliseconds)
        }
    }
  exec(flushSessionCookies)
    .exec(flushCookieJar)
    .exec(flushHttpCache)
    .exec { session => println(session); session }


}