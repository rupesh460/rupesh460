package eComm_Cart_Operations

object Configuration
{
  val BaseUrl = "https://c.cs8.visual.force.com"
  val Uri01 = "https://test.salesforce.com"
  val Uri02 = "https://cs8.salesforce.com"
  //val Uri02 = "https://api.perf.vlocity.dc.vloc-dev.com/dc/"

  //val minWaitMs = 3000
  //val maxWaitMs = 4000

  val minWaitMs=Integer.getInteger("minWaitMs", 3000)
  val maxWaitMs=Integer.getInteger("maxWaitMs", 4000)
  //val loginminWaitMs=Integer.getInteger("productViewsminWaitMs", 3000)
  //val loginmaxWaitMs=Integer.getInteger("productViewsmaxWaitMs", 4000)
  //val productViewsminWaitMs=Integer.getInteger("productViewsminWaitMs", 3000)
  //val productViewsmaxWaitMs=Integer.getInteger("productViewsmaxWaitMs", 4000)
  //val AddToCartminWaitMs=Integer.getInteger("AddToCartminWaitMs", 3000)
  //val AddToCartmaxWaitMs=Integer.getInteger("AddToCartmaxWaitMs", 4000)
  //val CheckOutminWaitMs=Integer.getInteger("CheckOutminWaitMs", 3000)
  //val CheckOutmaxWaitMs=Integer.getInteger("CheckOutmaxWaitMs", 4000)

  val BaseUrl_AWS = "https://1fhjm3ncac.execute-api.us-east-2.amazonaws.com/test/dc/"
  val Uri02_AWS =   "https://api.perf.vlocity.dc.vloc-dev.com/dc"


}