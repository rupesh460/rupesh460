package eComm_Cart_Operations

object Headers
{
  val header_0 = Map(
  "Accept" -> "text/javascript, text/html, application/xml, application/json, text/xml, */*",
  "Accept-Encoding" -> "gzip, deflate, br",
  "Accept-Language" -> "en-US,en;q=0.8",
  "Connection" -> "keep-alive",
  "Authorization" -> "Bearer ${Token_ID}")

  val header_1 =Map(

  // "Accept" -> "text/javascript, text/html, application/xml, application/json, text/xml, */*",
  //"Accept-Encoding" -> "gzip, deflate, br",
  // "Accept-Language" -> "en-US,en;q=0.8",
  // "Connection" -> "keep-alive",
  "Content-Type"->"application/json",
  //"charset"->"UTF-8",
  //"Authorization" -> "Bearer ${Token_ID}")
  "authorization" -> "Basic cGVyZjp4aXczVURhQVg2cDZRY2N0cERjYjJ5ZjZ0a2U3Z1FtZ1FMcA==")

}
