package OM_Standard


object Configuration
 {
	val BaseUrl = "https://c.cs8.visual.force.com"
	val Uri01 = "https://test.salesforce.com"
	val Uri05 = "https://c.cs8.visual.force.com"
	val Uri10 = "https://cs8.salesforce.com"


	val MinWaitMs = 15000
	val MaxWaitMs = 20000

	val MiniMinWaitMs = 1000
	val MiniMaxWaitMs = 3000

}
