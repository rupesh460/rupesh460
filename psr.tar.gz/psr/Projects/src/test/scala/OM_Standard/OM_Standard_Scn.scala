package OM_Standard

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._

class OM_Standard_Scn extends Simulation {

	val httpConf = http
		.baseUrl(Configuration.BaseUrl)
		.inferHtmlResources(BlackList(""".*\.js""", """.*\.css""", """.*\.gif""", """.*\.jpeg""", """.*\.jpg""", """.*\.ico""", """.*\.woff""", """.*\.(t|o)tf""", """.*\.png"""), WhiteList())
		.acceptHeader("*/*")
		.acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8")
		.acceptEncodingHeader("gzip, deflate, sdch")
		.acceptLanguageHeader("en-US,en;q=0.8")
		.disableCaching
		.contentTypeHeader("application/x-www-form-urlencoded; charset=UTF-8")
		.userAgentHeader("Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:41.0) Gecko/20100101 Firefox/41.0")

	val rampUpTimeSecs = Integer.getInteger("rampUpTimeSecs", 1)
	val NoofORDCRTusers = Integer.getInteger("NoofORDCRTusers", 1)
	val maxDurationSecs = Integer.getInteger("maxDurationSecs", 1)
	val testDuration = Integer.getInteger("testDuration",1)

	setUp(

		OM_Standard_Test.scn.inject(rampUsers(NoofORDCRTusers) during (rampUpTimeSecs seconds)).protocols(httpConf)).maxDuration(maxDurationSecs)	
  }