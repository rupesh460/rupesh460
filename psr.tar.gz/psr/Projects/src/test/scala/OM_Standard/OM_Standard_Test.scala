
//THe script takes Account ID, PriceList for which order has tb created ,
//PriceList entry ID for which add to cart to be done
package OM_Standard

  import scala.concurrent.duration._
  import io.gatling.core.Predef._
  import io.gatling.core.structure.ChainBuilder
  import io.gatling.http.Predef._
  import io.gatling.jdbc.Predef._
  import io.gatling.jsonpath._
  import Headers._
  import scala.collection._
  import java.time.format.DateTimeFormatter
  import java.time.LocalDateTime
  import java.time.LocalDate

import io.gatling.core.feeder._
import java.util.Base64
import java.nio.charset.StandardCharsets
import scala.util.matching.Regex



   object OM_Standard_Test {

      val uri01 = Configuration.Uri01
      val uri05 = Configuration.Uri05
      val uri10 = Configuration.Uri10
      var session_ids = Vector[String]()
      var xomSubmitOrder = new StringBuilder()
      val userFeeder = csv("./src/test/resources/data/OM_Standard/OM_Standard_Users.csv").random
      val pricelistEntryFeeder = csv("./src/test/resources/data/OM_Standard/OM_Standard_PriceListEntry.csv").random
      val accountFeeder = csv("./src/test/resources/data/OM_Standard/OM_Standard_Accounts.csv").random
      val pricelistFeeder = csv("./src/test/resources/data/OM_Standard/OM_Standard_Pricelist.csv").random

 val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
 val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
 val password_v = (passwordByEnv.get("perf3").toString)
 val password_encoded = password_v.substring(12,(password_v.length - 2 ))
 val credentials = new String(Base64.getDecoder.decode(password_encoded))

      
  	  val scn = scenario("OM_Standard_Test")
.exec(session => session.set("password",credentials))
      
      .feed(userFeeder)        
      .exec(http("OM_Standard_Login")
          .post(uri01 + "/")
          .headers(headers_00)
          .formParam("un", "${username}")
          .formParam("width", "1440")
          .formParam("height", "900")
          .formParam("hasRememberUn", "true")
          .formParam("startURL", "")
          .formParam("loginURL", "")
          .formParam("loginType", "")
          .formParam("useSecure", "true")
          .formParam("local", "")
          .formParam("lt", "standard")
          .formParam("qs", "r=https%3A%2F%2Fcs17.salesforce.com%2Fsecur%2Flogout.jsp")
          .formParam("locale", "")
          .formParam("oauth_token", "")
          .formParam("oauth_callback", "")
          .formParam("login", "")
          .formParam("serverid", "")
          .formParam("QCQQ", "M1D2l15jFvl")
          .formParam("display", "page")
          .formParam("username", "${username}")
          .formParam("pw", "${password}")
          .formParam("Login", ""))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("RESTGetOAuthToken")
          .post("https://test.salesforce.com/services/oauth2/token")
          .header("Content-Type", "application/x-www-form-urlencoded")
          .formParam("password", "${password}")
          .formParam("username", "${username}")
          .formParam("client_secret", "5644903920226338215")
          .formParam("client_id", "3MVG9MHOv_bskkhR5LPzqvofeG92uGkYzDJ8QAGeB7zALujRr0TGKmehi5HFuZZU6l2GxF76.Ddpoz1NpptCX")
          .formParam("grant_type", "password")
          .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
          .check(status.is(200)))

      .repeat(10000)
      {

      feed(accountFeeder)
      .feed(pricelistFeeder)
      .exec(http("Create_new_order")
          .post(uri10 +"/services/apexrest/v2/carts")
          .headers(header_1)
          .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
          .body(StringBody("""{"subaction":"createOrder",
                    "inputFields":[
                      {"AccountId":"${AccountId}"},
                      {"PriceListId__c":"${PriceListId}"},
                      {"Name":"NewOrder1"},{"Status":"Draft"},
                      {"EffectiveDate":"04/23/2018"}
                    ]}""")).asJson)
     


    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)  

     .feed(pricelistEntryFeeder)
      .exec(http("Add_items_to_cart") 
          .post(uri10 +"/services/apexrest/v2/cpq/carts/${OrderID}/items")
          .headers(header_1)
          .check(regex("""\{"totalSize":1,"messages":\[\{"code":"150","severity":"INFO","message":"Successfully(......)""").find.exists.saveAs("AddStatus"))
          .body( StringBody("""{"methodName":"postCartsItems","items":[{"itemId":"${PriceListEntryId}"}],"cartId":"${OrderID}","price":true,"validate":true,"includeAttachment":false,"pagesize":1,"lastRecordId":null,"hierarchy":-1,"query":"plan"}""")).asJson)




    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("SubmitOrder")
      .get(uri05 + "/apex/XOMSubmitOrder?scontrolCaching=1&id=${OrderID}")
      .headers(headers_05)
      .check(regex("""salesforce.com/a3t(.*?)'""").find.exists.saveAs("OrchestrationPlanID"))
    )




    } 

  }
