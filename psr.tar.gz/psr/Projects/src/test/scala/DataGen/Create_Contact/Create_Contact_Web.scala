//Query is on Rest call below - WHich fetches account name and id for which contact id is not create
package Create_Contact
  import scala.concurrent.duration._

  import io.gatling.core.Predef._
  import io.gatling.core.structure.ChainBuilder
  import io.gatling.http.Predef._
  import io.gatling.jdbc.Predef._
  import io.gatling.jsonpath._
  import Headers._
  import scala.collection._
  import java.time.format.DateTimeFormatter
  import java.time.LocalDateTime
  import java.time.LocalDate


   object Create_Contact_Web {

    var userid = new StringBuilder()
    val uri10 = Configuration.Uri10
    val uri01 = Configuration.Uri01
    val userFeeder = csv("./src/test/resources/data/ecom/Perf2users.csv").random
    var accountidlist = List[String]()
    var accountnamelist = List[String]()
   var random_index = 0
    val randomNumber = new scala.util.Random
    //val accountFeeder = csv("Perf2Accounts.csv").random
    val scn = scenario("Create_Contact")


     .feed(userFeeder)
      .exec(http("Web_Login")
      .post(uri01 + "/")
      .headers(headers_26)
      .formParam("un", "${username}")
      .formParam("width", "1920")
      .formParam("height", "1080")
      .formParam("hasRememberUn", "true")
      .formParam("startURL", "")
      .formParam("loginURL", "")
      .formParam("loginType", "")
      .formParam("useSecure", "true")
      .formParam("local", "")
      .formParam("lt", "standard")
      .formParam("qs", "")
      .formParam("locale", "")
      .formParam("oauth_token", "")
      .formParam("oauth_callback", "")
      .formParam("login", "")
      .formParam("serverid", "")
      .formParam("display", "page")
      .formParam("username", "${username}")
      .formParam("pw", "${password}")
      .formParam("Login", "Log In to Sandbox")
      .formParam("rememberUn", "on"))

        .pause(2000 milliseconds, 2000 milliseconds)


      .exec(http("GetCONFToken")
      .get("/003/e?retURL=%2F003%2Fo")
      .check(regex("""id="_CONFIRMATIONTOKEN" value="(.*?)"""").find.exists.saveAs("CONF_Token"))
      .headers(headers_0))

//Oath token for query
      .exec(http("RESTGetOAuthToken")
        .post("https://test.salesforce.com/services/oauth2/token")
        .header("Content-Type", "application/x-www-form-urlencoded")
        .formParam("password", "${password}")
            .formParam("username", "${username}")
            .formParam("client_secret", "7119599995527965426")
            .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
            .formParam("grant_type", "password")
            .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
            .check(status.is(200)))
              
    .pause(2000 milliseconds, 2000 milliseconds)

       .repeat(20000,"repeatid")
          {

              exec((s: Session) => s.set("userid",s.userId.toString))

          

             //Query AcountID and Name for which no contacs are created 
            .exec(http("GetAccountIdandNameQuery")
           .get(uri10 +"/services/data/v39.0/query/?q=SELECT Id,Name FROM Account where id not in(select accountid from contact) LIMIT 10000")
           .check(regex("<Id>(.*?)</Id>").findAll.saveAs("accountidlist"))
           .check(regex("<Name>(.*?)</Name>").findAll.saveAs("accountnamelist"))
           .headers(header_1))

                //Create random index and assign regex list to accountidlist and accountnamelist
            
            .exec( session => {
                  
                  accountidlist = session("accountidlist").as[List[String]]
                  accountnamelist = session("accountnamelist").as[List[String]]
                  random_index = randomNumber.nextInt(accountidlist.length-1)
                 //session.set("accountid", accountidlist(random_index) )
                  //session.set("accountname", accountnamelist(random_index) )
                  session
                })
              .exec( session => session.set("accountid", accountidlist(random_index) ) )
             .exec( session => session.set("accountname", accountnamelist(random_index) ) )
            

            .pause(2000 milliseconds, 2000 milliseconds)


   // .feed(accountFeeder)
    .exec(http("CreateContact")
      .post(uri10 + "/003/e")
      .headers(headers_26)
      .formParam("_CONFIRMATIONTOKEN", "${CONF_Token}")
      .formParam("cancelURL", "/003/o")
      .formParam("retURL", "/003/o")
      .formParam("save_new_url", "/003/e?retURL=%2F003%2Fo")
      .formParam("save", "Saving...")
      .formParam("con10", "")
      .formParam("name_salutationcon2", "")
      .formParam("con13", "")
      .formParam("name_firstcon2", "")
      .formParam("con12", "")
      .formParam("name_lastcon2", "Contact-lname-web0-${userid}-${repeatid}")
      .formParam("con14", "")
      .formParam("con4_lkid", "${accountid}")
      .formParam("con4_lkold", "${accountname}")
      .formParam("con4_lktp", "001")
      .formParam("con4_lspf", "1")
      .formParam("con4_lspfsub", "0")
      .formParam("con4_mod", "1")
      .formParam("lspffrom", "con4")
      .formParam("con4", "${accountname}")
      .formParam("con11", "")
      .formParam("con5", "")
      .formParam("con15", "")
      .formParam("con6", "")
      .formParam("con16", "")
      .formParam("con7", "")
      .formParam("con17", "")
      .formParam("con8_lkid", "000000000000000")
      .formParam("con8_lkold", "")
      .formParam("con8_lktp", "003")
      .formParam("con8_lspf", "0")
      .formParam("con8_lspfsub", "0")
      .formParam("con8_mod", "0")
      .formParam("con8", "")
      .formParam("con9", "")
      .formParam("con19street", "")
      .formParam("con18street", "")
      .formParam("con19city", "San Francisco")
      .formParam("con18city", "")
      .formParam("con19state", "California")
      .formParam("con18state", "")
      .formParam("con19zip", "94016")
      .formParam("con18zip", "")
      .formParam("con19country", "")
      .formParam("con18country", "")
      .formParam("con20", ""))
     // .check(bodyBytes.is(RawFileBody("CreateContactwithaccount_0000_response.txt"))))
        


      .pause(2000 milliseconds, 2000 milliseconds)



          }
    

    }
