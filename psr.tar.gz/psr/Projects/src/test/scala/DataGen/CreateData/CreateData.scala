package CreateData

import scala.concurrent.duration._
import io.gatling.core.Predef._
import io.gatling.core.structure.ChainBuilder
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._
import io.gatling.jsonpath._
import Headers._
import scala.collection._

object CreateData 
{
    var userid = new StringBuilder()
    
    val uri01 = Configuration.Uri01
    val uri02 = Configuration.Uri02
    val userFeeder = csv("./src/test/resources/data/datagen/Perf2users.csv").random
   
    val randomNumber = new scala.util.Random
    
    val scn = scenario("CreateData")

    /* ********* Get OAuth Token for Perf2 ************* */
    .feed(userFeeder)
    .exec(http("RESTGetOAuthToken")
      .post("https://test.salesforce.com/services/oauth2/token")
      .header("Content-Type", "application/x-www-form-urlencoded")
      .formParam("password", "${password}")
      .formParam("username", "${username}")
      .formParam("client_secret", "7119599995527965426")
      .formParam("client_id", "3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG")
      .formParam("grant_type", "password")
      .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
      .check(status.is(200)))

    .repeat(1)
    {
      /*
      /* ********** CreateBundle *********** */
      exec(http("CreateBundle")
        .get(uri02 +"/services/apexrest/v3/createbundle/")
        .headers(header_0))

      .pause(5000 milliseconds, 8000 milliseconds)
    

       /* ********** CreateBundle *********** */
      exec(http("CreateStdProd")
        .get(uri02 +"/services/apexrest/v3/createstdproduct/")
        .headers(header_0))

        */
         /* ********** CreateBundle *********** */
      exec(http("CreatePromotion")
        .get(uri02 +"/services/apexrest/v3/createpromotion")
        .headers(header_0))

      .pause(3000 milliseconds, 6000 milliseconds)
    }

      
}