package CreateData


object Configuration
{
	val BaseUrl = "https://c.cs8.visual.force.com"
	val Uri01 = "https://test.salesforce.com"
	val Uri02 = "https://cs8.salesforce.com"

}