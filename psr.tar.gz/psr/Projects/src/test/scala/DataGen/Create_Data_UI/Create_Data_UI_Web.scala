package Create_Data_UI
  import scala.concurrent.duration._

  import io.gatling.core.Predef._
  import io.gatling.core.structure.ChainBuilder
  import io.gatling.http.Predef._
  import io.gatling.jdbc.Predef._
  import io.gatling.jsonpath._
  import Headers._
  import scala.collection._
  import java.time.format.DateTimeFormatter
  import java.time.LocalDateTime
  import java.time.LocalDate


   object Create_Data_UI_Web {

    var userid = new StringBuilder()
    val uri10 = Configuration.Uri10
    val uri01 = Configuration.Uri01
    val userFeeder = csv("./src/test/resources/data/ecom/Perf2users.csv").random
    val scn = scenario("Create_Account")


     .feed(userFeeder)
      .exec(http("Web_Login")
      .post(uri01 + "/")
      .headers(headers_26)
      .formParam("un", "${username}")
      .formParam("width", "1920")
      .formParam("height", "1080")
      .formParam("hasRememberUn", "true")
      .formParam("startURL", "")
      .formParam("loginURL", "")
      .formParam("loginType", "")
      .formParam("useSecure", "true")
      .formParam("local", "")
      .formParam("lt", "standard")
      .formParam("qs", "")
      .formParam("locale", "")
      .formParam("oauth_token", "")
      .formParam("oauth_callback", "")
      .formParam("login", "")
      .formParam("serverid", "")
      .formParam("display", "page")
      .formParam("username", "${username}")
      .formParam("pw", "${password}")
      .formParam("Login", "Log In to Sandbox")
      .formParam("rememberUn", "on"))

        .pause(2000 milliseconds, 2000 milliseconds)


         .exec( session => session.set("runnumber", "19" ) )

              
  

       .repeat(1,"repeatid")
          {

              exec((s: Session) => s.set("userid",s.userId.toString))

        //////////////////////////////////Create Account -Start//////////////////////////////////

        //Get token to create account
      .exec(http("GetCONFTokenToCreateAccount")
      .get("/001/e?retURL=%2F001%2Fo&RecordType=012L0000000EP9F&ent=Account")
      .check(regex("""id="_CONFIRMATIONTOKEN" value="(.*?)"""").find.exists.saveAs("CONF_Token_Account"))
      .headers(headers_0))

    //Create account request
    .exec(http("CreateAccount")
      .post(uri10 + "/001/e")
      .headers(headers_26)
      .formParam("RecordType", "012L0000000EP9F")
      .formParam("_CONFIRMATIONTOKEN", "${CONF_Token_Account}")
      .formParam("cancelURL", "/001/o")
      .formParam("retURL", "/001/o")
      .formParam("save_new_url", "/001/e?ent=Account&retURL=%2F001%2Fo&RecordType=012L0000000EP9F")
      .formParam("save", "Saving...")
      .formParam("acc2", "Account-${runnumber}-${userid}-${repeatid}")
      .formParam("00NL0000004TxR0", "Active")
      .formParam("acc3_lkid", "0")
      .formParam("acc3_lkold", "null")
      .formParam("acc3_lktp", "1")
      .formParam("acc3_lspf", "0")
      .formParam("acc3_lspfsub", "0")
      .formParam("acc3_mod", "0")
      .formParam("acc3", "")
      .formParam("00NL0000004KE8H", "")
      .formParam("acc17street", "")
      .formParam("acc10", "")
      .formParam("acc17city", "San Francisco")
      .formParam("CF00NL0000004KE8A_lkid", "0")
      .formParam("CF00NL0000004KE8A_lkold", "null")
      .formParam("CF00NL0000004KE8A_lktp", "a2p")
      .formParam("CF00NL0000004KE8A_lspf", "0")
      .formParam("CF00NL0000004KE8A_lspfsub", "0")
      .formParam("CF00NL0000004KE8A_mod", "0")
      .formParam("CF00NL0000004KE8A", "")
      .formParam("acc17state", "California")
      .formParam("acc17zip", "94016")
      .formParam("acc17country", "")
      .formParam("00NL0000004KE8E", "")
      .formParam("00NL0000004KE83", "")
      .formParam("00NL0000004KE82", "")
      .formParam("00NL0000004KE7x", "")
      .formParam("00NL0000004KE84", "")
      .formParam("CF00NL0000004KE81_lkid", "0")
      .formParam("CF00NL0000004KE81_lkold", "null")
      .formParam("CF00NL0000004KE81_lktp", "a4E")
      .formParam("CF00NL0000004KE81_lspf", "0")
      .formParam("CF00NL0000004KE81_lspfsub", "0")
      .formParam("CF00NL0000004KE81_mod", "0")
      .formParam("CF00NL0000004KE81", "")
      .formParam("00NL0000004KE7z", "")
      .formParam("00NL0000004KE85", "")
      .formParam("00NL0000004KE86", "")
      .check(status.is(200))
      .check(regex("""handleRedirect\('\/(.+?)\'""").find.exists.saveAs("AccountId")))
     // .check(regex("""SfdcApp.projectOneNavigator.handleRedirect\(\'\/(.+)\'\)\;\s\}""").find.exists.saveAs("AccountId")))
               

     //////////////////////////////////Create Account -END//////////////////////////////////

      .pause(2000 milliseconds, 2000 milliseconds)

     //////////////////////////////////Create Contact -Start//////////////////////////////////

     //Get Conf token to create contct
     .exec(http("GetCONFTokenToCreateContact")
      .get("/003/e?retURL=%2F003%2Fo")
      .check(regex("""id="_CONFIRMATIONTOKEN" value="(.*?)"""").find.exists.saveAs("CONF_Token_Contact"))
      .headers(headers_0))

     //Create Contact Request
      .exec(http("CreateContact")
      .post(uri10 + "/003/e")
      .headers(headers_26)
      .formParam("_CONFIRMATIONTOKEN", "${CONF_Token_Contact}")
      .formParam("cancelURL", "/003/o")
      .formParam("retURL", "/003/o")
      .formParam("save_new_url", "/003/e?retURL=%2F003%2Fo")
      .formParam("save", "Saving...")
      .formParam("con10", "")
      .formParam("name_salutationcon2", "")
      .formParam("con13", "")
      .formParam("name_firstcon2", "")
      .formParam("con12", "")
      .formParam("name_lastcon2", "Contact-lname-${runnumber}-${userid}-${repeatid}")
      .formParam("con14", "")
      .formParam("con4_lkid", "${AccountId}")
      .formParam("con4_lkold", "Account-${runnumber}-${userid}-${repeatid}")
      .formParam("con4_lktp", "001")
      .formParam("con4_lspf", "1")
      .formParam("con4_lspfsub", "0")
      .formParam("con4_mod", "1")
      .formParam("lspffrom", "con4")
      .formParam("con4", "Account-${runnumber}-${userid}-${repeatid}")
      .formParam("con11", "")
      .formParam("con5", "")
      .formParam("con15", "")
      .formParam("con6", "")
      .formParam("con16", "")
      .formParam("con7", "")
      .formParam("con17", "")
      .formParam("con8_lkid", "000000000000000")
      .formParam("con8_lkold", "")
      .formParam("con8_lktp", "003")
      .formParam("con8_lspf", "0")
      .formParam("con8_lspfsub", "0")
      .formParam("con8_mod", "0")
      .formParam("con8", "")
      .formParam("con9", "")
      .formParam("con19street", "")
      .formParam("con18street", "")
      .formParam("con19city", "San Francisco")
      .formParam("con18city", "")
      .formParam("con19state", "California")
      .formParam("con18state", "")
      .formParam("con19zip", "94016")
      .formParam("con18zip", "")
      .formParam("con19country", "")
      .formParam("con18country", "")
      .formParam("con20", "")
      .check(status.is(200))
      .check(regex("""handleRedirect\('\/(.+?)\'""").find.exists.saveAs("ContactId")))
     //////////////////////////////////Create Contact -End//////////////////////////////////

      .pause(2000 milliseconds, 2000 milliseconds)

      //////////////////////////////////Create Case -Start//////////////////////////////////

      //Request to get conf token to create case
       .exec(http("GetCONFTokenToCreateCase")
      .get("/500/e?retURL=%2F500%2Fo")
      .check(regex("""id="_CONFIRMATIONTOKEN" value="(.*?)"""").find.exists.saveAs("CONF_Token_Case"))
      .headers(headers_0))

       //Request to create case 
       .exec(http("CreateCase")
      .post(uri10 + "/500/e")
      .headers(headers_0)
      .formParam("_CONFIRMATIONTOKEN", "${CONF_Token_Case}")
      .formParam("cancelURL", "/500/o")
      .formParam("retURL", "/500/o")
      .formParam("save_new_url", "/500/e?retURL=%2F500%2Fo")
      .formParam("cas7", "New")
      .formParam("cas3_lkid", "${ContactId}")
      .formParam("cas3_lkold", "Contact-lname-${runnumber}-${userid}-${repeatid}")
      .formParam("cas3_lktp", "003")
      .formParam("cas3_lspf", "0")
      .formParam("cas3_lspfsub", "0")
      .formParam("cas3_mod", "1")
      .formParam("cas3", "Contact-lname-${runnumber}-${userid}-${repeatid}")
      .formParam("cas8", "Medium")
      .formParam("cas4_lkid", "${AccountId}")
      .formParam("cas4_lkold", "Account-${runnumber}-${userid}-${repeatid}")
      .formParam("cas4_lktp", "001")
      .formParam("cas4_lspf", "0")
      .formParam("cas4_lspfsub", "0")
      .formParam("cas4_mod", "0")
      .formParam("cas4", "Account-${runnumber}-${userid}-${repeatid}")
      .formParam("cas11", "Email")
      .formParam("cas5", "")
      .formParam("CF00NL0000004KE91_lkid", "000000000000000")
      .formParam("CF00NL0000004KE91_lkold", "")
      .formParam("CF00NL0000004KE91_lktp", "a2p")
      .formParam("CF00NL0000004KE91_lspf", "0")
      .formParam("CF00NL0000004KE91_lspfsub", "0")
      .formParam("CF00NL0000004KE91_mod", "0")
      .formParam("CF00NL0000004KE91", "")
      .formParam("cas6", "")
      .formParam("CF00NL0000004KE94_lkid", "000000000000000")
      .formParam("CF00NL0000004KE94_lkold", "")
      .formParam("CF00NL0000004KE94_lktp", "a4K")
      .formParam("CF00NL0000004KE94_lspf", "0")
      .formParam("CF00NL0000004KE94_lspfsub", "0")
      .formParam("CF00NL0000004KE94_mod", "0")
      .formParam("CF00NL0000004KE94", "")
      .formParam("CF00NL0000004KE95_lkid", "000000000000000")
      .formParam("CF00NL0000004KE95_lkold", "")
      .formParam("CF00NL0000004KE95_lktp", "a4J")
      .formParam("CF00NL0000004KE95_lspf", "0")
      .formParam("CF00NL0000004KE95_lspfsub", "0")
      .formParam("CF00NL0000004KE95_mod", "0")
      .formParam("CF00NL0000004KE95", "")
      .formParam("cas14", "")
      .formParam("cas15", "")
      .formParam("cas16", "")
      .formParam("save", "Saving...")
      .check(status.is(200))
      .check(regex("""handleRedirect\('\/(.+?)\'""").find.exists.saveAs("CaseId")))



       //////////////////////////////////Create Case -End//////////////////////////////////

        .pause(2000 milliseconds, 2000 milliseconds)

        //////////////////////////////////Create Opportunity -Start//////////////////////////////////

        //Request to get conf token to create case
       .exec(http("GetCONFTokenToCreateOpportunity")
      .get("/006/e?retURL=%2F006%2Fo")
      .check(regex("""id="_CONFIRMATIONTOKEN" value="(.*?)"""").find.exists.saveAs("CONF_Token_Opportunity"))
      .headers(headers_0))


       //Request to create Opportunity
       .exec(http("CreateOpportunity")
      .post(uri10 + "/006/e")
      .headers(headers_0)
      .formParam("_CONFIRMATIONTOKEN", "${CONF_Token_Opportunity}")
      .formParam("cancelURL", "/006/o")
      .formParam("retURL", "/006/o")
      .formParam("save_new_url", "/006/e?retURL=%2F006%2Fo")
      .formParam("opp7", "")
      .formParam("opp3", "Opportunity-${runnumber}-${userid}-${repeatid}")
      .formParam("00NL0000004KEAa", "")
      .formParam("opp4_lkid", "${AccountId}")
      .formParam("opp4_lkold", "Account-${runnumber}-${userid}-${repeatid}")
      .formParam("opp4_lktp", "001")
      .formParam("opp4_lspf", "0")
      .formParam("opp4_lspfsub", "0")
      .formParam("opp4_mod", "1")
      .formParam("opp4", "Account-${runnumber}-${userid}-${repeatid}")
      .formParam("opp9", "6/21/2028")
      .formParam("opp11", "Prospecting")
      .formParam("00NL0000004KEAe", "")
      .formParam("opp5", "")
      .formParam("opp6", "")
      .formParam("opp10", "")
      .formParam("opp12", "10")
      .formParam("opp17_lkid", "000000000000000")
      .formParam("opp17_lkold", "null")
      .formParam("opp17_lktp", "701")
      .formParam("opp17_lspf", "0")
      .formParam("opp17_lspfsub", "0")
      .formParam("opp17_mod", "0")
      .formParam("opp17", "")
      .formParam("00NL0000004KEAk", "Not yet run")
      .formParam("00NL0000004KEAi", "")
      .formParam("00NL0000004KEAj", "")
      .formParam("CF00NL0000004U4DH_lkid", "000000000000000")
      .formParam("CF00NL0000004U4DH_lkold", "null")
      .formParam("CF00NL0000004U4DH_lktp", "800")
      .formParam("CF00NL0000004U4DH_lspf", "0")
      .formParam("CF00NL0000004U4DH_lspfsub", "0")
      .formParam("CF00NL0000004U4DH_mod", "0")
      .formParam("CF00NL0000004U4DH", "")
      .formParam("opp14", "")
      .formParam("save", "Saving...")
      .check(status.is(200))
      .check(regex("""handleRedirect\('\/(.+?)\'""").find.exists.saveAs("OpportunityId")))

        //////////////////////////////////Create Opportunity -End//////////////////////////////////

         .pause(2000 milliseconds, 2000 milliseconds)

        //////////////////////////////////Create Contract -Start//////////////////////////////////
         //Request to get conf token to create Contract
       .exec(http("GetCONFTokenToCreateOpportunity")
      .get("/800/e?retURL=%2F800%2Fo")
      .check(regex("""id="_CONFIRMATIONTOKEN" value="(.*?)"""").find.exists.saveAs("CONF_Token_Contract"))
      .headers(headers_0))


       //Request to create Contract

      .exec(http("CreateContract")
      .post(uri10 + "/800/e")
      .headers(headers_0)
      .formParam("_CONFIRMATIONTOKEN", "${CONF_Token_Contract}")
      .formParam("cancelURL", "/800/o")
      .formParam("retURL", "/800/o")
      .formParam("save_new_url", "/800/e?retURL=%2F800%2Fo")
      .formParam("save", "Saving...")
      .formParam("ctrc5", "6/20/2018")
      .formParam("ctrc7_lkid", "${AccountId}")
      .formParam("ctrc7_lkold", "Account-${runnumber}-${userid}-${repeatid}")
      .formParam("ctrc7_lktp", "001")
      .formParam("ctrc7_lspf", "1")
      .formParam("ctrc7_lspfsub", "0")
      .formParam("ctrc7_mod", "1")
      .formParam("lspffrom", "ctrc7")
      .formParam("ctrc7", "Account-${runnumber}-${userid}-${repeatid}")
      .formParam("CF00NL0000004U4AU_lkid", "000000000000000")
      .formParam("CF00NL0000004U4AU_lkold", "")
      .formParam("CF00NL0000004U4AU_lktp", "800")
      .formParam("CF00NL0000004U4AU_lspf", "0")
      .formParam("CF00NL0000004U4AU_lspfsub", "0")
      .formParam("CF00NL0000004U4AU_mod", "0")
      .formParam("CF00NL0000004U4AU", "")
      .formParam("ctrc16_lkid", "000000000000000")
      .formParam("ctrc16_lkold", "")
      .formParam("ctrc16_lktp", "003")
      .formParam("ctrc16_lspf", "0")
      .formParam("ctrc16_lspfsub", "0")
      .formParam("ctrc16_mod", "0")
      .formParam("ctrc16", "")
      .formParam("CF00NL0000004U4AV_lkid", "000000000000000")
      .formParam("CF00NL0000004U4AV_lkold", "")
      .formParam("CF00NL0000004U4AV_lktp", "800")
      .formParam("CF00NL0000004U4AV_lspf", "0")
      .formParam("CF00NL0000004U4AV_lspfsub", "0")
      .formParam("CF00NL0000004U4AV_mod", "0")
      .formParam("CF00NL0000004U4AV", "")
      .formParam("CustomerSignedTitle", "")
      .formParam("ctrc40", "")
      .formParam("ctrc6", "")
      .formParam("ctrc13", "")
      .formParam("CompanySigned_lkid", "000000000000000")
      .formParam("CompanySigned_lkold", "")
      .formParam("CompanySigned_lktp", "StandardUserLookup")
      .formParam("CompanySigned_lspf", "0")
      .formParam("CompanySigned_lspfsub", "0")
      .formParam("CompanySigned_mod", "0")
      .formParam("CompanySigned", "")
      .formParam("CompanySignedDate", "")
      .formParam("00NL0000004U4AH", "")
      .formParam("CF00NL0000004U4AS_lkid", "000000000000000")
      .formParam("CF00NL0000004U4AS_lkold", "")
      .formParam("CF00NL0000004U4AS_lktp", "006")
      .formParam("CF00NL0000004U4AS_lspf", "0")
      .formParam("CF00NL0000004U4AS_lspfsub", "0")
      .formParam("CF00NL0000004U4AS_mod", "0")
      .formParam("CF00NL0000004U4AS", "")
      .formParam("00NL0000004U4AZ", "")
      .formParam("CF00NL0000004U4AT_lkid", "000000000000000")
      .formParam("CF00NL0000004U4AT_lkold", "")
      .formParam("CF00NL0000004U4AT_lktp", "801")
      .formParam("CF00NL0000004U4AT_lspf", "0")
      .formParam("CF00NL0000004U4AT_lspfsub", "0")
      .formParam("CF00NL0000004U4AT_mod", "0")
      .formParam("CF00NL0000004U4AT", "")
      .formParam("00NL0000004U4Ae", "")
      .formParam("CF00NL0000004U4AX_lkid", "000000000000000")
      .formParam("CF00NL0000004U4AX_lkold", "")
      .formParam("CF00NL0000004U4AX_lktp", "0Q0")
      .formParam("CF00NL0000004U4AX_lspf", "0")
      .formParam("CF00NL0000004U4AX_lspfsub", "0")
      .formParam("CF00NL0000004U4AX_mod", "0")
      .formParam("CF00NL0000004U4AX", "")
      .formParam("00NL0000004U4Ac", "")
      .formParam("ctrc15", "Draft")
      .formParam("00NL0000004U4Ad", "")
      .formParam("00NL0000004U4AK", "")
      .formParam("ctrc25street", "")
      .formParam("ctrc25city", "")
      .formParam("ctrc25state", "")
      .formParam("ctrc25zip", "")
      .formParam("ctrc25country", "")
      .formParam("SpecialTerms", "")
      .formParam("Description", "")
      .check(status.is(200))
      .check(regex("""handleRedirect\('\/(.+?)\'""").find.exists.saveAs("ContractId")))

        //////////////////////////////////Create Contract -End//////////////////////////////////

         .pause(2000 milliseconds, 2000 milliseconds)


        //////////////////////////////////Create AccountBalance -Start//////////////////////////////////

          //Request to get conf token to create AccountBalance
       .exec(http("GetCONFTokenToCreateOpportunity")
      .get("/a47/e?retURL=%2Fa47%2Fo")
      .check(regex("""id="_CONFIRMATIONTOKEN" value="(.*?)"""").find.exists.saveAs("CONF_Token_AccountBalance"))
      .headers(headers_0))


       //Request to create AccountBalance

        .exec(http("CreateAccountBalance")
      .post(uri10 + "/a47/e")
      .headers(headers_0)
      .formParam("_CONFIRMATIONTOKEN", "${CONF_Token_AccountBalance}")
      .formParam("cancelURL", "/a47/o")
      .formParam("retURL", "/a47/o")
      .formParam("save_new_url", "/a47/e?retURL=%2Fa47%2Fo")
      .formParam("CF00NL0000004KE7p_lkid", "${AccountId}")
      .formParam("CF00NL0000004KE7p_lkold", "Account-${runnumber}-${userid}-${repeatid}")
      .formParam("CF00NL0000004KE7p_lktp", "001")
      .formParam("CF00NL0000004KE7p_lspf", "0")
      .formParam("CF00NL0000004KE7p_lspfsub", "0")
      .formParam("CF00NL0000004KE7p_mod", "1")
      .formParam("CF00NL0000004KE7p", "Account-${runnumber}-${userid}-${repeatid}")
      .formParam("00NL0000004KE8L", "6/27/2018")
      .formParam("00NL0000004KE8K", "5")
      .formParam("00NL0000004KE8J", "5")
      .formParam("00NL0000004KE8I", "10")
      .formParam("save", "Saving...")
      .check(status.is(200))
      .check(regex("""handleRedirect\('\/(.+?)\'""").find.exists.saveAs("AccountBalanceId")))

        //////////////////////////////////Create AccountBalance -End//////////////////////////////////


          }
    

    }
