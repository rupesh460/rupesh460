//Script is designed for 1 user only. Make sure to increment perfuserid in the declaration section
//Set number of "repeat" iterations
package Create_User
  import scala.concurrent.duration._

  import io.gatling.core.Predef._
  import io.gatling.core.structure.ChainBuilder
  import io.gatling.http.Predef._
  import io.gatling.jdbc.Predef._
  import io.gatling.jsonpath._
  import Headers._
  import scala.collection._
  import java.time.format.DateTimeFormatter
  import java.time.LocalDateTime
  import java.time.LocalDate


   object Create_User_Web {

    var userid = new StringBuilder()
    val uri10 = Configuration.Uri10
    val uri01 = Configuration.Uri01
    val userFeeder = csv("./src/test/resources/data/ecom/Perf2users.csv").random
    //val accountFeeder = csv("Perf2Accounts.csv").random
    var PerfUserid = 2 
    val scn = scenario("Create_User")


     .feed(userFeeder)
      .exec(http("Web_Login")
      .post(uri01 + "/")
      .headers(headers_26)
      .formParam("un", "${username}")
      .formParam("width", "1920")
      .formParam("height", "1080")
      .formParam("hasRememberUn", "true")
      .formParam("startURL", "")
      .formParam("loginURL", "")
      .formParam("loginType", "")
      .formParam("useSecure", "true")
      .formParam("local", "")
      .formParam("lt", "standard")
      .formParam("qs", "")
      .formParam("locale", "")
      .formParam("oauth_token", "")
      .formParam("oauth_callback", "")
      .formParam("login", "")
      .formParam("serverid", "")
      .formParam("display", "page")
      .formParam("username", "${username}")
      .formParam("pw", "${password}")
      .formParam("Login", "Log In to Sandbox")
      .formParam("rememberUn", "on"))

        .pause(2000 milliseconds, 2000 milliseconds)


      .exec(http("GetCONFToken")
      .get("/005/e?retURL=%2F005%3FisUserEntityOverride%3D1%26retURL%3D%252Fui%252Fsetup%252FSetup%253Fsetupid%253DUsers%26setupid%3DManageUsers&isUserEntityOverride=1")
      .check(regex("""id="_CONFIRMATIONTOKEN" value="(.*?)"""").find.exists.saveAs("CONF_Token"))
      .headers(headers_0))


              
    .pause(2000 milliseconds, 2000 milliseconds)

       .repeat(9,"repeatid")
          {

              exec((s: Session) => s.set("userid",s.userId.toString))
              .exec(session => session.set("perfuserid",PerfUserid))

   
    .exec(http("CreateUser")
      .post(uri10 + "/005/e?isUserEntityOverride=1")
      .headers(headers_26)
      .formParam("_CONFIRMATIONTOKEN", "${CONF_Token}")
      .formParam("cancelURL", "/005?isUserEntityOverride=1&retURL=%2Fui%2Fsetup%2FSetup%3Fsetupid%3DUsers&setupid=ManageUsers")
      .formParam("retURL", "/005?isUserEntityOverride=1&retURL=%2Fui%2Fsetup%2FSetup%3Fsetupid%3DUsers&setupid=ManageUsers")
      .formParam("save_new_url", "/005/e?isUserEntityOverride=1&retURL=%2F005%3FisUserEntityOverride%3D1%26retURL%3D%252Fui%252Fsetup%252FSetup%253Fsetupid%253DUsers%26setupid%3DManageUsers")
      .formParam("save", "Saving...")
      .formParam("name_firstName", "p2user${perfuserid}")
      .formParam("role", "000000000000000")
      .formParam("name_lastName", "p2user${perfuserid}")
      .formParam("user_license_id", "100j00000006pPj")
      .formParam("Alias", "p2user${perfuserid}")
      .formParam("Profile", "00ej0000000Y9tC")
      .formParam("Email", "rkasi@vlocity.com")
      .formParam("Username", "p2user${perfuserid}@perf2.sbx")
      .formParam("CommunityNickname", "p2user${perfuserid}")
      .formParam("Title", "")
      .formParam("CompanyName", "")
      .formParam("Department", "")
      .formParam("Division", "")
      .formParam("jigsawUserType", "")
      .formParam("dev_context_menu", "1")
      .formParam("no_content_send_emails", "1")
      .formParam("content_email_no_digest", "1")
      .formParam("CallCenter_lkid", "000000000000000")
      .formParam("CallCenter_lkold", "null")
      .formParam("CallCenter_lktp", "04v")
      .formParam("CallCenter_lspf", "0")
      .formParam("CallCenter_lspfsub", "0")
      .formParam("CallCenter_mod", "0")
      .formParam("CallCenter", "")
      .formParam("Phone", "")
      .formParam("Extension", "")
      .formParam("Fax", "")
      .formParam("MobilePhone", "")
      .formParam("EmailEncodingKey", "1")
      .formParam("EmployeeNumber", "")
      .formParam("Addressstreet", "")
      .formParam("Addresscity", "")
      .formParam("Addressstate", "")
      .formParam("Addresszip", "")
      .formParam("Addresscountry", "")
      .formParam("FederationIdentifier", "")
      .formParam("TimeZoneSidKey", "12")
      .formParam("LocaleSidKey", "1")
      .formParam("LanguageLocaleKey", "1")
      .formParam("DelegatedApprover_lkid", "000000000000000")
      .formParam("DelegatedApprover_lkold", "null")
      .formParam("DelegatedApprover_lktp", "StandardUserLookup")
      .formParam("DelegatedApprover_lspf", "0")
      .formParam("DelegatedApprover_lspfsub", "0")
      .formParam("DelegatedApprover_mod", "0")
      .formParam("DelegatedApprover", "")
      .formParam("Manager_lkid", "000000000000000")
      .formParam("Manager_lkold", "null")
      .formParam("Manager_lktp", "StandardUserLookup")
      .formParam("Manager_lspf", "0")
      .formParam("Manager_lspfsub", "0")
      .formParam("Manager_mod", "0")
      .formParam("Manager", "")
      .formParam("receiveApprovalsEmails", "SEND_APPROVER")
      .formParam("new_password", "1"))
     // .check(bodyBytes.is(RawFileBody("CreateContactwithaccount_0000_response.txt"))))
        


      .pause(2000 milliseconds, 2000 milliseconds)

    .exec( session => {
             PerfUserid= PerfUserid+1
             session
           })


          }
    

    }
