package eComm_Sky_Germany

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._

class eComm_AWS_Sky_Scn extends Simulation {

	val httpConf = http
		.baseUrl(Configuration.BaseUrl_AWS)
		.inferHtmlResources(BlackList(""".*\.js""", """.*\.css""", """.*\.gif""", """.*\.jpeg""", """.*\.jpg""", """.*\.ico""", """.*\.woff""", """.*\.(t|o)tf""", """.*\.png"""), WhiteList())
		.acceptHeader("*/*")
		.acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8")
		.acceptEncodingHeader("gzip, deflate, sdch")
		.acceptLanguageHeader("en-US,en;q=0.8")
		.disableCaching
		.contentTypeHeader("application/x-www-form-urlencoded; charset=UTF-8")
		.userAgentHeader("Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:41.0) Gecko/20100101 Firefox/41.0")

	val productViewUsers = Integer.getInteger("productViewUsers", 1)
	val productViewRampUp = Integer.getInteger("productViewRampUp", 1)

	val addToCartUsers = Integer.getInteger("addToCartUsers", 1)
	val addToCartRampUp = Integer.getInteger("addToCartRampUp", 1)

	val checkOutUsers = Integer.getInteger("checkOutUsers", 1)
	val checkOutRampUp = Integer.getInteger("checkOutRampUp", 1)

	val maxDurationSecs = Integer.getInteger("maxDurationSecs", 1)
	val testDuration = Integer.getInteger("testDuration",1)
	

	setUp(

		// eComm_AWS_Sky.productViewsScn.inject(rampUsers(productViewUsers) during (productViewRampUp seconds)).protocols(httpConf)).maxDuration(maxDurationSecs seconds)
		eComm_AWS_Sky.productViewsScn.inject(rampUsers(productViewRampUp) during (testDuration seconds)).protocols(httpConf)).maxDuration(maxDurationSecs seconds)
//		eComm_AWS.addToCartScn.inject(rampUsers(addToCartUsers) during (addToCartRampUp seconds)).protocols(httpConf),
//		eComm_AWS.checkOutScn.inject(rampUsers(checkOutUsers) during (checkOutRampUp seconds)).protocols(httpConf)).maxDuration(maxDurationSecs seconds)	
}
