package eComm_Sky_Germany

object Headers
{

val header_0 = Map(
  		//"Accept" -> "text/javascript, text/html, application/xml, application/json, text/xml, */*",
		//"Accept-Encoding" -> "gzip, deflate, br",
		//"Accept-Language" -> "en-US,en;q=0.8",
		"Content-Type" -> "application/json",
		"Connection" -> "keep-alive",
  		"authorization" -> "Basic cGVyZjp4aXczVURhQVg2cDZRY2N0cERjYjJ5ZjZ0a2U3Z1FtZ1FMcA==")

val header_1 = Map(
  		"Accept" -> "text/javascript, text/html, application/xml, application/json, text/xml, */*",
		//"Accept-Encoding" -> "gzip, deflate, br",
		//"Accept-Language" -> "en-US,en;q=0.8",
		"authorization" -> "Bearer ${Token_ID}",
		"Content-Type" -> "application/json",
		"Connection" -> "keep-alive")
}
