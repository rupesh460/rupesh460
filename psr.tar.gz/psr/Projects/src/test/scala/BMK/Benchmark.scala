  package BMK

  import scala.concurrent.duration._
  import io.gatling.core.Predef._
  import io.gatling.core.structure.ChainBuilder
  import io.gatling.http.Predef._
  import io.gatling.jdbc.Predef._
  import io.gatling.jsonpath._
  import Headers._
  import scala.collection._
  import java.time.format.DateTimeFormatter
  import java.time.LocalDateTime
  import java.time.LocalDate

import io.gatling.core.feeder._
import java.util.Base64
import java.nio.charset.StandardCharsets
import scala.util.matching.Regex

  object Benchmark {

    val uri01 = Configuration.Uri01
    val uri05 = Configuration.Uri05
    val uri10 = Configuration.Uri10
    var modifiedItemJson = new StringBuilder()
    val origItemAttrHeirarchy = new StringBuilder()
    val modItemAttrHeirarchy = new StringBuilder()
    val randomNumber = new scala.util.Random
    var randomLineItem = new StringBuilder()
    var pbeEntriesList = Vector[String]()
    var promotionList = Vector[String]()
    var lineItemsList = Vector[String]()
    var randomPBEntry = new StringBuilder()
    var accountName = new StringBuilder()
    var randomPromoId = new StringBuilder()
    var final_formatted_date = new StringBuilder()
    //val userFeeder = csv("./src/test/resources/data/devorg_bmk/EPC_BMK_Users.csv").random
    val product_feeder = csv("./src/test/resources/data/devorg_bmk/ProductIds.csv").random
    //val products_ids_loy = csv("./src/test/resources/data/devorg/EPC_BMK_Loyalty_ProductIds.csv").random

  
   val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
  val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
  val password_v = (passwordByEnv.get("perf3").toString)
  val password_encoded = password_v.substring(12,(password_v.length - 2 ))
  val credentials = new String(Base64.getDecoder.decode(password_encoded))



    val cpq_base_apis = scenario("cpq_base_apis")

    .exec(session => session.set("PriceListId",Configuration.PriceListId))
    .exec(session => session.set("PromotionID1",Configuration.Promotion3PI))
    .exec(session => session.set("PromotionID2",Configuration.Promotion5PI))
    .exec(session => session.set("UpdatePromotionID",Configuration.UpdatePromotion))
    .exec(session => session.set("UpdatePromotionItemID",Configuration.UpdatePromotionItem))
    .exec(session => session.set("PenaltyRulePromotionID",Configuration.PenaltyRulePromotion))
    .exec(session => session.set("password",credentials)) 

    //.feed(userFeeder)
    //.feed(passFeeder)
    .exec(http("RESTGetOAuthToken")
      .post("https://login.salesforce.com/services/oauth2/token")
      .header("Content-Type", "application/x-www-form-urlencoded")
      .formParam("password", "${password}")
      .formParam("username", "perf-cmt-release-bmk@vlocity.com")
      .formParam("client_secret", "2847028618258912343")
      .formParam("client_id", "3MVG9KsVczVNcM8xeKy2xCeFKhU5cLqUWx_oOlMOvZw3mINnx7tqn7vQL3YFko0YLGC_k8FBSC.DVtC_g4GWH")
      .formParam("grant_type", "password")
      .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
      .check(status.is(200)))

    .repeat(20000)
    {

      exec(session => session.set("AccountName",""))

      .exec( session => {
        val random_index = randomNumber.nextInt(100000)
        accountName.append("Acc-"+random_index)
        session
      })

      .exec(session => session.set("AccountName",accountName))

      .exec( session => {
        accountName = new StringBuilder()
        session
      })

      /* *********** CreateAccount *********** */
      .exec(http("CreateAccount")
        .post(uri10 +"/services/data/v44.0/sobjects/account")
        .headers(header_1)
        .check(regex(""""id":"(.*?)"""").find.exists.saveAs("AccountId"))
        .body( StringBody("""
        {
          "Name" : "${AccountName}",
          "ShippingCity" : "San Francisco",
          "RecordTypeId" : "0121U000000IuOgQAK",
          "vlocity_perf__Status__c": "Active"
        }""")).asJson)

      /* *********** CreateOrder *********** */
      .exec(http("Create_a_new_order")
        .post(uri10 +"/services/apexrest/vlocity_perf/v2/carts")
        .headers(header_1)
        .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
        .body( StringBody("""{"subaction":"createOrder",
          "inputFields":[
          {"AccountId":"${AccountId}"},
          {"vlocity_perf__PriceListId__c":"${PriceListId}"},
          {"Name":"Bmk-Order"},{"Status":"Draft"},
          {"EffectiveDate":"2/2/2019"}
          ]}""")).asJson)

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      /* ********** SetPriceListForCart *********** */
      .exec(http("Set_PriceList_for_the_order")
        .put(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/")
        .headers(header_1)
        .body(StringBody("""{
          "inputFields":
          [
          {
            "vlocity_perf__PriceListId__c": "${PriceListId}"
          }
          ],
          "cartId": "${OrderID}",
          "methodName": "updateCarts"
        }""")).asJson
        .check(regex(""""Id":"${OrderID}"""").find.exists))

        /* ********** GetListOfProductsForCart *********** */
      .exec(http("Get_list_of_products_for_cart")
        .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/products?pagesize=10")
        .check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfPBEntries"))
        .headers(header_1))


        /* ********** GetListOfPromotionsForCart *********** */
      .exec(http("Get_list_of_promotions_for_cart")
        .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/promotions?pagesize=10")
        .check(jsonPath("$.records[0].id").find.saveAs("PromotionID"))
        .check(jsonPath("$.records[*].id").findAll.saveAs("PromotionList"))
        .headers(header_1))

       .exec( session => {
        promotionList = session("PromotionList").as[Vector[String]]
        session
      })

     .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

     /* ********** AddPromotionToCart *********** */
     .exec(http("Add_a_promotion_which_has_3_promotion_items")
      .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/promotions")
      .headers(header_1)
      .body( StringBody("""{
        "items": [{"itemId":"${PromotionID1}"}],
        "promotionId":"${PromotionID1}",
        "cartId":"${OrderID}",
        "methodName":"postCartsPromoItems"
      }""")).asJson
      .check(regex("""BMK-Promo-1549615808521""").find.exists))

     /* ********** AddPromotionToCart *********** */
     .exec(http("Add_a_promotion_which_has_5_promotion_items")
      .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/promotions")
      .headers(header_1)
      .body( StringBody("""{
        "items": [{"itemId":"${PromotionID2}"}],
        "promotionId":"${PromotionID2}",
        "cartId":"${OrderID}",
        "methodName":"postCartsPromoItems"
      }""")).asJson
      .check(regex("""BMK-Promo-1549615894869""").find.exists))

     .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

     /* Adding promotion-601 to cart for Cancel promotion call */
     /* ********** AddPromotionToCart *********** */
     .exec(http("Add_a_promotion_to_cart_which_has_penalty_rule")
      .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/promotions")
      .headers(header_1)
      .body( StringBody("""{
        "items": [{"itemId":"${PenaltyRulePromotionID}"}],
        "promotionId":"${PenaltyRulePromotionID}",
        "cartId":"${OrderID}",
        "methodName":"postCartsPromoItems"
      }""")).asJson
      .check(regex("""BMK-Promo-1549615890400-Prod""").find.exists))

     .repeat(5)
     {

      /* ********** AddItemsToCart *********** */
      feed(product_feeder)
      .exec(http("Add_items_to_cart")
        .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items")
        .headers(header_1)
        .body( StringBody("""{
          "items":[{
            "itemId":"${ProductID}"
          }],
          "price":"true",
          "validate":"true",
          "pagesize":20
        }""")).asJson
        .check(regex("""INFO","message":"Successfully added.""").find.exists))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      }

  /*
  /* ********** AddItemsToCart *********** */
  .feed(products_ids_loy)
  .exec(http("Add_an_item_to_cart_which_has_Loyalty_Price")
    .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items")
    .headers(header_1)
    .body( StringBody("""{
      "items":[{
        "itemId":"${ProductID_Loy}"
      }],
      "hierarchy":3,
      "lastItemId":"",
      "pagesize":20
    }""")).asJson
    .check(regex("""INFO","message":"Successfully added.""").find.exists))

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  */


  /* ********** GetCarts *********** */
  .exec(http("Get_carts_pricing")
    .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}?price=true&validate=true")
    .headers(header_1))

  /* ********** GetCartLineItems_200LI_InCart *********** */
  .exec(http("GetCartLineItems")
    .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items?pagesize=10&price=true&validate=true")
    .headers(header_1)
    .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1"))
    .check(jsonPath("$.records[1].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem2"))
    .check(jsonPath("$.records[2].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem3"))
    .check(jsonPath("$.records[3].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem4")))


  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  /* *********** GetPromotionsAppliedToCart ********** */
  .exec(http("Get_promotions_applied_to_cart_Cart_has_3_promotions")
    .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/promotions?subaction=getPromotionsAppliedToCart")
    .check(jsonPath("$.records[0].Id.value").find.exists.saveAs("AppliedPromotionId1"))
    .check(jsonPath("$.records[1].Id.value").find.exists.saveAs("AppliedPromotionId2"))
    .headers(header_1))

  /* ********** GetCartItemsByItemId *********** */
  .exec(http("Get_line_item_details")
    .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items")
    .queryParamSeq(Seq(("id", "${LineItem1}")))
    .headers(header_1)
    .check(regex("""displaySequence":-1,(.+?),"productCategories"""").find.exists.saveAs("capturedItemHierarchy")))

  .exec(session => {
    //originalItemJson.append(session("capturedItemHierarchy").as[String])
    modifiedItemJson = new StringBuilder()
    modifiedItemJson.append("""{"items":{"records":[{"displaySequence":-1,""").append(session("capturedItemHierarchy").as[String]).append("}]}}")
    session
  })

  /* ********** UpdateItemsInCart *********** */
  /* Updating the Quantity from default 1.00 to 3.00 */
  .exec(http("Update_cart_line_item")
    .put(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items")
    .headers(header_1)
    .body(StringBody(session =>  modifiedItemJson.replaceAllLiterally(""""Quantity":{"value":1.00""",""""Quantity":{"value":3.00""").toString() )).asJson
    .check(regex("""INFO","message":"Successfully updated.""").find.exists))

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


  /* ********** DeleteItemFromCart********** */
  .exec(http("Delete_an_item_from_the_cart")
    .delete(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items/${LineItem2}")
    .headers(header_1)
    .check(regex("""INFO","message":"Successfully deleted.""").find.exists))

  /* ********** GetPricingDetailsForCartLineItem *********** */
  .exec(http("Get_pricing_details_for_the_cart_line_item")
    .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items/${LineItem3}/pricing?fields=vlocity_perf__RecurringCharge__c,vlocity_perf__OneTimeCharge__c")
    .headers(header_1))


   /* *********** DeletePromotionAppliedToCart ********** */
 .exec(http("Delete_an_applied_promotion_in_the_cart")
  .delete(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/promotions?id=${AppliedPromotionId1}")
  .headers(header_1)
  .check(regex("""INFO","message":"Successfully deleted.""").find.exists))

 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


 /* ********** CloneCartLineItem ********** */
 .exec(http("Clone_a_cart_line_item_Item_has_approximatel_2-3_childs")
  .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items/clone")
  .headers(header_1)
  .body( StringBody("""{
    "items": [
    {"itemId":"${LineItem3}"}
    ],
    "hierarchy": 1,
    "lastItemId": "",
    "pagesize": 20
  }""")).asJson
  .check(regex("""INFO","message":"Clone Successful.""").find.exists))

 .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

 /* ********** GetPricingDetailsForCartLineItem *********** */
 .exec(http("Get_pricing_details_for_the_cart_line_item")
  .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items/${LineItem4}/pricing?fields=vlocity_perf__RecurringCharge__c,vlocity_perf__OneTimeCharge__c")
  .headers(header_1))

  /* Adding Test-Prods-For-BMK-500 which is associated with BMK-Test-Promotion-98 which is of Update type */

/* ********** AddItemsToCart *********** */
.exec(http("Add_an_item_to_cart_for_update_promotion_call")
  .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items")
  .headers(header_1)
  .body( StringBody("""{
    "items":[{
      "itemId":"${UpdatePromotionItemID}"
    }],
    "hierarchy":3,
    "lastItemId":"",
    "pagesize":20
  }""")).asJson
  .check(regex("""INFO","message":"Successfully added.""").find.exists))

  /* ********** SubmitOrder ********** */
.exec(http("Submit_order_20_Items_in_cart")
  .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items/checkout")
  .headers(header_1)
  //.check(regex("""Account""").find.exists)
  .body( StringBody("""{
    "items":[
    {"itemId":"${LineItem1}"}
    ],
    "hierarchy":1,
    "lastItemId":"",
    "pagesize":20
  }""")).asJson)

.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

/* ********** GetAssetsForAccount ********** */
.exec(http("Get_assets_for_the_account")
  .get(uri10 +"/services/apexrest/vlocity_perf/v2/accounts/${AccountId}/assets")
  .headers(header_1)
  .check(jsonPath("$.records[*].Id.value").findAll.saveAs("ListOfAssetIds")))


  /* ********** GetRequestDateDetailsForOrderItem *********** */
.exec(http("GetRequestDateDetailsForOrderItem")
  .get(uri10 +"/services/data/v39.0/query/?q=SELECT+vlocity_perf__RequestDate__c+FROM+OrderItem+WHERE+vlocity_perf__RequestDate__c+!=+null+ORDER+BY+vlocity_perf__RequestDate__c+DESC+LIMIT+10")
  .check(regex("""<vlocity_perf__RequestDate__c>(.*?)</vlocity_perf__RequestDate__c>""").findAll.exists.saveAs("RequestDatesList"))
  .headers(header_1))

.exec( session => {
  val requestDateList = session("RequestDatesList").as[List[String]]
  val maxdate = requestDateList(0)
  val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
  val dateforcurrentrun = LocalDate.parse(maxdate,formatter).plusDays(1)
  final_formatted_date.append(dateforcurrentrun)
  session
})

.exec( session => session.set("DATE", final_formatted_date ) )
.exec( session => {
  final_formatted_date = new StringBuilder()
  session
})

.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

.exec(http("GetAssetId")
  .get(uri10 +"/services/data/v39.0/query/?q=SELECT Id,Name FROM Asset WHERE AccountId = '${AccountId}' AND Name = 'BMK-Promo-1549615893377-Prod' LIMIT 1")
  .check(regex("<Id>(.*?)</Id>").find.saveAs("AssetId"))
  .headers(header_1))

/* ************ AssetChangeToOrder *********** */
.exec(http("Asset_to_order_One_asset_has_been_converted_to_order")
  .post(uri10 +"/services/apexrest/vlocity_perf/v2/carts")
  .headers(header_1)
  .check(jsonPath("$.records[0].cartId").find.saveAs("CartId_ForUpdatePromo"))
  .body(StringBody("""{
    "subaction": "assetToOrder",
    "id":"${AssetId}",
    "accountId": "${AccountId}",
    "requestDate": "${DATE}"
  } """)).asJson)

.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

/* ********** AddPromotionToCart *********** */
.exec(http("Add_a_promotion_which_is_of_update_type")
  .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${CartId_ForUpdatePromo}/promotions")
  .headers(header_1)
  .body( StringBody("""{
    "items": [{"itemId":"${UpdatePromotionID}"}],
    "promotionId":"${UpdatePromotionID}",
    "cartId":"${CartId_ForUpdatePromo}",
    "methodName":"postCartsPromoItems"
  }""")).asJson)

/* ********** SubmitOrder ********** */
.exec(http("Submit_order_with_single_line_item")
  .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${CartId_ForUpdatePromo}/items/checkout")
  .headers(header_1)
  //.check(regex("""Account""").find.exists)
  .body( StringBody("""{}""")).asJson)

/* ********** GetRequestDateDetailsForOrderItem *********** */
.exec(http("GetRequestDateDetailsForOrderItem")
  .get(uri10 +"/services/data/v39.0/query/?q=SELECT+vlocity_perf__RequestDate__c+FROM+OrderItem+WHERE+vlocity_perf__RequestDate__c+!=+null+ORDER+BY+vlocity_perf__RequestDate__c+DESC+LIMIT+10")
  .check(regex("""<vlocity_perf__RequestDate__c>(.*?)</vlocity_perf__RequestDate__c>""").findAll.exists.saveAs("RequestDatesList"))
  .headers(header_1))

.exec( session => {
  val requestDateList = session("RequestDatesList").as[List[String]]
  val maxdate = requestDateList(0)
  val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
  val dateforcurrentrun = LocalDate.parse(maxdate,formatter).plusDays(1)
  final_formatted_date.append(dateforcurrentrun)
  session
})

.exec( session => session.set("DATE", final_formatted_date ) )
.exec( session => {
  final_formatted_date = new StringBuilder()
  session
})

.exec(http("GetAssetId")
  .get(uri10 +"/services/data/v39.0/query/?q=SELECT Id,Name FROM Asset WHERE AccountId = '${AccountId}' AND Name = 'BMK-Promo-1549615890400-Prod' LIMIT 1")
  .check(regex("<Id>(.*?)</Id>").find.saveAs("AssetId"))
  .headers(header_1))

/* ************ AssetChangeToOrder *********** */
.exec(http("Asset_to_order_One_asset_has_been_converted_to_order")
  .post(uri10 +"/services/apexrest/vlocity_perf/v2/carts")
  .headers(header_1)
  .check(jsonPath("$.records[0].cartId").find.saveAs("CartId_ForPenalty"))
  .body(StringBody("""{
    "subaction": "assetToOrder",
    "id":"${AssetId}",
    "accountId": "${AccountId}",
    "requestDate": "${DATE}"
  } """)).asJson)

.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

/* *********** GetPromotionsAppliedToCart ********** */
.exec(http("Get_promotions_applied_to_cart_Cart_has_PenaltyRulePromotion")
  .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${CartId_ForPenalty}/promotions?subaction=getPromotionsAppliedToCart")
  .check(jsonPath("$.records[0].Id.value").find.exists.saveAs("AppliedPromotionId"))
  .headers(header_1))


/* *********** CancelPromotionWhichHasPenalty ********** */
.exec(http("Cancel_a_applied_promotion_that_has_penalty_rule")
  .delete(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${CartId_ForPenalty}/promotions?id=${AppliedPromotionId}")
  .headers(header_1)
  .check(regex("""INFO","message":"Successfully deleted.""").find.exists))

/* ********** SubmitOrder ********** */
.exec(http("Submit_order_with_single_line_item")
  .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${CartId_ForPenalty}/items/checkout")
  .headers(header_1)
  //.check(regex("""Account""").find.exists)
  .body( StringBody("""{}""")).asJson)

.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

}

val cpq_diff_cart_shapes = scenario("cpq_diff_cart_shapes")

.exec(session => session.set("PriceListId",Configuration.PriceListId))


.exec(http("RESTGetOAuthToken")
  .post("https://login.salesforce.com/services/oauth2/token")
  .header("Content-Type", "application/x-www-form-urlencoded")
  .formParam("password", "${password}")
  .formParam("username", "perf-cmt-release-bmk@vlocity.com")
  .formParam("client_secret", "2847028618258912343")
  .formParam("client_id", "3MVG9KsVczVNcM8xeKy2xCeFKhU5cLqUWx_oOlMOvZw3mINnx7tqn7vQL3YFko0YLGC_k8FBSC.DVtC_g4GWH")
  .formParam("grant_type", "password")
  .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
  .check(status.is(200)))

.repeat(20000)
{

  exec(session => session.set("AccountName",""))

  .exec( session => {
    val random_index = randomNumber.nextInt(100000)
    accountName.append("Acc-"+random_index)
    session
  })

  .exec(session => session.set("AccountName",accountName))

  .exec( session => {
    accountName = new StringBuilder()
    session
  })

  /* *********** CreateAccount *********** */
  .exec(http("CreateAccount")
    .post(uri10 +"/services/data/v44.0/sobjects/account")
    .headers(header_1)
    .check(regex(""""id":"(.*?)"""").find.exists.saveAs("AccountId"))
    .body( StringBody("""
    {
      "Name" : "${AccountName}",
      "ShippingCity" : "San Francisco",
      "RecordTypeId" : "0121U000000IuOgQAK",
      "vlocity_perf__Status__c"    : "Active"
    }""")).asJson)

  /* *********** CreateOrder *********** */
  .exec(http("Create_a_new_order")
    .post(uri10 +"/services/apexrest/vlocity_perf/v2/carts")
    .headers(header_1)
    .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
    .body( StringBody("""{"subaction":"createOrder",
      "inputFields":[
      {"AccountId":"${AccountId}"},
      {"vlocity_perf__PriceListId__c":"${PriceListId}"},
      {"Name":"Bmk-Order"},{"Status":"Draft"},
      {"EffectiveDate":"2/2/2019"}
      ]}""")).asJson)

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  /* ********** SetPriceListForCart *********** */
  .exec(http("Set_PriceList_for_the_order")
    .put(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/")
    .headers(header_1)
    .body(StringBody("""{
      "inputFields":
      [
      {
        "vlocity_perf__PriceListId__c": "${PriceListId}"
      }
      ],
      "cartId": "${OrderID}",
      "methodName": "updateCarts"
    }""")).asJson
    .check(regex(""""Id":"${OrderID}"""").find.exists))

    .repeat(7)
  {

    /* ********** AddItemsToCart *********** */
    feed(product_feeder)
    .exec(http("Add_items_to_cart-1")
      .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items")
      .headers(header_1)
      .body( StringBody("""{
        "items":[{
          "itemId":"${ProductID}"
        }],
        "price":"true",
        "validate":"true",
        "pagesize":20
      }""")).asJson
      .check(regex("""INFO","message":"Successfully added.""").find.exists))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  }


  /* ********** AddItemsToCart *********** */
  .feed(product_feeder)
  .exec(http("Add_items_to_cart_when_cart_has_20_line_items")
    .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items")
    .headers(header_1)
    .body( StringBody("""{
      "items":[{
        "itemId":"${ProductID}"
      }],
      "price":"true",
      "validate":"true",
      "pagesize":20
    }""")).asJson
    .check(regex("""INFO","message":"Successfully added.""").find.exists))

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


  /* ********** GetCartLineItems_20LI_InCart *********** */
  .exec(http("Get_list_of_cart_line_items_Cart_has_approximately_20_line_items")
    .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items?pagesize=10&price=true&validate=true")
    .headers(header_1)
    .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1"))
    .check(jsonPath("$.records[1].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem2")))

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  /* ********** DeleteItemFromCart********** */
  .exec(http("Delete_an_item_from_the_cart_Cart_has_20_line_items")
    .delete(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items/${LineItem2}")
    .headers(header_1)
    .check(regex("""INFO","message":"Successfully deleted.""").find.exists))
  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  .repeat(27)
  {

    /* ********** AddItemsToCart *********** */
    feed(product_feeder)
    .exec(http("Add_items_to_cart-1")
      .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items")
      .headers(header_1)
      .body( StringBody("""{
        "items":[{
          "itemId":"${ProductID}"
        }],
        "price":"true",
        "validate":"true",
        "pagesize":20
      }""")).asJson
      .check(regex("""INFO","message":"Successfully added.""").find.exists))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  }

  /* ********** AddItemsToCart *********** */
  .feed(product_feeder)
  .exec(http("Add_items_to_cart_when_cart_has_100_line_items")
    .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items")
    .headers(header_1)
    .body( StringBody("""{
      "items":[{
        "itemId":"${ProductID}"
      }],
      "price":"true",
      "validate":"true",
      "pagesize":20
    }""")).asJson
    .check(regex("""INFO","message":"Successfully added.""").find.exists))

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  /* ********** GetCartLineItems_100LI_InCart *********** */
  .exec(http("Get_list_of_cart_line_items_Cart_has_approximately_100_line_items")
    .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items?pagesize=10&price=true&validate=true")
    .headers(header_1)
    .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1"))
    .check(jsonPath("$.records[1].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem2")))


  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  /* ********** DeleteItemFromCart********** */
  .exec(http("Delete_an_item_from_the_cart_Cart_has_100_line_items")
    .delete(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items/${LineItem2}")
    .headers(header_1)
    .check(regex("""INFO","message":"Successfully deleted.""").find.exists))
  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  .repeat(33)
  {

    /* ********** AddItemsToCart *********** */
    feed(product_feeder)
    .exec(http("Add_items_to_cart-1")
      .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items")
      .headers(header_1)
      .body( StringBody("""{
        "items":[{
          "itemId":"${ProductID}"
        }],
        "price":"true",
        "validate":"true",
        "pagesize":20
      }""")).asJson
      .check(regex("""INFO","message":"Successfully added.""").find.exists))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  }

  /* ********** AddItemsToCart *********** */
  .feed(product_feeder)
  .exec(http("Add_items_to_cart_when_cart_has_200_line_items")
    .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items")
    .headers(header_1)
    .body( StringBody("""{
      "items":[{
        "itemId":"${ProductID}"
      }],
      "price":"true",
      "validate":"true",
      "pagesize":20
    }""")).asJson
    .check(regex("""INFO","message":"Successfully added.""").find.exists))

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


  /* ********** GetCartLineItems_200LI_InCart *********** */
  .exec(http("Get_list_of_cart_line_items_Cart_has_approximately_200_line_items")
    .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items?pagesize=10&price=true&validate=true")
    .headers(header_1)
    .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1"))
    .check(jsonPath("$.records[1].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem2")))

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  /* ********** DeleteItemFromCart********** */
  .exec(http("Delete_an_item_from_the_cart_Cart_has_200_line_items")
    .delete(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items/${LineItem2}")
    .headers(header_1)
    .check(regex("""INFO","message":"Successfully deleted.""").find.exists))
  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)


  /* ********** SubmitOrder ********** */
  .exec(http("Submit_order_with_approximately_210_line_items")
    .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items/checkout")
    .headers(header_1)
    //.check(regex("""Account""").find.exists)
    .body( StringBody("""{
      "items":[
      {"itemId":"${LineItem1}"}
      ],
      "hierarchy":1,
      "lastItemId":"",
      "pagesize":20
    }""")).asJson)

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
}


}
