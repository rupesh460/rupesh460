package CPQ_Cart_Operations

object Configuration
 {
	val BaseUrl = "https://c.na85.visual.force.com"
	val Uri01 = "https://login.salesforce.com"
	val Uri05 = "https://c.na85.visual.force.com"
	val Uri10 = "https://na85.salesforce.com"

	val PriceListId = "a2r1U000000dBBaQAM" // BMK-Pricelist

	val Promotion3PI = "a341U000000cc9ZQAQ" // BMK-Promo-1549615808521
	val Promotion5PI = "a341U000000ccJQQAY" //BMK-Promo-1549615894869 

	val UpdatePromotion = "a341U000000ccJLQAY" // BMK-Promo-1549615893377   
	val UpdatePromotionItem = "01u1U000000lc0JQAQ" // BMK-Promo-1549615893377-Prod

	val PenaltyRulePromotion = "a341U000000ccJGQAY" // BMK-Promo-1549615890400

	val MinWaitMs = 1500
	val MaxWaitMs = 2000

}
