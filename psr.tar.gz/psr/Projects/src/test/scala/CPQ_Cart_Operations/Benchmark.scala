  package CPQ_Cart_Operations

  import scala.concurrent.duration._
  import io.gatling.core.Predef._
  import io.gatling.core.structure.ChainBuilder
  import io.gatling.http.Predef._
  import io.gatling.jdbc.Predef._
  import io.gatling.jsonpath._
  import Headers._
  import scala.collection._
  import java.time.format.DateTimeFormatter
  import java.time.LocalDateTime
  import java.time.LocalDate

import io.gatling.core.feeder._
import java.util.Base64
import java.nio.charset.StandardCharsets
import scala.util.matching.Regex


  object Benchmark {

    val uri01 = Configuration.Uri01
    val uri05 = Configuration.Uri05
    val uri10 = Configuration.Uri10
    var modifiedItemJson = new StringBuilder()
    val origItemAttrHeirarchy = new StringBuilder()
    val modItemAttrHeirarchy = new StringBuilder()
    val randomNumber = new scala.util.Random
    var randomLineItem = new StringBuilder()
    var pbeEntriesList = Vector[String]()
    var promotionList = Vector[String]()
    var lineItemsList = Vector[String]()
    var randomPBEntry = new StringBuilder()
    var accountName = new StringBuilder()
    var randomPromoId = new StringBuilder()
    var final_formatted_date = new StringBuilder()
    //val userFeeder = csv("./src/test/resources/data/devorg_bmk/EPC_BMK_Users.csv").random
    val product_feeder = csv("./src/test/resources/data/devorg_bmk/ProductIds.csv").random
    //val products_ids_loy = csv("./src/test/resources/data/devorg/EPC_BMK_Loyalty_ProductIds.csv").random
    val offerCountFeeder = csv("./src/test/resources/data/eComm/NoOfOffersToAdd_CPQ.csv").circular  

 val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
  val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
  val password_v = (passwordByEnv.get("perf3").toString)
  val password_encoded = password_v.substring(12,(password_v.length - 2 ))
  val credentials = new String(Base64.getDecoder.decode(password_encoded))


val cpq_diff_cart_shapes = scenario("cpq_diff_cart_shapes")

.exec(session => session.set("PriceListId",Configuration.PriceListId))
.exec(session => session.set("password",credentials))
.exec(http("RESTGetOAuthToken")
  .post("https://login.salesforce.com/services/oauth2/token")
  .header("Content-Type", "application/x-www-form-urlencoded")
  .formParam("password", "${password}")
  .formParam("username", "perf-cmt-release-bmk@vlocity.com")
  .formParam("client_secret", "2847028618258912343")
  .formParam("client_id", "3MVG9KsVczVNcM8xeKy2xCeFKhU5cLqUWx_oOlMOvZw3mINnx7tqn7vQL3YFko0YLGC_k8FBSC.DVtC_g4GWH")
  .formParam("grant_type", "password")
  .check(regex("<access_token>(.+?)</access_token>").find.exists.saveAs("Token_ID"))
  .check(status.is(200)))

.repeat(20000)
{

  exec(session => session.set("AccountName",""))

  .exec( session => {
    val random_index = randomNumber.nextInt(100000)
    accountName.append("Acc-"+random_index)
    session
  })

  .exec(session => session.set("AccountName",accountName))

  .exec( session => {
    accountName = new StringBuilder()
    session
  })

  /* *********** CreateAccount *********** */
  .exec(http("CreateAccount")
    .post(uri10 +"/services/data/v44.0/sobjects/account")
    .headers(header_1)
    .check(regex(""""id":"(.*?)"""").find.exists.saveAs("AccountId"))
    .body( StringBody("""
    {
      "Name" : "${AccountName}",
      "ShippingCity" : "San Francisco",
      "RecordTypeId" : "0121U000000IuOgQAK",
      "vlocity_perf__Status__c"    : "Active"
    }""")).asJson)

  /* *********** CreateOrder *********** */
  .exec(http("Create a new order")
    .post(uri10 +"/services/apexrest/vlocity_perf/v2/carts")
    .headers(header_1)
    .check(regex(""""Id":"(.*?)"""").find.exists.saveAs("OrderID"))
    .body( StringBody("""{"subaction":"createOrder",
      "inputFields":[
      {"AccountId":"${AccountId}"},
      {"vlocity_perf__PriceListId__c":"${PriceListId}"},
      {"Name":"Bmk-Order"},{"Status":"Draft"},
      {"EffectiveDate":"2/2/2019"}
      ]}""")).asJson)

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  /* ********** SetPriceListForCart *********** */
/*  .exec(http("Set PriceList for the order")
    .put(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/")
    .headers(header_1)
    .body(StringBody("""{
      "inputFields": 
      [
      {
        "vlocity_perf__PriceListId__c": "${PriceListId}"
      }
      ],
      "cartId": "${OrderID}",
      "methodName": "updateCarts"
    }""")).asJson
    .check(regex(""""Id":"${OrderID}"""").find.exists)) */
    .feed(offerCountFeeder)
    .repeat("${OfferCount}") 
   // .repeat(7)
  {  

    /* ********** AddItemsToCart *********** */
    feed(product_feeder) 
    .exec(http("Add items to cart-${OfferCount}")
      .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items")
      .headers(header_1)
      .body( StringBody("""{
        "items":[{
          "itemId":"${ProductID}"
        }],
        "price":"true",
        "validate":"true",
        "pagesize":20
      }""")).asJson
      .check(regex("""INFO","message":"Successfully added.""").find.exists))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  }
.feed(offerCountFeeder)
.repeat (1) 
{
feed(product_feeder)
    .exec(http("Add items to cart-${OfferCount} + 3 ")
      .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items")
      .headers(header_1)
      .body( StringBody("""{
        "items":[{
          "itemId":"${ProductID}"
        }],
        "price":"true",
        "validate":"true",
        "pagesize":20
      }""")).asJson
      .check(regex("""INFO","message":"Successfully added.""").find.exists))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

}
  /* ********** GetCartLineItems_20LI_InCart *********** */
  .exec(http("Get list of cart line items.")
    .get(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items?pagesize=10&price=true&validate=true")
    .headers(header_1)
    .check(jsonPath("$.records[0].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem1"))
    .check(jsonPath("$.records[1].actions.updateitems.rest.params.items..itemId").find.saveAs("LineItem2")))

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  /* ********** DeleteItemFromCart********** */
/*  .exec(http("Delete an item from the cart. Cart has 20 line items")
    .delete(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items/${LineItem2}")
    .headers(header_1)
    .check(regex("""INFO","message":"Successfully deleted.""").find.exists)) 
  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds) */
    /* ********** AddItemsToCart *********** */
 /* .repeat(27)
  {


    feed(product_feeder) 
    .exec(http("Add items to cart-1")
      .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items")
      .headers(header_1)
      .body( StringBody("""{
        "items":[{
          "itemId":"${ProductID}"
        }],
        "price":"true",
        "validate":"true",
        "pagesize":20
      }""")).asJson
      .check(regex("""INFO","message":"Successfully added.""").find.exists))

    .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
    
  } */


.feed(offerCountFeeder)
.repeat (1) 
{
feed(product_feeder)
  /* ********** SubmitOrder ********** */ 
  .exec(http("Submit order - with 3*${OfferCount} lineitems")
    .post(uri10 +"/services/apexrest/vlocity_perf/v2/cpq/carts/${OrderID}/items/checkout")
    .headers(header_1)
    //.check(regex("""Account""").find.exists)
    .body( StringBody("""{
      "items":[
      {"itemId":"${LineItem1}"}
      ],
      "hierarchy":1,
      "lastItemId":"",
      "pagesize":20
    }""")).asJson) 

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
}
}
}
