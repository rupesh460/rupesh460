package CME

  import scala.concurrent.duration._
  import io.gatling.core.Predef._
  import io.gatling.core.structure.ChainBuilder
  import io.gatling.http.Predef._
  import io.gatling.jdbc.Predef._
  import io.gatling.jsonpath._
  import Headers._
  import scala.collection._
  import java.time.format.DateTimeFormatter
  import java.time.LocalDateTime
  import java.time.LocalDate
  import scala.util.Random
  import io.gatling.core.feeder._
  import java.util.Base64
  import java.nio.charset.StandardCharsets
  import scala.util.matching.Regex


object Benchmark_CME_Clone 
{

  val baseurl = Configuration.BaseUrl
  val uri01 = Configuration.Uri01
  val uri02 = Configuration.Uri02
  val uri05 = Configuration.Uri05
  val uri10 = Configuration.Uri10
  var CloneName = Configuration.CloneName
  val user_feeder = csv("./src/test/resources/data/cme/TestUsers.csv").random
  val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
  val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
  val password_v = (passwordByEnv.get("cme").toString)
  val password_encoded = password_v.substring(12,(password_v.length - 2 ))
  val credentials = new String(Base64.getDecoder.decode(password_encoded))

  val scn_Clone = scenario("scn_Clone")
    
    /* ***** LandingPage ****** */
      .exec(http("T001_LandingPage")
      .get(uri10 + "/")
      .check(regex("""<input type="hidden" name="QCQQ" value="(.*?)" \/>""").find.exists.saveAs("QCQQID"))
      .headers(headers_0))
        
      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(session => session.set("password",credentials))
  
    /* ****** Login Page ******** */ 
      .feed(user_feeder)
      .exec(http("T002_Login")
      .post(uri10 + "/")
      .headers(headers_18)
      .formParam("un", "${p_username}")
      .formParam("width", "1440")
      .formParam("height", "900")
      .formParam("hasRememberUn", "true")
      .formParam("startURL", "")
      .formParam("loginURL", "")
      .formParam("loginType", "")
      .formParam("useSecure", "true")
      .formParam("local", "")
      .formParam("lt", "standard")
      .formParam("qs", "r=https%3A%2F%2Fna136.salesforce.com%2F")
      .formParam("locale", "")
      .formParam("oauth_token", "")
      .formParam("oauth_callback", "")
      .formParam("login", "")
      .formParam("serverid", "")
      .formParam("QCQQ", "${QCQQID}")
      .formParam("display", "page")
      .formParam("username", "${p_username}")
      .formParam("ExtraLog", "%5B%7B%22width%22:1440%7D,%7B%22height%22:900%7D,%7B%22language%22:%22en-GB%22%7D,%7B%22offset%22:-5.5%7D,%7B%22scripts%22:%5B%7B%22size%22:249,%22summary%22:%22if%20(self%20==%20top)%20%7Bdocument.documentElement.style.v%22%7D,%7B%22size%22:528,%22summary%22:%22var%20SFDCSessionVars=%7B%5C%22server%5C%22:%5C%22https:%5C%5C/%5C%5C/login.sal%22%7D,%7B%22url%22:%22https://login.salesforce.com/jslibrary/SfdcSessionBase208.js%22%7D,%7B%22url%22:%22https://login.salesforce.com/jslibrary/LoginHint208.js%22%7D,%7B%22size%22:26,%22summary%22:%22LoginHint.hideLoginForm();%22%7D,%7B%22size%22:2626,%22summary%22:%22(function()%20%7B%5Cn%5Ct%5Ct%20%5Ct/*%5Cn%5Ct%5Ct%20%20%20%20function%20bindResponse(r%22%7D,%7B%22size%22:36,%22summary%22:%22LoginHint.getSavedIdentities(false);%22%7D,%7B%22url%22:%22https://login.salesforce.com/jslibrary/baselogin4.js%22%7D,%7B%22url%22:%22https://login.salesforce.com/jslibrary/LoginMarketingSurveyResponse.js%22%7D,%7B%22size%22:397,%22summary%22:%22function%20handleLogin()%7Bdocument.login.un.value=doc%22%7D%5D%7D,%7B%22scriptCount%22:10%7D,%7B%22iframes%22:%5B%22https://c.salesforce.com/login-messages/promos.html?r=https%253A%252F%252Fna136.salesforce.com%252F%22,%22https://login.salesforce.com/login/sessionserver212.html%22%5D%7D,%7B%22iframeCount%22:2%7D,%7B%22referrer%22:%22https://na136.salesforce.com/%22%7D%5D")
      .formParam("pw", "${password}")
      .formParam("Login", "Log In"))
      
    /* ***** HomePage ****** */
      .exec(http("T003_HomePage")
      .get("/home/home.jsp")
      .check(regex(""""Opportunity_Tab"><a href="(.*?)" title""").find.exists.saveAs("OptyTabId"))
      .check(regex("""linkToken=(.+?)&""").find.exists.saveAs("TokenID"))
      .headers(headers_36))

      .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  .repeat(1)
  {
      pace(90 seconds)

    /* ****** Opportunity Tab Page ******** */
      .exec(http("T004_SelectOppTab")
      .get("${OptyTabId}")
      .check(regex("""<th scope="row" class=" dataCell  "><a href="\/(.*?)">""").findRandom.exists.saveAs("OppID"))
      .headers(headers_49))
      
    /* ****** Selected Opportunity Page ******** */ 
      .exec(http("T005_SelectPerfOPTY")
      .get("/${OppID}")
      .check(regex("""amp;accid=(.*?)"""").find.exists.saveAs("dataid"))
      .headers(headers_49))

    /* ****** Click Multi-ServicePoint Button ******** */
      .exec(http("T006_SELECTMSP")
      .get(uri02 + "/apex/MultiServiceConfiguration?scontrolCaching=1&id=${OppID}")// 0064T000001f1Id 0064T000001f1Id
      .check(regex("""id=(.*?)&""").find.exists.saveAs("ID1"))
      .check(regex("""parentId=(.*?)&""").find.exists.saveAs("parentIdID"))
      .check(regex("""vf":\{"vid":"(.*?)"""").find.exists.saveAs("vid"))
      .headers(headers_90))
      
      .exec(http("T006_OMScript")
      .get(uri02 + "/apex/apex/OmniScriptUniversalPage?id=${ID1}&parentId=${parentIdID}&layout=lightning")//${OppID}
      .check(regex(""""name":"BuildJSONWithPrefillV2","len":6,"ns":"vlocity_cmt","ver":38\.0,"csrf":"(.*?)"""").find.exists.saveAs("CSRF1"))
      .check(regex(""""name":"GenericInvoke2","len":4,"ns":"vlocity_cmt","ver":38\.0,"csrf":"(.*?)"""").find.exists.saveAs("GetDetail_Csrf"))
      .check(regex(""""name":"getCustomLabels","len":2,"ns":"vlocity_cmt","ver":38\.0,"csrf":"(.*?)"""").find.exists.saveAs("gCL_Csrf"))
      .headers(headers_91))


      .exec(http("T006_BuildJSONWithPrefillV2")
      .post(uri02 + "/apexremote")
      .headers(headers_104)     
      .body(ElFileBody("./src/test/resources/bodies/CME/first/0104_request.json")))
      //.body(StringBody("""{"action":"vlocity_cmt.BusinessProcessDisplayController","method":"BuildJSONWithPrefillV2","data":["MultiService","CPQConfiguration","English","","{\"Id\":\"${ID}\"}",null],"type":"rpc","tid":2,"ctx":{"csrf":"${BJson_Csrf}","vid":"0664T000000TiUg","ns":"vlocity_cmt","ver":38}}""")).asJson,
            
           .exec(http("T006_GenericInvoke2_getFilterFieldList")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/first/0106_request.json")))
      //.body(StringBody("""{"action":"vlocity_cmt.BusinessProcessDisplayController","method":"GenericInvoke2","data":["vlocity_cmt.MultiServiceAppHandler","getDisplayFieldList","{}","{}"],"type":"rpc","tid":3,"ctx":{"csrf":"${GetDetail_Csrf}","vid":"0664T000000TiUg","ns":"vlocity_cmt","ver":38}}""")).asJson,
           
           .exec(http("T006_GenericInvoke2_getDisplayFieldList")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/first/0107_request.json")))
      //.body(StringBody(""""{"action":"vlocity_cmt.BusinessProcessDisplayController","method":"GenericInvoke2","data":["vlocity_cmt.MultiServiceAppHandler","getFilterFieldList","{}","{}"],"type":"rpc","tid":4,"ctx":{"csrf":"${GetDetail_Csrf}","vid":"0664T000000TiUg","ns":"vlocity_cmt","ver":38}}""")).asJson,
            
            .exec(http("T006_GenericInvoke2_getMasterQuotes")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/first/0108_request.json"))
      .check(regex(""""Id\\":\\"(.*?)\\"""").findRandom.exists.saveAs("ContextID")))
      //.body(StringBody("""{"action":"vlocity_cmt.BusinessProcessDisplayController","method":"GenericInvoke2","data":["vlocity_cmt.MultiServiceAppHandler","getMasterQuotes","{\"parentId\":\"${parentIdID}\"}","{}"],"type":"rpc","tid":5,"ctx":{"csrf":"${GetDetail_Csrf}","vid":"0664T000000TiUg","ns":"vlocity_cmt","ver":38}}""")).asJson,

          .exec(http("T006_GenericInvoke2_getObjectFieldsDescribe")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/first/0109_request.json")))
      //.body(StringBody("""{"action":"vlocity_cmt.BusinessProcessDisplayController","method":"GenericInvoke2","data":["vlocity_cmt.MultiServiceAppHandler","getObjectFieldsDescribe","{\"objectNames\":[\"vlocity_cmt__ServicePoint__c\"]}","{}"],"type":"rpc","tid":6,"ctx":{"csrf":"${GetDetail_Csrf}","vid":"0664T000000TiUg","ns":"vlocity_cmt","ver":38}}""")).asJson))
   .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("T007_SelectOneOpty_GenericInvoke2_getGroups")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/first/0110_request.json")))
      


      //.body(StringBody("""{"action":"vlocity_cmt.BusinessProcessDisplayController","method":"GenericInvoke2","data":["vlocity_cmt.MultiServiceAppHandler","getUnGroupedServices","{\"parentId\":\"${parentIdID}\",\"contextId\":\"${ContextID}\",\"offset\":0,\"pageSize\":30}","{}"],"type":"rpc","tid":7,"ctx":{"csrf":"${GetDetail_Csrf}","vid":"0664T000000TiUg","ns":"vlocity_cmt","ver":38}}""")).asJson //${ContextID}
      .exec(http("T007_SelectOneOpty_GenericInvoke2_getUnGroupedServices")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/first/0111_request.json"))
      .check(regex("""\{\\"messages\\":\[\],\\"displaySequence\\":-1,\\"Id\\":\{\\"value\\":\\"(.*?)\\"""").find(0).exists.saveAs("Identifier_1"))
        .check(regex("""\{\\"messages\\":\[\],\\"displaySequence\\":-1,\\"Id\\":\{\\"value\\":\\"(.*?)\\"""").find(1).exists.saveAs("Identifier_2")))
    
  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .feed(CloneName)
    .exec(http("T008_Clone_GenericInvoke2_cloneMasterQuote")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/first/0113_request.json")))
    
     .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
      //.body(StringBody("""{"action":"vlocity_cmt.BusinessProcessDisplayController","method":"GenericInvoke2","data":["vlocity_cmt.MultiServiceAppHandler","cloneMasterQuote","{\"parentId\":\"${parentIdID}\",\"masterQuoteId\":\"${ContextID}\",\"name\":\"Clone - PerfQuote_02\"}","{}"],"type":"rpc","tid":9,"ctx":{"csrf":"${GetDetail_Csrf}","vid":"0664T000000TiUg","ns":"vlocity_cmt","ver":38}}""")).asJson
      .exec(http("T008_Clone_getCustomLabels")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/first/0112_request.json")))
      //.body(StringBody("""{"action":"vlocity_cmt.BusinessProcessDisplayController","method":"getCustomLabels","data":[["Info","Close"],null],"type":"rpc","tid":10,"ctx":{"csrf":"${gCL_Csrf}","vid":"0664T000000TiUg","ns":"vlocity_cmt","ver":38}}""")).asJson,
            .exec(http("T008_Clone_GenericInvoke2_getMasterQuotes")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/first/0114_request.json")))
      //.body(StringBody("""{"action":"vlocity_cmt.BusinessProcessDisplayController","method":"GenericInvoke2","data":["vlocity_cmt.MultiServiceAppHandler","getMasterQuotes","{\"parentId\":\"${parentIdID}\"}","{}"],"type":"rpc","tid":11,"ctx":{"csrf":"${GetDetail_Csrf}","vid":"0664T000000TiUg","ns":"vlocity_cmt","ver":38}}""")).asJson))*/
}
}
   