package CME

  import scala.concurrent.duration._
  import io.gatling.core.Predef._
  import io.gatling.core.structure.ChainBuilder
  import io.gatling.http.Predef._
  import io.gatling.jdbc.Predef._
  import io.gatling.jsonpath._
  import Headers._
  import scala.collection._
  import java.time.format.DateTimeFormatter
  import java.time.LocalDateTime
  import java.time.LocalDate
  import scala.util.Random
  import io.gatling.core.feeder._
  import java.util.Base64
  import java.nio.charset.StandardCharsets
  import scala.util.matching.Regex


object Benchmark_CME_Checkout {

  val uri01 = Configuration.Uri01
  val uri02 = Configuration.Uri02
  val uri05 = Configuration.Uri05
  val uri10 = Configuration.Uri10
  var GroupName = Configuration.GroupName
  val user_feeder = csv("./src/test/resources/data/CME/TestUsers.csv").random

  val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
  val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
  val password_v = (passwordByEnv.get("cme").toString)
  val password_encoded = password_v.substring(12,(password_v.length - 2 ))
  val credentials = new String(Base64.getDecoder.decode(password_encoded))

  val checkout = scenario("checkout")
    
   .exec(http("T001_LandingPage")
      .get(uri10 + "/")
      .check(regex("""<input type="hidden" name="QCQQ" value="(.*?)" \/>""").find.exists.saveAs("QCQQID"))
      .headers(headers_0))
      
  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

  .exec(session => session.set("password",credentials))

/* ****** Login page ******** */ 
    .feed(user_feeder)
    .exec(http("T002_Login")
      .post(uri10 + "/")
      .headers(headers_18)
      .formParam("un", "${p_username}")
      .formParam("width", "1440")
      .formParam("height", "900")
      .formParam("hasRememberUn", "true")
      .formParam("startURL", "")
      .formParam("loginURL", "")
      .formParam("loginType", "")
      .formParam("useSecure", "true")
      .formParam("local", "")
      .formParam("lt", "standard")
      .formParam("qs", "r=https%3A%2F%2Fna136.salesforce.com%2F")
      .formParam("locale", "")
      .formParam("oauth_token", "")
      .formParam("oauth_callback", "")
      .formParam("login", "")
      .formParam("serverid", "")
      .formParam("QCQQ", "${QCQQID}")
      .formParam("display", "page")
      .formParam("username", "${p_username}")
      .formParam("ExtraLog", "%5B%7B%22width%22:1440%7D,%7B%22height%22:900%7D,%7B%22language%22:%22en-GB%22%7D,%7B%22offset%22:-5.5%7D,%7B%22scripts%22:%5B%7B%22size%22:249,%22summary%22:%22if%20(self%20==%20top)%20%7Bdocument.documentElement.style.v%22%7D,%7B%22size%22:528,%22summary%22:%22var%20SFDCSessionVars=%7B%5C%22server%5C%22:%5C%22https:%5C%5C/%5C%5C/login.sal%22%7D,%7B%22url%22:%22https://login.salesforce.com/jslibrary/SfdcSessionBase208.js%22%7D,%7B%22url%22:%22https://login.salesforce.com/jslibrary/LoginHint208.js%22%7D,%7B%22size%22:26,%22summary%22:%22LoginHint.hideLoginForm();%22%7D,%7B%22size%22:2626,%22summary%22:%22(function()%20%7B%5Cn%5Ct%5Ct%20%5Ct/*%5Cn%5Ct%5Ct%20%20%20%20function%20bindResponse(r%22%7D,%7B%22size%22:36,%22summary%22:%22LoginHint.getSavedIdentities(false);%22%7D,%7B%22url%22:%22https://login.salesforce.com/jslibrary/baselogin4.js%22%7D,%7B%22url%22:%22https://login.salesforce.com/jslibrary/LoginMarketingSurveyResponse.js%22%7D,%7B%22size%22:397,%22summary%22:%22function%20handleLogin()%7Bdocument.login.un.value=doc%22%7D%5D%7D,%7B%22scriptCount%22:10%7D,%7B%22iframes%22:%5B%22https://c.salesforce.com/login-messages/promos.html?r=https%253A%252F%252Fna136.salesforce.com%252F%22,%22https://login.salesforce.com/login/sessionserver212.html%22%5D%7D,%7B%22iframeCount%22:2%7D,%7B%22referrer%22:%22https://na136.salesforce.com/%22%7D%5D")
      .formParam("pw", "${password}")
      .formParam("Login", "Log In"))
      


            /* ***** HomePage ****** */
            .exec(http("T003_HomePage")
      .get("/home/home.jsp")
      .check(regex(""""Opportunity_Tab"><a href="(.*?)"""").find.exists.saveAs("OptyTabId"))
      .check(regex("""linkToken=(.+?)&""").find.exists.saveAs("TokenID"))
      //.check(regex("""linkToken=(.+?)&""").find.exists.saveAs("TokenID"))
      .headers(headers_36))

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)        
    
       /* ****** Home page ******** */ 
  
        .repeat(1)
{
pace(90 seconds)
    
    .exec(http("T004_SelectOppTab")
      .get("${OptyTabId}")
      .check(regex("""<th scope="row" class=" dataCell  "><a href="\/(.*?)">""").findRandom.exists.saveAs("OppID"))
      .headers(headers_49))

      
/* ****** Oppturnity page ******** */ 

.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
            .exec(http("T005_SelectPerfOPTY")
      .get("/${OppID}")
            .check(regex("""amp;accid=(.*?)"""").find.exists.saveAs("dataid"))
      .headers(headers_49))


           
  /* ****** Selected Oppturnity page ******** */  



    .exec(http("T006_SELECTMSP")
      .get(uri02 + "/apex/MultiServiceConfiguration?scontrolCaching=1&id=${OppID}")// 0064T000001f1Id 0064T000001f1Id
      .check(regex("""id=(.*?)&""").find.exists.saveAs("ID1"))
        .check(regex("""parentId=(.*?)&""").find.exists.saveAs("parentIdID"))
        .check(regex("""vf":\{"vid":"(.*?)"""").find.exists.saveAs("vid"))

            .headers(headers_90))
      
      .exec(http("T006_SELECTMSP_OMScript")
      .get(uri02 + "/apex/apex/OmniScriptUniversalPage?id=${ID1}&parentId=${parentIdID}&layout=lightning")//${OppID}
      .check(regex(""""name":"BuildJSONWithPrefillV2","len":6,"ns":"vlocity_cmt","ver":38\.0,"csrf":"(.*?)"""").find.exists.saveAs("CSRF1"))
      .check(regex(""""name":"GenericInvoke2","len":4,"ns":"vlocity_cmt","ver":38\.0,"csrf":"(.*?)"""").find.exists.saveAs("GetDetail_Csrf"))
      .check(regex(""""name":"getCustomLabels","len":2,"ns":"vlocity_cmt","ver":38\.0,"csrf":"(.*?)"""").find.exists.saveAs("gCL_Csrf"))
      .headers(headers_91))


           .exec(http("T006_SELECTMSP_BuildJSONWithPrefillV2")
      .post(uri02 + "/apexremote")
      .headers(headers_104)     
      .body(ElFileBody("./src/test/resources/bodies/CME/first/0104_request.json")))
      //.body(StringBody("""{"action":"vlocity_cmt.BusinessProcessDisplayController","method":"BuildJSONWithPrefillV2","data":["MultiService","CPQConfiguration","English","","{\"Id\":\"${ID}\"}",null],"type":"rpc","tid":2,"ctx":{"csrf":"${BJson_Csrf}","vid":"0664T000000TiUg","ns":"vlocity_cmt","ver":38}}""")).asJson,
            
           .exec(http("T006_SELECTMSP_GenericInvoke2_getFilterFieldList")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/first/0106_request.json")))
      //.body(StringBody("""{"action":"vlocity_cmt.BusinessProcessDisplayController","method":"GenericInvoke2","data":["vlocity_cmt.MultiServiceAppHandler","getDisplayFieldList","{}","{}"],"type":"rpc","tid":3,"ctx":{"csrf":"${GetDetail_Csrf}","vid":"0664T000000TiUg","ns":"vlocity_cmt","ver":38}}""")).asJson,
           
           .exec(http("T006_SELECTMSP_GenericInvoke2_getDisplayFieldList")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/first/0107_request.json")))
      //.body(StringBody(""""{"action":"vlocity_cmt.BusinessProcessDisplayController","method":"GenericInvoke2","data":["vlocity_cmt.MultiServiceAppHandler","getFilterFieldList","{}","{}"],"type":"rpc","tid":4,"ctx":{"csrf":"${GetDetail_Csrf}","vid":"0664T000000TiUg","ns":"vlocity_cmt","ver":38}}""")).asJson,
            
            .exec(http("T006_SELECTMSP_GenericInvoke2_getMasterQuotes")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/first/0108_request.json"))
      .check(regex(""""Id\\":\\"(.*?)\\"""").findRandom.exists.saveAs("ContextID")))
      //.body(StringBody("""{"action":"vlocity_cmt.BusinessProcessDisplayController","method":"GenericInvoke2","data":["vlocity_cmt.MultiServiceAppHandler","getMasterQuotes","{\"parentId\":\"${parentIdID}\"}","{}"],"type":"rpc","tid":5,"ctx":{"csrf":"${GetDetail_Csrf}","vid":"0664T000000TiUg","ns":"vlocity_cmt","ver":38}}""")).asJson,

          .exec(http("T006_SELECTMSP_GenericInvoke2_getObjectFieldsDescribe")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/first/0109_request.json")))
      //.body(StringBody("""{"action":"vlocity_cmt.BusinessProcessDisplayController","method":"GenericInvoke2","data":["vlocity_cmt.MultiServiceAppHandler","getObjectFieldsDescribe","{\"objectNames\":[\"vlocity_cmt__ServicePoint__c\"]}","{}"],"type":"rpc","tid":6,"ctx":{"csrf":"${GetDetail_Csrf}","vid":"0664T000000TiUg","ns":"vlocity_cmt","ver":38}}""")).asJson))
.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("T007_SelectOneOpty_GenericInvoke2_getGroups")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/first/0110_request.json")))
      


      //.body(StringBody("""{"action":"vlocity_cmt.BusinessProcessDisplayController","method":"GenericInvoke2","data":["vlocity_cmt.MultiServiceAppHandler","getUnGroupedServices","{\"parentId\":\"${parentIdID}\",\"contextId\":\"${ContextID}\",\"offset\":0,\"pageSize\":30}","{}"],"type":"rpc","tid":7,"ctx":{"csrf":"${GetDetail_Csrf}","vid":"0664T000000TiUg","ns":"vlocity_cmt","ver":38}}""")).asJson //${ContextID}
      .exec(http("T007_SelectOneOpty_GenericInvoke2_getUnGroupedServices")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/first/0111_request.json"))
      .check(regex("""\{\\"messages\\":\[\],\\"displaySequence\\":-1,\\"Id\\":\{\\"value\\":\\"(.*?)\\"""").find(0).exists.saveAs("Identifier_1"))
        .check(regex("""\{\\"messages\\":\[\],\\"displaySequence\\":-1,\\"Id\\":\{\\"value\\":\\"(.*?)\\"""").find(1).exists.saveAs("Identifier_2")))

         .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)



         .feed(GroupName)
    .exec(http("T008_Addtogroup_createNewGroup")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/addtogroup/0110_request.json"))
      .check(regex(""""groupId\\"\:\\"(.*?)\\"""").find.exists.saveAs("groupId"))
      .check(regex("""id=(.*?)&""").find.exists.saveAs("ID"))
      .check(regex(""""groupCartId\\"\:\\"(.*?)\\"""").find.exists.saveAs("groupCartId")))


      .exec(http("T008_Addtogroup_getCustomLabels")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/addtogroup/0109_request.json")))
            
            .exec(http("T008_Addtogroup_GenericInvoke2")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/addtogroup/0111_request.json")))
           
           .exec(http("T008_Addtogroup_GenericInvoke2_getUnGroupedServices")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/addtogroup/0112_request.json")))
            
            .exec(http("T008_Addtogroup_GenericInvoke2_getGroups")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/addtogroup/0113_request.json")))

       /* ****** Go to Next ******** */ 
.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("T009_GoNext")
      .get(uri02 + "/apex/apex/apex/MultiServiceCPQRedirect?contextId=${ContextID}&parentId=${parentIdID}&redirectToFirstGroup=true&groupPageSize=20&groupedServicePageSize=20")
      .headers(headers_80))
      
      .exec(http("T009_GoNext_MultiServiceHybridCPQ")
      .get(uri02 + "/apex/MultiServiceHybridCPQ?applyToGroup=false&contextId=${ContextID}&groupCart=true&groupCartId=null&groupedServicePageSize=20&groupPageSize=20&id=${ID}&parentId=${parentIdID}&priceValidate=false")
      .check(regex("""var sessionId = '(.*?)'""").find.exists.saveAs("Oauth"))
      .check(regex("""\{"name":"getActiveTemplateNames","len":0,"ns":"vlocity_cmt","ver":41\.0,"csrf":"(.*?)"\}""").find.exists.saveAs("getActiveTemplateNames"))
      .check(regex("""\{"name":"getUserProfile","len":0,"ns":"vlocity_cmt","ver":41\.0,"csrf":"(.*?)"\}""").find.exists.saveAs("getUserProfile"))
      .check(regex("""\{"name":"getCustomPermissionsForUser","len":0,"ns":"vlocity_cmt","ver":41\.0,"csrf":"(.*?)"\}""").find.exists.saveAs("getCustomPermissionsForUser"))
      .check(regex("""\{"name":"getCustomSettings","len":1,"ns":"vlocity_cmt","ver":41\.0,"csrf":"(.*?)"\}""").find.exists.saveAs("getCustomSettings"))
      .check(regex("""\{"name":"getCustomLabels","len":2,"ns":"vlocity_cmt","ver":41\.0,"csrf":"(.*?)"\}""").find.exists.saveAs("getCustomLabels"))
      .check(regex("""\{"name":"doGenericInvoke","len":4,"ns":"vlocity_cmt","ver":41\.0,"csrf":"(.*?)"\}""").find.exists.saveAs("doGenericInvoke"))
      .check(regex("""\{"name":"getActionDetailsByName","len":5,"ns":"vlocity_cmt","ver":41\.0,"csrf":"(.*?)"\}""").find.exists.saveAs("getActionDetailsByName"))
      .headers(headers_80))
    
    .pause(1)
    
    .exec(http("T009_GoNext_getActiveTemplateNames")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0109_request.json")))

      .exec(http("T009_GoNext_getCustomSettings_1")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0110_request.json")))

            .exec(http("T009_GoNext_getCustomPermissionsForUser")
      .post("/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0111_request.json")))

            .exec(http("T009_GoNext_getUserProfile")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0112_request.json")))

            .exec(http("T009_GoNext_1")
      .post(uri02 + "/cometd/41.0/")
      .headers(headers_113)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0113_request.json")))

            .exec(http("T009_GoNext_getCustomSettings_2")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0114_request.json")))

            .exec(http("T009_GoNext_getCustomSettings_3")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0115_request.json")))
            
            .exec(http("T009_GoNext_getCustomLabels_1")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0116_request.json")))

            .exec(http("T009_GoNext_doGenericInvoke_getCustomSettings_1")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0117_request.json")))

            .exec(http("T009_GoNext_getCustomSettings_4")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0118_request.json")))
            
        
            .exec(http("T009_GoNext_doGenericInvoke_getCartsItems")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0121_request.json")))
            
            .exec(http("T009_GoNext_doGenericInvoke_getCarts_1")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0122_request.json")))

            .exec(http("T009_GoNext_doGenericInvoke_getCartsTargetOffers")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0123_request.json")))

            .exec(http("T009_GoNext_doGenericInvoke_getGroups")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0124_request.json")))

            .exec(http("T009_GoNext_doGenericInvoke_getCartsProducts")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0125_request.json")))

            .exec(http("T009_GoNext_doGenericInvoke_getCustomSettings_2")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0126_request.json")))

            .exec(http("T009_GoNext_doGenericInvoke_getCarts_2")
      .post("/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0127_request.json")))

            
            .exec(http("T009_GoNext_doGenericInvoke_getCartsPromotions")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0129_request.json")))

            .exec(http("T009_GoNext_doGenericInvoke_getCustomSettings_3")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0130_request.json")))

            .exec(http("T009_GoNext_doGenericInvoke_getCartsDiscounts")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0131_request.json")))

            .exec(http("T009_GoNext_doGenericInvoke_getCustomSettings_4")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0132_request.json")))

            .exec(http("T009_GoNext_doGenericInvoke_getCustomSettings_5")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0133_request.json")))

            .exec(http("T009_GoNext_2")
      .post(uri02 + "/cometd/41.0/")
      .headers(headers_113)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0134_request.json")))

            .exec(http("T009_GoNext_getCustomLabels_2")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0135_request.json")))

            
            .exec(http("T009_GoNext_getCustomLabels_3")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0137_request.json")))

            .exec(http("T009_GoNext_getCustomLabels_4")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0138_request.json")))

            .exec(http("T009_GoNext_doGenericInvoke_getPriceLists")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0139_request.json"))
      .check(regex("""\\"displaySequence\\":-1,\\"Id\\":\\"(.*?)\\""").find.exists.saveAs("PriceListId")))
            
            .exec(http("T009_GoNext_getCustomLabels_5")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0141_request.json")))

            .exec(http("T009_GoNext_3")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0142_request.json")))


           
            .exec(http("T009_GoNext_getCustomLabels_6")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0144_request.json")))
            

            .exec(http("T009_GoNext_getCustomLabels_7")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0146_request.json")))

            .exec(http("T009_GoNext_getCustomLabels_8")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0147_request.json")))

            .exec(http("T009_GoNext_doGenericInvoke_getCustomSettings_6")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0148_request.json")))

            .exec(http("T009_GoNext_getCustomLabels_9")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0149_request.json")))

            .exec(http("T009_GoNext_getCustomLabels_10")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0150_request.json")))

            .exec(http("T009_GoNext_getCustomLabels_11")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0151_request.json")))

            .exec(http("T009_GoNext_getCustomLabels_12")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0152_request.json")))

   .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    /* ****** Add Pricelist ******** */ 
    
    .exec(http("T010_Add_Pricelist_doGenericInvoke_updateCarts")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0153_request.json")))

      .exec(http("T010_Add_Pricelist_doGenericInvoke_getCartsTargetOffers")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0154_request.json")))

            .exec(http("T010_Add_Pricelist_doGenericInvoke_getCartsItems")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0155_request.json")))

            .exec(http("T010_Add_Pricelist_doGenericInvoke_getCartsPromotions")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0156_request.json")))

            .exec(http("T010_Add_Pricelist_doGenericInvoke_getCartsProducts")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0157_request.json"))
      .check(regex(""""postCartsItems\\",\\"items\\":\[\{\\"itemId\\":\\"(.*?)\\""").find.exists.saveAs("postCartsItemsitemId")))

            .exec(http("T010_Add_Pricelist_doGenericInvoke_getCarts")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0158_request.json")))
           
           .exec(http("T010_Add_Pricelist_doGenericInvoke_getCartsDiscounts")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0159_request.json")))
    
   .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)
    

    /* ****** AddToCart ******** */ 

    .exec(http("T011_AddToCart_getCustomLabels")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0160_request.json")))

      .exec(http("T011_AddToCart_doGenericInvoke_postCartsItems")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0161_request.json")))
            
            .exec(http("T011_AddToCart_doGenericInvoke_getCartLineItemPrices")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0162_request.json")))

            .exec(http("T011_AddToCart_doGenericInvoke_getCarts")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0163_request.json")))
            
    
      /* ****** ApplyToGroup ******** */ 

  .pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

    .exec(http("T012_ApplyToGroup_getActionDetailsByName")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0165_request.json")))

      .exec(http("T012_ApplyToGroup_OmniScript")
      .get(uri02 + "/apex/vlocity_cmt__OmniScriptUniversalPage?groupCartId=${groupCartId}&parentId=${parentIdID}&groupId=${groupId}&layout=lightning&contextId=${ContextID}&groupPageSize=20&groupedServicePageSize=20&trackKey=1571293583278")
      .headers(headers_166))
            
            
            .exec(http("T012_ApplyToGroup_BuildJSONWithPrefillV2")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0179_request.json"))
      .check(regex("""\\"timeStamp\\":\\"(.*?)\\""").find.exists.saveAs("timeStamp"))
      .check(regex("""\\"userId\\":\\"(.*?)\\"""").find.exists.saveAs("userId"))
      .check(regex("""\\"userName\\":\\"(.*?)\\"""").find.exists.saveAs("userName"))
      .check(regex("""\\"userProfile\\":\\"(.*?)\\"""").find.exists.saveAs("userProfile"))
      .check(regex("""\\"userTimeZone\\":(.*?),""").find.exists.saveAs("userTimeZone"))
      .check(regex("""\\"userCurrencyCode\\":\\"(.*?)\\"""").find.exists.saveAs("userCurrencyCode")))


            .exec(http("T012_ApplyToGroup_GenericInvoke2")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0180_request.json")))

            .exec(http("T012_ApplyToGroup_MultiServiceCPQRedirect")
      .get(uri02 + "/apex/apex/MultiServiceCPQRedirect?id=${ID}&contextId=${ContextID}&parentId=${parentIdID}&groupCart=true&applyToGroup=true&groupPageSize=20&groupedServicePageSize=20")
      .headers(headers_166))


            .exec(http("T012_ApplyToGroup_MultiServiceHybridCPQ")
      .get(uri02 + "/apex/MultiServiceHybridCPQ?applyToGroup=true&contextId=${ContextID}&groupCart=true&groupCartId=null&groupedServicePageSize=20&groupPageSize=20&id=${ID}&parentId=${parentIdID}&priceValidate=false")
      .headers(headers_166))

            
            .exec(http("T012_ApplyToGroup_getCustomPermissionsForUser")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0189_request.json")))

            .exec(http("T012_ApplyToGroup_getCustomSettings")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0190_request.json")))

            .exec(http("T012_ApplyToGroup_getActiveTemplateNames")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0191_request.json")))

            .exec(http("T012_ApplyToGroup_getUserProfile")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0192_request.json")))

            .exec(http("T012_ApplyToGroup_getCustomSettings_1")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0193_request.json")))

            .exec(http("T012_ApplyToGroup_getCustomSettings_2")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0194_request.json")))

            .exec(http("T012_ApplyToGroup_1")
      .post(uri02 + "/cometd/41.0/")
      .headers(headers_113)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0195_request.json")) //"clientId":"(.*?)","
            .check(regex(""""clientId":"(.*?)",""").find.exists.saveAs("clientId")))


            .exec(http("T012_ApplyToGroup_getCustomSettings_3")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0196_request.json")))

            .exec(http("T012_ApplyToGroup_getCustomLabels_1")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0197_request.json")))

            .exec(http("T012_ApplyToGroup_doGenericInvoke_getCustomSettings_1")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0198_request.json")))
            
            .exec(http("T012_ApplyToGroup_doGenericInvoke_getCarts_1")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0201_request.json")))

            .exec(http("T012_ApplyToGroup_doGenericInvoke_getGroups")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0202_request.json")))

            .exec(http("T012_ApplyToGroup_doGenericInvoke_getCartsTargetOffers")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0203_request.json")))

            .exec(http("T012_ApplyToGroup_doGenericInvoke_getCartsItems")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0204_request.json")))

            .exec(http("T012_ApplyToGroup_doGenericInvoke_getCartsProducts")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0205_request.json")))
            
           /* .exec(http("T012_ApplyToGroup_doGenericInvoke_getCustomSettings_2")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0207_request.json")))*/

            .exec(http("T012_ApplyToGroup_doGenericInvoke_getCarts_2")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0208_request.json")))

            
            .exec(http("T012_ApplyToGroup_doGenericInvoke_getCartsDiscounts")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0210_request.json")))

          /*  .exec(http("T012_ApplyToGroup_doGenericInvoke_getCustomSettings_3")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0211_request.json")))

            .exec(http("T012_ApplyToGroup_doGenericInvoke_getCustomSettings_4")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0212_request.json")))

            .exec(http("T012_ApplyToGroup_doGenericInvoke_getCustomSettings_5")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0213_request.json")))

            .exec(http("T012_ApplyToGroup_doGenericInvoke_getCustomSettings_6")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0214_request.json")))*/

            .exec(http("T012_ApplyToGroup_getCustomLabels_2")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0215_request.json")))

            .exec(http("T012_ApplyToGroup_2")
      .post(uri02 + "/cometd/41.0/")
      .headers(headers_113)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0216_request.json")))

            .exec(http("T012_ApplyToGroup_getCustomLabels_3")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0217_request.json")))

            .exec(http("T012_ApplyToGroup_getCustomLabels_4")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0218_request.json")))

            .exec(http("T012_ApplyToGroup_getCustomLabels_5")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0219_request.json")))

            .exec(http("T012_ApplyToGroup_getCustomLabels_6")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0220_request.json")))

            .exec(http("T012_ApplyToGroup_doGenericInvoke_getPriceLists")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0221_request.json")))

            .exec(http("T012_ApplyToGroup_getCustomLabels_7")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0222_request.json")))

            .exec(http("T012_ApplyToGroup_getCustomLabels_8")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0223_request.json")))

            
           /* .exec(http("T012_ApplyToGroup_getCustomLabels_9")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/applytogroup/0227_request.json")))*/

         /* ****** Price and Validate ******** */ 
.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("T013_P&V_getActionDetailsByName")
      .post(uri02 +"/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0000_request.json")))

      .exec(http("T013_P&V_OmniScript")
      .get(uri02 + "/apex/vlocity_cmt__OmniScriptUniversalPage?groupCartId}&parentId=${parentIdID}&groupId=${groupId}&layout=lightning&contextId=${ContextID}&groupPageSize=20&groupedServicePageSize=20&trackKey=1571293583278")
      .headers(headers_166))
           
           
           .exec(http("T013_P&V_BuildJSONWithPrefillV2")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0014_request.json"))
      .check(regex("""\\"timeStamp\\":\\"(.*?)\\""").find.exists.saveAs("timeStamp1"))
      .check(regex("""\\"userId\\":\\"(.*?)\\"""").find.exists.saveAs("userId1"))
      .check(regex("""\\"userName\\":\\"(.*?)\\"""").find.exists.saveAs("userName1"))
      .check(regex("""\\"userProfile\\":\\"(.*?)\\"""").find.exists.saveAs("userProfile1"))
      .check(regex("""\\"userTimeZone\\":(.*?),""").find.exists.saveAs("userTimeZone1"))
      .check(regex("""\\"userCurrencyCode\\":\\"(.*?)\\"""").find.exists.saveAs("userCurrencyCode1")))

            .exec(http("T013_P&V_GenericInvoke2")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0015_request.json")))
            
            .exec(http("T013_P&V_MultiServiceCPQRedirect")
      .get(uri02 + "/apex/apex/MultiServiceCPQRedirect?d=${ID}&contextId=${ContextID}&parentId=${parentIdID}&groupCart=true&applyToGroup=true&groupPageSize=20&groupedServicePageSize=20")
      .headers(headers_57))
            
            .exec(http("T013_P&V_MultiServiceHybridCPQ")
      .get(uri02 + "/apex/MultiServiceHybridCPQ?applyToGroup=true&contextId=${ContextID}&groupCart=true&groupCartId=null&groupedServicePageSize=20&groupPageSize=20&id=${ID}&parentId=${parentIdID}&priceValidate=false")
      .headers(headers_57))

            
            .exec(http("T013_P&V_getCustomSettings_1")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0023_request.json")))
            
            .exec(http("T013_P&V_getActiveTemplateNames")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0024_request.json")))

            .exec(http("T013_P&V_getCustomPermissionsForUser")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0025_request.json")))

            .exec(http("T013_P&V_getUserProfile")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0026_request.json")))

            .exec(http("T013_P&V_getCustomSettings_2")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0027_request.json")))

            .exec(http("T013_P&V_getCustomSettings_3")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0028_request.json")))

            .exec(http("T013_P&V_1")
      .post(uri02 + "/cometd/41.0/")
      .headers(headers_113)
      .check(regex(""""clientId":"(.*?)",""").find.exists.saveAs("clientId1"))
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0029_request.json")))

            .exec(http("T013_P&V_getCustomSettings_4")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0030_request.json")))

            
           
            .exec(http("T013_P&V_doGenericInvoke_getCustomSettings_1")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0032_request.json")))
            
           
           .exec(http("T013_P&V_doGenericInvoke_getGroups_1")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0034_request.json")))

            .exec(http("T013_P&V_doGenericInvoke_getCartsTargetOffers")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0035_request.json")))

            .exec(http("T013_P&V_doGenericInvoke_getCarts_1")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0036_request.json")))

            .exec(http("T013_P&V_doGenericInvoke_getCartsItems")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0037_request.json")))

            /*.exec(http("T013_P&V_doGenericInvoke_getCustomSettings_2")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0038_request.json")))*/

            .exec(http("T013_P&V_doGenericInvoke_getCartsProducts")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0039_request.json")))

            .exec(http("T013_P&V_doGenericInvoke_getCartsPromotions")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0040_request.json")))
            
            /*.exec(http("T013_P&V_doGenericInvoke_getCustomSettings_3")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0042_request.json")))*/

           
            .exec(http("T013_P&V_doGenericInvoke_getCartsDiscounts")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0044_request.json")))

           /* .exec(http("T013_P&V_doGenericInvoke_getCustomSettings_4")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0045_request.json")))*/

            .exec(http("T013_P&V_doGenericInvoke_getCarts_2")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0046_request.json")))

            /*.exec(http("T013_P&V_doGenericInvoke_getCustomSettings_5")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0047_request.json")))

            .exec(http("T013_P&V_doGenericInvoke_getCustomSettings_6")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0048_request.json")))*/

            .exec(http("T013_P&V_2")
      .post(uri02 + "/cometd/41.0/")
      .headers(headers_113)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0049_request.json"))
      .check(regex(""""clientId":"(.*?)",""").find.exists.saveAs("clientId2")))


            .exec(http("T013_P&V_getCustomLabels_1")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0050_request.json")))

            /*.exec(http("T013_P&V_getCustomLabels_2")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0051_request.json")))

            .exec(http("T013_P&V_getCustomLabels_3")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0052_request.json")))

            .exec(http("T013_P&V_getCustomLabels_4")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0053_request.json")))
            
            .exec(http("T013_P&V_getCustomLabels_5")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0054_request.json")))*/
            
            .exec(http("T013_P&V_doGenericInvoke_getPriceLists")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0056_request.json")))
            
            /*.exec(http("T013_P&V_getCustomLabels_6")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0057_request.json")))

            .exec(http("T013_P&V_getCustomLabels_7")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0058_request.json")))

            .exec(http("T013_P&V_getCustomLabels_8")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0059_request.json")))

            
            .exec(http("T013_P&V_getCustomLabels_9")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0061_request.json")))*/

            .exec(http("T013_P&V_getCustomLabels_10")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0062_request.json")))

            .exec(http("T013_P&V_getCustomLabels_11")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0063_request.json")))

            
            .exec(http("T013_P&V_getCustomLabels_12")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0066_request.json")))
            
            .exec(http("T013_P&V_getCustomLabels_13")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0067_request.json")))
           
           

            /*.exec(http("T013_P&V_doGenericInvoke_getGroups_2")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0069_request.json")))

          /*  .exec(http("T013_P&V_doGenericInvoke_getCarts_3")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0070_request.json")))*/

    .pause(2)
    

      .exec(http("T013_P&V_doGenericInvoke_getGroups_3")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0072_request.json")))*/

           /* .exec(http("T013_P&V_doGenericInvoke_getCarts_4")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0073_request.json")))*/

            .exec(http("T013_P&V_getCustomLabels_14")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("./src/test/resources/bodies/CME/pandv/0074_request.json")))


      /*  ********* Checkout **************** */
.pause(Configuration.MinWaitMs milliseconds, Configuration.MaxWaitMs milliseconds)

      .exec(http("T014_Checkout_getActionDetailsByName")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/checkout/0000_request.json"))
      .check(regex("""AccountId=(.*?)&layout=lightning""").find.exists.saveAs("AccountId")))




      .exec(http("T014_Checkout_Omniscript")
      .get(uri02 + "/apex/vlocity_cmt__OmniScriptUniversalPage?Id=${ID}&OpportunityId=${OppID}&GroupId=${groupId}&AccountId=${AccountId}&layout=lightning&contextId=${ContextID}&trackKey=1571654915546")
      .headers(headers_90))

      .exec(http("T014_Checkout_AccountID")
      .get(uri02 + "/${AccountId}")
      .headers(headers_15)
      .check(regex("""title="AssetConfiguration" width="100%"><\/iframe><form  accept-charset="UTF-8" action="https:\/\/vlocity-cmt\.na136\.visual\.force\.com\/servlet\/servlet\.Integration\?lid=(.*?)&""").find.exists.saveAs("C_lid"))
      .check(regex("""title="AssetConfiguration" width="100%"><\/iframe><form  accept-charset="UTF-8" action="https:\/\/vlocity-cmt\.na136\.visual\.force\.com\/servlet\/servlet\.Integration\?lid=.*&amp;ic=1&amp;linkToken=(.*?)"""").find.exists.saveAs("C_linkToken"))
      .check(regex("""title="AssetConfiguration" width="100%"><\/iframe><form  accept-charset="UTF-8" action="https:\/\/vlocity-cmt\.na136\.visual\.force\.com\/servlet\/servlet\.Integration\?lid=.*&amp;ic=1&amp;linkToken=.*" enctype="application\/x-www-form-urlencoded" id="echoScontrolForm_.*" method="post" name="echoScontrolForm_.*" target=".*" ><input type="hidden" name="echoScontrol" value="(.*?)" \/>""").find.exists.saveAs("C_echoScontrol"))
      .check(regex("""title="AssetConfiguration" width="100%"><\/iframe><form  accept-charset="UTF-8" action="https:\/\/vlocity-cmt\.na136\.visual\.force\.com\/servlet\/servlet\.Integration\?lid=.*&amp;ic=1&amp;linkToken=.*" enctype="application\/x-www-form-urlencoded" id="echoScontrolForm_.*" method="post" name="echoScontrolForm_.*" target=".*" ><input type="hidden" name="echoScontrol" value=".*" \/><input type="hidden" name="echoScontrolMac" value="(.*?)"""").find.exists.saveAs("C_echoScontrolMac")))


      .exec(http("T014_Checkout_Servlet")
      .post(uri02 + "/servlet/servlet.Integration?lid=${C_lid}&ic=1&linkToken=${C_linkToken}")
      .headers(headers_33)
      .formParam("echoScontrol", "${C_echoScontrol}")
      .formParam("echoScontrolMac", "${C_echoScontrolMac}")
      .check(regex(""""name":"getAssetList","len":3,"ns":"vlocity_cmt","ver":33.0,"csrf":"(.*?)"""").find.exists.saveAs("getAssetList")))

      .exec(http("T014_Checkout_BuildJSONWithPrefillV2")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/checkout/0013_request.json"))
      .check(regex("""\\"timeStamp\\":\\"(.*?)\\""").find.exists.saveAs("timeStamp2"))
      .check(regex("""\\"userId\\":\\"(.*?)\\"""").find.exists.saveAs("userId2"))
      .check(regex("""\\"userName\\":\\"(.*?)\\"""").find.exists.saveAs("userName2"))
      .check(regex("""\\"userProfile\\":\\"(.*?)\\"""").find.exists.saveAs("userProfile2"))
      .check(regex("""\\"userTimeZone\\":(.*?),""").find.exists.saveAs("userTimeZone2"))
      .check(regex("""\\"userCurrencyCode\\":\\"(.*?)\\"""").find.exists.saveAs("userCurrencyCode2")))

            

            .exec(http("T014_Checkout_GenericInvoke2")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/checkout/0059_request.json")))

      .exec(http("T014_Checkout_getAssetList")
      .post(uri02 + "/apexremote")
      .headers(headers_87)
      .body(ElFileBody("./src/test/resources/bodies/CME/checkout/0060_request.json")))

     }
}
   