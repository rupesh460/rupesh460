package CME

import java.time.format.DateTimeFormatter
import scala.util.Random
import scala.concurrent.duration.DurationInt
import java.time.LocalDate

object Configuration
 {
	val BaseUrl = "https://na136.salesforce.com"
	val Uri01 = "https://c.na136.content.force.com"
    val Uri02 = "https://vlocity-cmt.na136.visual.force.com"
    val Uri05 = "https://c.salesforce.com"
    val Uri10 = "https://login.salesforce.com"
	val MinWaitMs = 2000
	val MaxWaitMs = 3000
	var CloneName = Iterator.continually(Map("clonename" -> (Random.alphanumeric.take(7).mkString + "-Clone")))
	var GroupName = Iterator.continually(Map("grpname" -> (Random.alphanumeric.take(7).mkString + "PerfTest")))
	var Date = DateTimeFormatter.ofPattern("MM/dd/YYYY").format(java.time.LocalDate.now)
    var Oppty = Iterator.continually(Map("oppname" -> (Random.alphanumeric.take(4).mkString + "BOppty")))
    var QuoteName = Iterator.continually(Map("mbq" -> (Random.alphanumeric.take(5).mkString + "Quotes")))

}