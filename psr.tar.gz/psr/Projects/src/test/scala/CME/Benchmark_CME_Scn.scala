package CME

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._

class Benchmark_CME_Scn extends Simulation 
{


	val httpProtocol = http
		.baseUrl(Configuration.BaseUrl)
		.inferHtmlResources(BlackList(""".*\.js""", """.*\.css""", """.*\.gif""", """.*\.jpeg""", """.*\.jpg""", """.*\.ico""", """.*\.woff""", """.*\.woff2""", """.*\.(t|o)tf""", """.*\.png""", """.*detectportal\.firefox\.com.*"""), WhiteList())
		.userAgentHeader("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36")
		.acceptHeader("*/*")
		.acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8")
		.acceptEncodingHeader("gzip, deflate, sdch")
		.acceptLanguageHeader("en-US,en;q=0.8")
		.disableCaching
		.contentTypeHeader("application/x-www-form-urlencoded; charset=UTF-8")

	// //val httpConf = http
	// 	.baseUrl(Configuration.BaseUrl)
	// 	.inferHtmlResources(BlackList(""".*\.js""", """.*\.css""", """.*\.gif""", """.*\.jpeg""", """.*\.jpg""", """.*\.ico""", """.*\.woff""", """.*\.(t|o)tf""", """.*\.png"""), WhiteList())
	// 	.acceptHeader("*/*")
	// 	.acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8")
	// 	.acceptEncodingHeader("gzip, deflate, sdch")
	// 	.acceptLanguageHeader("en-US,en;q=0.8")
	// 	.disableCaching
	// 	.contentTypeHeader("application/x-www-form-urlencoded; charset=UTF-8")
	// 	.userAgentHeader("Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:41.0) Gecko/20100101 Firefox/41.0")

	val rampUpTimeSecs = Integer.getInteger("rampUpTimeSecs", 1)
	val users = Integer.getInteger("scn_Clone", 1)
	//val cpq_diff_cart_shapes_users = Integer.getInteger("cpq_diff_cart_shapes_users")
	val maxDurationSecs = Integer.getInteger("maxDurationSecs", 1)
	val testDuration = Integer.getInteger("testDuration",1)

	setUp(//Benchmark_CME_Clone.scn_Clone.inject(rampUsers(users) during (rampUpTimeSecs seconds)).protocols(httpProtocol)).maxDuration(maxDurationSecs)
	//Benchmark_CME_GenerateOpportunity.opportunity.inject(rampUsers(users) during (rampUpTimeSecs seconds)).protocols(httpProtocol)).maxDuration(maxDurationSecs)


	   //Benchmark_CME_ApplyFilter.applyFilter.inject(rampUsers(users) during (rampUpTimeSecs seconds)).protocols(httpProtocol)).maxDuration(maxDurationSecs)
	   Benchmark_CME_Checkout.checkout.inject(rampUsers(users) during (rampUpTimeSecs seconds)).protocols(httpProtocol)).maxDuration(maxDurationSecs)
		
		//Benchmark.scn_Clone.inject(rampUsers(scn_Clone_users) during (rampUpTimeSecs seconds)).protocols(httpConf),
		//Benchmark.cpq_diff_cart_shapes.inject(rampUsers(cpq_diff_cart_shapes_users) during (rampUpTimeSecs seconds)).protocols(httpConf)).maxDuration(maxDurationSecs)	
}