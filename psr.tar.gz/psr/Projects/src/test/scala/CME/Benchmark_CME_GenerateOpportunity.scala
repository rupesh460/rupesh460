package CME

import scala.concurrent.duration._
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import scala.util.Random
import scala.concurrent.duration.DurationInt
import Headers._
import io.gatling.core.feeder._
import java.util.Base64
import java.nio.charset.StandardCharsets
import scala.util.matching.Regex

object Benchmark_CME_GenerateOpportunity {

  val uri01 = Configuration.Uri01
  val uri02 = Configuration.Uri02
  val uri10 = Configuration.Uri10
  var Date =  Configuration.Date
  var OppTurnity = Configuration.Oppty
  var QuoteName = Configuration.QuoteName
  val recordsByEnv: Map[String, Seq[Record[Any]]] = csv("./src/test/resources/data/common/credentials.prop").readRecords.groupBy { record => record("env").toString }
  val passwordByEnv: Map[String, Seq[Any]] = recordsByEnv.mapValues { records => records.map { record => record("password") } }
  val password_v = (passwordByEnv.get("cme").toString)
  val password_encoded = password_v.substring(12,(password_v.length - 2 ))
  val credentials = new String(Base64.getDecoder.decode(password_encoded))

   val opportunity = scenario("opportunity")
    
  .exec(http("T001_LandingPage")
      .get(uri10 + "/")
      .check(regex("""<input type="hidden" name="QCQQ" value="(.*?)" \/>""").find.exists.saveAs("QCQQID"))
      .headers(headers_0))

  .exec(session => session.set("password",credentials))

    .exec(http("T002_Login")
      .post(uri10 + "/")
      .headers(headers_18)
      .formParam("un", "perf-cme-105-bmk@vlocity.com")
      .formParam("width", "1440")
      .formParam("height", "900")
      .formParam("hasRememberUn", "true")
      .formParam("startURL", "")
      .formParam("loginURL", "")
      .formParam("loginType", "")
      .formParam("useSecure", "true")
      .formParam("local", "")
      .formParam("lt", "standard")
      .formParam("qs", "r=https%3A%2F%2Fna136.salesforce.com%2F")
      .formParam("locale", "")
      .formParam("oauth_token", "")
      .formParam("oauth_callback", "")
      .formParam("login", "")
      .formParam("serverid", "")
      .formParam("QCQQ", "${QCQQID}")
      .formParam("display", "page")
      .formParam("username", "perf-cme-105-bmk@vlocity.com")
      .formParam("ExtraLog", "%5B%7B%22width%22:1440%7D,%7B%22height%22:900%7D,%7B%22language%22:%22en-GB%22%7D,%7B%22offset%22:-5.5%7D,%7B%22scripts%22:%5B%7B%22size%22:249,%22summary%22:%22if%20(self%20==%20top)%20%7Bdocument.documentElement.style.v%22%7D,%7B%22size%22:528,%22summary%22:%22var%20SFDCSessionVars=%7B%5C%22server%5C%22:%5C%22https:%5C%5C/%5C%5C/login.sal%22%7D,%7B%22url%22:%22https://login.salesforce.com/jslibrary/SfdcSessionBase208.js%22%7D,%7B%22url%22:%22https://login.salesforce.com/jslibrary/LoginHint208.js%22%7D,%7B%22size%22:26,%22summary%22:%22LoginHint.hideLoginForm();%22%7D,%7B%22size%22:2626,%22summary%22:%22(function()%20%7B%5Cn%5Ct%5Ct%20%5Ct/*%5Cn%5Ct%5Ct%20%20%20%20function%20bindResponse(r%22%7D,%7B%22size%22:36,%22summary%22:%22LoginHint.getSavedIdentities(false);%22%7D,%7B%22url%22:%22https://login.salesforce.com/jslibrary/baselogin4.js%22%7D,%7B%22url%22:%22https://login.salesforce.com/jslibrary/LoginMarketingSurveyResponse.js%22%7D,%7B%22size%22:397,%22summary%22:%22function%20handleLogin()%7Bdocument.login.un.value=doc%22%7D%5D%7D,%7B%22scriptCount%22:10%7D,%7B%22iframes%22:%5B%22https://c.salesforce.com/login-messages/promos.html?r=https%253A%252F%252Fna136.salesforce.com%252F%22,%22https://login.salesforce.com/login/sessionserver212.html%22%5D%7D,%7B%22iframeCount%22:2%7D,%7B%22referrer%22:%22https://na136.salesforce.com/%22%7D%5D")
      .formParam("pw", "${password}")
      .formParam("Login", "Log In"))
      


            /* ***** HomePage ****** */
      .exec(http("T003_HomePage")
      .get("/home/home.jsp")
      .check(regex("""Opportunity_Tab"><a href="\/(.*?)\/""").find.exists.saveAs("OppturbityID"))
      .check(regex("""linkToken=(.+?)&""").find.exists.saveAs("TokenID"))
      //.check(regex("""linkToken=(.+?)&""").find.exists.saveAs("TokenID"))
      .headers(headers_1))

  .pause(10)         
    
       /* ****** Home page ******** */ 

.repeat(25)
    {
    exec(http("T004_SelectOppTab")
      .get("/${OppturbityID}/o")
      //.check(regex("""<th scope="row" class=" dataCell  "><a href="\/(.*?)">""").findRandom.exists.saveAs("OppID"))
      .headers(headers_0))

    .pause(4)
    .exec(http("request_42")
      .get("/${OppturbityID}/e?retURL=%2F${OppturbityID}%2Fo")
      .check(regex("""id="_CONFIRMATIONTOKEN" value="(.*?)"""").find.exists.saveAs("CONFIRMATIONTOKEN"))
      .headers(headers_0))
    


.exec(session => session
       .set("CurrentDate", Date)  // Populate the “myToday” session variable with today’s date
   )
    //.pause(26)

    .feed(OppTurnity)
    .exec(http("request_56")
      .post("/${OppturbityID}/e")
      .headers(headers_56)
      .formParam("_CONFIRMATIONTOKEN", "${CONFIRMATIONTOKEN}")
      .formParam("cancelURL", "/${OppturbityID}/o")
      .formParam("retURL", "/${OppturbityID}/o")
      .formParam("save_new_url", "/${OppturbityID}/e?retURL=%2F${OppturbityID}%2Fo")
      .formParam("opp9", "${CurrentDate}")
      .formParam("opp3", "Pbulk-${oppname}")
      .formParam("opp11", "Prospecting")
      .formParam("opp4_lkid", "")
      .formParam("opp4_lkold", "null")
      .formParam("opp4_lktp", "001")
      .formParam("opp4_lspf", "0")
      .formParam("opp4_lspfsub", "0")
      .formParam("opp4_mod", "1")
      .formParam("opp4", "PerfBulkBusinessAcc5")
      .formParam("opp12", "10")
      .formParam("opp5", "")
      .formParam("opp7", "")
      .formParam("opp17_lkid", "000000000000000")
      .formParam("opp17_lkold", "null")
      .formParam("opp17_lktp", "701")
      .formParam("opp17_lspf", "0")
      .formParam("opp17_lspfsub", "0")
      .formParam("opp17_mod", "0")
      .formParam("opp17", "")
      .formParam("opp6", "")
      .formParam("opp10", "")
      .formParam("opp14", "")
      .formParam("save", "Saving...")
      .formParam("isSetupParam", "0")
      .check(regex("""window.location.href ='\/(.*?)'""").find.exists.saveAs("OppID")))



      .exec(http("request_57")
      .get("/${OppID}")
      .headers(headers_91))
      

    .exec(http("request_84")
      .get(uri02 + "/apex/MultiServiceConfiguration?scontrolCaching=1&id=${OppID}")
        .check(regex("""id=(.*?)&""").find.exists.saveAs("ID1"))
        .check(regex("""parentId=(.*?)&""").find.exists.saveAs("parentIdID"))
        .headers(headers_90))

  .exec(http("T006_SELECTMSP_OMScript")
      .get(uri02 + "/apex/apex/OmniScriptUniversalPage?id=${ID1}&parentId=${parentIdID}&layout=lightning")//${OppID}
      .check(regex(""""name":"BuildJSONWithPrefillV2","len":6,"ns":"vlocity_cmt","ver":32\.0,"csrf":"(.*?)"""").find.exists.saveAs("CSRF1"))
      .check(regex(""""name":"GenericInvoke2","len":4,"ns":"vlocity_cmt","ver":32\.0,"csrf":"(.*?)"""").find.exists.saveAs("GetDetail_Csrf"))
      .check(regex(""""name":"getCustomLabels","len":2,"ns":"vlocity_cmt","ver":32\.0,"csrf":"(.*?)"""").find.exists.saveAs("gCL_Csrf"))
      .headers(headers_91))

      
            
            .exec(http("request_98")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("/src/test/resources/bodies/cMENew1/oppturnity/0098_request.json")))

           .exec(http("request_99")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("/src/test/resources/bodies/cMENew1/oppturnity/0099_request.json")))

      .exec(http("request_100")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("/src/test/resources/bodies/cMENew1/oppturnity/0100_request.json")))

      .exec(http("request_101")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("/src/test/resources/bodies/cMENew1/oppturnity/0101_request.json")))




      .exec(http("request_103")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("/src/test/resources/bodies/cMENew1/oppturnity/0103_request.json")))


    .pause(5)
    .exec(http("request_105")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("/src/test/resources/bodies/cMENew1/oppturnity/0105_request.json")))

.feed(QuoteName)
      .exec(http("request_106")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("/src/test/resources/bodies/cMENew1/oppturnity/0106_request.json")))

            .exec(http("request_107")
      .post(uri02 + "/apexremote")
      .headers(headers_104)
      .body(ElFileBody("/src/test/resources/bodies/cMENew1/oppturnity/0107_request.json")))


  }
}
   