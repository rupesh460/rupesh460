package eComm_V107_loggedin


import io.gatling.core.Predef._
import io.gatling.http.Predef._

class eComm_SF_Scn extends Simulation {

  val httpConf = http
    .baseUrl(Configuration.BaseUrl)
    .inferHtmlResources(BlackList(""".*\.js""", """.*\.css""", """.*\.gif""", """.*\.jpeg""", """.*\.jpg""", """.*\.ico""", """.*\.woff""", """.*\.(t|o)tf""", """.*\.png"""), WhiteList())
    .acceptHeader("*/*")
    .acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8")
    .acceptEncodingHeader("gzip, deflate, sdch")
    .acceptLanguageHeader("en-US,en;q=0.8")
    .disableCaching
    .contentTypeHeader("application/x-www-form-urlencoded; charset=UTF-8")
    .userAgentHeader("Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:41.0) Gecko/20100101 Firefox/41.0")

  //Anonymous Scenarios
  val loginUsers = Integer.getInteger("SF_DC_Anon_Login", 1)
  val loginRampUp = Integer.getInteger("SF_DC_Anon_Login_RampUp", 1)

  val productViewUsers = Integer.getInteger("SF_DC_Anon_ProductViews", 1)
  val productViewRampUp = Integer.getInteger("SF_DC_Anon_ProductViews_RampUp", 1)

  val addToCartUsers = Integer.getInteger("SF_DC_Anon_AddToCart", 1)
  val addToCartRampUp = Integer.getInteger("SF_DC_Anon_AddToCart_RampUp", 1)

  val checkOutUsers = Integer.getInteger("SF_DC_Anon_CheckOut", 1)
  val checkOutRampUp = Integer.getInteger("SF_DC_Anon_CheckOut_RampUp", 1)

  //Loggedin Scenarios
  val loginLoggedinUsers = Integer.getInteger("SF_DC_Loggedin_Login", 1)
  val loginLoggedinRampUp = Integer.getInteger("SF_DC_Loggedin_Login_RampUp", 1)

  val productViewLoggedinUsers = Integer.getInteger("SF_DC_Loggedin_ProductViews", 1)
  val productViewLoggedinRampUp = Integer.getInteger("SF_DC_Loggedin_ProductViews_RampUp", 1)

  val addToCartLoggedinUsers = Integer.getInteger("SF_DC_Loggedin_AddToCart", 1)
  val addToCartLoggedinRampUp = Integer.getInteger("SF_DC_Loggedin_AddToCart_RampUp", 1)

  val checkOutLoggedinUsers = Integer.getInteger("SF_DC_Loggedin_CheckOut", 1)
  val checkOutLoggedinRampUp = Integer.getInteger("SF_DC_Loggedin_CheckOut_RampUp", 1)


  val maxDurationSecs = Integer.getInteger("maxDurationSecs", 1)
  val testDuration = Integer.getInteger("testDuration", 1)

  setUp(

    eComm_SF.loginLoggedinScn.inject(rampUsers(loginLoggedinUsers) during (loginLoggedinRampUp seconds)).protocols(httpConf),
    eComm_SF.productViewsLoggedinScn.inject(rampUsers(productViewLoggedinUsers) during (productViewLoggedinRampUp seconds)).protocols(httpConf),
    eComm_SF.addToCartLoggedinScn.inject(rampUsers(addToCartLoggedinUsers) during (addToCartLoggedinRampUp seconds)).protocols(httpConf),
    eComm_SF.checkOutLoggedinScn.inject(rampUsers(checkOutLoggedinUsers) during (checkOutLoggedinRampUp seconds)).protocols(httpConf)).maxDuration(maxDurationSecs seconds)
}
