package com.vlocity.perf;

import static io.restassured.RestAssured.given;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Arrays;
import org.testng.annotations.Test;
import com.google.gson.JsonArray;
import com.google.gson.JsonParser;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class csvreader {

	static String accesstoken ="";
	static Map<String, ArrayList<String>> map = new HashMap<String, ArrayList<String>>();
	static ArrayList<String> arrlist = new ArrayList<String>();

	public static void writeDataAtOnce(Map<String, ArrayList<String>> map2,String macdoutputfile) 
	{ 

		// first create file object for file placed at location  
		File file = new File(System.getProperty("user.dir")+"//"+macdoutputfile+".csv"); 
		try { 
			// create FileWriter object with file as parameter 
			FileWriter outputfile = new FileWriter(file); 

			// create CSVWriter object filewriter object as parameter 
			CSVWriter writer = new CSVWriter(outputfile, ',', 
					CSVWriter.NO_QUOTE_CHARACTER, 
					CSVWriter.DEFAULT_ESCAPE_CHARACTER, 
					CSVWriter.DEFAULT_LINE_END);

			for (Entry<String, ArrayList<String>> ee : map2.entrySet()) {
				List<String> values = ee.getValue();
				String str[] = new String[values.size()]; 

				// ArrayList to Array Conversion 
				for (int j = 0; j < values.size(); j++) { 

					// Assign each value to String array 
					str[j] = values.get(j); 
				}
				List<String[]> list = new ArrayList<String[]>();
				list.add(str);
				writer.writeAll(list); 
			} 
			writer.close(); 
		} 
		catch (IOException e) { 
			e.printStackTrace(); 
		} 
	} 

	private static String authenticateUser() throws IOException {

		//Getting the details from properties file
		String tokenurl= "https://test.salesforce.com/services/oauth2/token";
		String password="providepassword";
//Provide the password above
		String username="kasi_test@perftest3.";
		String client_id="3MVG9ahGHqp.k2_zfR5r43TBpmTjEH7th9xkn4Zjxb5U_bOokQPXtxzaZAIh5z3qfwae0VhsBUDu.5m4S3qUG";
		String client_secret="7119599995527965426";
		//Getting the access Token
		String response =
				given()
				.header("Content-Type", "application/x-www-form-urlencoded").formParam("grant_type", "password")
				.formParam("client_id", client_id)
				.formParam("client_secret", client_secret)
				.formParam("username", username)
				.formParam("password", password)
				.when()
				.post(tokenurl)
				.asString();

		//System.out.println(response);
		JsonPath jsonPath = new JsonPath(response);
		String accessToken = jsonPath.getString("access_token");

		return accessToken;
	}


	public static void readDataLineByLine(String inputfile,String outputfile) 
	{ 

		//map.put("header",new ArrayList<String>(Arrays.asList("AccountId","Rootitemid_add","Account.Name","AssetId_add","AssetId_add02","AssetId_add03","AssetId_add04","AssetId_add05","AssetId_add06","AssetId_add07","AssetId_add08","AssetId_add09","AssetId_add10","AssetId_add11","AssetId_add12","AssetId_add13","AssetId_add14","AssetId_add15","AssetId_add16","AssetId_add17","AssetId_add18","AssetId_add19","AssetId_add20")));

		try { 
			// class with CSV file as a parameter. 
			FileReader filereader = new FileReader(new File(System.getProperty("user.dir")+"//"+inputfile+".csv")); 

			// file reader as a parameter 
			CSVReader csvReader = new CSVReader(filereader); 
			String[] nextRecord; 
			// we are going to read data line by line 
			while ((nextRecord = csvReader.readNext()) != null) { 
				String str = "https://cs17.salesforce.com/services/data/v40.0/query/?q=SELECT Id FROM Asset WHERE RootItemId__c = '"+nextRecord[2]+"' and AccountId='"+nextRecord[0]+"'";    	
				Response response = null;
				try {
					response = 
							given()
							.auth().oauth2(accesstoken)
							.contentType(ContentType.JSON)
							.accept(ContentType.JSON)
							.expect()
							.when()
							.get(str);
				}
				catch(Exception e){
					System.out.println("----------------Not Able To Get Response---------------");
					e.printStackTrace();
				}
				arrlist.add(nextRecord[0]);
				arrlist.add(nextRecord[2]);
				arrlist.add(nextRecord[3]);
				JsonArray jarr = (new JsonParser().parse(response.asString())).getAsJsonObject().get("records").getAsJsonArray();
				for(int j=0;j<jarr.size();j++)
				{
					String str1 = jarr.get(j).getAsJsonObject().get("Id").toString();
					arrlist.add(str1.trim().replaceAll("\"", ""));
				}
				for(String macd: arrlist)
				{
					System.out.print(macd.trim().replaceAll("\"", "")+",");

				}
				System.out.println();
				//System.out.println(arrlist);
				map.put(nextRecord[1],new ArrayList<String>(arrlist));
				arrlist.clear();
			} 
			writeDataAtOnce(map,outputfile);
		} 
		catch (Exception e) { 
			e.printStackTrace(); 
		} 
	} 

	@Test
	public static void macddatacreation() throws IOException {
		String inputfile = System.getProperty("inputfile");
		String outputfile =System.getProperty("outputfile");
		accesstoken =authenticateUser();
		readDataLineByLine(inputfile,outputfile);

	}

}
