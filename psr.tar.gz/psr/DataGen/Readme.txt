##################################
Version: 100.3.1
Folder: Data_generation
##################################

1. Products creation and Bundle Creation

	This script helps you create products and create a bundle out of created products.
	The bundle structure that is created using this script is mentioned below.

	BNDL-PROD-PRNT
        BNDL-PROD-CHLD-1
            BNDL-PROD-CHLD-1.1
                BNDL-PROD-CHLD-1.1.1
                BNDL-PROD-CHLD-1.1.2
                BNDL-PROD-CHLD-1.1.3
                ...
                ...
                ...
                BNDL-PROD-CHLD-1.1.10
            BNDL-PROD-CHLD-1.2
            BNDL-PROD-CHLD-1.3
            ...
            ...
            ...
            BNDL-PROD-CHLD-1.10
        BNDL-PROD-CHLD-2
        BNDL-PROD-CHLD-3
        ...
        ...
        ...
        BNDL-PROD-CHLD-20

    1.1 To create such a bundle, create your products with appropriate names for each level.
    1.2 Once the products are ready create the PCI( Product Child Item ) with the right parent id and child ids.

2. Create Pricebook entries in standard pricebook and user Pricebook
	
	2.1 Create standard pricebook entries which is mandatory for all the products.
	2.2 Create pricebook entries for your pricebook.

3. Assign attributes to the products

	3.1 Fetch attributes from Attribute__c object and store it in a list.
	3.2 Loop through the products and create a AttributeAssignment__c entry for each product which an attribute fetched randomly from the attribute list.

4. Create Pricelist entries
	
	4.1 Select the products for which you want to create the PLEs.
	4.2 Create a PriceListEntry__c entry for those products.

5. Create Promotions
	
	5.1 Create a Promotion__c entry for new promotion.
	5.2 Associate the new Promotion to a Pricelist - Give the Pricelist id while creating the Promotion
	5.3 Create a Promotion Item that is associated for each promotion. 
		5.3.1 Make sure you created a Price list entry for the Promotion Item that you are tagging to the Promotion.
		5.3.2 The Promotion Item can be off Add/Update type. Create based on the requirement.

6. Associate Rules to Promotions

	6.1 Pick the Promotions for which you want to associate rules.
	6.2 Fetch the Rules from Rule__c object and store it in a list.
	6.3 Create a RuleAssignment__c entry with a Rule picked randomly from the Rule list.