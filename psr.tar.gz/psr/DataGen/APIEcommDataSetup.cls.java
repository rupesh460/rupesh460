public class APIEcommDataSetup
{

    public static List<Product2> rootProdList = new List<Product2>();
    public static List<Product2> ecomProdList = new List<Product2>();
    public static List<Product2> childProdList = new List<Product2>();
    public static List<Catalog__c> catalogList = new List<Catalog__c>();
    public static List<CatalogProductRelationship__c> catProdRels = new List<CatalogProductRelationship__c>();
    public static List<Promotion__c> promoList = new List<Promotion__c>();
    public static List<PromotionItem__c> promoItemList = new List<PromotionItem__c>();

    public static void setupData()
    {

        createProductBundles();

        createPriceListEntries();

        createPromotions();

        createCatalogProdRelationships();
        String catalogCode = 'ECOM-CATALOG';

        //createContextProfile((new List<SObject> rootProdList), (new List<SObject> promoList), catalogCode);

    }


   private static void createCatalogs()
    {
        for(Integer i=1;i<20;i++)
        {
            Catalog__c catalog = new Catalog__c(CatalogCode__c = 'ECOM-CATALOG-'+i,Name = 'Ecom-Catalog-'+i,DefaultPriceListId__c='a2rL0000000oevyIAA',Description__c='Test Catalog'+i+' for Ecommerce',IsActive__c=true,IsCatalogRoot__c=true);
            catalogList.add(catalog);
        }
        insert catalogList;
    }

    public static Map<String, Object> createContextProfile(List<SObject> products, List<SObject> promotions,
            String catalogCode)
    {
        Map<String, Object> contextProfile = new Map<String, Object>();

        EventMessage__c  em = new EventMessage__c(Name = 'pushevent', Type__c = 'Context');
        insert em;
        
        List<SObject> sobjectList = new List<SObject>();

        //create dimensions

        ContextDimension__c accSlaDim = new ContextDimension__c(Name = 'accSla', Code__c = 'accSla', ConditionWeight__c = 1.0,
                DataType__c = 'Text',
                DomainType__c = 'Type in', IsActive__c = true, Volatility__c = 'Always', CacheableMode__c = true,
                Values__c = 'silver,gold');
        ContextDimension__c accPhoneDim = new ContextDimension__c(Name = 'accPhone', Code__c = 'accPhone',
                ConditionWeight__c = 1.0, DataType__c = 'Text',
                DomainType__c = 'Type in', IsActive__c = true, Volatility__c = 'Always', CacheableMode__c = true,
                Values__c = '1234,5678,9871');
        ContextDimension__c accStatusDim = new ContextDimension__c(Name = 'accStatus', Code__c = 'accStatus',
                ConditionWeight__c = 1.0, DataType__c = 'Text',
                DomainType__c = 'Type in', IsActive__c = true, Volatility__c = 'Always', CacheableMode__c = true,
                Values__c = 'Active,Inactive,Expired');


        sobjectList.add(accSlaDim);
        sobjectList.add(accPhoneDim);
        sobjectList.add(accStatusDim);

        insert sobjectList;
        sobjectList.clear();

        //create context scopes

        ContextScope__c orderEntityScope = new ContextScope__c(Name = 'Order', Code__c = 'Order', Entity__c = 'Order',
                ScopeType__c = 'Entity');
        ContextScope__c accountEntityScope = new ContextScope__c(Name = 'Account', Code__c = 'Account', Entity__c = 'Order',
                ScopeType__c = 'Entity', EntityPath__c = 'Account');

        sobjectList.add(orderEntityScope);
        sobjectList.add(accountEntityScope);

        insert sobjectList;
        sobjectList.clear();


        //create dimensions mapping
        ContextMapping__c accSlaMap = new ContextMapping__c(ContextScopeId__c = accountEntityScope.Id,
                InitializationPolicy__c = 'Always Reinitialize', InitializationType__c = 'Source Expression',
                Dimension__c = accSlaDim.Id, Source__c = 'Sla__c', Sequence__c = 1.0, IsActive__c = true);
        ContextMapping__c accPhoneMap = new ContextMapping__c(ContextScopeId__c = accountEntityScope.Id,
                InitializationPolicy__c = 'Always Reinitialize', InitializationType__c = 'Source Expression',
                Dimension__c = accPhoneDim.Id, Source__c = 'Phone', Sequence__c = 2.0, IsActive__c = true);
        ContextMapping__c accStatusMap = new ContextMapping__c(ContextScopeId__c = accountEntityScope.Id,
                InitializationPolicy__c = 'Always Reinitialize', InitializationType__c = 'Source Expression',
                Dimension__c = accStatusDim.Id, Source__c = 'Status__c', Sequence__c = 3.0, IsActive__c = true);

        sobjectList.add(accSlaMap);
        sobjectList.add(accPhoneMap);
        sobjectList.add(accStatusMap);
        insert sobjectList;
        sobjectList.clear();

        //create ruleset
        Rule__c conRuleSet1 = new Rule__c(Name = 'ecommRS1', RuleType__c = 'Qualification', IsActive__c = true,
                                          RulePurpose__c = 'Eligibility',
                                          FailureMessage__c = 'Qualification Ruleset-1: failed.', Expression__c = '', Operation__c = 'And');
        Rule__c conRuleSet2 = new Rule__c(Name = 'ecommRS2', RuleType__c = 'Qualification', IsActive__c = true,
                                          RulePurpose__c = 'Eligibility',
                                          FailureMessage__c = 'Qualification Ruleset-2: failed.', Expression__c = '', Operation__c = 'Or');
        Rule__c conRuleSet3 = new Rule__c(Name = 'ecommRS3', RuleType__c = 'Qualification', IsActive__c = true,
                                          RulePurpose__c = 'Eligibility',
                                          FailureMessage__c = 'Qualification Ruleset-3: failed.', Expression__c = '', Operation__c = 'And');
        Rule__c conRuleSet4 = new Rule__c(Name = 'ecommRS4', RuleType__c = 'Qualification', IsActive__c = true,
                                          RulePurpose__c = 'Eligibility',
                                          FailureMessage__c = 'Qualification Ruleset-4: failed.', Expression__c = '', Operation__c = 'Or');

        sobjectList.add(conRuleSet1);
        sobjectList.add(conRuleSet2);
        sobjectList.add(conRuleSet3);
        sobjectList.add(conRuleSet4);
        insert sobjectList;
        sobjectList.clear();

        //create rule
        EntityFilter__c r1 = new EntityFilter__c(Name = 'ecommR1', IsActive__c = true, Code__c = 'ecommR1',
                Expression__c = '', Operation__c = 'Or', FailureMessage__c = 'ecommR1: failed');
        EntityFilter__c r2 = new EntityFilter__c(Name = 'ecommR2', IsActive__c = true, Code__c = 'ecommR2',
                Expression__c = '', Operation__c = 'And', FailureMessage__c = 'ecommR2: failed');
        EntityFilter__c r3 = new EntityFilter__c(Name = 'ecommR3', IsActive__c = true, Code__c = 'ecommR3',
                Expression__c = '', Operation__c = 'Or', FailureMessage__c = 'ecommR3: failed');
        EntityFilter__c r4 = new EntityFilter__c(Name = 'ecommR4', IsActive__c = true, Code__c = 'ecommR4',
                Expression__c = '', Operation__c = 'Or', FailureMessage__c = 'ecommR4: failed');

        sobjectList.add(r1);
        sobjectList.add(r2);
        sobjectList.add(r3);
        sobjectList.add(r4);

        insert sobjectList;
        sobjectList.clear();

        //create rule condition
        EntityFilterCondition__c slaGoldFilterCondition = new EntityFilterCondition__c(Code__c = 'slaGold',
                EntityFilterId__c = r1.Id,
                ContextDimensionId__c = accSlaDim.Id, FieldName__c = 'accSla',  Value__c = 'Gold', ConditionType__c = 'Simple',
                FailLevel__c = 'Hard Fail', FailureMessage__c = 'sla gold: failed', Operator__c = '==');
        EntityFilterCondition__c statusInactiveCondition = new EntityFilterCondition__c(Code__c = 'statusInactive',
                EntityFilterId__c = r1.Id,
                ContextDimensionId__c = accStatusDim.Id, FieldName__c = 'accStatus',  Value__c = 'Inactive',
                ConditionType__c = 'Simple', FailLevel__c = 'Hard Fail', FailureMessage__c = 'status inactive: failed',
                Operator__c = '==');

        EntityFilterCondition__c slaSilverFilterCondition = new EntityFilterCondition__c(Code__c = 'slaSilver',
                EntityFilterId__c = r2.Id,
                ContextDimensionId__c = accSlaDim.Id, FieldName__c = 'accSla',  Value__c = 'Silver', ConditionType__c = 'Simple',
                FailLevel__c = 'Hard Fail', FailureMessage__c = 'sla silver: failed', Operator__c = '==');
        EntityFilterCondition__c statusActiveCondition = new EntityFilterCondition__c(Code__c = 'statusInactive',
                EntityFilterId__c = r2.Id,
                ContextDimensionId__c = accStatusDim.Id, FieldName__c = 'accStatus',  Value__c = 'Active', ConditionType__c = 'Simple',
                FailLevel__c = 'Hard Fail', FailureMessage__c = 'status active: failed', Operator__c = '==');


        EntityFilterCondition__c slaPlatinumFilterCondition = new EntityFilterCondition__c(Code__c = 'slaPlatinum',
                EntityFilterId__c = r3.Id,
                ContextDimensionId__c = accSlaDim.Id, FieldName__c = 'accSla',  Value__c = 'Platinum', ConditionType__c = 'Simple',
                FailLevel__c = 'Hard Fail', FailureMessage__c = 'sla Platinum: failed', Operator__c = '==');
        EntityFilterCondition__c phone1234Condition = new EntityFilterCondition__c(Code__c = 'phone1234',
                EntityFilterId__c = r3.Id,
                ContextDimensionId__c = accPhoneDim.Id, FieldName__c = 'accPhone',  Value__c = '1234', ConditionType__c = 'Simple',
                FailLevel__c = 'Hard Fail', FailureMessage__c = 'acc phone 1234: failed', Operator__c = '==');

        EntityFilterCondition__c slaBronzeFilterCondition = new EntityFilterCondition__c(Code__c = 'bronzeGold',
                EntityFilterId__c = r4.Id,
                ContextDimensionId__c = accSlaDim.Id, FieldName__c = 'accSla',  Value__c = 'Bronze', ConditionType__c = 'Simple',
                FailLevel__c = 'Hard Fail', FailureMessage__c = 'sla Bronze: failed', Operator__c = '==');
        EntityFilterCondition__c phone5678Condition = new EntityFilterCondition__c(Code__c = 'phone5678',
                EntityFilterId__c = r4.Id,
                ContextDimensionId__c = accPhoneDim.Id, FieldName__c = 'accPhone',  Value__c = '5678', ConditionType__c = 'Simple',
                FailLevel__c = 'Hard Fail', FailureMessage__c = 'phone 5678: failed', Operator__c = '==');

        sobjectList.add(slaGoldFilterCondition);
        sobjectList.add(slaSilverFilterCondition);
        sobjectList.add(slaPlatinumFilterCondition);
        sobjectList.add(slaBronzeFilterCondition);

        sobjectList.add(statusInactiveCondition);
        sobjectList.add(statusActiveCondition);
        sobjectList.add(phone1234Condition);
        sobjectList.add(phone5678Condition);

        insert sobjectList;

        sobjectList.clear();

        List<Rule__c> rulesetList = [select Id from Rule__c where name like 'Qualification Ruleset%' order by name];
        //assign rule to ruleset
        RuleFilter__c conRuleSetRule1 = new RuleFilter__c(ActionTaken__c = 'Qualify', RuleId__c = conRuleSet1.Id,
                EntityFilterId__c = r1.Id, Sequence__c = 1.0);
        RuleFilter__c conRuleSetRule2 = new RuleFilter__c(ActionTaken__c = 'Qualify', RuleId__c = conRuleSet1.Id,
                EntityFilterId__c = r2.Id, Sequence__c = 2.0);

        RuleFilter__c conRuleSetRule3 = new RuleFilter__c(ActionTaken__c = 'Qualify', RuleId__c = conRuleSet2.Id,
                EntityFilterId__c = r2.Id, Sequence__c = 1.0);
        RuleFilter__c conRuleSetRule4 = new RuleFilter__c(ActionTaken__c = 'Qualify', RuleId__c = conRuleSet2.Id,
                EntityFilterId__c = r3.Id, Sequence__c = 2.0);

        RuleFilter__c conRuleSetRule5 = new RuleFilter__c(ActionTaken__c = 'Qualify', RuleId__c = conRuleSet3.Id,
                EntityFilterId__c = r3.Id, Sequence__c = 1.0);
        RuleFilter__c conRuleSetRule6 = new RuleFilter__c(ActionTaken__c = 'Qualify', RuleId__c = conRuleSet3.Id,
                EntityFilterId__c = r4.Id, Sequence__c = 2.0);

        RuleFilter__c conRuleSetRule7 = new RuleFilter__c(ActionTaken__c = 'Qualify', RuleId__c = conRuleSet4.Id,
                EntityFilterId__c = r4.Id, Sequence__c = 1.0);
        RuleFilter__c conRuleSetRule8 = new RuleFilter__c(ActionTaken__c = 'Qualify', RuleId__c = conRuleSet4.Id,
                EntityFilterId__c = r1.Id, Sequence__c = 2.0);



        sobjectList.add(conRuleSetRule1);
        sobjectList.add(conRuleSetRule2);
        sobjectList.add(conRuleSetRule3);
        sobjectList.add(conRuleSetRule4);
        sobjectList.add(conRuleSetRule5);
        sobjectList.add(conRuleSetRule6);
        sobjectList.add(conRuleSetRule7);
        sobjectList.add(conRuleSetRule8);
        insert sobjectList;
        sobjectList.clear();

        //assign rules to prod/promo
        RuleAssignment__c prod1Assignment = new RuleAssignment__c(Name = 'CPQ Ruleset Obj-1', RuleId__c = conRuleSet1.Id,
                ObjectId__c = products.get(0).Id);
        sobjectList.add(prod1Assignment);
        RuleAssignment__c promo1Assignment = new RuleAssignment__c(Name = 'CPQ Ruleset Obj-3', RuleId__c = conRuleSet2.Id,
                ObjectId__c = promotions.get(0).Id);
        sobjectList.add(promo1Assignment);
        insert sobjectList;
        sobjectList.clear();

        return contextProfile;
    }

    private static void createProductBundles()
    {
        //Inserting  Root Products
        String rootProductNamePrefix = 'eCom-Prod-';
        String rootProductCodePrefix = 'ECOMROOT00';

        String childProductNamePrefix = 'eCom-Child-Prod-';
        String childProductCodePrefix = 'ECOMCHILD00';


        for (Integer i=0;i<5;i++)
        {
            Product2 product = new Product2(Name = rootProductNamePrefix+i,
                                            ProductCode = rootProductCodePrefix+i,
                                            Description = rootProductCodePrefix+i,                        
                                            IsOrderable__c = true,
                                            SpecificationType__c = 'Product',
                                            IsActive = true);
            rootProdList.add(product);
        }  

        insert rootProdList;


        //Inserting rootPCI for Products

        List<ProductChildItem__c> rootPCIlist = new List<ProductChildItem__c>();
        for (Integer i=0;i<rootProdList.size();i++)
        {
            ProductChildItem__c rootPCI = new ProductChildItem__c(Name = 'rootPCI',
                                                                            ChildLineNumber__c = '0001',
                                                                            ParentProductId__c = rootProdList[i].Id,
                                                                            Quantity__c = 1.00,
                                                                            MaxQuantity__c = 999.00,
                                                                            MinQuantity__c = 0.00,
                                                                            MaximumChildItemQuantity__c = 999.00,
                                                                            MinimumChildItemQuantity__c = 0.00,
                                                                            IsRootProductChildItem__c = true);

            rootPCIlist.add(rootPCI);
        }

        insert rootPCIlist;

        //Inserting Child Products

        for (Integer i=0;i<20;i++)
        {
            Product2 product = new Product2(Name = childProductNamePrefix+i,
                                            ProductCode = childProductCodePrefix+i,
                                            Description = childProductCodePrefix+i,                        
                                            IsOrderable__c = true,
                                            SpecificationType__c = 'Product',
                                            IsActive = true);
            childProdList.add(product);
        }  

        insert childProdList;

        //Inserting PCI for Child Products
        List<ProductChildItem__c> childPCIlist = new List<ProductChildItem__c>();

        for (Integer i=0;i<childProdList.size();i++)
        {

            ProductChildItem__c childProductItem = new ProductChildItem__c(Name = childProdList[i].Name,
                                                                            ChildLineNumber__c = '0001.000'+(math.mod(i, 4)),
                                                                            ChildProductId__c = childProdList[i].Id,
                                                                            Quantity__c = 1.00,
                                                                            MaxQuantity__c = 3.00,
                                                                            MinQuantity__c = 1.00,
                                                                            ParentProductId__c = rootProdList[math.mod(i, 4)].Id);
            childPCIlist.add(childProductItem);

        }
        insert childPCIlist;
        

        List<SObject> children = new List<SObject>();
        children.addAll(childPCIlist);

        ProductHierarchyBatchService resolveProductHierarchy = new ProductHierarchyBatchService();
        resolveProductHierarchy.resolveProductHierearchyItems(children);
    }

    private static void createPriceListEntries()
    {
        List<PricingElement__c> peList = [SELECT Id,Name,PriceListId__c FROM PricingElement__c WHERE PriceListId__c = 'a2rL0000000oevyIAA' AND Name LIKE '$%'];
        List<TimePlan__c> timePlanList = [ SELECT Id FROM TimePlan__c ];
        List<TimePolicy__c> timePolicyList = [ SELECT Id FROM TimePolicy__c ];
        List<PriceListEntry__c> tempList = new List<PriceListEntry__c>();

        for(Integer i=0;i<rootProdList.size();i++)
        {
            PriceListEntry__c ple = new PriceListEntry__c();
            ple.Name = rootProdList.get(i).Name + '-PLE';
            ple.DisplayText__c = rootProdList.get(i).Name + '-PLE';
            ple.IsActive__c = true;
            ple.IsBasePrice__c = true;
            ple.EffectiveFromDate__c = Date.today();
            ple.EffectiveUntilDate__c = Date.today().addYears(2);
            ple.IsOverride__c = false;
            ple.PriceListId__c = 'a2rL0000000oevyIAA';
            ple.PricingElementId__c = peList.get(getRandom(peList.size())).Id;
            ple.BasePriceListId__c = 'a2rL0000000oevyIAA';
            ple.ProductId__c = rootProdList.get(i).Id;
            ple.TimePlanId__c = timePlanList.get(getRandom(timePlanList.size())).Id;
            ple.TimePolicyId__c = timePolicyList.get(getRandom(timePolicyList.size())).Id;
            tempList.add(ple);

        }
        for(Integer i=0;i<childProdList.size();i++)
        {
            PriceListEntry__c ple = new PriceListEntry__c();
            ple.Name = childProdList.get(i).Name + '-PLE';
            ple.DisplayText__c = childProdList.get(i).Name + '-PLE';
            ple.IsActive__c = true;
            ple.IsBasePrice__c = true;
            ple.EffectiveFromDate__c = Date.today();
            ple.EffectiveUntilDate__c = Date.today().addYears(2);
            ple.IsOverride__c = false;
            ple.PriceListId__c = 'a2rL0000000oevyIAA';
            ple.PricingElementId__c = peList.get(getRandom(peList.size())).Id;
            ple.BasePriceListId__c = 'a2rL0000000oevyIAA';
            ple.ProductId__c = childProdList.get(i).Id;
            ple.TimePlanId__c = timePlanList.get(getRandom(timePlanList.size())).Id;
            ple.TimePolicyId__c = timePolicyList.get(getRandom(timePolicyList.size())).Id;
            tempList.add(ple);

        }
        insert tempList;

    }

    private static void createPromotions()
    {
        for(Integer i=0;i<5;i++)
        {
            Promotion__c promo = new Promotion__c(Name = 'eComPromotion-'+i, Code__c = 'ECOMPROMO'+i, PriceListId__c = 'a2rL0000000oevyIAA');
            promoList.add(promo);
        }
        insert promoList;
       
        for(Integer i=0;i<promoList.size();i++)
        {
            if(math.mod(i,2)==0)
            {
                PromotionItem__c promoItem = new PromotionItem__c(Name = childProdList[i].Name, PromotionId__c = promoList[i].Id, ProductId__c = childProdList[i].Id,ActionType__c = 'Add',IsActive__c = true,MaxQuantity__c = 10,MinQuantity__c = 1,Quantity__c = 1);
                promoItemList.add(promoItem);
            }
            else    
            {
                PromotionItem__c promoItem = new PromotionItem__c(Name = childProdList[i].Name, PromotionId__c = promoList[i].Id, ProductId__c = childProdList[i].Id,ActionType__c = 'Add/Update',IsActive__c = true,MaxQuantity__c = 10,MinQuantity__c = 1,Quantity__c = 1);
                promoItemList.add(promoItem);   
            }
        }
        insert promoItemList;

    }

    private static void createCatalogProdRelationships()
    {
        //Create the catalog product relationships
        for(Integer i=0;i<rootProdList.size();i++)
        {

            CatalogProductRelationship__c catProdRel = new CatalogProductRelationship__c(Name = rootProdList[i].Name,
                    CatalogId__c = 'a0JL00000043Qlx', Product2Id__c = rootProdList[i].Id);
            catProdRels.add(catProdRel);
        }
        for(Integer i=0;i<promoList.size();i++)
        {

            CatalogProductRelationship__c catPromoRel = new CatalogProductRelationship__c(Name = promoList[i].Name,
                    CatalogId__c = 'a0JL00000043Qlx', PromotionId__c = promoList[i].Id);
            catProdRels.add(catPromoRel);    
        }
        insert catProdRels;
    }

    private static void loadAPIMetadata()
    {
        List<VlocityAPIMetadata__c> apiMetaDataList = new List<VlocityAPIMetadata__c>();

        //Adding records
        apiMetaDataList.add(createMetadataRecord('ContextEligibilityGenerator', 'DefaultCtxCombinationsCHandler', null, null, null,
                            true, 1));
        apiMetaDataList.add(createMetadataRecord('GetOffersHierarchyHelper', 'DefaultGetOfferHierarchyCHandler', null,
                            '{"batchSize":1}', null, true, 2));
        apiMetaDataList.add(createMetadataRecord('GetOffers', 'DefaultGetOffersCHandler', 'DefaultGetOffersRHandler', null,
                            '/v3/catalogs/{catalog_code}/offers', true, 3));
        apiMetaDataList.add(createMetadataRecord('GetContainOffers', 'DefaultGetRelatedOffersCHandler',
                            'DefaultGetRelatedOffersRHandler', '{\"pageSize\":\"20\",\"offset\":\"0\"}',
                            '/v3/catalogs/{catalogCode}/offers?contains={productCode}&context={contextParams}', true, 4));
        apiMetaDataList.add(createMetadataRecord('GetPrices', 'DefaultGetPricesCHandler', 'DefaultGetPricesRHandler', null,
                            '/v3/prices', true, 5));
        apiMetaDataList.add(createMetadataRecord('GetOfferDetails', 'DefaultGetOfferDetailsCHandler',
                            'DefaultGetOfferDetailsRHandler', '{"batchSize":1}', '/v3/catalogs/{catalog_code}/offers/{offer_code}', true, 6));
        apiMetaDataList.add(createMetadataRecord('ConfigureOfferDetail', null, 'DefaultConfigureOfferRHandler', null,
                            '/v3/catalogs/{catalog_code}/offers/{offer_code}', true, 7));
        apiMetaDataList.add(createMetadataRecord('CreateEcomCart', null, 'DefaultCreateEcomCartRHandler', null, '/v3/carts',
                            true, 8));
        apiMetaDataList.add(createMetadataRecord('basketOperations', null, 'DefaultBasketOperationsRHandler', null, null, true, 9));
        insert apiMetaDataList;
    }

    private static VlocityAPIMetadata__c createMetadataRecord(String name, String apiCHandler, String apiRHandler,
            String params, String apiUrl, Boolean isActive, Integer sequence)
    {

        VlocityAPIMetadata__c metaData = new VlocityAPIMetadata__c();
        metaData.APIName__c = name;
        metaData.APIHandler__c = apiCHandler;
        metaData.APIResponseHandler__c = apiRHandler;
        metaData.APIParams__c = params;
        metaData.APIUrl__c = apiUrl;
        metaData.IsActive__c = isActive;
        metaData.Sequence__c = sequence;

        return metaData;
    }

    private static Integer getRandom(Integer size)
    {
        Double d = math.random() * size;
        return d.intValue();
    }
    
    public static void cleanUpData()
    {
        delete [SELECT Id FROM Product2 WHERE Name LIKE 'eCom%'];
        delete [SELECT Name FROM Promotion__c WHERE Name LIKE 'eCom%'];
        delete [SELECT Id FROM CatalogProductRelationship__c WHERE Name LIKE 'eCom%'];
        delete [SELECT Id FROM PriceListEntry__c WHERE Name LIKE 'eCom%'];
    }

    public static void insertECOMBundles()
    {
        Integer randomNum = getRandom(10000);
        String uniqueTagName = 'eCom-Prod'+randomNum;
        createECOMProductBundle(uniqueTagName,4,10);

    }

    private static void createECOMProductBundle(String uniqueTagName,Integer depth,Integer maxLineItems)
    {
        for(Integer i=0;i<=maxLineItems;i++)
        {
            Product2 product = new Product2(Name = uniqueTagName+i,
                                            ProductCode = uniqueTagName+i,
                                            Description = uniqueTagName+i,                        
                                            IsOrderable__c = true,
                                            SpecificationType__c = 'Product',
                                            IsActive = true);
            ecomProdList.add(product);
        }
        System.debug('all products in bundle:::'+ecomProdList);
        insert ecomProdList;
        
        List<ProductChildItem__c> rootPCIlist = new List<ProductChildItem__c>();
        for (Integer i=0;i<=6;i++)
        {
            ProductChildItem__c rootPCI = new ProductChildItem__c(Name = 'rootPCI',
                                                                ChildLineNumber__c = '0001',
                                                                ParentProductId__c = ecomProdList[i].Id,
                                                                Quantity__c = 1.00,
                                                                MaxQuantity__c = 999.00,
                                                                MinQuantity__c = 0.00,
                                                                MaximumChildItemQuantity__c = 999.00,
                                                                MinimumChildItemQuantity__c = 0.00,
                                                                IsRootProductChildItem__c = true);

            rootPCIlist.add(rootPCI);
        }
        insert rootPCIlist;

        List<ProductChildItem__c> bundlePCIlist;

        ProductChildItem__c ch1 = new ProductChildItem__c(Name = ecomProdList[1].Name,
                                                                    ChildLineNumber__c = '0001',
                                                                    ChildProductId__c = ecomProdList[1].Id,
                                                                    Quantity__c = 1.00,
                                                                    MaxQuantity__c = 3.00,
                                                                    MinQuantity__c = 1.00,
                                                                    ParentProductId__c = ecomProdList[0].Id);

        ProductChildItem__c ch2 = new ProductChildItem__c(Name = ecomProdList[2].Name,
                                                                    ChildLineNumber__c = '0002',
                                                                    ChildProductId__c = ecomProdList[2].Id,
                                                                    Quantity__c = 1.00,
                                                                    MaxQuantity__c = 3.00,
                                                                    MinQuantity__c = 1.00,
                                                                    ParentProductId__c = ecomProdList[1].Id);

        ProductChildItem__c ch3 = new ProductChildItem__c(Name = ecomProdList[3].Name,
                                                                    ChildLineNumber__c = '0003',
                                                                    ChildProductId__c = ecomProdList[3].Id,
                                                                    Quantity__c = 1.00,
                                                                    MaxQuantity__c = 3.00,
                                                                    MinQuantity__c = 1.00,
                                                                    ParentProductId__c = ecomProdList[1].Id);

        ProductChildItem__c ch4 = new ProductChildItem__c(Name = ecomProdList[4].Name,
                                                                    ChildLineNumber__c = '0004',
                                                                    ChildProductId__c = ecomProdList[4].Id,
                                                                    Quantity__c = 1.00,
                                                                    MaxQuantity__c = 3.00,
                                                                    MinQuantity__c = 1.00,
                                                                    ParentProductId__c = ecomProdList[2].Id);

        ProductChildItem__c ch5 = new ProductChildItem__c(Name = ecomProdList[5].Name,
                                                                    ChildLineNumber__c = '0005',
                                                                    ChildProductId__c = ecomProdList[5].Id,
                                                                    Quantity__c = 1.00,
                                                                    MaxQuantity__c = 3.00,
                                                                    MinQuantity__c = 1.00,
                                                                    ParentProductId__c = ecomProdList[2].Id);

        ProductChildItem__c ch6 = new ProductChildItem__c(Name = ecomProdList[6].Name,
                                                                    ChildLineNumber__c = '0006',
                                                                    ChildProductId__c = ecomProdList[6].Id,
                                                                    Quantity__c = 1.00,
                                                                    MaxQuantity__c = 3.00,
                                                                    MinQuantity__c = 1.00,
                                                                    ParentProductId__c = ecomProdList[3].Id);

        ProductChildItem__c ch7 = new ProductChildItem__c(Name = ecomProdList[7].Name,
                                                                    ChildLineNumber__c = '0007',
                                                                    ChildProductId__c = ecomProdList[7].Id,
                                                                    Quantity__c = 1.00,
                                                                    MaxQuantity__c = 3.00,
                                                                    MinQuantity__c = 1.00,
                                                                    ParentProductId__c = ecomProdList[3].Id);

        ProductChildItem__c ch8 = new ProductChildItem__c(Name = ecomProdList[8].Name,
                                                                    ChildLineNumber__c = '0008',
                                                                    ChildProductId__c = ecomProdList[8].Id,
                                                                    Quantity__c = 1.00,
                                                                    MaxQuantity__c = 3.00,
                                                                    MinQuantity__c = 1.00,
                                                                    ParentProductId__c = ecomProdList[4].Id);

        ProductChildItem__c ch9 = new ProductChildItem__c(Name = ecomProdList[9].Name,
                                                                    ChildLineNumber__c = '0009',
                                                                    ChildProductId__c = ecomProdList[9].Id,
                                                                    Quantity__c = 1.00,
                                                                    MaxQuantity__c = 3.00,
                                                                    MinQuantity__c = 1.00,
                                                                    ParentProductId__c = ecomProdList[4].Id);

        ProductChildItem__c ch10 = new ProductChildItem__c(Name = ecomProdList[10].Name,
                                                                    ChildLineNumber__c = '00010',
                                                                    ChildProductId__c = ecomProdList[10].Id,
                                                                    Quantity__c = 1.00,
                                                                    MaxQuantity__c = 3.00,
                                                                    MinQuantity__c = 1.00,
                                                                    ParentProductId__c = ecomProdList[5].Id);

        bundlePCIlist = new List<ProductChildItem__c>{ch1,ch2,ch3,ch4,ch5,ch6,ch7,ch8,ch9,ch10};
        insert bundlePCIlist;

    }
    public static void cleanUpEcomBundle()
    {
        delete [];
    }

}