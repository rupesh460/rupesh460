/*
/services/apexrest/v3/createattributes/*
*
* Author:: Krishnan Iyer
* 
*
* Usage:   Creates specified number of attributes split across different types.
*          # 1/4th of the total number would be attributes with Picklists.
*          # 3/4th of the total number are randomly split among Number, Currency,
*          Percent & Text types.
*
* NOTE:  - Can be run any number of times consecutively to create a large volume
*          of attributes.
*
*        - Can be followed with the class 'DatagenAssignAttributes' to assign all
*          attributes created here to products.
*       
* Input Required: Attribute Category Id & Total no. of attributes to create
*/

@RestResource(urlMapping = '/v3/createattributes/*')
global class DatagenCreateAttributes 
{
    public static List<vlocity_cmt__Attribute__c> attribList = new List<vlocity_cmt__Attribute__c>();
    public static final String attributeCategoryId = 'a0K3h000001hfj7EAA'; //Replace with Id from table AttributeCategory__c
    
    @HttpGet
    global static void createAttributes() 
    {
        createAttributes(80, attributeCategoryId); //Replace first argument with total number of attributes to create
    }
     
    private static void createAttributes(Integer noOfAttributes, String catid)
    {
        Integer fourth = noOfAttributes/4;
        Integer threeFourth = 3*(noOfAttributes/4);

        //Creating Picklists
        List<vlocity_cmt__Picklist__c> pkl = new List<vlocity_cmt__Picklist__c>();
        Integer index = [Select count() from vlocity_cmt__Picklist__c];

        for(Integer i = index ; i<index+fourth; i++)
        {
            vlocity_cmt__Picklist__c pl = new vlocity_cmt__Picklist__c();
            pl.Name = 'PerfPicklist_'+(i+1);
            pl.vlocity_cmt__Code__c = 'PerfPicklist_'+(i+1);
            pl.vlocity_cmt__DataType__c = 'Number';
            pl.vlocity_cmt__EffectiveFromDate__c = Date.today();
            pl.vlocity_cmt__IsActive__c = true;

            pkl.add(pl);
        }
        Insert pkl;

        //Creating values for picklists created above
        List<vlocity_cmt__PicklistValue__c> pklValue = new List<vlocity_cmt__PicklistValue__c>();
        Integer pkValueCount = [Select count() from vlocity_cmt__PicklistValue__c];
        
        for(Integer i=0; i<pkl.size(); i++)
        {
          for(Integer j=1; j<=3; j++)
          {
              vlocity_cmt__PicklistValue__c pl = new vlocity_cmt__PicklistValue__c();

              pl.Name = ''+j;
              pl.vlocity_cmt__Code__c = 'PerfPicklistVal_'+(i+pkValueCount+1)+'_'+j;
              pl.vlocity_cmt__EffectiveFromDate__c = Date.today();
              pl.vlocity_cmt__IsActive__c = true;
              pl.vlocity_cmt__NumberValue__c = Math.random()*300;
              pl.vlocity_cmt__PicklistId__c = pkl[i].Id;
              pl.vlocity_cmt__Sequence__c = Double.valueOf(j);

              pklValue.add(pl);
          }
        }
        Insert pklValue;

        //Creating attributes with picklists
        Integer attribPickCount = [Select count() from vlocity_cmt__Attribute__c where Name LIKE 'PerfAttributePick%'];

        for(Integer i=0; i<pkl.size(); i++)
        {
            vlocity_cmt__Attribute__c att = new vlocity_cmt__Attribute__c();

            att.Name = 'PerfAttributePick_'+(i+attribPickCount+1);
            att.vlocity_cmt__AttributeCategoryId__c = catid;
            att.vlocity_cmt__Code__c = 'PerfAttributePick_'+(i+attribPickCount+1);
            att.vlocity_cmt__DisplaySequence__c = Double.valueOf(i+1);
            att.vlocity_cmt__Filterable__c = true;
            att.vlocity_cmt__IsCloneable__c = true;
            att.vlocity_cmt__PicklistId__c = pkl[i].Id;
            att.vlocity_cmt__ValueType__c = 'Picklist';

            attribList.add(att);
        }
        //Insert attribList;

        //Creating attributes with different data types
        List<String> valueType = new List<String>{'Number', 'Currency', 'Text', 'Percent', 'Text'};
        Integer attribNormCount = [Select count() from vlocity_cmt__Attribute__c where Name LIKE 'PerfAttributeNorm%'];
        
        for(Integer i=0; i<threeFourth; i++)
        {
            vlocity_cmt__Attribute__c att = new vlocity_cmt__Attribute__c();
            Integer randomVType = Integer.valueOf(Math.random()*valueType.size());

            att.Name = 'PerfAttributeNorm_'+(i+attribNormCount+1);
            att.vlocity_cmt__AttributeCategoryId__c = catid;
            att.vlocity_cmt__Code__c = 'PerfAttributeNorm_'+(i+attribNormCount+1);
            att.vlocity_cmt__DisplaySequence__c = Integer.valueOf(Math.random()*10);
            att.vlocity_cmt__Filterable__c = true;
            att.vlocity_cmt__IsCloneable__c = true;
            att.vlocity_cmt__Value__c = ''+i;
            att.vlocity_cmt__ValueType__c = valueType[randomVType];

            attribList.add(att);
        }
        Insert attribList;
    }
}