/*
/services/apexrest/v3/assignattributes/*
*
* Author:: Krishnan Iyer
* 
*
* Usage: Assigns specified number of attributes per product.
*          
*
* NOTE: - Run consecutively to assign unique attributes to all products.
*
*       - Replace 'vlocity_cmt__' with the namespace of your org.
*       
* Input Required: Attribute Category Id, ObjectClassID for Product2 & no. of
*                 attributes per product to be assigned.
*
*/

@RestResource(urlMapping = '/v3/assignattributes/*')
global class DatagenAssignAttributes 
{   
    public static final String prodName = 'Level'; //Replace with the approximate Product Name to filter query results.
    public static final String attCategoryId = 'a0K3h000001hfj7EAA'; //Replace with Id from table AttributeCategory__c
    public static final String obClassId = 'a213h0000005yWrAAI'; //Replace with Id from table ObjectClass__c corresponding to 'Product2' object

    @HttpGet
    global static void assignAttributes() 
    {
        assignAttributes(40, prodName, attCategoryId, obClassId); //Assigns 40 attributes per product
    }

    private static void assignAttributes(Integer noOfAttributes, String pName, String catid, String obclsid)
    {
        List<vlocity_cmt__ObjectFieldAttribute__c> ofattrib = new List<vlocity_cmt__ObjectFieldAttribute__c>();
        List<vlocity_cmt__AttributeAssignment__c> attrAssign = new List<vlocity_cmt__AttributeAssignment__c>();
        
        List<vlocity_cmt__Attribute__c> attribList = [Select Id, Name, vlocity_cmt__PicklistId__c, vlocity_cmt__Value__c, vlocity_cmt__ValueType__c from vlocity_cmt__Attribute__c where Id NOT IN (Select vlocity_cmt__AttributeId__c from vlocity_cmt__AttributeAssignment__c) ORDER BY CreatedDate LIMIT 100];
        
        pName = pName + '%';
        List<Product2> prodList = Database.query('select Id, Name from Product2 where Name LIKE :pName ORDER BY Name ASC');
        
        Integer prodCount = [select count() from vlocity_cmt__AttributeAssignment__c];
        prodCount = (prodCount/noOfAttributes);

        for(Integer i=prodCount; i<prodCount+1; i++)
        {
            for(Integer j=0; j<noOfAttributes; j++)
            {
                vlocity_cmt__ObjectFieldAttribute__c ob = new vlocity_cmt__ObjectFieldAttribute__c();
                vlocity_cmt__AttributeAssignment__c attr = new vlocity_cmt__AttributeAssignment__c();

                ob.vlocity_cmt__AttributeId__c = attribList[j].Id;
                ob.vlocity_cmt__IsActive__c = true;
                ob.vlocity_cmt__SubClassId__c = prodList[i].Id;
                ob.vlocity_cmt__ObjectClassId__c = obclsid;
                ob.vlocity_cmt__ObjectType__c = 'Product2';

                ofattrib.add(ob);

                attr.vlocity_cmt__AttributeCategoryId__c = catid;
                attr.vlocity_cmt__AttributeId__c = attribList[j].Id;
                attr.Name = prodList[i].Name;
                attr.vlocity_cmt__ObjectId__c = prodList[i].Id;
                attr.vlocity_cmt__AttributeDisplaySequence__c = ''+(j+1);
                attr.vlocity_cmt__AttributeDisplayNameOverride__c = attribList[j].Name;
                attr.vlocity_cmt__Value__c = attribList[j].vlocity_cmt__Value__c;
                attr.vlocity_cmt__DisplaySequence__c = 'null';
                attr.vlocity_cmt__ValueDataType__c = attribList[j].vlocity_cmt__ValueType__c;
                attr.vlocity_cmt__ObjectType__c = 'Product2';
                attr.vlocity_cmt__PicklistId__c = attribList[j].vlocity_cmt__PicklistId__c;

                attrAssign.add(attr);
            }
            
        }
        Insert ofattrib;
        Insert attrAssign;
    }
}