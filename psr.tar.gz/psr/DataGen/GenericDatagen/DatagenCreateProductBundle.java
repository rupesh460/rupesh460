/*
/services/apexrest/v3/createproductbundle/*
*
* Author:: Krishnan Iyer
* 
*
* Usage 1: Product Bundle: Create a product bundle with a specified number of root products having
*          one child product at each level of the specified depth. 
*
* Usage 2: Simple Products: Create simple products by setting Depth as 1.
*
*
* NOTE: - The count of 'Depth' includes the Root product level. Setting 'depth' as 0 will not create
*         any products.
*
*       - Can be run any number of times consecutively to create a large volume of products/ product 
*         bundles.
*       
*       - In both cases Pricelist entries are automatically created. Ensure Pricing elements are
*         populated before running this.
*       
* Input Required: Pricelist Id, Product names (Enter rootProdName in case of simple products)
*/

@RestResource(urlMapping = '/v3/createproductbundle/*')
global class DatagenCreateProductBundle 
{
    public static List<Product2> prodList = new List<Product2>();
    public static final String priceListId = 'a3T5w000000ANmFEAW'; //Replace with Id from table PriceList__c

    @HttpGet
    global static void createProductBundle() 
    {

        String rootProdName = 'RootProduct_0'; //Replace with intended Root Product Name or Simple Product Name
        String childName = 'LevelNProduct_0'; //Replace with intended Child Product Name
        createProductBundle(rootProdName,childName,5,2); //Name, Depth, Number of Root Products only
    }
     
    private static void createProductBundle(String rootProdName, String childName, Integer depth, Integer noOfRootProducts)
    {
        Integer totalProducts = depth * noOfRootProducts;
        Integer childProducts = totalProducts - noOfRootProducts;
        String ri = rootProdName.substring(0,rootProdName.length()-3)+'%';
        String ci = childName.substring(0,childName.length()-3)+'%';
        //system.debug('riQuery: '+ri);
        //system.debug('ciQuery: '+ci);
        Integer rootIndex = Database.countQuery('SELECT count() FROM Product2 WHERE Name LIKE :ri');
        Integer childIndex = Database.countQuery('SELECT count() FROM Product2 WHERE Name LIKE :ci');
        Integer childCount = 0;

        for(Integer i=rootIndex; i<totalProducts+rootIndex; i++)
        {
            Product2 prod = new Product2(Name = rootProdName+(i+1),
                                            ProductCode = rootProdName+(i+1),
                                            Description = rootProdName+(i+1),
                                            vlocity_cmt__Status__c = 'Active',
                                            vlocity_cmt__IsOrderable__c = true,
                                            vlocity_cmt__SpecificationType__c = 'Product',
                                            vlocity_cmt__EffectiveDate__c = Date.today(),
                                            IsActive = true);
            prodList.add(prod);
        }
        insert prodList;

        for(Integer i=noOfRootProducts; i<totalProducts; i++)
        {
           /* Integer ci = [SELECT count() FROM Product2 WHERE Name LIKE 'LevelNProduct_%'];
            if(ci<=9)
            {
                childName = 'LevelNProduct_00';
            }
            else if(ci>9 && ci<=99)
            {
                childName = 'LevelNProduct_0';
            }*/

            prodList[i].vlocity_cmt__IsOrderable__c = false;
            prodList[i].Name = childName+(i-noOfRootProducts+childIndex+1);
            prodList[i].Description = childName+(i-noOfRootProducts+childIndex+1);
            prodList[i].ProductCode = childName+(i-noOfRootProducts+childIndex+1);
        }
        update prodList;

        List<vlocity_cmt__ProductChildItem__c> childList = new List<vlocity_cmt__ProductChildItem__c>();
        
        for(Integer x=0; x<noOfRootProducts; x++)
        {
            for(Integer z=1; z<depth; z++)
            {
                      vlocity_cmt__ProductChildItem__c ch = new vlocity_cmt__ProductChildItem__c();

                      ch.Name = prodList[z-1+noOfRootProducts].Name;
                      ch.vlocity_cmt__ChildLineNumber__c = '000'+z;
                      ch.vlocity_cmt__ChildProductId__c = prodList[z-1+noOfRootProducts+childCount].Id;
                      ch.vlocity_cmt__Quantity__c = 1.00;
                      ch.vlocity_cmt__MaxQuantity__c = 3.00;
                      ch.vlocity_cmt__MinQuantity__c = 0.00;
                      if(z==1)
                      {
                        ch.vlocity_cmt__ParentProductId__c = prodList[x].Id;
                      }
                      else
                      {
                        ch.vlocity_cmt__ParentProductId__c = prodList[z-2+noOfRootProducts+childCount].Id;
                      }

                      childList.add(ch);
            }
            childCount=childCount+depth-1;
        }
        insert childList;

    createPLEs(totalProducts, priceListId); //Creates Pricelist entries for all products
    }

    private static void createPLEs(Integer totalProducts, String pLId)
    {

        List<vlocity_cmt__PriceListEntry__c> pleList = new List<vlocity_cmt__PriceListEntry__c>();
        List<vlocity_cmt__PricingElement__c> peList =Database.query('SELECT Id, Name FROM vlocity_cmt__PricingElement__c WHERE vlocity_cmt__PriceListId__c = :pLId ORDER BY Name LIMIT 500');

        if(peList.size()<totalProducts)
        {
            for(Integer i=0;i<peList.size();i++)
            {

                vlocity_cmt__PriceListEntry__c ple1 = new vlocity_cmt__PriceListEntry__c();

                ple1.Name = prodList[i].Name + '-PLE';
                ple1.vlocity_cmt__DisplayText__c = peList[i].Name;
                ple1.vlocity_cmt__IsActive__c = true;
                ple1.vlocity_cmt__IsBasePrice__c = true;
                ple1.vlocity_cmt__EffectiveFromDate__c = Date.today();
                ple1.vlocity_cmt__EffectiveUntilDate__c = Date.today().addYears(10);
                ple1.vlocity_cmt__IsOverride__c = false;
                ple1.vlocity_cmt__PriceListId__c = pLId;
                ple1.vlocity_cmt__PricingElementId__c = peList[i].Id;
                ple1.vlocity_cmt__BasePriceListId__c = pLId;
                ple1.vlocity_cmt__ProductId__c = prodList[i].Id;

                pleList.add(ple1);
            }
            
            for(Integer i=peList.size();i<totalProducts;i++)
            {

                vlocity_cmt__PriceListEntry__c ple2 = new vlocity_cmt__PriceListEntry__c();

                ple2.Name = prodList[i].Name + '-PLE';
                ple2.vlocity_cmt__DisplayText__c = peList[1].Name;
                ple2.vlocity_cmt__IsActive__c = true;
                ple2.vlocity_cmt__IsBasePrice__c = true;
                ple2.vlocity_cmt__EffectiveFromDate__c = Date.today();
                ple2.vlocity_cmt__EffectiveUntilDate__c = Date.today().addYears(10);
                ple2.vlocity_cmt__IsOverride__c = false;
                ple2.vlocity_cmt__PriceListId__c = pLId;
                ple2.vlocity_cmt__PricingElementId__c = peList[1].Id;
                ple2.vlocity_cmt__BasePriceListId__c = pLId;
                ple2.vlocity_cmt__ProductId__c = prodList[i].Id;

                pleList.add(ple2);
            }

            insert pleList;
        }

        else if(peList.size()>=totalProducts)
        {
            for(Integer i=0;i<totalProducts;i++)
            {

                vlocity_cmt__PriceListEntry__c ple1 = new vlocity_cmt__PriceListEntry__c();

                ple1.Name = prodList[i].Name + '-PLE';
                ple1.vlocity_cmt__DisplayText__c = peList[i].Name;
                ple1.vlocity_cmt__IsActive__c = true;
                ple1.vlocity_cmt__IsBasePrice__c = true;
                ple1.vlocity_cmt__EffectiveFromDate__c = Date.today();
                ple1.vlocity_cmt__EffectiveUntilDate__c = Date.today().addYears(10);
                ple1.vlocity_cmt__IsOverride__c = false;
                ple1.vlocity_cmt__PriceListId__c = pLId;
                ple1.vlocity_cmt__PricingElementId__c = peList[i].Id;
                ple1.vlocity_cmt__BasePriceListId__c = pLId;
                ple1.vlocity_cmt__ProductId__c = prodList[i].Id;

                pleList.add(ple1);
            }
            insert pleList;
        }    
    }
}