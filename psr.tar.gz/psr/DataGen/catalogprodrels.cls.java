

  
List<CatalogProductRelationship__c> catProdRels = new List<CatalogProductRelationship__c>();

List<Product2> prodListBnd = [SELECT Id,Name FROM Product2 WHERE Name LIKE '%Bnd-____0' LIMIT 50];
for(Integer i=0;i<prodListBnd.size();i++)
{

    CatalogProductRelationship__c catProdRel = new CatalogProductRelationship__c(Name = prodListBnd[i].Name,
            CatalogId__c = 'a0JL00000043Qlx', Product2Id__c = prodListBnd[i].Id);
    catProdRels.add(catProdRel);
}
insert catProdRels;

List<Product2> prodListStd = [SELECT Id,Name FROM Product2 WHERE Name LIKE '%eCom-Prod-Std%' LIMIT 100];
for(Integer i=0;i<prodListStd.size();i++)
{

    CatalogProductRelationship__c catProdRel = new CatalogProductRelationship__c(Name = prodListStd[i].Name,
            CatalogId__c = 'a0JL00000043Qlx', Product2Id__c = prodListStd[i].Id);
    catProdRels.add(catProdRel);
}
insert catProdRels;

List<Promotion__c> promoList = [SELECT Id,Name FROM Promotion__c WHERE Name LIKE '%eCom-Promo%' LIMIT 20];  
for(Integer i=0;i<promoList.size();i++)
{

    CatalogProductRelationship__c catPromoRel = new CatalogProductRelationship__c(Name = promoList[i].Name,
            CatalogId__c = 'a0JL00000043Qlx', PromotionId__c = promoList[i].Id);
    catProdRels.add(catPromoRel);    
}
insert catProdRels;